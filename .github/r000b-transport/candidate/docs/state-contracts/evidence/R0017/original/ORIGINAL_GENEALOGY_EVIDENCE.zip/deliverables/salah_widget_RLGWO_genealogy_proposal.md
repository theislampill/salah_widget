# salah_widget — RLGWO genealogy and intended-work proposal

**Status: rough owner-review glosses only. Nothing filed, commented on, reopened, numbered, implemented or published.**

This is preparation for your substantial RLGWO specifications, which can run 80–300 KB in your workflow. It is not a set of complete work orders or a substitute for their evidence, acceptance, genealogy and closure material. Length is not a quality quota.

Application: `f71fef6ccf7e4efcb57b5a26688d2360461a3253` (unchanged from the audit). Methodology: `IMPLEMENTAUDIT.md@e78f7cb21af4197d490f10bc95917a4c75f748aa`.

## Decision summary

**Recommend amendments to seven closed owners, additions to two already-open owners, and two new unnumbered candidates.** Reopening for an approved extension is different from declaring a historical completion certificate invalid. R000B has the clearest direct counterexample to an existing promise. R0021 needs a narrowly bounded resource-lifecycle follow-up; the remaining five closed owners would gain explicit new scope.

The live census contains **37 RLGWOs: 34 closed and three open—R0013/#19, R0015/#21 and R0016/#22.** Draft PRs #38/#43 are not open RLGWO issues or fresh substantive owners. Original issue bodies were screened; relevant amendments and closure records were inspected. Historical evidence was not universally requalified.

## Cheap loose ends completed

All **97 payload files** in the recovered original evidence archive matched its manifest. The new bounded checks contain **17 observations**, not 17 product acceptance passes.

| Check | Result | Boundary |
|---|---|---|
| Shared geocoder, 9 observations | Out-of-range and nonfinite coordinates are returned as candidates; a healthy-shaped HTTP 503 body is accepted; transport failure and no matches both become `[]`. Healthy/zero-axis/NaN controls discriminate. | Exact source functions with controlled responses/timers; no browser or live-provider claim. An abort-ignorant body remaining unsettled is conditional, not a demonstrated native outage. |
| Regression runner, 4 observations | A true 1-second interval is reported as 102 or 95 seconds in JSON paths because parsing overwrites the timing origin. TAP timing and nonzero-exit failure controls remain correct. | Whole source file matches its Git blob. Subprocess execution was stubbed; no product test suites ran. |
| Firefox metadata parser, 4 observations | Malformed JSON and valid empty metadata produce the same success/absence output. Known legacy/current extension positives still work. | Exact embedded Python excerpt only, private fixture files; no installer entry or PowerShell run. |

No new heavy smokes, full offline build, browser/pixel campaign, Windows native qualification or C-to-WASM equivalence proof was attempted. The original 221 non-byte-qualified manifest entries remain unqualified; this follow-up does not silently turn them green.

## A. Closed owners proposed for amendment and reopening

### R000B / #11 — Withdraw expired weather influence even when the prayer model is unavailable

**Disposition:** Corrective reopening: current source counterexample to an existing per-use expiry obligation.

**Intent:** Ensure weather authority withdrawal reaches cloud coverage and every affected consumer independently of prayer-model availability. Preserve the distinction between unknown weather and measured clear sky, and preserve established cloud motion/population.

**GDOPL benefit:** Restore a cross-owner invariant: an unavailable timetable must not preserve expired weather authority.

**Comment/amendment gloss:** Append NF02, exact current source and prior source-level witness; identify the missing no-prayer-model expiry branch. Amend the existing consumer-withdrawal acceptance surface, without rewriting the old certificate.

**Evidence boundary:** Underlying state and painter-call behavior is reproduced; no new browser-pixel evidence. Historical accepted expiry cases remain valid in their scopes.

**Findings:** NF02. **Related:** [R0005 / #5](https://github.com/theislampill/salah_widget/issues/5), [R000D / #13](https://github.com/theislampill/salah_widget/issues/13), [R0024 / #36](https://github.com/theislampill/salah_widget/issues/36), [R0025 / #37](https://github.com/theislampill/salah_widget/issues/37).

**References:** [Owner/closure](https://github.com/theislampill/salah_widget/issues/11) · [Owner/closure](https://github.com/theislampill/salah_widget/issues/11#issuecomment-6178186713) · [Pinned source](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/index.html#L3024-L3042) · [Pinned source](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/index.html#L3247-L3262)

### R0021 / #33 — Make renderer construction, replacement and cleanup instance-owned

**Disposition:** Narrow lifecycle follow-up under the existing renderer owner; constructor failure is established, full Moon-wrapper replacement is conditional.

**Intent:** Clean up resources acquired before a constructor fails, and bind disposal to the retiring instance rather than whichever instance is currently global. Establish the supported replacement boundary; do not invent a universal hot-reload feature.

**GDOPL benefit:** Prevent failed or retiring components from leaving resources behind or destroying a healthy successor.

**Comment/amendment gloss:** Append RF02 and conditional RF01, map to S5/S6/TA3 resource ownership, preserve prior scoped acceptance, and specify a bounded constructor/replacement increment. RF04 remains an investigation note, not a proved failure.

**Evidence boundary:** Controlled construction/replacement probes, not an observed ordinary Moon outage or measured heap leak. Preserve approved S1, TA1–TA5 and performance exceptions; do not restart completed native campaigns.

**Findings:** RF01, RF02. **Related:** [R0003 / #3](https://github.com/theislampill/salah_widget/issues/3), [R0017 / #23](https://github.com/theislampill/salah_widget/issues/23).

**References:** [Owner/closure](https://github.com/theislampill/salah_widget/issues/33#issuecomment-6326407465) · [Pinned source](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/real-sky/native-host.mjs#L60-L69) · [Pinned source](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/moon/src/moon-native.mjs#L1-L13) · [Pinned source](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/moon/src/moon-native.mjs#L239-L280)

### R0007 / #7 — Define date-aware next-event selection across adjacent admitted timetables

**Disposition:** Explicit scope extension, not invalidation of the previous DST/countdown repair.

**Intent:** Reconcile prayer-day versus civil-day semantics and choose the correct next admitted event across the day boundary, including supported nonstandard ordering. Keep the selected name, clock, target date and countdown epoch consistent; preserve DST, missing-data and tie policies.

**GDOPL benefit:** Eliminate the seam between same-day chronological selection and the hard-coded next-day Fajr assumption.

**Comment/amendment gloss:** Append NF01 and explain the approved-contract distinction. Propose a separately identified chronological-selection increment while preserving the completed DST acceptance rows.

**Evidence boundary:** The prior contract deliberately retained event-selection order and tomorrow’s Fajr. The 269-minute controlled discrepancy motivates a new selection requirement; it does not demonstrate the old zoned-duration conversion failed.

**Findings:** NF01. **Related:** [R0002 / #2](https://github.com/theislampill/salah_widget/issues/2), [R0005 / #5](https://github.com/theislampill/salah_widget/issues/5), [R0008 / #8](https://github.com/theislampill/salah_widget/issues/8).

**References:** [Owner/closure](https://github.com/theislampill/salah_widget/issues/7) · [Owner/closure](https://github.com/theislampill/salah_widget/issues/7#issuecomment-6162239043) · [Pinned source](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/index.html#L2219-L2252)

### R000D / #13 — Separate weather/radar retry elapsed time from source and receipt UTC

**Disposition:** Explicit retry-clock extension; existing monotonic attempt deadlines are not being replaced.

**Intent:** Maintain weather/radar retry opportunities across wall-clock corrections while preserving their cooldowns, attempt ownership, normal poll opportunities and truthful source/receipt timestamps.

**GDOPL benefit:** Make safety and recovery compatible: correctly rejecting future-dated evidence must not strand replacement acquisition.

**Comment/amendment gloss:** Append XF02, retain D01–D06 and other satisfied rows, and extend D07’s retry contract with backward/forward clock-discontinuity cases and healthy elapsed-time controls.

**Evidence boundary:** Existing deadlines already use elapsed time. The added obligation concerns wall-based cooldowns; 19 prior controlled observations exist, not a measured live one-hour outage.

**Findings:** XF02. **Related:** [R0006 / #6](https://github.com/theislampill/salah_widget/issues/6), [R000B / #11](https://github.com/theislampill/salah_widget/issues/11), [R0020 / #32](https://github.com/theislampill/salah_widget/issues/32).

**References:** [Owner/closure](https://github.com/theislampill/salah_widget/issues/13#issuecomment-6183596140) · [Pinned source](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/index.html#L1368-L1378) · [Pinned source](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/index.html#L1445-L1451) · [Pinned source](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/index.html#L3636-L3644)

### R0003 / #3 — Invalidate only the runtime owners affected by a configuration change

**Disposition:** Optimization extension to the existing runtime-generation/async ownership contract.

**Intent:** Introduce a small semantic effect matrix. Display-only label/time/date-format edits should update affected presentation without discarding valid prayer/weather/sky work. Real target, calculation, units and timezone changes must still invalidate every affected owner.

**GDOPL benefit:** Reduce avoidable requests, recomputation and interruption without weakening stale-result rejection.

**Comment/amendment gloss:** Append XF01 as a new semantic-delta increment, not a failure of the earlier ABA repair. Recheck the specific ownership proofs whose assumptions change under narrower invalidation.

**Evidence boundary:** Excessive reset selection is source-reproduced; user-visible latency, flicker and network savings are not measured. Preserve ABA, captured cache keys, provider-adopted timezone and original location-fix time.

**Findings:** XF01. **Related:** [R0007 / #7](https://github.com/theislampill/salah_widget/issues/7), [R000F / #15](https://github.com/theislampill/salah_widget/issues/15), [R0010 / #16](https://github.com/theislampill/salah_widget/issues/16), [R0023 / #35](https://github.com/theislampill/salah_widget/issues/35).

**References:** [Owner/closure](https://github.com/theislampill/salah_widget/issues/3#issuecomment-6182373378) · [Pinned source](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/index.html#L3484-L3527)

### R000F / #15 — Separate draft edits from committed preview identity

**Disposition:** Preview-efficiency extension; the accepted latest-location-intent contract remains intact.

**Intent:** Deduplicate equivalent input/change refreshes using the actual generated configuration identity. Keep draft state, exported configuration and active iframe distinct; preserve deliberate reload behavior and latest-intent guards.

**GDOPL benefit:** Avoid restarting an unchanged widget and paying its initialization/resource costs twice.

**Comment/amendment gloss:** Append CF05 and add a bounded preview-publication/idempotence increment. Retain all accepted form intent, close/reopen, candidate cycling and async-error protections.

**Evidence boundary:** The actual audit witness is an unchanged input/change pair yielding two iframe assignments, not a separately tested Preview-button workflow. No native performance saving is claimed.

**Findings:** CF05. **Related:** [R0003 / #3](https://github.com/theislampill/salah_widget/issues/3), [R0010 / #16](https://github.com/theislampill/salah_widget/issues/16), [R0012 / #18](https://github.com/theislampill/salah_widget/issues/18), [R001A / #26](https://github.com/theislampill/salah_widget/issues/26).

**References:** [Owner/closure](https://github.com/theislampill/salah_widget/issues/15#issuecomment-6073051895) · [Pinned source](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/builder.html#L212-L254)

### R0017 / #23 — Bind applicable regression instruments and timing receipts to the current runtime

**Disposition:** Explicit evaluator-family extension, not proof that the closed smoke campaign was falsely passed.

**Intent:** Correct the runner’s timing-variable collision; reconcile current-source extraction/bootstrap adapters and required historical inputs without weakening assertions or reporting missing checks as passes. Distinguish real product failures, unavailable evidence, superseded predicates and harness failures.

**GDOPL benefit:** Make future acceptance decisions trustworthy and avoid spending engineering time on misclassified red/green signals.

**Comment/amendment gloss:** Append EF01 and the fresh timing witness; explicitly extend the instrument scope beyond the original smoke page. Preserve historical failures and the previous source-bound smoke certificate.

**Evidence boundary:** Four fresh runner observations used stub subprocess output, not actual suites. JSON paths corrupt reported elapsed seconds; a nonzero exit still produces FAIL. Original native smoke acceptance is separate.

**Findings:** EF01. **Related:** [R0003 / #3](https://github.com/theislampill/salah_widget/issues/3), [R0007 / #7](https://github.com/theislampill/salah_widget/issues/7), [R000B / #11](https://github.com/theislampill/salah_widget/issues/11), [R000D / #13](https://github.com/theislampill/salah_widget/issues/13), [R0021 / #33](https://github.com/theislampill/salah_widget/issues/33).

**References:** [Owner/closure](https://github.com/theislampill/salah_widget/issues/23#issuecomment-6181220586) · [Pinned source](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/tools/cp9/run_native_regressions.py#L24-L41)

## Already-open owners: extend rather than reopen

### R0015 / #21 — Add an explicit PowerShell staged-artifact transaction slice

**Disposition:** Amend an already-open owner; PowerShell was outside the original Bash witness and requires explicit scope approval.

**Intent:** Keep partial downloads out of the reusable success cache, validate candidate content before handoff, extract into new owned staging without deleting a usable predecessor, and withhold malformed presets from manual-import success paths.

**Why reuse it:** Under a fully proposed extension, R0015 can own staged-write admission and retained artifact lifetime on both platforms. A different interpreter alone is not a new invariant. If the owner keeps this charter strictly Bash-only, revisit the route rather than silently expanding it.

**Benefit:** Make artifact readiness and lifetime truthful across failure, retry and replacement, while preserving recoverable user-facing bundles.

**Boundary:** These PowerShell paths are source-confirmed, not freshly qualified on Windows 5.1/7. Linux/Bash permission evidence proves no Windows ACL/reparse property. Existing installer residuals remain separate.

**Findings:** CF01, CF02, CF03. **Related:** [R0013 / #19](https://github.com/theislampill/salah_widget/issues/19), [R0014 / #20](https://github.com/theislampill/salah_widget/issues/20), [R0016 / #22](https://github.com/theislampill/salah_widget/issues/22).

**References:** [Source/owner](https://github.com/theislampill/salah_widget/issues/21) · [Source/owner](https://github.com/theislampill/salah_widget/issues/21#issuecomment-6074575663) · [Source/owner](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/install.ps1#L345-L409)

### R0013 / #19 — Preserve unknown Firefox discovery status through target selection

**Disposition:** Amend an already-open discovery/target-selection owner; explicitly include the corresponding PowerShell consumer.

**Intent:** Distinguish unreadable/malformed metadata from verified absence and known legacy/current extension state. Carry that distinction into target eligibility, warnings and manual handoff without treating unknown as permission.

**Why reuse it:** A complete extension of R0013’s target discovery/selection contract is sufficient. Creating a new issue solely because the same uncertainty reaches PowerShell would needlessly split a shared discovery invariant.

**Benefit:** Prevent downstream installer actions from treating missing knowledge as a verified safe target.

**Boundary:** Four fresh executions of the exact embedded Python parser show malformed and valid-empty metadata return identical absence flags; positive old/new controls work. No installer entry or PowerShell execution occurred.

**Findings:** CF10. **Related:** [R0014 / #20](https://github.com/theislampill/salah_widget/issues/20), [R0015 / #21](https://github.com/theislampill/salah_widget/issues/21), [R0016 / #22](https://github.com/theislampill/salah_widget/issues/22).

**References:** [Source/owner](https://github.com/theislampill/salah_widget/issues/19) · [Source/owner](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/install.sh#L273-L321) · [Source/owner](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/install.ps1#L231-L267)

## B. New unnumbered RLGWO candidates

These are packet-local proposal keys, not allocated Rockstar identities. Publication, identity reservation and full specification authoring remain unapproved.

### NEW-LOCATION-ADMISSION — Admit external location data and expose acquisition outcomes truthfully

**Intent:** Validate coarse and forward-geocoder responses before normalization or candidate publication. Reject invalid coordinates and inappropriate HTTP results, preserve legitimate zero coordinates, distinguish no matches from transport/admission failure, and preserve useful fallback and owned feedback.

**Why a new owner:** R001E addresses valid zero-axis dispatch and preserves normalization; R001F addresses bounded coarse-request completion; R000F addresses latest intent; R0023 addresses provenance. None owns the new shared provider-validity/outcome boundary. Broadening one of these would add that distinct accepting responsibility, so a separate candidate is clearer.

**GDOPL benefit:** Keep untrusted provider output from acquiring valid-location authority and make failed acquisition diagnosable.

**Boundary:** Prior coarse clamping witness plus nine fresh shared-geocoder observations. The new witness proves returned candidates, not full native selection. Abort-ignorant body liveness is conditional and not promoted to a real outage. Do not change all hash/manual normalization by association.

**Findings:** CF04, CF06. **Related:** [R000F / #15](https://github.com/theislampill/salah_widget/issues/15), [R001E / #30](https://github.com/theislampill/salah_widget/issues/30), [R001F / #31](https://github.com/theislampill/salah_widget/issues/31), [R0023 / #35](https://github.com/theislampill/salah_widget/issues/35).

**References:** [Source/owner](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/config.js#L248-L268) · [Source/owner](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/config.js#L332-L385) · [Source/owner](https://github.com/theislampill/salah_widget/issues/30) · [Source/owner](https://github.com/theislampill/salah_widget/issues/31) · [Source/owner](https://github.com/theislampill/salah_widget/issues/15)

### NEW-SPECTRAL-CACHE — Bound exact fitted-spectrum retention under continuously changing twilight inputs

**Intent:** Establish an authorized canonical-source route, then bound fitted-spectrum cache retention without changing spectral arithmetic, silently quantizing colors or patching generated copies. Demonstrate exact recomputation/equivalence and state bounds; evaluate CPU tradeoffs separately.

**Why a new owner:** R0021’s accepted resource cells concern host instances, jobs and decoders. A complete spectral-cache extension would add a separate scientific-code owner and exact-output acceptance surface; a distinct cache obligation avoids confusing those certificates.

**GDOPL benefit:** Prevent an optimization from accumulating unbounded retained state while protecting scientific output and responsiveness.

**Boundary:** Existing source probes establish unbounded retained fits and current twilight callers. No production heap trajectory, battery saving or benchmark improvement is measured. Immutable vendor/copied core ownership is a real implementation constraint.

**Findings:** RF03. **Related:** [R0017 / #23](https://github.com/theislampill/salah_widget/issues/23), [R0021 / #33](https://github.com/theislampill/salah_widget/issues/33).

**References:** [Source/owner](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/real-sky/core/src/spectral.mjs#L9-L41) · [Source/owner](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/real-sky/core/src/sky-background.mjs#L72-L82) · [Source/owner](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/real-sky/native-preview.mjs#L332-L340) · [Source/owner](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/AGENTS.md)

## Not converted into repair-ready RLGWOs

**Frozen V1 — CF07, CF08, CF09:** retain the missing async fences, false reset-success and header-only timeout findings under a legacy support-policy decision. Current-root repairs deliberately preserved V1. Do not reopen R0003, R000F, R0011 or R001F merely because their frozen predecessor behaves differently. A maintained V1 variant would need explicit owner authorization and a separate approved boundary.

**NH01, NH02, RF04:** retain the fit-cache geometry, uncaught-callback recovery and frozen-scene decode-settlement hypotheses as unverified. Their first missing discriminators are recorded in the JSON. A fabricated throw or never-resolving test double cannot, by itself, establish an ordinary product incident.

**R37 and R26:** the previously missed C/WASM resource owner is now catalogued; a catalogue omission is not a demonstrated kernel defect. R26’s error recovery was narrowed to the delivered sticky-failure/worker-retirement route; arbitrary reuse after failure is not claimed. Neither requires an invented repair order.

**Old acceptance exceptions:** R0021’s expressly approved startup/cost evidence limits remain approved and scoped. This planning exercise neither revokes them nor treats our lack of fresh native testing as a defect. The earlier solar-strobe report remains unproved, not newly certified fixed or newly proven here.

## C. Integration and GDOPL intent

The project-level improvement is clearer responsibility at the joins: which input changes which owner, which results are eligible, when their influence must be withdrawn, how replacement remains possible, and which instance must clean up. Use a compact effect/constraint matrix as a supporting artifact. Do not create an “explicit-state-machine rewrite” RLGWO or mandate a framework for all 83 machines.

For practical ordering, first repair only the evaluation adapters needed by the selected correction. Address the weather-withdrawal and prayer-selection semantics, then retry-clock recovery. Display/preview idempotence can follow without relaxing request ownership. Installer work can be prepared independently but must use one writer for overlapping script hunks. Renderer lifecycle and spectral retention have separate acceptance surfaces and should not reopen all celestial startup qualification.

Native prayer/weather/config changes share `src/native/index.html`; integrate and qualify affected cumulative changes serially. Location-admission and builder work share config/form consumers; keep validity, edit intent and preview identity separate. Installer additions consume R0016’s dry-run boundary and R0014’s PowerShell launch compatibility. Cross-references are not automatic whole-issue prerequisites.

Before any later filing, re-read current issue states, bodies/amendments, relevant certificates and the target source; bind the new comments/specification revisions and renew owner approval for the actual publication set. Append new evidence and versioned increments; do not rewrite old completion evidence or invent adoption/acceptance authority.

## Method and remaining limits

The routing follows [IMPLEMENTAUDIT’s existing-owner versus distinct-work-order comparison](https://github.com/theislampill/IMPLEMENTAUDIT.md/blob/e78f7cb21af4197d490f10bc95917a4c75f748aa/skills/implementaudit/references/issue-ready-work-orders.md): prefer a sufficient explicit extension, preserve different mechanisms and accepting boundaries, and do not allocate identities from a local draft.

All prioritization is qualitative. No measured project gradient, global optimum, speedup, battery saving, full-platform certification or fresh independent-agent review is claimed. The new checks and same-assistant routing review are separate from independent reviewers retained in the original audit and historical GitHub certificates.
