"""Run the original runner with a stub subprocess, never a product test suite."""
from pathlib import Path
import json,hashlib,importlib.util,types,tempfile
from unittest.mock import patch
HERE=Path(__file__).resolve().parent
source=HERE/'run_native_regressions.py';b=source.read_bytes()
blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
assert blob=='58acb195c0dc80c1683393e991c66207e097994c',(blob,'source copy does not match pinned Git blob')
spec=importlib.util.spec_from_file_location('original_runner',source);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
rows=[]
inputs=[('tap-positive','# tests 1\n# pass 1\n# fail 0\n',0,1),('json-leading','{"results":[{"status":"PASS"}]}\n',0,102),('json-prefixed','prefix\n{"results":[{"status":"PASS"}]}\n',0,95),('tap-failure','# tests 1\n# pass 0\n# fail 1\n',1,1)]
for name,output,code,observed in inputs:
 def fake_run(cmd,*,cwd,stdout,stderr,timeout):
  stdout.write(output);return types.SimpleNamespace(returncode=code)
 with tempfile.TemporaryDirectory() as t,patch.object(m,'NAMED',[]),patch.object(m.subprocess,'run',fake_run),patch.object(m.time,'monotonic',side_effect=[100.0,101.0]):
  r=m.run(Path(t),HERE/('runner-'+name));cmd=r['commands'][0]
 assert cmd['seconds']==observed
 assert r['status']==('PASS' if code==0 else 'FAIL')
 rows.append({'case':name,'clockStart':100,'clockEnd':101,'trueElapsedSeconds':1,'recordedSeconds':cmd['seconds'],'exitCode':code,'aggregateStatus':r['status'],'counts':cmd['counts']})
report={'schema':'salah-genealogy-cheap-runner-probe/v1','status':'PASS_OBSERVATIONS_NOT_PRODUCT_ACCEPTANCE','source':{'path':'tools/cp9/run_native_regressions.py','commit':'f71fef6ccf7e4efcb57b5a26688d2360461a3253','gitBlob':blob,'fullSourceGitBlobVerified':True},'cases':rows,'interpretation':'JSON parsing overwrites timer origin with a text offset. TAP timing and nonzero-exit aggregate failure controls remain correct. This proves timing-metadata corruption, not all test verdicts being false.','actualSuitesLaunched':0,'networkCalls':0}
(HERE/'runner-probe-results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
