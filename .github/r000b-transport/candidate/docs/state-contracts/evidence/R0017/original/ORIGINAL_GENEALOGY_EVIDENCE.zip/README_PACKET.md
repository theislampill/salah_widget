# Salah widget RLGWO genealogy proposal — read-only packet

Start with `deliverables/salah_widget_RLGWO_genealogy_proposal.md`.
`deliverables/salah_widget_RLGWO_genealogy_proposal.json` contains the routing ledger, 37-issue census, limitations and integration groups.
`ROUTING_REVIEW.md` records the same-assistant final challenge pass.
`READBACK_SUMMARY.json` records the live-reference/census summaries and original archive verification; it is not a complete raw GitHub-response export.

`prior/salah_widget_state_machine_evidence.zip` is the unchanged original evidence archive. Its 97 payload files were independently rehashed by this follow-up process; no application checkout is included. Unpack it only into a separate directory.

The new `probes/` files contain three narrow original-source investigations and their raw outputs. Observation checks can be rerun from that directory with:

    node geocoder-probe.cjs
    python runner_probe.py
    python firefox_status_probe.py

These commands exercise fixture data only. The runner probe replaces subprocess execution and launches no product test suite. No native browser, PowerShell, installer entry, live provider or scientific build qualification is claimed.

No application source, GitHub issue/comment/state, branch or PR was changed. New work-order keys are local proposal aliases, not allocated RLGWO identities. The proposals are incomplete as execution specifications by design: this is the requested rough genealogy and intended-outcome stage, not full RLGWO authoring.

`MANIFEST.json` binds every other file included in this packet. It excludes itself to avoid self-reference.
