'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert/strict'),crypto=require('crypto');
const path=require('path');const source=fs.readFileSync(path.join(__dirname,'geocoder-excerpt.js'),'utf8');
const cases=[];
function realm(fetch){let timer;let cleared=false;let requests=[];let signal;
 const context=vm.createContext({AbortController,fetch:(url,init)=>{requests.push(url);signal=init.signal;return fetch(url,init);},
 setTimeout:fn=>{timer=fn;return 1;},clearTimeout:()=>{cleared=true;}});
 vm.runInContext(source+'\nthis.search=geocodeSearch;',context);
 return {search:context.search,fire:()=>timer(),get signal(){return signal;},get cleared(){return cleared;},requests};}
const row=(lat='51.5',lon='-0.12')=>({class:'place',name:'Fixture',lat,lon,address:{country_code:'gb'}});
const response=(body,ok=true)=>Promise.resolve({ok,status:ok?200:503,json:()=>Promise.resolve(body)});
(async()=>{
 let r=realm(()=>response([row()]));let v=await r.search('London');assert.equal(v.length,1);assert.equal(v[0].lat,51.5);assert.ok(r.cleared);cases.push({id:'healthy',count:v.length,latitude:v[0].lat,timerCleared:r.cleared});
 r=realm(()=>response([]));let empty=await r.search('London');assert.equal(empty.length,0);cases.push({id:'valid-no-match',result:empty});
 r=realm(()=>Promise.reject(Error('controlled transport failure')));let failure=await r.search('London');assert.equal(failure.length,0);assert.equal(JSON.stringify(failure),JSON.stringify(empty));cases.push({id:'transport-failure',result:failure,indistinguishableFromNoMatch:true});
 r=realm(()=>response([row('999','999')]));v=await r.search('London');assert.equal(v[0].lat,999);assert.equal(v[0].lon,999);cases.push({id:'out-of-range',candidateReturned:true,lat:v[0].lat,lon:v[0].lon});
 r=realm(()=>response([row('Infinity','Infinity')]));v=await r.search('London');assert.equal(v[0].lat,Infinity);assert.equal(v[0].lon,Infinity);cases.push({id:'nonfinite',candidateReturned:true,lat:'Infinity',lon:'Infinity'});
 r=realm(()=>response([row()],false));v=await r.search('London');assert.equal(v.length,1);cases.push({id:'http503-healthy-shaped-body',candidateReturned:true,status:503});
 r=realm(()=>response([row('not-a-number','0')]));v=await r.search('London');assert.equal(v.length,0);cases.push({id:'nan-control',candidateRejected:true});
 r=realm(()=>response([row('0','0')]));v=await r.search('London');assert.equal(v[0].lat,0);assert.equal(v[0].lon,0);cases.push({id:'zero-axis-control',candidateRetained:true});
 r=realm(()=>Promise.resolve({ok:true,json:()=>new Promise(()=>{})}));let settled=false;r.search('London').then(()=>settled=true,()=>settled=true);
 await new Promise(setImmediate);r.fire();await new Promise(setImmediate);assert.equal(r.signal.aborted,true);assert.equal(settled,false);
 cases.push({id:'abort-ignorant-body',abortRequested:true,settled:false,interpretation:'Conditional protocol observation only; no native abort-ignorant response or real outage established.'});
 const out={schema:'salah-genealogy-cheap-geocoder-probe/v1',status:'PASS_OBSERVATIONS_NOT_PRODUCT_ACCEPTANCE',source:{commit:'f71fef6ccf7e4efcb57b5a26688d2360461a3253',path:'src/native/config.js',gitBlob:'a5d42c4d4b3f3988329e7690c32cce81b5d8cf21',acquisition:'Verbatim function excerpt from live GitHub fetch_file; audit-local source only',excerptSha256:crypto.createHash('sha256').update(source).digest('hex')},node:process.version,cases,limits:['Controlled fetch/response/timers; no network or browser','No application files changed','Returned candidates only; full selection/adoption and pixels not executed','Bounding-box helper is not exercised by these inputs']};
 fs.writeFileSync(path.join(__dirname,'geocoder-results.json'),JSON.stringify(out,null,2));console.log(JSON.stringify(out,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
