import json, re, sys
path = sys.argv[1]
has_new = False
has_old = False
matches = []
try:
    data = json.load(open(path, encoding="utf-8"))
except Exception:
    print("0|0|")
    raise SystemExit
for addon in data.get("addons", []):
    parts = []
    for key in ("id", "name"):
        if addon.get(key):
            parts.append(str(addon.get(key)))
    loc = addon.get("defaultLocale") or {}
    if loc.get("name"):
        parts.append(str(loc.get("name")))
    hay = " ".join(parts)
    if re.search(r"\bTablissNG\b|tablissng", hay, re.I):
        has_new = True
        matches.append(hay)
    elif re.search(r"\bTabliss\b", hay, re.I) and not re.search(r"NG|tablissng", hay, re.I):
        has_old = True
        matches.append(hay)
print(("1" if has_new else "0") + "|" + ("1" if has_old else "0") + "|" + "; ".join(matches))
