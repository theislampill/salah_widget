"""Execute only the pinned install.sh Python parser against private fixture files."""
import hashlib,json,subprocess,sys,tempfile
from pathlib import Path
base=Path(__file__).resolve().parent
source=base/'firefox_status_excerpt.py'
cases=[('valid-empty','{"addons":[]}', '0|0|'),
       ('invalid-json','{"addons":[', '0|0|'),
       ('legacy-positive','{"addons":[{"name":"Tabliss"}]}','0|1|Tabliss'),
       ('new-positive','{"addons":[{"name":"TablissNG"}]}','1|0|TablissNG')]
rows=[]
with tempfile.TemporaryDirectory(prefix='salah-discovery-isolated-') as tmp:
    for label,text,expected in cases:
        p=Path(tmp)/(label+'.json');p.write_text(text)
        r=subprocess.run([sys.executable,str(source),str(p)],capture_output=True,text=True,timeout=3)
        observed=r.stdout.strip()
        assert r.returncode==0 and observed==expected, (label,r.returncode,observed)
        rows.append({'case':label,'input':text,'exitCode':r.returncode,'stdout':observed,'expectedObservation':expected,'matches':True})
receipt={'schema':'salah-genealogy/cheap-firefox-discovery-probe/1','sourceCommit':'f71fef6ccf7e4efcb57b5a26688d2360461a3253','sourcePath':'install.sh','sourceGitBlob':'37fd56626a8634415940994ad9cce2a4aeaba402','sourceSpan':'embedded Python heredoc in firefox_status; function at install.sh:273-321','excerptSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'observation':'Malformed JSON and valid-empty metadata both return success and identical absence flags. Positive old/new detection still works.','cases':rows,'limits':'Exact embedded Python parser excerpt only. No installer entry, browser, real profile, PowerShell, network, or platform qualification. All input files were private fixtures.'}
(base/'firefox-status-results.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'observations':len(rows),'allExpectedObservations':all(r['matches'] for r in rows),'malformedEqualsEmpty':rows[0]['stdout']==rows[1]['stdout']},indent=2))
