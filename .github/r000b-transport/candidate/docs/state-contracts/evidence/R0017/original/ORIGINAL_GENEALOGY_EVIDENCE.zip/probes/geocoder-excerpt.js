  function _nomCands(arr) {
    if (!Array.isArray(arr)) return [];
    var places = arr.filter(function (r) { return r.class === "place" || r.class === "boundary"; });
    return (places.length ? places : arr).map(function (res) {
      var a = res.address || {};
      var place = a.city || a.town || a.village || a.hamlet || a.municipality || a.suburb || a.county || res.name || "";
      return { lat: parseFloat(res.lat), lon: parseFloat(res.lon), name: place,
        norm: [place, a.state || a.region || a.province || "", a.country || ""].filter(Boolean).join(", "),
        cc: (a.country_code || "").toLowerCase(), provider:"Nominatim",
        bounds:Array.isArray(res.boundingbox) && res.boundingbox.length === 4 ? locationBounds({south:boundsNumber(res.boundingbox[0]),north:boundsNumber(res.boundingbox[1]),west:boundsNumber(res.boundingbox[2]),east:boundsNumber(res.boundingbox[3])}) : null };
    });
  }
  function _zipCand(j) {
    if (!j || !j.places || !j.places.length) return null;
    var p = j.places[0], place = (p["place name"] || "").split(" (")[0].trim();
    return { lat: +p.latitude, lon: +p.longitude, name: place,
      norm: [place, p.state || "", j.country || ""].filter(Boolean).join(", "),
      cc: (j["country abbreviation"] || "").toLowerCase(), provider:"Zippopotam", bounds:null };
  }
  function _dedupeCands(cs) {
    var out = [];
    cs.forEach(function (c) {
      if (c.lat == null || isNaN(c.lat) || c.lon == null || isNaN(c.lon)) return;
      if (!out.some(function (o) { return o.norm === c.norm || (Math.abs(o.lat - c.lat) < 0.2 && Math.abs(o.lon - c.lon) < 0.2); })) out.push(c);
    });
    return out;
  }
  function geocodeSearch(query, opts) {
    opts = opts || {};
    var q = String(query == null ? "" : query).trim();
    if (q.length < 2) return Promise.resolve([]);
    var homeCC = opts.homeCC || "";
    var ac = new AbortController(), to = setTimeout(function () { ac.abort(); }, opts.timeoutMs || 8000);
    var bias = (/\d/.test(q) && homeCC) ? ("&countrycodes=" + homeCC) : "";      // a digit ⇒ likely a postcode ⇒ keep it in the viewer's country
    var bare = q.replace(/\s/g, ""), caFSA = /^[A-Za-z]\d[A-Za-z]/.test(bare) ? bare.slice(0, 3).toUpperCase() : null;
    var jobs = [ fetch("https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=1&limit=5" + bias + "&q=" + encodeURIComponent(q), { signal: ac.signal })
      .then(function (r) { return r.json(); }).then(_nomCands).catch(function () { return []; }) ];
    if (caFSA) jobs.push( fetch("https://api.zippopotam.us/ca/" + caFSA, { signal: ac.signal })
      .then(function (r) { return r.ok ? r.json() : null; }).then(function (j) { var c = _zipCand(j); return c ? [c] : []; }).catch(function () { return []; }) );
    return Promise.all(jobs).then(function (res) {
      clearTimeout(to);
      return _dedupeCands(res.reduce(function (a, b) { return a.concat(b); }, []));
    }).catch(function () { clearTimeout(to); return []; });
  }
