function New-StagingCompilerContext {
    if ($DryRun) { throw 'Offline preview does not allocate compiler scratch.' }
    $native = Initialize-CompilerNative
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    try {
        $sid = $identity.User.Value; $defaultOwnerSid = $identity.Owner.Value
        if (-not $sid -or -not $defaultOwnerSid) { throw 'Compiler token ownership could not be read.' }
        if ($defaultOwnerSid -cnotin @($sid,'S-1-5-32-544')) { throw 'Unsupported compiler default owner.' }
    } finally { $identity.Dispose() }
    $trustedInstaller = ''; try { $trustedInstaller = ([Security.Principal.NTAccount]::new('NT SERVICE','TrustedInstaller').Translate([Security.Principal.SecurityIdentifier])).Value } catch {}
    $context = [pscustomobject]@{Id=[guid]::NewGuid().ToString('N');Status='parent-admission';Path=$null;Identity=$null;Sid=$sid;DefaultOwnerSid=$defaultOwnerSid;InvocationStarted=$false;CompilerExitCode=$null;Created=$false;RootLease=$null;Leases=[Collections.Generic.List[object]]::new();CleanupError=$null}
    $script:CompilerScratch = $context
    try {
        $path = [IO.Path]::GetTempPath()
        if (-not $path -or $path -notmatch '^[A-Za-z]:[\\/]' -or $path -match '[\x00-\x1f]' -or $path.Substring(2).Contains(':')) { throw 'Unsupported compiler parent path.' }
        $full = [IO.Path]::GetFullPath($path).TrimEnd([IO.Path]::DirectorySeparatorChar)
        $root = [IO.Path]::GetPathRoot($full)
        if ($root.Length -ne 3 -or [IO.DriveInfo]::new($root).DriveType -eq [IO.DriveType]::Network) { throw 'Compiler scratch requires a local drive.' }
        $serial=[uint32]0; $maximum=[uint32]0; $flags=[uint32]0
        $format=[Text.StringBuilder]::new(32)
        if (-not $native::GetVolumeInformationW($root,$null,0,[ref]$serial,[ref]$maximum,[ref]$flags,$format,[uint32]$format.Capacity) -or ($flags -band 8) -eq 0) { throw 'Compiler scratch requires persistent local access control.' }
        # The held-handle identity contract uses NTFS volume and 64-bit file IDs.
        $paths=@($root); $current=$root
        foreach ($part in $full.Substring($root.Length).Split([IO.Path]::DirectorySeparatorChar)) {
            if (-not $part -or $part -in @('.','..') -or $part.Trim(' ') -cne $part -or $part.EndsWith('.')) { throw 'Ambiguous compiler parent component.' }
            $current=Join-Path $current $part; $paths += $current
        }
        $last=$null
        foreach ($component in $paths) {
            $lease=Open-CompilerDirectoryLease $component $sid $trustedInstaller; [void]$context.Leases.Add($lease)
            if (-not $lease.Facts.TrustedAncestor) { throw 'Compiler ancestor permits foreign replacement or has an untrusted owner.' }
            $last=$lease.Facts
        }
        if (-not $last.TrustedParent) { throw 'Compiler parent is not owned by this user with trusted write access.' }
        $context.Path=Join-Path $full ('SalahWidgetCompiler-'+$context.Id); $context.Status='candidate'
        $security=[Security.AccessControl.RawSecurityDescriptor]::new('O:'+ $sid +'D:P(A;OICI;FA;;;'+ $sid +')')
        $bytes=New-Object byte[] $security.BinaryLength; $security.GetBinaryForm($bytes,0)
        $descriptor=[Runtime.InteropServices.Marshal]::AllocHGlobal($bytes.Length)
        $size=if ([IntPtr]::Size -eq 8) {24} else {12}; $attributes=[Runtime.InteropServices.Marshal]::AllocHGlobal($size)
        try {
            [Runtime.InteropServices.Marshal]::Copy($bytes,0,$descriptor,$bytes.Length)
            [Runtime.InteropServices.Marshal]::WriteInt32($attributes,0,$size)
            [Runtime.InteropServices.Marshal]::WriteIntPtr($attributes,[IntPtr]::Size,$descriptor)
            [Runtime.InteropServices.Marshal]::WriteInt32($attributes,([IntPtr]::Size*2),0)
            if (-not $native::CreateDirectoryW($context.Path,$attributes)) { throw [ComponentModel.Win32Exception]::new([Runtime.InteropServices.Marshal]::GetLastWin32Error(),'Create exclusive private compiler directory') }
            $context.Created=$true
        } finally { [Runtime.InteropServices.Marshal]::FreeHGlobal($attributes); [Runtime.InteropServices.Marshal]::FreeHGlobal($descriptor) }
        $context.RootLease=Open-CompilerDirectoryLease $context.Path $sid $trustedInstaller
        if (-not $context.RootLease.Facts.Private) { throw 'New compiler directory did not read back as private.' }
        $context.Identity=$context.RootLease.Facts.Identity; $context.Status='owned'
        return $context
    } catch {
        $context.Status=if ($context.Created) {'retained-unproved'} else {'refused-before-create'}
        if ($context.RootLease) { $context.RootLease.Handle.Dispose() }
        foreach ($lease in $context.Leases) { $lease.Handle.Dispose() }
        if ($context.Created) { Write-Warn ('Unproved compiler scratch retained at '+$context.Path) }
        throw
    }
}