using System;
using System.IO;
using System.Text;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;
using Microsoft.Win32.SafeHandles;
namespace SalahVolumeProbeb9b295889b7a411781bcf6c32b63c10d {
  public sealed class PathFacts {
    public string Path, Identity, Owner;
    public bool Directory, Private, TrustedParent, TrustedAncestor, WriteRestricted;
    public long Length;
    public uint Links;
  }
  public sealed class DirectoryLease : IDisposable {
    internal SafeFileHandle Handle;
    public PathFacts Facts;
    public void Dispose() { if (Handle != null) { Handle.Dispose(); Handle = null; } }
  }
  public sealed class ByteProof { public long Length; public uint Crc; public string Hash; }
  public static class StageNative {
    [StructLayout(LayoutKind.Sequential)] struct SecurityAttributes {
      public int Length; public IntPtr Descriptor; [MarshalAs(UnmanagedType.Bool)] public bool Inherit;
    }
    [StructLayout(LayoutKind.Sequential)] struct FileInformation {
      public uint Attributes; public System.Runtime.InteropServices.ComTypes.FILETIME Creation, Access, Write;
      public uint Volume, SizeHigh, SizeLow, Links, IndexHigh, IndexLow;
    }
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
    static extern bool CreateDirectoryW(string path, ref SecurityAttributes security);
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
    static extern SafeFileHandle CreateFileW(string path, uint access, uint share, IntPtr security, uint disposition, uint flags, IntPtr template);
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true, EntryPoint="CreateFileW")]
    static extern SafeFileHandle CreateSecuredFile(string path, uint access, uint share, ref SecurityAttributes security, uint disposition, uint flags, IntPtr template);
    [DllImport("kernel32.dll", SetLastError=true)] static extern bool GetFileInformationByHandle(SafeFileHandle file, out FileInformation info);
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] static extern uint GetFinalPathNameByHandleW(SafeFileHandle file, StringBuilder path, uint length, uint flags);
    [DllImport("kernel32.dll", SetLastError=true)] static extern uint GetFileType(SafeFileHandle file);
    [DllImport("advapi32.dll", SetLastError=true)] static extern uint GetSecurityInfo(SafeFileHandle handle, int type, uint information, out IntPtr owner, out IntPtr group, out IntPtr dacl, out IntPtr sacl, out IntPtr descriptor);
    [DllImport("advapi32.dll")] static extern uint GetSecurityDescriptorLength(IntPtr descriptor);
    [DllImport("kernel32.dll")] static extern IntPtr LocalFree(IntPtr memory);
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true, EntryPoint="GetVolumeInformationW")]
    static extern bool ReadActualVolume(string root, StringBuilder name, uint nameSize, out uint serial, out uint maximumComponent, out uint flags, StringBuilder format, uint formatSize);
    public static bool FixtureNative, FixtureSuccess=true, FixturePreserveActual;
    public static string FixtureFilesystem="NTFS", FixtureActualFilesystem="";
    public static uint FixtureFlags=8;
    public static int FixtureCalls;
    public static bool FixtureNameRequested;
    public static bool GetVolumeInformationW(string root, StringBuilder name, uint nameSize, out uint serial, out uint maximumComponent, out uint flags, StringBuilder format, uint formatSize) {
      FixtureCalls++; FixtureNameRequested=format!=null && formatSize!=0;
      if (FixtureNative) {
        StringBuilder actual=new StringBuilder(64);
        bool ok=ReadActualVolume(root,name,nameSize,out serial,out maximumComponent,out flags,actual,64);
        FixtureActualFilesystem=actual.ToString();
        if (!ok) return false;
        if (FixturePreserveActual) { if (format!=null) format.Append(actual); return true; }
      } else { serial=1; maximumComponent=255; flags=8; FixtureActualFilesystem="NO_NATIVE_VOLUME"; }
      if (!FixtureSuccess) return false;
      flags=FixtureFlags;
      if (format!=null) { format.Length=0; format.Append(FixtureFilesystem); }
      return true;
    }
    static Exception Error(string operation) { return new Win32Exception(Marshal.GetLastWin32Error(), operation); }
    static string installerSid;
    static bool TrustedOwner(string owner, string user) {
      if (owner==user || owner=="S-1-5-18" || owner=="S-1-5-32-544") return true;
      // Resolve the local OS servicing principal only when needed. Do not
      // require self-ownership of the Windows volume/Users ancestors.
      if (installerSid==null) {
        try { installerSid=((SecurityIdentifier)new NTAccount("NT SERVICE", "TrustedInstaller").Translate(typeof(SecurityIdentifier))).Value; }
        catch { installerSid=""; }
      }
      return installerSid.Length!=0 && owner==installerSid;
    }
    static readonly uint[] CrcTable = MakeCrcTable();
    static uint[] MakeCrcTable() {
      uint[] table = new uint[256];
      for (uint i=0; i<256; i++) { uint value=i; for (int bit=0; bit<8; bit++) value=(value & 1) != 0 ? 0xedb88320u ^ (value >> 1) : value >> 1; table[i]=value; }
      return table;
    }
    public static ByteProof Fingerprint(Stream source, long maximum, Stream destination) {
      byte[] buffer = new byte[65536]; long length=0; uint crc=0xffffffffu;
      using (System.Security.Cryptography.SHA256 hash = System.Security.Cryptography.SHA256.Create()) {
        int count;
        while ((count=source.Read(buffer,0,buffer.Length)) != 0) {
          length += count; if (length > maximum) throw new IOException("Archive member exceeds its declared supported size.");
          for (int i=0; i<count; i++) crc=CrcTable[(crc ^ buffer[i]) & 255] ^ (crc >> 8);
          hash.TransformBlock(buffer,0,count,null,0); if (destination != null) destination.Write(buffer,0,count);
        }
        hash.TransformFinalBlock(new byte[0],0,0);
        return new ByteProof { Length=length, Crc=crc ^ 0xffffffffu, Hash=BitConverter.ToString(hash.Hash).Replace("-","").ToLowerInvariant() };
      }
    }
    static byte[] Exact(BinaryReader reader, int count) { byte[] bytes=reader.ReadBytes(count); if (bytes.Length != count) throw new IOException("Truncated ZIP structure."); return bytes; }
    static bool Same(byte[] first, byte[] second) { if (first.Length != second.Length) return false; for (int i=0; i<first.Length; i++) if (first[i] != second[i]) return false; return true; }
    // The supported archive contract is single-disk, non-ZIP64, stored/deflated
    // ZIP with checked central/local records, descriptors and member CRCs.
    public static uint[] ReadZipCrcs(Stream stream) {
      if (!stream.CanSeek || stream.Length < 22 || stream.Length > 134217728) throw new IOException("Unsupported ZIP size.");
      BinaryReader reader = new BinaryReader(stream, Encoding.UTF8, true);
      long tailStart=Math.Max(0,stream.Length-65557); stream.Position=tailStart; byte[] tail=Exact(reader,(int)(stream.Length-tailStart)); int end=-1;
      for (int i=tail.Length-22; i>=0; i--) if (BitConverter.ToUInt32(tail,i)==0x06054b50 && i+22+BitConverter.ToUInt16(tail,i+20)==tail.Length) { end=i; break; }
      if (end<0 || BitConverter.ToUInt16(tail,end+4)!=0 || BitConverter.ToUInt16(tail,end+6)!=0) throw new IOException("Unsupported or incomplete ZIP directory.");
      int count=BitConverter.ToUInt16(tail,end+10); uint centralSize=BitConverter.ToUInt32(tail,end+12), centralOffset=BitConverter.ToUInt32(tail,end+16);
      if (count==0 || count>10000 || count!=BitConverter.ToUInt16(tail,end+8) || (long)centralOffset+centralSize!=tailStart+end) throw new IOException("Inconsistent or unsupported ZIP directory.");
      uint[] crcs=new uint[count]; long[] starts=new long[count], ends=new long[count]; stream.Position=centralOffset;
      for (int i=0; i<count; i++) {
        byte[] central=Exact(reader,46); if (BitConverter.ToUInt32(central,0)!=0x02014b50) throw new IOException("Malformed ZIP central record.");
        ushort flags=BitConverter.ToUInt16(central,8), method=BitConverter.ToUInt16(central,10);
        uint compressed=BitConverter.ToUInt32(central,20), expanded=BitConverter.ToUInt32(central,24), local=BitConverter.ToUInt32(central,42);
        if ((flags & ~0x080e)!=0 || (method!=0 && method!=8) || compressed==uint.MaxValue || expanded==uint.MaxValue || local==uint.MaxValue || BitConverter.ToUInt16(central,34)!=0) throw new IOException("Unsupported encrypted, split or ZIP64 member.");
        crcs[i]=BitConverter.ToUInt32(central,16); byte[] name=Exact(reader,BitConverter.ToUInt16(central,28)); Exact(reader,BitConverter.ToUInt16(central,30)+BitConverter.ToUInt16(central,32));
        long nextCentral=stream.Position; stream.Position=local; byte[] header=Exact(reader,30);
        if (BitConverter.ToUInt32(header,0)!=0x04034b50 || BitConverter.ToUInt16(header,6)!=flags || BitConverter.ToUInt16(header,8)!=method) throw new IOException("ZIP local record disagrees with its directory.");
        byte[] localName=Exact(reader,BitConverter.ToUInt16(header,26)); if (!Same(name,localName)) throw new IOException("ZIP local member name differs.");
        Exact(reader,BitConverter.ToUInt16(header,28)); long dataEnd=stream.Position+compressed;
        if (local>=centralOffset || dataEnd>centralOffset) throw new IOException("ZIP member overlaps its directory.");
        if ((flags & 8)==0) {
          if (BitConverter.ToUInt32(header,14)!=crcs[i] || BitConverter.ToUInt32(header,18)!=compressed || BitConverter.ToUInt32(header,22)!=expanded) throw new IOException("ZIP local sizes or CRC differ.");
        } else {
          stream.Position=dataEnd; uint first=reader.ReadUInt32(); uint crc=first==0x08074b50 ? reader.ReadUInt32() : first;
          if (crc!=crcs[i] || reader.ReadUInt32()!=compressed || reader.ReadUInt32()!=expanded) throw new IOException("ZIP data descriptor differs."); dataEnd=stream.Position;
        }
        starts[i]=local; ends[i]=dataEnd; stream.Position=nextCentral;
      }
      if (stream.Position!=(long)centralOffset+centralSize) throw new IOException("Unexpected ZIP directory bytes.");
      Array.Sort(starts,ends); long previous=0;
      for (int i=0; i<count; i++) { if (starts[i]!=previous || ends[i]<=starts[i] || ends[i]>centralOffset) throw new IOException("Overlapping or unsupported ZIP member layout."); previous=ends[i]; }
      if (previous!=centralOffset) throw new IOException("Unaccounted ZIP payload bytes.");
      stream.Position=0; return crcs;
    }
    public static string CurrentSid() { using (WindowsIdentity identity = WindowsIdentity.GetCurrent()) { return identity.User.Value; } }
    public static void RequireLocalAclVolume(string path) {
      string root = System.IO.Path.GetPathRoot(path);
      if (root == null || root.Length != 3 || root[1] != ':' || new DriveInfo(root).DriveType == DriveType.Network)
        throw new IOException("Staging requires a supported local drive path.");
      uint serial, maximum, flags; StringBuilder format = new StringBuilder(32);
      if (!GetVolumeInformationW(root, null, 0, out serial, out maximum, out flags, format, (uint)format.Capacity)) throw Error("Read staging volume");
      if ((flags & 8) == 0) throw new IOException("Staging volume does not provide persistent access control.");
      if (!String.Equals(format.ToString(), "NTFS", StringComparison.OrdinalIgnoreCase)) throw new IOException("Staging requires the supported NTFS filesystem.");
    }
    static byte[] Descriptor(string sid, bool directory) {
      RawSecurityDescriptor descriptor = new RawSecurityDescriptor("O:" + sid + "D:P(A;" + (directory ? "OICI" : "") + ";FA;;;" + sid + ")");
      byte[] bytes = new byte[descriptor.BinaryLength]; descriptor.GetBinaryForm(bytes, 0); return bytes;
    }
    public static void CreatePrivateDirectory(string path, string sid) {
      byte[] bytes = Descriptor(sid, true); GCHandle pinned = GCHandle.Alloc(bytes, GCHandleType.Pinned);
      try {
        SecurityAttributes security = new SecurityAttributes(); security.Length = Marshal.SizeOf(typeof(SecurityAttributes)); security.Descriptor = pinned.AddrOfPinnedObject();
        if (!CreateDirectoryW(path, ref security)) throw Error("Create exclusive private staging directory");
      } finally { pinned.Free(); }
    }
    public static void CreatePrivateFile(string path, string sid) {
      byte[] bytes = Descriptor(sid, false); GCHandle pinned = GCHandle.Alloc(bytes, GCHandleType.Pinned);
      try {
        SecurityAttributes security = new SecurityAttributes(); security.Length = Marshal.SizeOf(typeof(SecurityAttributes)); security.Descriptor = pinned.AddrOfPinnedObject();
        using (SafeFileHandle file = CreateSecuredFile(path, 0xc0000000, 0, ref security, 1, 0x80, IntPtr.Zero)) {
          if (file.IsInvalid) throw Error("Create exclusive private staging file");
        }
      } finally { pinned.Free(); }
    }
    static PathFacts Read(SafeFileHandle handle, string path, string sid) {
      FileInformation info;
      if (!GetFileInformationByHandle(handle, out info)) throw Error("Read staging identity");
      if ((info.Attributes & 0x400) != 0 || GetFileType(handle) != 1) throw new IOException("Reparse or non-disk staging object refused.");
      StringBuilder physical = new StringBuilder(32768);
      uint count = GetFinalPathNameByHandleW(handle, physical, (uint)physical.Capacity, 0);
      if (count == 0 || count >= physical.Capacity) throw Error("Read physical staging path");
      string finalPath = physical.ToString(); if (finalPath.StartsWith("\\\\?\\", StringComparison.Ordinal)) finalPath = finalPath.Substring(4);
      if (!String.Equals(finalPath.TrimEnd('\\'), System.IO.Path.GetFullPath(path).TrimEnd('\\'), StringComparison.OrdinalIgnoreCase)) throw new IOException("Aliased staging path refused.");
      IntPtr owner, group, dacl, sacl, descriptor;
      uint code = GetSecurityInfo(handle, 1, 5, out owner, out group, out dacl, out sacl, out descriptor);
      if (code != 0) throw new Win32Exception((int)code, "Read staging access control");
      try {
        byte[] bytes = new byte[GetSecurityDescriptorLength(descriptor)]; Marshal.Copy(descriptor, bytes, 0, bytes.Length);
        RawSecurityDescriptor security = new RawSecurityDescriptor(bytes, 0);
        string actualOwner = security.Owner == null ? "" : security.Owner.Value;
        bool writeRestricted = security.DiscretionaryAcl != null;
        bool parentSafe = actualOwner == sid && writeRestricted;
        bool ancestorSafe = TrustedOwner(actualOwner,sid) && security.DiscretionaryAcl != null;
        bool privateAcl = parentSafe && (security.ControlFlags & ControlFlags.DiscretionaryAclProtected) != 0 && security.DiscretionaryAcl.Count == 1;
        if (security.DiscretionaryAcl != null) foreach (GenericAce generic in security.DiscretionaryAcl) {
          CommonAce ace = generic as CommonAce;
          if (ace == null || ace.IsCallback) { parentSafe = false; ancestorSafe = false; privateAcl = false; writeRestricted = false; continue; }
          bool allowed = ace.AceQualifier == AceQualifier.AccessAllowed;
          bool inheritOnly = (ace.AceFlags & AceFlags.InheritOnly) != 0;
          string principal = ace.SecurityIdentifier.Value;
          uint mask = unchecked((uint)ace.AccessMask);
          if (allowed && !inheritOnly && (mask & 0x500d0156u) != 0 && principal != sid && principal != "S-1-5-18" && principal != "S-1-5-32-544") { parentSafe = false; writeRestricted = false; }
          // Earlier ancestors may grant create-file/create-directory (2/4)
          // without granting replacement, attribute or ACL/owner authority.
          if (allowed && !inheritOnly && (mask & 0x500d0150u) != 0 && principal != sid && principal != "S-1-5-18" && principal != "S-1-5-32-544" && !TrustedOwner(principal,sid)) ancestorSafe = false;
          if (!allowed || inheritOnly || principal != sid || (mask & 0x1f01ffu) != 0x1f01ffu) privateAcl = false;
        }
        return new PathFacts { Path=finalPath, Identity=info.Volume.ToString("x8") + ":" + info.IndexHigh.ToString("x8") + info.IndexLow.ToString("x8"), Owner=actualOwner,
          Directory=(info.Attributes & 0x10) != 0, Private=privateAcl, TrustedParent=parentSafe, TrustedAncestor=ancestorSafe, WriteRestricted=writeRestricted, Length=((long)info.SizeHigh << 32) | info.SizeLow, Links=info.Links };
      } finally { if (descriptor != IntPtr.Zero) LocalFree(descriptor); }
    }
    public static PathFacts Inspect(string path, string sid) {
      using (SafeFileHandle file = CreateFileW(path, 0x20080, 7, IntPtr.Zero, 3, 0x02200000, IntPtr.Zero)) {
        if (file.IsInvalid) throw Error("Open staging object without following reparse points");
        return Read(file, path, sid);
      }
    }
    public static DirectoryLease OpenDirectory(string path, string sid) {
      // FILE_LIST_DIRECTORY participates in delete sharing; metadata-only access does not.
      SafeFileHandle file = CreateFileW(path, 0x20081, 3, IntPtr.Zero, 3, 0x02200000, IntPtr.Zero);
      if (file.IsInvalid) { file.Dispose(); throw Error("Lock staging directory identity"); }
      try { PathFacts facts = Read(file, path, sid); if (!facts.Directory) throw new IOException("Expected staging directory."); return new DirectoryLease { Handle=file, Facts=facts }; }
      catch { file.Dispose(); throw; }
    }
  }
}