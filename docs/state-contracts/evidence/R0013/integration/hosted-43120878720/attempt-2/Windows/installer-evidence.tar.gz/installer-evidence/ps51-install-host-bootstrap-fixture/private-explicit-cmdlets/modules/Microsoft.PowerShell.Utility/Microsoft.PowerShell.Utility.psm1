[IO.File]::AppendAllText($env:R0013_PHASES,'utility-wrapper-entered'+[Environment]::NewLine)
Import-Module $env:R0013_NATIVE_UTILITY -Scope Local
[IO.File]::AppendAllText($env:R0013_PHASES,'native-utility-imported'+[Environment]::NewLine)
[Console]::OutputEncoding=New-Object Text.UTF8Encoding $false
[IO.File]::AppendAllText($env:R0013_PHASES,'encoding-constructor-returned'+[Environment]::NewLine)
function Write-Host { param($Object) [Console]::WriteLine([string]$Object) }
Export-ModuleMember -Function Write-Host -Cmdlet *
[IO.File]::AppendAllText($env:R0013_PHASES,'utility-exports-complete'+[Environment]::NewLine)