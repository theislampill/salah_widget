[IO.File]::AppendAllText($env:R0013_PHASES,'script-enter'+[Environment]::NewLine)
[IO.File]::AppendAllText($env:R0013_PHASES,'join-path-begin'+[Environment]::NewLine)
$path=Join-Path $env:TEMP 'no-created-directory'
[IO.File]::AppendAllText($env:R0013_PHASES,'join-path-returned'+[Environment]::NewLine)
[IO.File]::AppendAllText($env:R0013_PHASES,'write-host-begin'+[Environment]::NewLine)
Write-Host 'R0013 bootstrap probe; no installer invocation'
[IO.File]::AppendAllText($env:R0013_PHASES,'write-host-returned'+[Environment]::NewLine)
[IO.File]::WriteAllText($env:R0013_ACQUIRE_READY,$env:R0013_ACQUIRE_NONCE)
[IO.File]::AppendAllText($env:R0013_PHASES,'script-completed'+[Environment]::NewLine)