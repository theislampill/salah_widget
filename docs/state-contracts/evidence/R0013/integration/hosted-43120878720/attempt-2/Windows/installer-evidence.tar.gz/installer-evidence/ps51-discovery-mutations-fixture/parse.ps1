param([string]$SourceFile)
$t=$null;$e=$null;$null=[Management.Automation.Language.Parser]::ParseFile($SourceFile,[ref]$t,[ref]$e);if(@($e).Count){exit 1}
