
$ErrorActionPreference='Stop'
$data=ConvertFrom-Json -InputObject '[{"addons":[]}]'
$accepted=@{}
foreach($row in @(
    @('trailing-comma','{"addons":[],}'),@('array-trailing-comma','{"addons":[],"other":[1,]}'),
    @('trailing-comment','{"addons":[]} /* comment */'),@('single-quotes',"{'addons':[]}"),@('bare-key','{addons:[]}')
)){
    try{$null=ConvertFrom-Json -InputObject $row[1] -ErrorAction Stop;$accepted[$row[0]]=$true}
    catch{$accepted[$row[0]]=$false}
}
[pscustomobject]@{version=$PSVersionTable.PSVersion.ToString();singletonType=$data.GetType().FullName;singletonIsArray=($data -is [array]);singletonIsObject=($data -is [pscustomobject]);accepts=$accepted}|ConvertTo-Json -Depth 8 -Compress
