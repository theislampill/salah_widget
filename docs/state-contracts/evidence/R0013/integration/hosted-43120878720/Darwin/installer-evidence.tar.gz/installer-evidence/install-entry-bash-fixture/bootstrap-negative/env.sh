
record(){ printf '%s\n' "$*" >> "$EFFECT_LOG"; }
check_path(){ case "$1" in "$FIXTURE_ROOT"/*) ;; *) record "ESCAPE $1"; return 99 ;; esac; }
command(){
  if [ "$1" = -v ] && [ "${2:-}" = python3 ] && [ "${INSTALL_DISCOVERY_NO_PYTHON:-0}" = 1 ]; then return 1; fi
  if [ "$1" = -v ]; then case "${2:-}" in /Applications/*|google-chrome|google-chrome-stable|chrome|microsoft-edge|microsoft-edge-stable|brave-browser|brave|chromium|chromium-browser|firefox|librewolf) return 1 ;; esac; fi
  builtin command "$@"
}
[(){
  if builtin [ "$#" = 3 ] && builtin [ "$1" = -x ]; then case "$2" in /Applications/*) return 1 ;; esac; fi
  builtin [ "$@"
}
mkdir(){ for item in "$@"; do case "$item" in -*) ;; *) check_path "$item" || return ;; esac; done; record "mkdir $*"; builtin command mkdir "$@"; }
mktemp(){ for item in "$@"; do case "$item" in -*) ;; *) check_path "$item" || return ;; esac; done; record "mktemp $*"; builtin command mktemp "$@"; }
rm(){ for item in "$@"; do case "$item" in -*) ;; *) check_path "$item" || return ;; esac; done; record "remove $*"; builtin command rm "$@"; }
cp(){ for item in "$@"; do case "$item" in -*) ;; *) check_path "$item" || return ;; esac; done; record "copy $*"; builtin command cp "$@"; }
mv(){ for item in "$@"; do case "$item" in -*) ;; *) check_path "$item" || return ;; esac; done; record "move $*"; builtin command mv "$@"; }
curl(){
  record "download $*"
  local item previous='' url='' destination=''
  for item in "$@"; do
    [ "$previous" != -o ] || destination="$item"
    case "$item" in file://*) url="$item" ;; esac
    previous="$item"
  done
  case "$url" in "file://$FIXTURE_ROOT"/*) ;; *) record 'DENIED network'; return 99 ;; esac
  check_path "$destination" || return
  builtin command curl --proto '=file' "$@"
}
python3(){
  if [ "$#" = 3 ] && [ "$1" = - ] && [ "$2" = fixture/repo ]; then
    record "metadata $3"; cat >/dev/null
    [ "${FAIL_METADATA:-0}" != 1 ] || { record 'DENIED metadata fixture'; return 99; }
    case "$3" in chromium) printf 'v-fixture\ttabliss-chromium.zip\tfile://%s\n' "$ASSET_FIXTURE" ;; firefox) printf 'v-fixture\ttabliss-firefox-signed.xpi\tfile://%s\n' "$ASSET_FIXTURE" ;; *) return 99 ;; esac
  else "$INSTALL_TEST_PYTHON" "$@"; fi
}
xclip(){ local text; text="$(cat)"; record "clipboard $text"; }
pbcopy(){ local text; text="$(cat)"; record "clipboard $text"; }
xdg-open(){ record "open $*"; }
open(){ record "open $*"; }
unzip(){ record "extract $*"; return 99; }
