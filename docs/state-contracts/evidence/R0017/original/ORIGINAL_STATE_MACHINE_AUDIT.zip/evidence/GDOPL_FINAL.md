# GDOPL projection: make authority, transitions and effects explicit

This section is an architectural projection, not an implemented change, measured optimization, or claim that a numerical solver has been adopted. GDOPL means **Gradient Descent Over the Project Lagrangian**. The optimized object is the whole project's objective and constraint structure. A locally faster renderer is not an admissible improvement if it makes the prayer result stale, silently changes the scientific model, or weakens the evidence supporting the result.

## The useful field is larger than a collection of enums

Treat each catalogued protocol as a component with retained state, accepted events, guards, effects, publication authority, and recovery. The app's state is the constrained product of those components together with clocks, resource ownership and delivery identity. Numeric time, geometry and coverage make this a hybrid state space; it is not a small finite automaton that can sensibly be flattened into one giant list of states.

Some useful coordinates are already explicit: native request generations, attempt deadlines, the sky lifecycle epoch, a latest-only queue, the lunar worker serial, and publication currentness. The problem is not a total absence of state modeling. The highest-value work makes the **relationships between those owners** explicit and gives hidden resource lifetimes the same discipline.

A compact component record would carry `phase`, `ownerId`, `revision`, `acceptedIdentity`, `pendingOperation`, `publishedReceipt`, and `failureReason` only where those fields are meaningful. A pure formatting function should remain pure. A cache needs a validity key and retention policy, not an invented seven-state workflow. An already explicit queue should not be rewritten merely to fit a uniform framework.

The most important distinction is between a state that describes a valid input, a state that permits an effect, and evidence that the effect actually occurred. `ready`, `current`, `decoded`, `adopted`, and `displayed` are not interchangeable. The current refined sky host correctly retains separate accepted and displayed jobs; that distinction should be preserved when extracting a shared contract, rather than collapsed into one convenient `ready` flag.

## Binding constraints and directional costs

The admissible region should preserve at least these constraints:

1. A provider, worker, image, font, or lookup completion may mutate only the generation, operation, session and source identity that still own it. Returning from A to A after visiting B is a new ownership event.
2. Prayer names, dates, countdown targets and epoch differences must come from a mutually consistent admitted timetable and timezone. Missing tomorrow data cannot be represented as a known absolute countdown.
3. Weather presentation must preserve the distinction between a model estimate, a forecast preview, a synthetic fixture and direct observation. Stale model coverage must lose its permission across every consumer.
4. Sky, solar mask, lunar detail and celestial geometry must satisfy their publication and currentness contracts at the final consumer. A new accepted job cannot renew old displayed pixels by association.
5. Required prayer/settings behavior must remain available when optional astronomy is unavailable. Optional rendering must not silently move expensive physical work onto the prayer UI thread.
6. Disposal belongs to the instance that acquired the resource. A retiring instance cannot dispose its successor's global resource.
7. Generated artifacts must remain attributable to the canonical native/Moon owners; frozen V1 remains a separate compatibility target. A partial file's existence is not validation.
8. Evidence must describe what was actually run. Source tests, synthetic schedules, native pixels, operating-system installation, and performance measurement retain separate meanings.

These constraints are not penalties that can be traded away for a better average score. Within the admissible region, compare directional changes in stale exposure, time to useful presentation, redundant acquisition, frame/worker pressure, retained memory, code ownership complexity, and verification burden. Keep that comparison as a typed vector until the owner has supplied defensible priorities. The audit has not measured weights or a gradient and does not claim a global optimum.

## Separate the time domains

| Domain | Current examples | What the explicit contract must prevent |
|---|---|---|
| Civil/astronomical time | `simNow`, timezone day, prayer epochs, celestial observer UTC | Treating elapsed milliseconds as a civil day, or taking an event from the wrong zone/day |
| Preview time and rate | live, frozen preview, advancing preview, explicit seeks | A preview reset retaining a previous generation's result, or forecast preview leaking into live observation claims |
| Monotonic elapsed time | network attempt deadlines, prayer retry cooldown, worker deadlines, paint cadence | Wall-clock adjustments extending a transport lease or accelerating retries |
| Source validity and receipt time | weather source interval, retrieval age, renderer accepted UTC | A new receipt making old source data fresh, or an accepted replacement extending old displayed-frame age |
| Actual presentation progress | CSS transforms/fades, image decode, native composition, font layout | A target style or completed calculation being reported as pixels already displayed |

Current weather and radar cooldowns still use wall time even though visible refresh opportunities use elapsed time. Their discontinuity behavior must be assessed separately; the table describes distinct domains, not a claim that all existing scheduling uses the preferred clock.

Epochs are ordering and authority coordinates, not another clock. A deadline determines whether work may finish; a publication predicate determines whether its result may become visible. Both are necessary, and cancelling transport is not a substitute for checking ownership at adoption.

## A configuration effect matrix is a first practical variation

The current `applyConfig` has a narrow appearance-only path and a broad reset for other changes. The source-bound probe establishes that changing only time format, date format, or label restarts data acquisition and scene ownership. An explicit effect matrix makes a smaller candidate change reviewable:

| Accepted change | Prayer acquisition | Weather acquisition | Radar acquisition | Celestial scene and presentation |
|---|---|---|---|---|
| Label | Preserve | Preserve | Preserve | Update header label |
| Time/date format | Preserve | Preserve | Preserve | Update text, dates and countdown fit where affected |
| Timetable appearance | Preserve | Preserve | Preserve | Update row material; retain existing narrow path |
| Method/school | Reacquire affected timetable | Preserve unless another consumed field changes | Preserve unless target/provenance changes | Preserve accepted observer; revisit only actual dependent inputs |
| Temperature units | Preserve | Reacquire, or convert only under a defined admission contract | Preserve unchanged coordinate/provenance target | Update weather consumers consistently |
| Coordinates | New ownership generation | New ownership generation | New ownership generation | New observer/scene; withdraw obsolete location-dependent presentation |
| Acquisition evidence changes at unchanged coordinates | Preserve time/location outputs only if their accepted dependencies still match | Reconcile target claim authority and original provenance | Reconcile target provenance even when tile coordinates match | Preserve original fix time; never turn coarse/unknown evidence into a point claim |
| Timezone/accepted clock intent | Reconcile civil-day/target identity | Reevaluate interval/preview/live authority and consumed zone | Reevaluate age/authority; do not reacquire solely for text formatting | Invalidate affected currentness and recompute relevant consumers |
| Light pollution | Preserve | Preserve | Preserve | Invalidate the consumed physical-renderer input |
| Decorative seed, if runtime mutation is actually added | Preserve | Preserve | Preserve | First define its owner/rebinding semantics; current cloud seed reads boot query state |

This is a proposed dependency matrix, not a specification silently imposed on every preference. In particular, provider-adopted timezone and acquisition evidence cannot be overwritten by a display-only edit. The existing appearance-only branch already demonstrates why rebinding the entire configuration object can be wrong even when the edit looks harmless.

The candidate should initially introduce small, narrowly tested branches. Moving immediately to many independent revisions would increase the number of consistency rules before their dependencies have been demonstrated. Preserve the existing broad location generation as the safe fallback while deriving and testing the minimum necessary smaller invalidation scopes. The number of revision counters is a design result, not an acceptance requirement.

Weather units and radar dependencies are independently visible in the [weather request](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/index.html#L1368-L1379) and [radar target/URL](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/index.html#L1445-L1466). [Target capture](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/index.html#L1306-L1325) preserves intent, accuracy, original acquisition time and provenance. These constraints become more important when broad invalidation is narrowed.

## Cross-machine schedules reveal the conflicts

### Weather expiry while the timetable is missing

An accepted cloudy scene is displayed. The civil day changes; the successor timetable is unavailable. The location and live scene identity remain the same. Weather then expires. The no-timetable render branch withdraws header/precipitation but does not run the cloud-state withdrawal that the full atmosphere path performs. The resulting tuple is `prayer unavailable + weather unavailable + previous cloud coverage retained`.

The useful variation is to make cloud permission depend on the admitted weather decision independently of timetable readiness. It must not fabricate prayer inputs merely to reach the full painter. A cheap withdrawal can be independent of expensive cloud evolution, while a healthy new weather model can install its own current targets. Acceptance requires both missing-timetable and healthy-timetable controls, followed by native composition checks.

### Reordered daily events crossing midnight

The current model accepts and sorts reordered clocks, then falls back to a named next-day Fajr event after today's last event. That is a conflict between a chronological selection machine and a conventional-name assumption at its boundary. The variation is one event-selection contract across admitted neighboring days, with stable equal-time policy and real timezone-derived epochs. The existing ordinary ordering and DST cases are countervariations that must remain correct.

### Editing a label while work is in flight

The UI edit is locally valid, but its broad configuration transition cancels unrelated prayer/weather work and resets a usable scene. At the builder boundary, `input` and `change` can each force a fresh iframe navigation even when the serialized configuration is unchanged. Local responsiveness and whole-project work efficiency diverge. Distinguish draft form state, serialized output state, and committed preview state; reuse a preview only when its effective identity is unchanged. Keep immediate embed-code accuracy and explicit refresh behavior.

### Replacing a runtime while globals point to its successor

The Moon wrapper creates and assigns a new detail owner before disposing the old runtime. The old runtime's disposer dereferences the global detail owner, which now identifies the new instance. The controlled replacement probe disposes both old and new detail instances. This is a temporal ownership violation, not a numerical rendering problem. Acquire resources into an instance-owned record; dispose the captured old record before publishing the successor. Normal one-time page startup is a separate control and is not claimed to reproduce this replacement-only path.

### Cache admission and file existence

The PowerShell download cache can use `Test-Path` as its admission test after downloading directly to the reusable destination. A partial earlier transfer can therefore become a later ready-looking artifact. An explicit lifecycle distinguishes absent, downloading, staged, validated and published artifacts. Validation may be reused only with the identity it actually established. The Bash staging path already supplies a useful contrast; parity should be expressed as a common contract, not assumed from similar command names.

### Correcting the system clock while freshness rejects old evidence

A live weather/radar attempt records wall time T. The system clock is corrected backward within the same civil day, the target generation is unchanged, and elapsed time continues. Weather freshness correctly rejects a receipt that now appears to come from the future. Periodic refresh opportunities still occur, but weather and radar cooldowns compare the corrected wall time against their old wall-time markers. Negative differences suppress the replacement acquisition that could restore usable evidence.

This is a source-derived cross-domain schedule, with any executed gate probe reported separately under XF02. It is a system-clock correction, not a timezone/DST offset change. The binding constraint is **freshness rejection must leave a viable recovery route**. Use an owned elapsed scheduling bound or an explicit clock-discontinuity transition while retaining UTC source/receipt timestamps for truthfulness. A scheduling fix must never make future-dated or expired weather eligible. Controls include ordinary operation, backward and forward clock corrections, target reset, busy/cancelled attempts and retry bounds. [Freshness](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/index.html#L1291-L1304), [weather gate](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/index.html#L1368-L1378), [radar gate](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/index.html#L1445-L1451), [elapsed refresh opportunity](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/index.html#L3636-L3644).

### A frozen scene does not guarantee asynchronous progress

The solar-mask composition owner fences cancellation and currentness, but an image decode has no intrinsic elapsed settlement deadline. A frozen accepted UTC can stay current while publication remains pending. RF04 therefore contributes a liveness obligation: accepted, decoded, displayed, cancelled and failed states need distinct terminals, and an optional decode attempt needs a bounded progress rule or an explicitly accepted dependence on platform settlement. A suitable elapsed deadline would retire only that attempt; it could not grant stale pixels publication authority. No never-settling browser decode was reproduced, so this remains a conditional hypothesis. [Composition owner](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/real-sky/native-composition.mjs#L45-L68).

### Budgeting across individually bounded workers

Latest-only queues, fixed row partitions and per-job deadlines bound particular owners. They do not by themselves establish a whole-widget CPU, memory, or startup budget across preview, refined sky, Moon workers, native cloud painting and iframe replacement. A candidate shared priority contract can protect prayer/settings responsiveness, then first useful celestial presentation, then refinement. It needs native measurements before adoption. Reducing worker count or suppressing refinement may improve pressure while worsening latency or accepted quality; those countervariations must be measured rather than declared successful from source inspection.

## Candidate GDOPL steps and the evidence they need

| Candidate | Expected direction | Countervariation / binding risk | Proof needed before calling it an improvement |
|---|---|---|---|
| One chronological prayer-boundary selector | Fewer inconsistent midnight transitions | Equal clocks, polar ordering, DST folds/gaps, missing successor | Source-bound event schedules and existing date/countdown regressions |
| Independent weather-to-cloud permission transition | Less stale visual weather | Do not invent a timetable or discard healthy motion unnecessarily | Expiry/recovery schedules with and without a prayer model; native pixels |
| Selective config invalidation | Less duplicate fetch/recompute/withdrawal | A→B→A, provider timezone, source evidence and stale completions | Effect matrix tests plus native settings transition capture |
| Separate builder draft/output/preview revisions | Fewer unnecessary navigation lifetimes | Embed output must stay current; deliberate Refresh must still reload | Unchanged-hash controls, input/change sequences, navigation/request measurements |
| Instance-owned construction/disposal | Fewer orphan resources and successor destruction | Partial construction and idempotent teardown must both work | Fault injection at each acquired resource; replacement and repeated-disposal controls |
| Explicit artifact staging/admission | Reject partial or invalid retained downloads | Do not destroy a previously verified artifact when a new download fails | Filesystem failure injection and native PowerShell/Bash execution |
| A bounded cache contract across both spectral layers | Predictable retention under varying inputs | Quantization/eviction must not alter scientific values or add excessive recomputation | Native input reachability, memory profile, numeric parity and hit/miss traces |
| Separate freshness time from retry scheduling | Preserve recovery after system-clock changes | Do not bless future/stale receipts or create a request storm | Exact-owner clock schedules, target reset and ordinary cooldown controls; native clock-change capture |
| Bound optional decode progress independently of scene time | Avoid an unbounded accepted-but-undisplayed attempt | Timeout must not republish obsolete pixels or damage valid retained frames | Controlled decode settlement/cancellation/deadline schedules; platform reachability remains unverified |
| Repair evaluator source boundaries | More trustworthy change comparisons | A green test may be achieved by skipping its intended assertion | Assertion-reachability checks, negative controls, explicit historical exclusions |

## Architecture choice and adoption order

Prefer small domain-owned transition functions, typed result envelopes, and resource records, with explicit cross-owner publication contracts. Keep scientific kernels and pure projections as functions. Use hierarchical/orthogonal state descriptions for independently changing domains. Avoid a single global FSM, which would create a combinatorial representation and encourage unrelated lifecycle coupling. Avoid a framework migration until a demonstrated recurring need justifies its dependency and maintenance cost. Diagrams alone are useful orientation but cannot enforce owner identity or verify a late callback.

Source ownership constrains which variations are admissible. `real-sky/core` is copied output, and `vendor/real-sky` is an immutable scientific baseline under the repository instructions. A spectral-cache repair therefore needs an accepted upstream/source-owner route or a separately approved integration change; directly patching the copied module is not an admissible shortcut. Frozen V1 likewise requires a separate compatibility decision. The ordinary native, builder and Moon integration owners can be considered independently without silently expanding that authority.

The per-machine catalogue already supplies an explicit candidate contract for every retained owner: states, guarded events, effects, invariants, recovery and cross-owner dependencies. Those contracts are the coordinates of this projected field; the schedules above identify where separate contracts interact. A new enum or framework is not automatically required for each row.

The first stage would record these contracts and repair the narrow reproduced joins. The second would introduce the configuration effect matrix, instance-owned teardown, and artifact admission. The third would measure whole-widget scheduling and retention before changing worker/cache policy. Each stage should retain a small reversible change, its source-bound baseline, a negative control, and an independent post-change review. This audit authorizes none of those production changes by itself.

The inner loop executes a specific configuration and event schedule and records its actual outputs, resources and failures. The outer GDOPL loop proposes a change to the project's representation, ownership, procedure or implementation, checks that it remains admissible, and compares those inner traces. A local green check does not certify the outer change. The audit's strongest result is therefore a set of concrete, falsifiable directions and counterdirections, with the obligations that decide whether a future step is actually better.
