# salah_widget — implicit state machines, audit and GDOPL projection

## Result and scope

The final catalogue contains **{{machine_count}} behavioral protocols** at the decomposition used in this audit: **{{implicit_count}} implicit**, **{{partly_count}} partly explicit**, and **{{explicit_count}} already explicit**. Already explicit protocols remain in the catalogue because they constrain the implicit ones around them. One legacy native Moon implementation is dormant in generated delivery; the native synthetic-star implementation is replaced while its integration contract remains active. Identical generated copies are not counted again.

The strongest additional value comes from exposing **cross-owner transitions**: what loses authority when time, configuration, weather, the document or a resource owner changes; which consumer must withdraw; and what evidence establishes actual publication. The application already contains substantial protections for late responses, A→B→A configuration changes, exact prayer-day ownership, renderer epochs, asset generations, worker cancellation and accepted-versus-displayed frames. Those are findings to preserve, not scaffolding to discard in a rewrite.

The established observations include two prayer/weather transition defects, a clock-discontinuity recovery conflict, invalid coordinate admission, unnecessary configuration and builder invalidation, conditional renderer construction/replacement defects, unbounded spectral-fit retention with reachable twilight inputs, installer admission/rollback inconsistencies, frozen V1 risks, and validation-instrument drift. Each has an individual evidence limit and proposed verification route. A native visual failure, measured performance loss, production incident frequency or release readiness is not inferred from a source-level probe.

This is a completed read-only assessment of the inspected population and its stated gaps. Production fixes, commits, issues, installation and deployment are outside the performed work. A completed audit record does not mean the application is defect-free or that every repair is complete.

## Exact revisions and ownership

| Subject | Pinned revision |
|---|---|
| Application | [`theislampill/salah_widget` — `f71fef6ccf7e4efcb57b5a26688d2360461a3253`](https://github.com/theislampill/salah_widget/tree/f71fef6ccf7e4efcb57b5a26688d2360461a3253) |
| Application tree | `79aedcac840d624b5ea423922314f0832dc3f750` |
| Methodology | [`theislampill/IMPLEMENTAUDIT.md` — `e78f7cb21af4197d490f10bc95917a4c75f748aa`](https://github.com/theislampill/IMPLEMENTAUDIT.md/tree/e78f7cb21af4197d490f10bc95917a4c75f748aa) |
| Generated root entry | Git blob `da7cfbb7263926cae378ebcc564a7b2dfffc3606`; SHA-256 `b4a6831b80439d3002f9cf4fae5bc15943bc9f9f2fa5ab0c4a1fc09f33a57298`; 1,586,459 bytes |

The report follows the repository's [source-ownership and visual-evidence instructions](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/AGENTS.md). Native runtime, configuration and builder changes belong in `src/native`; integration belongs in `real-sky/native-*` and `native-host-hooks.js`; Moon changes belong in `moon/src` and its documented asset/build owners. Root HTML, bundles, copied core and offline expansion are generated. `vendor/real-sky` and frozen V1 have additional preservation boundaries. A finding in copied code does not grant authority to patch that copy.

{{currentness_statement}}

## How the methodology was applied

The requested [IMPLEMENTAUDIT execution spine](https://github.com/theislampill/IMPLEMENTAUDIT.md/blob/e78f7cb21af4197d490f10bc95917a4c75f748aa/skills/implementaudit/SKILL.md) routes an audit without implementation authorization through its read-only lane. The audit object, source identity, ownership, selected actions, exclusions and terminal criteria are recorded in the evidence package. No implementation controller or release claim was fabricated for an imported read-only source snapshot.

For every machine, the catalogue records its retained state, meaningful states, events and guarded transitions, effects, invariants, expiry/cancellation/error/recovery, dependencies, source anchors, review disposition, relevant tests and remaining risk. Findings additionally carry impact, confidence, repair scope, effort/risk, owner, acceptance, verification and rollback. A positive inspection means no additional defect was established in that bounded review; it is not universal correctness proof.

The first discovery divided the source into native application, rendering/resource protocols, and configuration/delivery/legacy surfaces. Its named population was frozen at 82 entries before independent omission discovery. The root reverse census subsequently made the C/WASM arena and retained kernel state a separate R37 entry instead of leaving it implicit inside the JavaScript engine row. The independent second pass then worked backward from event sources, effects, storage, resources, cleanup and generated ownership, recording both additions and apparent omissions merged into existing owners.

{{second_pass_summary}}

Definition and granularity matter. A machine here retains action-distinguishing state across events, time, calls or persistence. A pure normalization or classifier is a derived region unless it participates in retained authority or lifetime. A loop inside one numerical calculation is not automatically another app machine. The resulting count is a useful, inspectable decomposition, not a unique mathematical count or a proof that every possible semantic abstraction has been enumerated.

## Highest-value findings

### NF01 — Reordered prayer times fail at the next-day transition

Admission permits reordered finite clocks, and today's event list is sorted. After today's last event, `model()` nevertheless constructs tomorrow's next event from `tomorrow.timings.Fajr`. The exact-source probe admits both records, sets the clock to 23:00, and gives tomorrow Isha at 00:31 and Fajr at 05:00. The model selects Fajr with **360 minutes** remaining; the earliest admitted next-day event is **91 minutes** away, a **269-minute discrepancy**. An ordinary-order control remains correct. This is a demonstrated admitted-input inconsistency; real-provider prevalence was not measured. [Admission](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/index.html#L990-L1010), [boundary selection](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/index.html#L2219-L2252).

The narrow repair direction is one date-aware chronological event-selection rule across admitted neighboring days. It must retain stable ties, exact timezone conversion and truthful missing-successor behavior. Rejecting previously supported reordered clocks would hide the boundary error by changing the input contract.

### NF02 — Expired weather can retain cloud coverage when prayer data is unavailable

At the same live location, civil midnight does not change the sky scene identity. If the next timetable is unavailable and weather then expires, the no-timetable branch clears the weather header and precipitation while bypassing `applyCloudState`. The controlled probe retains coverage **[0.92, 0.90, 0.60]** and the previous positive cloud-density profile after the weather decision becomes unavailable. The complete-atmosphere withdrawal control clears both. This establishes retained state and raster-call behavior, not native screen pixels. [Scene identity](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/index.html#L2142-L2158), [cloud withdrawal](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/index.html#L3024-L3042), [no-timetable render](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/index.html#L3252-L3262).

The required dependency is weather authority → cloud permission, independently of timetable readiness. An unavailable condition must not be relabelled as an observed clear sky, and a repair should preserve cloud population/motion and independent celestial rendering.

### XF02 — Wall-clock rollback can suppress the recovery that freshness now requires

The independent GDOPL review found a further conflict between source/receipt freshness and retry scheduling. Weather freshness rejects negative ages. Weather and radar cooldowns retain `Date.now()` attempt markers, while the visible loop offers refresh opportunities using elapsed time. A backward system-clock change can therefore reject weather while keeping replacement acquisition behind a negative cooldown delta. [Freshness and selection](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/index.html#L1291-L1304), [weather retry gate](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/index.html#L1368-L1378), [radar retry gate](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/index.html#L1445-L1451).

The exact-source probe has **19 controlled observations**, independently rerun by root with identical output. In a same-day, unchanged-target schedule, a one-hour backward change makes weather ineligible, and neither acquisition function passes its request gate after 60 or 600 elapsed seconds. Independent no-track boundary controls open the gates at original wall T+60 seconds and T+600 seconds; ordinary-clock and fresh full-track controls remain distinct. The tested gates also match generated root delivery exactly. The probe stops at a request-creation spy: it establishes gate behavior, not an actual OS/browser incident, network recovery or outage duration.

The candidate repair separates elapsed retry ownership from UTC source/receipt truth. It must preserve fail-closed freshness, attempt fences, normal cooldowns and the independent healthy-track gate.

### CF04 — Invalid provider coordinates become a successful, different location

The provider path checks null/NaN before passing coordinates to the general normalizer. The source-bound probe supplies **999, 999** and receives `ok: true` with **90, 180**, with no fallback call. This makes invalid acquisition data look like a valid site. Input validation belongs before normalization at this acquisition boundary; normalizing stored/form values is a separate contract. [Provider path](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/config.js#L248-L268).

### XF01 / CF05 — Two different levels invalidate more work than the edit requires

In the widget, changing only time format, date format or label takes the full runtime-generation/reset/weather/prayer path. Appearance already has a narrow branch. The exact `applyConfig` function executed with effect spies confirms which effects are selected; it does not measure a flash or actual network cost. [Owner](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/index.html#L3484-L3527).

In the builder, an unchanged `input`/`change` pair produces **two iframe source assignments with new revisions** while the serialized hash remains identical. This is a controlled source-assignment count; actual browser navigation cost, CPU and bandwidth impact remain unmeasured. Separate immediate draft/output updates from semantically changed preview navigation; retain an explicit forcing refresh. [Builder revision and bindings](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/src/native/builder.html#L212-L254).

### RF01 / RF02 — Resource ownership is incomplete at replacement and failed construction

Full Moon-wrapper reinstallation assigns a new global detail owner before disposing the old runtime. The old disposer reads that global, so it disposes the successor. The controlled two-install probe confirms both detail instances disposed with a new runtime installed. Ordinary first boot and incremental worker-source refinement are separate paths. [Installation](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/moon/src/moon-native.mjs#L1-L13), [disposal](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/moon/src/moon-native.mjs#L239-L280).

Native sky construction inserts a canvas before establishing a usable context and registered cleanup owner. Two controlled context failures leave two unowned canvases. The confirmed result is orphaned DOM resources; later browser or visual consequences remain unverified. Both findings favor instance-owned resource records and rollback during construction. [Constructor](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/real-sky/native-host.mjs#L60-L69).

### RF03 — A bounded outer cache hides an unbounded inner cache

The spectral selection cache stops retaining new entries at 12,000; its separate exact B–V fit map has no bound. A generic controlled sequence retains **12,020 fits** beside **12,000 outer entries**. A second source-bound probe uses the pinned twilight function and actual physical/preview color expressions: **1,000 altitudes produce 2,000 distinct colors and 1,989 retained fitted spectra**; 11 inputs intentionally use model fallback. This establishes retention and current caller reachability. It does not measure heap pressure, latency or a flicker cause. [Fit cache](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/real-sky/core/src/spectral.mjs#L9-L41), [physical caller](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/real-sky/core/src/sky-background.mjs#L72-L82), [preview caller](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/real-sky/native-preview.mjs#L332-L340).

Any repair must preserve exact scientific output and follow an explicitly accepted canonical-source route. Direct edits to generated copied core or immutable scientific vendor are outside the current ownership contract.

### Delivery, legacy and evaluator findings

PowerShell can treat a partial download as cached success, removes the previous unpacked directory before replacement succeeds, and returns a preset path even after JSON parsing failed. Both installer families collapse malformed Firefox metadata into absence flags. These are source-confirmed ordering/state distinctions; no native Windows installation was run. [Download/extraction/preset](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/install.ps1#L345-L409), [Firefox status](https://github.com/theislampill/salah_widget/blob/f71fef6ccf7e4efcb57b5a26688d2360461a3253/install.ps1#L231-L267).

Frozen V1 has unfenced old async work, a reset path that reports deletion after a failed storage removal, and a coarse-detection timeout retired at headers before the body finishes. Those are separate compatibility findings, not attributed to current root behavior. V1 remains unchanged; any repair needs its own ownership/version decision.

The geocoder also collapses transport failure into the same empty result as a valid zero-match search. That is a lower-priority observability issue. Retained regression fixtures have several stale bootstrap assumptions, and the regression runner overwrites a monotonic start timestamp with a JSON text offset, invalidating some reported durations. Those evaluator issues remain distinct from application defects.

## Verification evidence and limits

| Evidence | Observed outcome | Meaning and limit |
|---|---|---|
| Root native `*.test.cjs` cohort | 538 tests: initially 533 pass, 1 VM timeout, 4 TODO | The unchanged 16-case failing suite passed in isolation; 534 non-TODO cases have pass evidence. Initial timeout retained; resource contention is plausible, not uniquely proved. |
| Renderer cohort | Initial 250 passing cases plus 25 passing cases from five suites rerun after exact missing input restoration | 275 distinct cases have pass evidence. The initial five failures occurred at suite load for missing scientific input. |
| 27 retained named native commands | 13 exit successfully; 14 remain nonzero | Each nonzero result is classified as fixture drift, missing historical Git inputs, or both. The aggregate runner remains red. |
| New focused audit probes | Prayer boundary, weather/cloud expiry, config effects, malformed provider input, builder navigation, legacy reset/deadline, renderer replacement/construction, cache retention and clock-discontinuity gates | Exact owners or source expressions with controlled dependencies; root independently reran the specialist probes. |
| Source identity | {{verified_blob_count}} local blobs match their Git object IDs | Identity proof for downloaded bytes, not proof of semantic correctness or deployment identity. |

The local snapshot was imported through GitHub rather than cloned with history. Full `offline.html` (81,698,493 bytes), the 9.8 MB generated native data script and most large lunar chunks were reconciled through source/generator/data relationships without full-byte delivery qualification. The complete scientific/asset suite, full regeneration, native browser scenes/motion, live-provider behavior, platform install, permission prompts and production heap/timing remain unverified. Vendor demonstration applications and their research tooling are separate retained scientific support, not deployed widget viewers under this audit scope.

The report preserves the distinction between observed failure, source-proven reachable behavior, controlled counterexample, conditional hypothesis, intentional design, fixture defect and unavailable environment. It does not promote old PASS receipts or a fresh status file into current release evidence.

## Hypotheses and rejected leads

Three first-pass hypotheses remain explicitly unverified: a countdown-fit cache key may omit a path dependency; a concrete reachable render exception could expose RAF recovery weakness; and a never-settling solar-mask decode with a frozen scene clock could block optional publication without an intrinsic wall-clock deadline. None is presented as a demonstrated native defect. The catalogue states the discriminator needed for each.

Continuous mask-decode replacement starvation was rejected because publication refuses new work while one decode is pending. Treating legacy synthetic stars/Moon as competing current generated owners was rejected after generator reconciliation. Historical particle-selector drift and a concurrent VM timeout were rejected as sufficient evidence of product failure. A retained legacy elevation scalar was also insufficient to establish stale physical-renderer height: generated delivery installs a separate generation/coordinate-bound elevation owner and removes the legacy star implementation. Existing declared physical fallback, bounded worker retry, and the whole-document native loop lifetime were assessed against their actual contracts rather than rejected merely for using fallback, retry or long-lived listeners.

## Self-critique and closure boundary

1. The chosen state-machine granularity is explicit and source-bound, but not uniquely canonical. The second pass and exclusion ledger reduce omission risk; they do not prove semantic exhaustiveness.
2. The strongest counterexamples exercise real source functions with controlled dependencies. Their native visual/platform magnitude still needs the repository's actual acceptance evidence before a repair is qualified.
3. Generated delivery and immutable scientific inputs constrain both coverage and repair ownership. This report identifies those limits instead of treating a source audit as a deployable release qualification.

{{independent_review_statement}}

Every catalogue entry has an audit disposition and remaining-risk statement. Confirmed repairs are deferred because this task is an audit and architectural projection. Conditional hypotheses are terminally recorded as unverified, intentional behavior is retained, and rejected claims remain documented with their reasons. The following catalogue and finding contracts are the complete detailed deliverable for the inspected population.
