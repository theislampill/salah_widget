"""Assemble the read-only audit deliverable from source-bound specialist records.

This script writes audit artifacts only. It never writes inside salah_widget/.
"""
from pathlib import Path
import copy
import collections
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent.parent
E = ROOT / 'evidence'
OUT = ROOT / 'deliverables'
OUT.mkdir(exist_ok=True)
COMMIT = 'f71fef6ccf7e4efcb57b5a26688d2360461a3253'
METHOD = 'e78f7cb21af4197d490f10bc95917a4c75f748aa'
BASE = f'https://github.com/theislampill/salah_widget/blob/{COMMIT}/'

def read(path):
    return json.loads((E / path).read_text())

def transform(value, lane):
    if isinstance(value, list):
        return [transform(x, lane) for x in value]
    if isinstance(value, dict):
        return {k: transform(v, lane) for k, v in value.items()}
    if not isinstance(value, str):
        return value
    if lane == 'configuration':
        value = re.sub(r'\bF(\d{2})\b', r'CF\1', value)
    if lane == 'native':
        value = value.replace('root-F01', 'XF01')
    if lane == 'rendering':
        value = value.replace('canonical Horizon source', 'canonical scientific source/upstream under an explicitly accepted ownership route')
        value = value.replace('owning Horizon-source route', 'explicitly accepted canonical scientific source/upstream route')
        value = re.sub(r'(?<![/\w-])moon-engine\.mjs:', 'moon/src/moon-engine.mjs:', value)
    return value

def explicitness(nature):
    n = nature.lower()
    if 'partly' in n or 'partial' in n or 'mixed' in n:
        return 'partly explicit'
    if 'explicit' in n:
        return 'already explicit'
    return 'implicit'

def disposition(value):
    return value.get('disposition', '') if isinstance(value, dict) else str(value or '')

def scope(mid, m):
    if mid == 'N11':
        return 'dormant native-source compatibility'
    if mid.startswith('C'):
        number = int(mid[1:])
        if 15 <= number <= 23:
            return 'frozen V1 compatibility'
        if 8 <= number <= 14 or number == 24:
            return 'delivery and build support'
    return m.get('scope_class', 'current runtime and integration')

def source_url(s):
    p = s.get('path', '')
    if p.startswith('evidence/') or not p:
        return None
    u = BASE + p
    if isinstance(s.get('start'), int):
        u += '#L' + str(s['start'])
        if isinstance(s.get('end'), int) and s['end'] != s['start']:
            u += '-L' + str(s['end'])
    return u

lanes = {}
machines = []
findings = []
hypotheses = []
rejected = []
for lane in ['native', 'rendering', 'configuration']:
    x = transform(read(f'lanes/{lane}.json'), lane)
    lanes[lane] = x
    for raw in x['machines']:
        m = copy.deepcopy(raw)
        m['origin_lane'] = lane
        m['explicitness'] = explicitness(m['nature'])
        m['scope_class'] = scope(m['id'], m)
        m['inspection_disposition'] = disposition(m.get('audit'))
        m['source_commit'] = COMMIT
        if m['id'] == 'R26':
            # SD-F02 is an accepted report correction. Preserve the raw lane
            # packet and qualify the derived contract against the C/JS owner.
            m['states'].append('native scene refusal / instance recovery unproven')
            m['transitions'][2] = ('On a camera miss, successful begin_scene clears the camera key until the full camera pass completes. '
                                   'A begin_scene refusal throws before that key is cleared; failed allocation can already have mutated native state.')
            m['invariants'][1] = ('After successful begin_scene, a partial camera pass cannot be reused; a completed camera after ordinary lighting cancellation retains its geometry. '
                                  'This does not establish reuse after native allocation or other scene-admission refusal.')
            m['recovery'] = ('Ordinary cancellation releases active and invalidates incomplete lighting; camera reuse remains subject to successful scene initialization and its exact key. '
                             'Native frame-allocation refusal can leave changed kernel state and a stale cameraKey, so arbitrary same-instance error recovery is not established. '
                             'The shipped non-AbortError path makes the row bridge failure sticky and closes the current worker; new-worker/new-instance recovery is the supported boundary. '
                             'No public dispose exists for a standalone engine; its owner must retire the realm/resource after such refusal. See R37 and SD-F02.')
            m['audit']['disposition'] = ('source-proven exclusive execution and ordinary cancellation guards; recovery claim qualified by independent SD-F02; '
                                          'full assets, allocation failure execution and source-to-WASM equivalence remain unverified')
            m['audit']['report_correction_ids'] = ['SD-F02']
            m['inspection_disposition'] = m['audit']['disposition']
            m['remaining_risk'] += (' Failed-growth-then-reuse behavior is a static contract hazard, not a reproduced native publication defect. '
                                    'Standalone recovery after refusal needs a separate explicit requirement and bounded verification.')
            m['source'].extend([
                {'path': 'moon/src/moon_kernel.c', 'start': 234, 'end': 242, 'symbol': 'begin_scene frame allocation'},
                {'path': 'moon/src/moon-pool.mjs', 'start': 18, 'end': 26, 'symbol': 'sticky non-AbortError failure'},
                {'path': 'moon/src/moon-native.mjs', 'start': 53, 'end': 67, 'symbol': 'failed / closeWorker'},
                {'path': 'moon/src/moon-native.mjs', 'start': 195, 'end': 198, 'symbol': 'worker error retirement'}
            ])
        for s in m.get('source', []):
            if isinstance(s, dict) and source_url(s):
                s['url'] = source_url(s)
        machines.append(m)
    for raw in x.get('findings', []):
        f = copy.deepcopy(raw)
        f['origin_lane'] = lane
        f['audit_disposition'] = 'inspected; finding retained'
        f['implementation_disposition'] = 'deferred — read-only audit and projection'
        f['repair_subtype'] = f.get('repair_class', '')
        f['repair_class'] = 'product-or-skill defect'
        if f['id'] == 'RF04':
            f['audit_disposition'] = 'unverified conditional liveness hypothesis'
            f['repair_class'] = None
            f['repair_class_status'] = 'Unverified hypothesis; no defect repair class adopted.'
            hypotheses.append(f)
        else:
            findings.append(f)
    for c in x.get('unverified_or_rejected', []):
        (hypotheses if c.get('disposition') == 'unverified' else rejected).append(c)
    rejected.extend(x.get('rejected_leads', []))

for raw in read('root_findings.json'):
    f = copy.deepcopy(raw)
    f['id'] = 'XF01' if f['id'] == 'F01' else 'EF01'
    f['origin_lane'] = 'root integration'
    f['repair_subtype'] = f.get('repair_class', '')
    f['repair_class'] = 'instrument/acceptance defect' if f['id'] == 'EF01' else 'product-or-skill defect'
    if f['id'] == 'XF01':
        f['machines'] = ['N01', 'N03', 'N04', 'N08', 'N10', 'N13']
        f['smallest_safe_change'] = ('Derive a configuration effect matrix and the minimum necessary ownership revisions; initially add narrowly guarded formatting/label-only branches '
                                    'without removing current location-generation fences, adopted timezone or acquisition-evidence identity. Separate weather units from radar dependencies.')
    findings.append(f)

additional_root = E / 'additional_root_findings.json'
if additional_root.exists():
    findings.extend(json.loads(additional_root.read_text()))
    for m in machines:
        if m['id'] in ['N02', 'N08', 'N09', 'N10', 'N19']:
            m.setdefault('cross_machine_findings', []).append('XF02')
            m['inspection_disposition'] += '; XF02 establishes conditional clock-discontinuity coupling'
            if isinstance(m.get('audit'), dict):
                m['audit']['disposition'] = m['inspection_disposition']
            m['remaining_risk'] += (' Wall-clock rollback can reject weather freshness while weather/radar retry gates remain closed; '
                                    'exact-source gates were exercised under XF02, without native browser/provider qualification.')
            if m['id'] == 'N08':
                m['audit']['performance_scale'] = m['audit']['performance_scale'].replace('60s retry bound', '60s wall-time retry gate; XF02 shows that backward wall-clock changes extend elapsed waiting')

# The omission review has an independent schema. Root's accepted additions are
# recorded separately so a reviewer suggestion cannot silently become authority.
accepted_path = E / 'second_pass_acceptance.json'
accepted = json.loads(accepted_path.read_text()) if accepted_path.exists() else {
    'status': 'pending', 'new_machines': [], 'new_findings': [],
    'summary': 'Independent omission review is still in progress.'}
for raw in accepted.get('new_machines', []):
    m = copy.deepcopy(raw)
    m['origin_lane'] = 'independent second discovery / root accepted'
    m['explicitness'] = explicitness(m.get('nature', 'implicit'))
    m['scope_class'] = scope(m['id'], m)
    m['inspection_disposition'] = disposition(m.get('audit'))
    m['source_commit'] = COMMIT
    for s in m.get('source', []):
        if isinstance(s, dict) and source_url(s):
            s['url'] = source_url(s)
    machines.append(m)
findings.extend(accepted.get('new_findings', []))
hypotheses.extend(accepted.get('hypotheses', []))
rejected.extend(accepted.get('rejected', []))

# Shared reporting fields distinguish an inspected observation from a repair.
for f in findings:
    if 'category' not in f:
        f['category'] = 'Evidence / evaluation' if f['id'] == 'EF01' else 'Correctness / state ownership / efficiency'
    f.setdefault('owner_source', f.get('owner', 'See source anchors in the affected machine records.'))
    f.setdefault('fix_sketch', f.get('smallest_safe_change', f.get('fix_route', f.get('fix_sketch_route'))))
    f.setdefault('rollback', f.get('rollback_plan_closure', 'No application mutation in this audit; any later repair must carry its own rollback.'))
    f.setdefault('remaining_risk', f.get('risk'))
    f.setdefault('route', 'deferred')
    f.setdefault('implementation_disposition', 'deferred — read-only audit and architectural projection')
    f.setdefault('deferred_rationale', 'The finding is retained; product/instrument repair and its acceptance are outside the performed read-only work.')
for f in hypotheses:
    f.setdefault('title', f.get('claim', f.get('name', f['id'])))
    f.setdefault('category', 'Correctness / liveness / unverified contract')
    f.setdefault('evidence', f.get('reason', 'See source anchors and schedule in this record.'))
    f.setdefault('impact', 'Conditional impact only; a reachable counterexample or platform settlement failure is not established.')
    f.setdefault('effort', 'A bounded discriminator is required before estimating a repair.')
    f.setdefault('risk', 'Premature repair could add complexity or hide the actual invariant without an established failing schedule.')
    f.setdefault('confidence', 'Unverified as an application defect; source concern and next discriminator are retained.')
    f.setdefault('fix_sketch', f.get('next_evidence', f.get('fix_sketch_route')))
    f.setdefault('repair_class', None)
    f.setdefault('repair_class_status', 'No defect repair class adopted until the hypothesis is established.')
    f.setdefault('owner_source', 'See source anchors for ' + ', '.join(f.get('machines', [])))
    f.setdefault('acceptance', f.get('next_evidence', 'Establish or reject the conditional schedule before adopting a repair.'))
    f.setdefault('verification', f.get('next_evidence', 'See the bounded discriminator and source trace in this record.'))
    f.setdefault('rollback', f.get('rollback_plan_closure', 'No application change; retain the hypothesis and original evidence if a later discriminator rejects it.'))
    f.setdefault('remaining_risk', f.get('reason', f.get('risk')))
    f.setdefault('route', 'deferred')
    f.setdefault('audit_disposition', 'unverified; terminally recorded with a discriminator')

rejected.append({
    'id': 'GR06', 'claim': 'A retained legacy siteElev scalar necessarily leaks stale height into the current physical renderer.',
    'disposition': 'rejected',
    'reason': 'Generated delivery substitutes the legacy star implementation. The physical renderer reads a separate generation/coordinate-bound accepted elevation record and falls back explicitly when that record is ineligible.',
    'evidence': ['tools/build_native.py:50–72,82', 'real-sky/native-host-hooks.js:2–8,17–20,36'],
    'limit': 'Does not claim every legacy diagnostic scalar is reset; no native pixel or source-to-runtime execution proof is inferred.'
})

ids = [m['id'] for m in machines]
assert len(ids) == len(set(ids)), 'Duplicate catalogue ID'
for m in machines:
    for key in ['id', 'name', 'source', 'states', 'transitions', 'invariants', 'recovery', 'dependencies', 'inspection_disposition', 'remaining_risk']:
        assert m.get(key), (m['id'], key)
assert len({f['id'] for f in findings}) == len(findings)

natures = collections.Counter(m['explicitness'] for m in machines)
scopes = collections.Counter(m['scope_class'] for m in machines)
hashes = read('source_hashes.json')
verified_count = sum(bool(x.get('matches_git_blob')) for x in hashes)
verification_path = E / 'final_verification.json'
verification = json.loads(verification_path.read_text()) if verification_path.exists() else {'status': 'pending'}
review_path = E / 'review_acceptance.json'
review = json.loads(review_path.read_text()) if review_path.exists() else {'status': 'pending'}
final = accepted.get('status') == 'accepted' and verification.get('status') == 'verified' and review.get('status') == 'accepted'

metadata = {
    'title': 'salah_widget — implicit state machines, audit and GDOPL projection',
    'report_state': 'FINAL read-only assessment' if final else 'DRAFT — verification or independent review pending',
    'repository': 'theislampill/salah_widget', 'source_commit': COMMIT,
    'source_tree': '79aedcac840d624b5ea423922314f0832dc3f750',
    'methodology_repository': 'theislampill/IMPLEMENTAUDIT.md', 'methodology_commit': METHOD,
    'machine_count': len(machines), 'explicitness_counts': dict(natures),
    'scope_counts': dict(scopes), 'established_observation_count': len(findings),
    'hypothesis_count': len(hypotheses), 'verified_blob_count': verified_count,
    'no_application_mutation': True,
    'granularity': 'Retained action-distinguishing protocol, including relevant partly/already-explicit dependencies; no duplicated generated copies.',
    'source_identity_limit': 'Verified acquired blobs; omitted large generated data/assets and historical support are listed separately. Not native visual, deployment, or performance qualification.',
    'verification': verification,
    'second_pass_acceptance': accepted,
    'independent_review_acceptance': review,
    'normalizations': [
        'Configuration finding F01–F10 are namespaced CF01–CF10.',
        'Root broad configuration reset is XF01; evaluator drift is EF01.',
        'Nature/disposition spelling normalized without changing source machine records.',
        'Renderer unqualified moon-engine citation resolved to moon/src/moon-engine.mjs per structural verification.',
        'Unsupported Horizon owner name replaced with canonical scientific source/upstream under an explicitly accepted ownership route.',
        'R26 recovery qualified under accepted SD-F02: ordinary cancellation differs from native allocation refusal; shipped non-AbortError recovery retires the worker. Raw lane evidence is preserved.',
        'RF04 remains an unverified hypothesis; no defect or instrument-failure authority inferred from its original repair-class label.',
        'Repair classes normalized to the methodology taxonomy; original detailed descriptions retained as repair_subtype.',
        'XF01 proposes the minimum necessary ownership revisions, not a fixed number of independent revision counters.'
    ]
}
catalogue = {'metadata': metadata, 'machines': machines, 'findings': findings,
             'unverified_hypotheses': hypotheses, 'rejected_or_qualified_leads': rejected,
             'inherited_v1_mappings': lanes['configuration'].get('inherited_protocols', []),
             'coverage_exclusions': {k: v.get('exclusions', []) for k, v in lanes.items()}}
catalogue_path = OUT / 'salah_widget_state_machine_catalogue.json'
catalogue_path.write_text(json.dumps(catalogue, indent=2, ensure_ascii=False) + '\n')

substitutions = {
    'machine_count': len(machines), 'implicit_count': natures['implicit'],
    'partly_count': natures['partly explicit'], 'explicit_count': natures['already explicit'],
    'verified_blob_count': verified_count,
    'currentness_statement': verification.get('currentness_statement', 'Final branch and byte-identity reconciliation is pending.'),
    'second_pass_summary': accepted.get('summary', ''),
    'independent_review_statement': review.get('summary', 'Independent projection review is pending.')
}
overview = (E / 'REPORT_OVERVIEW.md').read_text()
for k, v in substitutions.items():
    overview = overview.replace('{{' + k + '}}', str(v))
assert not re.search(r'\{\{[^}]+\}\}', overview), 'Unresolved report placeholder'

def label(k):
    return k.replace('_', ' ').capitalize()

def md(value):
    if isinstance(value, dict):
        if value.get('path'):
            suffix = (f":{value['start']}" if value.get('start') else '') + (f"–{value['end']}" if value.get('end') and value.get('end') != value.get('start') else '')
            u = value.get('url') or source_url(value)
            ref = f"[{value['path']}{suffix}]({u})" if u else f"`{value['path']}{suffix}`"
            return ref + (' — ' + value['symbol'] if value.get('symbol') else '')
        return '\n\n'.join('**' + label(k) + ':** ' + md(v) for k, v in value.items())
    if isinstance(value, list):
        return '\n' + '\n'.join('- ' + md(v).replace('\n', '\n  ') for v in value) + '\n'
    return str(value)

sections = []
groups = [
    ('Native application', [m for m in machines if m['id'].startswith('N')]),
    ('Rendering, workers and retained resources', [m for m in machines if m['id'].startswith('R')]),
    ('Configuration, delivery and frozen V1', [m for m in machines if m['id'].startswith('C')]),
    ('Independent second-discovery additions', [m for m in machines if m['id'].startswith('S')])
]
for group, rows in groups:
    if not rows:
        continue
    table = '| ID | Protocol | Explicitness | Scope |\n|---|---|---|---|\n'
    for m in rows:
        table += f"| [{m['id']}](#{m['id']}) | {m['name']} | {m['explicitness']} | {m['scope_class']} |\n"
    sections.append({'heading': group, 'index': table, 'machines': [
        {'id': m['id'], 'name': m['name'], 'explicitness': m['explicitness'],
         'body': '\n\n'.join('### ' + label(k) + '\n\n' + md(v) for k, v in m.items()
                             if k not in ['id', 'name', 'origin_lane', 'source_commit'])}
        for m in rows]})

contracts = []
for f in findings + hypotheses:
    name = f.get('title', f.get('claim', f.get('name', f['id'])))
    contracts.append({'id': f['id'], 'name': name,
        'body': '\n\n'.join('### ' + label(k) + '\n\n' + md(v) for k, v in f.items() if k not in ['id', 'title', 'name'])})

payload = {'metadata': metadata, 'overview': overview, 'catalogue_sections': sections,
    'finding_contracts': contracts, 'gdopl': (E / 'GDOPL_FINAL.md').read_text(),
    'rejected': md(rejected), 'source_pin': COMMIT,
    'second_discovery': (E / 'lanes/second-discovery.md').read_text() if (E / 'lanes/second-discovery.md').exists() else 'Pending.',
    'projection_review': (E / 'lanes/gdopl-review.md').read_text() if (E / 'lanes/gdopl-review.md').exists() else 'Pending.',
    'structural_verification': (E / 'lanes/structural-verification.md').read_text() if (E / 'lanes/structural-verification.md').exists() else 'Pending.'}
(E / 'report_render_input.json').write_text(json.dumps(payload, ensure_ascii=False) + '\n')
print(json.dumps({'state': metadata['report_state'], 'machines': len(machines), 'explicitness': dict(natures),
    'scopes': dict(scopes), 'observations': len(findings), 'hypotheses': len(hypotheses),
    'catalogue_sha256': hashlib.sha256(catalogue_path.read_bytes()).hexdigest()}, indent=2))
