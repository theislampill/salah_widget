import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const {chromium}=await import(pathToFileURL(path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES,'playwright/index.mjs')));
const browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
const out=path.join(root,'evidence/report-layout');fs.mkdirSync(out,{recursive:true});
const report=pathToFileURL(path.join(root,'deliverables/salah_widget_state_machine_audit.html')).href;
const checks=[];
try{
 for(const [name,width,height] of [['desktop',1440,1000],['mobile',390,844]]){
  const page=await browser.newPage({viewport:{width,height},deviceScaleFactor:1});
  const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto(report,{waitUntil:'load'});
  const structure=await page.evaluate(()=>{
   const ids=Array.from(document.querySelectorAll('[id]'),x=>x.id);
   const links=Array.from(document.querySelectorAll('a[href^="#"]'),x=>x.getAttribute('href').slice(1));
   return {title:document.title,records:document.querySelectorAll('details[id]').length,
    machineRecords:Array.from(document.querySelectorAll('details[id]')).filter(x=>/^[NRC]\d\d$/.test(x.id)).length,
    duplicateIds:ids.filter((x,i)=>ids.indexOf(x)!==i),missingFragmentTargets:links.filter(x=>!document.getElementById(x)),
    viewport:innerWidth,documentWidth:document.documentElement.scrollWidth,
    unresolvedPlaceholders:/\{\{[^}]+\}\}/.test(document.body.innerText),
    externalMedia:document.querySelectorAll('script[src],img[src],link[rel="stylesheet"]').length};
  });
  await page.screenshot({path:path.join(out,name+'-overview.png')});
  await page.locator('a[href="#R26"]').first().click();
  const opened=await page.locator('#R26').evaluate(e=>e.open);
  await page.locator('#R26').screenshot({path:path.join(out,name+'-R26.png')});
  checks.push({name,...structure,recordLinkOpens:opened,pageErrors:errors});
  await page.close();
 }
}finally{await browser.close();}
fs.writeFileSync(path.join(out,'checks.json'),JSON.stringify({scope:'Report artifact layout and navigation only; no app/browser qualification',checks},null,2)+'\n');
console.log(JSON.stringify(checks,null,2));
if(checks.some(c=>c.machineRecords!==83||c.duplicateIds.length||c.missingFragmentTargets.length||c.unresolvedPlaceholders||c.pageErrors.length||!c.recordLinkOpens||c.documentWidth>c.viewport))process.exitCode=1;
