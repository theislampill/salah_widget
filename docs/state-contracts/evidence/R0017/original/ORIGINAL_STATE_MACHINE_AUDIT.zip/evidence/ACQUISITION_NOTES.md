# Acquisition abnormalities and scope

All authored app runtime files selected in the first import (78 files including frozen-v1 and owner docs/build scripts) matched Git blob IDs. Supporting imports encountered a Github contents endpoint limitation: files larger than about 1 MiB returned empty content. Placeholder imports failed blob validation and were removed before use. Root generated index.html was then recovered by the Git blob endpoint and matched its exact expected Git ID. Large generated lunar texture chunk files and an oversized scientific fixture remain omitted; these are data payloads, not additional authored stateful code. Three fixture JSON files required restoration of their original CRLF endings to match Git blob IDs; exact byte checks then passed.

The recursive historical docs tree request returned a transport error. A nonrecursive root tree and direct current owner-document reads succeeded. A guessed POST_CP9_DAG.md path returned 404; the actual integration doc names DAG_LEDGER.json. No absent file was treated as read or passing evidence. Offline.html (81,698,493 bytes) is not fully imported or rebuilt; generated-entry parity has a narrower boundary.

These are transport/input completeness limits. They are not product bug evidence and do not qualify release, deployment or native visual acceptance.
