# GR04 exact-source clock-discontinuity probe

**Result: the bounded synthetic assertions passed.** GR04 is now supported by execution of the unchanged source gate functions, not only static reasoning. This is evidence of conditional freshness and scheduling behavior, not a native-browser, provider, performance, or product-readiness verdict. Root retains acceptance and classification authority.

## Exact source and controls

The probe reads `salah_widget/src/native/index.html` from the pinned imported snapshot `f71fef6ccf7e4efcb57b5a26688d2360461a3253` and requires SHA256 `6054f1eb3e7f04aa5975707345810b64fc824bc99e17ce3798369a959a123fad` before and after execution. It extracts verbatim `weatherEligibility`, `selectedWeather`, `fetchWeather`, and `fetchRadar`, plus the unchanged numeric/coordinate/target helpers and relevant constants. The result JSON records every slice's source location and SHA256. No function body is rewritten or instrumented.

`Date.now()` and retained input state are controlled. The target generation and coordinates remain fixed; live mode is selected; both busy flags are false. No configuration reset occurs. `beginRequest` records which acquisition owner reaches that boundary and returns `null`. Therefore no operation, attempt, timer, request, response, or UI mutation is created. Reaching that spy is **not** a dispatched request. Forbidden dependencies are guarded and were never reached.

The settled fixture records both attempt times and the weather receipt at T = `2026-11-06T14:00:00.000Z`; current source validity begins thirty seconds earlier. The rollback occurs at T + one second and subtracts one hour from wall time without moving the modeled elapsed clock. Every tested instant stays within the same UTC civil day. The fixture satisfies the tested eligibility predicates; upstream provider/record admission is outside this probe.

Two sequential rollback traces use the same retained owner throughout: one with current weather but no hourly track, and one with a present hourly track. The current-only fixture isolates the one-minute retry gate; the full-track fixture protects against confusing it with the separate fifteen-minute freshness gate.

## Observations

| Controlled opportunity | Current weather eligible/selected? | Weather reaches `beginRequest`? | Radar reaches `beginRequest`? |
|---|---|---|---|
| Before rollback, T + 1 s | Yes | No | No |
| Immediately after the one-hour rollback | No | No | No |
| Sixty elapsed seconds after rollback | No | No | No |
| Six hundred elapsed seconds after rollback | No | No | No |
| Original wall T + 59.999 s, current-only boundary fixture | Yes | No | No |
| Original wall T + 60 s, current-only boundary fixture | Yes | Yes | No |
| Original wall T + 599.999 s, current-only boundary fixture | Yes | Yes | No |
| Original wall T + 600 s, current-only boundary fixture | Yes | Yes | Yes |

The first four rows hold for both track states. After rollback, source and receipt ages are negative, so `weatherEligibility` rejects the retained record and `selectedWeather` returns no current record. Both request cooldowns remain closed even after the modeled elapsed intervals have passed.

The boundary fixtures are independent snapshots of the same settled retained state. With rollback they require 3,660/4,200 elapsed seconds from T to reach the original weather/radar wall thresholds; normal no-rollback controls reach those thresholds at 60/600 elapsed seconds. One millisecond before each threshold, its respective gate stays closed.

The full-track normal controls behave differently as expected: fresh complete weather still blocks weather acquisition at T + 60 s and T + 600 s, while radar reaches its gate at T + 600 s. A fresh record plus a track legitimately takes the earlier freshness return. That control prevents overstating “weather always reacquires after one minute.”

There were **19 observation rows**, **9 recorded boundary reaches**, **zero forbidden dependency calls**, and **zero elapsed-clock reads by the tested functions** at these gates. All target/configuration/retained-state assertions passed, and the canonical source hash remained unchanged. Modeled elapsed time is a controlled input for comparing schedules, not a measurement of real runtime performance.

## Assessment and limits

The probe supports the GR04 conflict: a backward wall-clock correction can withdraw current-weather eligibility while weather/radar request gates wait for the old wall-time deadlines. It supports separating elapsed scheduling bounds from source/receipt UTC validity in a future authorized variation. It does not prove that any corrective implementation is correct or adopted.

The caller refresh loop, actual system clock, browser rendering, transport completion, new response adoption, active requests, explicit target resets, previews, day rollover, and DST transitions are not exercised. `beginRequest` deliberately does not renew attempt timestamps; the later boundary rows therefore do not represent a continuous history of successful acquisitions after prior rows. No application source, projection, lane packet, or machine count was modified.

## Replay

From the audit workspace:

```sh
node evidence/probes/root/clock-discontinuity.cjs > evidence/probes/root/clock-discontinuity.json
```

The probe exits nonzero on assertion or source-pin failure. It emits its JSON result only after all assertions pass. The recorded run used Node `v24.22.1`.
