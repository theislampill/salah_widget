'use strict';
// Source-bound schedule probes. No browser, fetch, clipboard, install or build sinks.
const fs=require('node:fs');
const assert=require('node:assert/strict');
const root='/workspace/scratch/8ab1bbbe9699/salah_widget';
const {environment,fixture,deferred,drain}=require(root+'/tests/r000f-fixture.cjs');
const out=[];
function configEnv(file){const e=environment();e.sandbox.AbortController=AbortController;e.run(fs.readFileSync(root+'/'+file,'utf8'));return e;}
(async()=>{
  const e=configEnv('src/native/config.js');let calls=0;
  e.sandbox.fetch=async()=>{calls++;return {ok:true,json:async()=>({latitude:'999',longitude:'999',city:'Controlled fixture',country_code:'US'})};};
  const r=await e.sandbox.SalahConfig.coarseDetect({timeoutMs:10});
  assert.equal(r.ok,true);assert.equal(r.cfg.lat,90);assert.equal(r.cfg.lon,180);assert.equal(calls,1);
  out.push({check:'coarse provider invalid coordinate admission',result:'confirmed',supplied:[999,999],adopted:[r.cfg.lat,r.cfg.lon],providerCalls:calls});
  const b=fixture('builder');const before=b.run('rev');const hash=b.hash();
  b.input('method','4','input');b.input('method','4','change');
  assert.equal(b.hash(),hash);assert.equal(b.run('rev')-before,2);
  out.push({check:'builder unchanged input/change preview revision',result:'confirmed',sameSerializedHash:true,previewNavigationsAdded:b.run('rev')-before});
  for(const file of ['src/native/config.js','v1/config.js']){
    const t=configEnv(file),body=deferred();let n=0,settled=false;
    t.sandbox.fetch=async()=>({ok:true,json:()=> ++n===1?body.promise:Promise.resolve({loc:'40,-74',city:'Fallback',country:'US'})});
    t.sandbox.SalahConfig.coarseDetect({timeoutMs:10}).then(()=>{settled=true;});
    await drain();await t.advance(11);await drain();
    assert.equal(settled,file.startsWith('src/'));
    out.push({check:'headers-before-body deadline',source:file,settledAfterDeadline:settled,bodyRequests:n,result:file.startsWith('src/')?'current fallback owns deadline':'frozen v1 deadline retired at headers'});
  }
  const v=configEnv('v1/config.js'),vkey='salah_widget:v1:config:v1';
  v.storage.set(vkey,JSON.stringify({v:1,lat:40,lon:-74,source:'manual'}));
  v.sandbox.localStorage.removeItem=key=>{if(key===vkey)throw new Error('controlled denied deletion');v.storage.delete(key);};
  const messages=[];v.sandbox._setStatus=(text,error)=>messages.push({text,error:!!error});
  v.sandbox.SalahConfig.coarseDetect=async()=>({ok:false});
  v.run('var _storageErr="controlled prior error";var _hashCfg={};');
  const old=fs.readFileSync(root+'/v1/index.html','utf8');
  v.run(old.slice(old.indexOf('async function _resetLocal(){'),old.indexOf('function _openSettings(){')));
  await v.run('_resetLocal()');assert.ok(v.storage.has(vkey));assert.equal(v.run('_storageErr'),null);
  assert.ok(messages.at(-1).text.startsWith('Local settings cleared'));
  out.push({check:'v1 reset failed removal',result:'confirmed',savedRecordRetained:true,storageErrorCleared:true,messages});
  const g=configEnv('src/native/config.js');g.sandbox.fetch=async()=>{throw new Error('controlled unavailable provider');};
  const failed=await g.sandbox.SalahConfig.geocodeSearch('Paris',{});assert.equal(failed.length,0);
  out.push({check:'geocoder failed transport shape',result:'confirmed',returnedCandidates:failed,classification:'same shape as valid zero matches'});
  const output={sourcePin:'f71fef6ccf7e4efcb57b5a26688d2360461a3253',kind:'source-bound mocked schedule, no native or timing qualification',checks:out};
  fs.writeFileSync('/workspace/scratch/8ab1bbbe9699/evidence/probes/configuration/results.json',JSON.stringify(output,null,2)+'\n');
  console.log(JSON.stringify(output,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
