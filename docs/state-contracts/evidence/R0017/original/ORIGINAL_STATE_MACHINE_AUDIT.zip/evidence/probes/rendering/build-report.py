import json
from pathlib import Path
base=Path('/workspace/scratch/8ab1bbbe9699')
machines=[]
def A(path,start,end,symbol): return dict(path=path,start=start,end=end,symbol=symbol)
def M(i,name,nature,source,retained,states,transitions,invariants,recovery,dependencies,outcome,tests,risk,findings=()):
 machines.append(dict(id=f'R{i:02}',name=name,nature=nature,source=source,retained_state=retained,states=states,transitions=transitions,invariants=invariants,recovery=recovery,dependencies=dependencies,audit=dict(disposition=outcome,finding_ids=list(findings)),tests=tests,remaining_risk=risk))
M(1,'Native sky snapshot identity, epoch, freshness and throughput admission','partly explicit',
 [A('real-sky/native-lifecycle.mjs',9,93,'NativeSkyLifecycle'),A('real-sky/native-contract.mjs',3,25,'nativeIdentity/nativeJob/nativeResultCurrent')],
 'epoch; observed wall/monotonic clock; identity; latest/pending/displayed jobs; lastSubmit; duration WeakMap; disposed; availability.',
 ['unobserved','pending','ready/current','paused','invalidated','rate-throughput unavailable','disposed'],
 ['observe validates snapshot; identity, pause, clock discontinuity bump epoch and revoke display.','request coalesces same pending UTC, throttles by rate, clones through queue; forced request does not duplicate identical pending work.','result requires matching latest job, epoch, identity, UTC age <=30000ms and ready raster; slow fast-clock result records throughput unavailability.','display expiry withdraws display without bumping epoch, preserving a separately submitted fresh refresh.'],
 ['An accepted completion cannot regain authority after A→B→A because epoch is separate from identity.','Paint age comes from original job UTC; failure or newly accepted work cannot rejuvenate older displayed pixels.'],
 'Invalid/paused input withdraws; current request failure invokes current error path only; disposal invalidates and disposes queue. Queue execution settlement is externally bounded by worker client.',
 ['R02 queue','R05 client','R10 actual DOM publication','native host snapshot owner R15'],
 'source-proven positive protection; no new defect in this domain',
 ['tests/real-sky/native-lifecycle.test.mjs:13–30','tests/real-sky/native-rate-availability.test.mjs:12–50','parent aggregate275 existing renderer cases PASS'],
 'Epoch/clock/currentness correctness inspected and exercised by existing mocks. Native event-loop stalls and high-rate visible continuity require native capture, not flags.')
M(2,'Latest-only serialized render queue','explicit',
 [A('real-sky/core/src/latest-render-queue.mjs',1,31,'LatestRenderQueue')],
 'next sequence; busy flag; one pending slot holding cloned request plus promise resolvers; disposed.',
 ['idle','executing','executing plus newest pending','disposed'],
 ['submit increments sequence and resolves replaced pending work as superseded; structuredClone establishes input ownership.','drain executes one item; publish only latest sequence and not disposed.','finally clears busy and drains newest pending even after rejection.','dispose invalidates generation and resolves queued item; active item completes without publication.'],
 ['At most one active execution and one queued replacement.','Late success/error cannot publish after a newer submission.','Every ordinary execution path releases busy in finally.'],
 'Executor errors reject the matching promise; callbacks participate in error path. Active uncooperative executor cannot be forcibly canceled by this generic queue; owner client deadlines supply liveness.',
 ['R01','R05'],
 'source-proven positive serialization; callback-throw/unbounded arbitrary executor lead not promoted',
 ['tests/real-sky/native-rate-availability.test.mjs:28,50 exercise coalescing/reload disposal','tests/real-sky/native-lifecycle.test.mjs:18–19 stale completion/error schedules'],
 'Arbitrary onError throwing could escape normal promise settlement, but production callbacks inspected did not establish that schedule; generic API contract remains worth documenting.')
M(3,'Native asset loader generation, timeout, suspension and retry','explicit',
 [A('real-sky/native-assets.mjs',4,33,'NativeAssetLoader')],
 'generation; AbortController; timeout; disposed/suspended flags; state; reset/load/start hooks.',
 ['idle','loading','ready','unavailable','suspended','disposed'],
 ['retry aborts prior generation, resets renderer, races load against bounded timeout.','load resolution checks generation/disposal/suspension before start and ready.','suspend increments generation before abort; resume retries once from suspension.','dispose revokes pending and is terminal.'],
 ['Late A completion/rejection cannot overwrite B.','No timed-out load may invoke start.','Timeout value bounded1..120000ms; default15000ms.'],
 'Error becomes explicit unavailable; retry is authorized recovery; timers/controller cleared in finally. Hooks do not automatically roll back side effects of a partly executed start.',
 ['R04 script transport','R10 host construction'],
 'positive generation/timeout protections; caller construction rollback gap RF02',
 ['tests/real-sky/native-assets.test.mjs:6–12','tests/real-sky/cp9-page-lifecycle.test.mjs:6–9'],
 'Corrupt-start test proves no false-ready state, not cleanup of DOM allocated before a throw. See RF02.', ['RF02'])
M(4,'Native asset script, inline pack and page lifecycle ownership','implicit',
 [A('real-sky/native-assets.mjs',38,77,'startNativeSkyAssets')],
 'initial inline pack captured once; loader; badge; current script handlers/element; pagehide/pageshow listeners; deferred two-frame start.',
 ['inline retained','script loading','pack admitted','renderer started','page suspended','resuming','disposed'],
 ['entry consumes/deletes global pack; loader reset disposes registered runtime, resets frame, requests preview catalogue reset.','each generation owns a fresh script URL; onload consumes pack and removes handlers/element; abort rejects.','successful load starts independent preview catalogue admission and refined runtime.','pagehide suspends; persisted pageshow resumes; dispose removes listeners and deferred frames.'],
 ['Per-generation element identity/abort limits stale script callbacks.','Page suspension revokes deferred startup before it can construct a renderer.','Bootstrap preview is an independent availability owner.'],
 'Network/script/pack errors become loader unavailable. Retry refetches pinned local script; no source substitution. Only registered runtime is reset, leaving RF02 provisional DOM outside custody.',
 ['R03','R13','R14','R10'],
 'source-proven ownership map; construction gap RF02; stale identical global pack not established as content corruption',
 ['tests/real-sky/native-assets.test.mjs:14–21','tests/real-sky/cp9-page-lifecycle.test.mjs:9','tests/real-sky/native-preview-host.test.mjs:258–270'],
 'Browser script execution after element removal may assign a global pinned pack; all generations fetch identical pinned bytes, so semantic stale-target publication was not proved.', ['RF02'])
M(5,'Reference worker client boot, RPC deadlines and fallback mode','partly explicit',
 [A('real-sky/core/src/reference-worker-client.mjs',1,53,'ReferenceRenderClient'),A('real-sky/native-worker-policy.mjs',1,7,'requireNativeWorker')],
 'worker; ready promise/resolver; boot timer; serial; pendingMap; mode; warnings; lazy fallback; disposed.',
 ['booting','worker ready','worker request pending','fallback','failed/native unavailable','disposed'],
 ['construction creates worker, installs listeners, posts boot and starts timeout.','ready settles gate; render waits for ready, checks disposal and limits native worker pending requests.','response id resolves exactly one pending request and clears timer.','fatal/startup/error/render timeout fails pending work, terminates worker and transitions fallback.','native fallback factory throws, preserving UI responsiveness instead of synchronous physical rendering.'],
 ['Ready promise settles on boot success, failure and disposal.','Pending RPCs are rejected and timers cleared when worker is abandoned.','Native worker loss does not cause hidden main-thread physics.'],
 'Reference fallback can lazily render after one task yield; native remains unavailable until outer asset/runtime retry. Dispose terminates and rejects all pending promises; no in-place worker recreation.',
 ['R06','R09','R03 restart'],
 'source-proven positive lifetime and deadline fences; no new defect',
 ['tests/real-sky/cp9-worker-policy.test.mjs:4–5','tests/real-sky/native-host-composition.test.mjs:129 failure retention'],
 'Warnings lack a general cap but this instance normally transitions away from its worker once. Duplicate post-failure callbacks were not shown to yield product-scale growth.')
M(6,'Sky worker boot, engine ownership and transferable raster response','implicit',
 [A('real-sky/native-worker.js',1773,1774,'nativeWorkerEngine/self.onmessage'),A('tools/build_native.py',29,31,'native worker wrapper generation'),A('real-sky/core/src/reference-engine.mjs',38,44,'rasterTransferables')],
 'module-scoped engine; message id; active async render continuation; per-result transfer list seenSet.',
 ['unbooted','booted','rendering','result/error posted','realm terminated'],
 ['boot creates engine and posts ready.','render awaits engine.render and returns id-bound result or error.','result transfer walker emits each ArrayBuffer only once despite aliased typed arrays.','unhandled rejection posts fatal; owning client terminates realm on failure.'],
 ['Caller queue/client supply single execution; worker wrapper itself is not a concurrent job scheduler.','Transferred raster buffers are retired from worker ownership after response; metadata is cloned.'],
 'Errors remain explicit. Termination and restart belong to R05/R03; direct duplicate boot or parallel unsolicited messages are outside the shipped client protocol.',
 ['R02','R05','R09'],
 'positive trusted-protocol coupling; duplicate-boot/parallel-message lead rejected for shipped caller',
 ['tests/real-sky/native-engine.test.mjs','tests/real-sky/native-worker-lunar-display.test.mjs','tests/real-sky/cp9-worker-policy.test.mjs'],
 'Directly exporting this wrapper as a general multi-caller worker would require its own admission/boot idempotence; that use is not established here.')
M(7,'Diffuse asset admission, cancellation and content cache','partly explicit',
 [A('real-sky/core/src/diffuse-assets.mjs',14,69,'parseDiffuseManifest/DiffuseAssetStore/readBoundedUTF8')],
 'immutable manifest/catalogue; exact catalogue text; three-entry hash-key cache; serial; abortcontroller; state; disposed.',
 ['idle','loading with binding revoked','ready','superseded','unavailable','disposed'],
 ['load advances generation and aborts prior read, immediately removes current binding authority.','reload removes matching hash cache; misses bounded-read and verify exact bytes/hash/schema/grid/id before binding.','generation checked after read and before cache/state publication.','failure publishes unavailable only for current generation; disposal aborts/clears text/cache and revokes state.'],
 ['At most the three pinned manifest asset hashes retained.','Wrong catalogue, grid or bytes cannot create a registered binding.','Old loader failure cannot remove new ready binding.'],
 'Ordinary later load retries unavailable; explicit reload evicts good cached tier; DOM/native timeout is supplied by outer client/loader.',
 ['R36 capability','R09'],
 'source-proven positive resource custody; no new defect',
 ['tests/real-sky/native-engine.test.mjs exercises unavailable metadata/native tier','tests/real-sky/native-assets.test.mjs covers outer failure/retry, not every store interleaving'],
 'No new store-specific adversarial probe run in this lane; manifest trust is a pin/provenance boundary, not authenticity from a hash alone.')
M(8,'Sky catalogue replacement generation and last-result authority','explicit',
 [A('real-sky/core/src/scene.mjs',11,21,'SkyController')],
 'validated catalogue; generation; last; error.',
 ['unavailable','replacement pending','ready catalogue','projection ready/error'],
 ['replaceAsync increments generation, clears catalogue/last before await.','success validates catalogue then checks generation; stale failure ignored.','clear increments generation and removes catalogue/last.','update computes fresh projection from current observer or unavailable result.'],
 ['A→B→A ordering cannot restore an old async load.','Failure is empty sources, never a fictional sky.','last is diagnostic current computation, not a stale frame fallback.'],
 'New replacement is recovery; invalid projection yields unavailable; no own time scheduler or disposal needed beyond owner lifetime.',
 ['R09 PhysicalSkyBridge'],
 'source-proven positive authority fence',
 ['tests/real-sky/native-engine.test.mjs integration; no isolated SkyController schedule test observed among supplied native suites'],
 'Synchronous validation of a late large catalogue still costs CPU before its generation guard; no magnitude/production trace established.')
M(9,'Engine binding selection, load keys and declared physical fallback','implicit',
 [A('real-sky/native-engine.mjs',8,27,'NativeSkyEngine'),A('real-sky/core/src/reference-engine.mjs',7,35,'ReferenceSkyEngine'),A('real-sky/core/integration/resilient-sky-bridge.mjs',7,18,'ResilientPhysicalSkyBridge'),A('real-sky/core/integration/physical-sky-bridge.mjs',5,18,'PhysicalSkyBridge')],
 'native pack/loaded flag/store/bridge; reference loadKey+disposed; resilient base bridge plus binding→bridge WeakMap and last diagnostics.',
 ['assets not attempted','registered diffuse ready','declared CP6 fallback','disabled diffuse','disposed'],
 ['native loads requested embedded tier once; failed asset still marks attempt complete.','reference reloads on changed tier/fault/revision OR non-ready store; failure is retryable next render.','resilient chooses only current ready binding, otherwise computes a new CP6 frame at accepted observer and labels fallback.','native requires cloudTransmission1/cloudGlow0; deep-night decomposition executes in worker.'],
 ['Asset failure cannot relabel invalid observer/physics as valid.','Fallback recomputes current physical state; bridge.last does not serve old pixels.','Native foreground owns cloud attenuation exactly once.'],
 'Native failed embedded tier remains fallback until full pack/runtime retry; deliberate immutable-pack policy, not claimed automatic in-engine recovery. Reference retries unavailable. Dispose clears pack/store/last; weak bridge entries can die with binding.',
 ['R07','R08','R36','R03 retry','R10 foreground'],
 'positive declared fallback; native sticky-attempt lead rejected by immutable pack/restart design',
 ['tests/real-sky/native-engine.test.mjs','tests/real-sky/native-worker-lunar-display.test.mjs','tests/real-sky/native-preservation.test.mjs'],
 'Runtime injection of repaired assetTexts into a previously attempted native engine is unsupported; supporting it would require a new revision protocol.')
M(10,'Refined sky construction, accepted frame, displayed frame and DOM commit','implicit',
 [A('real-sky/native-host.mjs',60,234,'startNativeSky/clear/publishPrepared/compose/accept/dispose'),A('real-sky/native-composition.mjs',108,167,'NativeForegroundCapture/sameNativePresentation')],
 'inserted canvas/badge; frame/job vs paintedFrame/paintedJob; pendingJob; last exact foreground capture/mask/rows; decoded publication; RAF/interval/client/workerURL.',
 ['constructing','waiting','accepted but not displayed','mask decode pending','displayed current','retaining old displayed','withdrawn to preview','disposed'],
 ['construction disposes old owner then allocates DOM before runtime is registered.','accept stores validated current result; worker-native deep-night preparation required.','compose captures fresh native foreground; exact same-frame/rows/maskKey/full-byte equality may skip redraw.','publish checks captured job/frame identity/currentness before and after fallible lunar detail, then commits pixels/mask/class and painted provenance.','failure may retain only original paintedJob if still current; clear withdraws and asks preview update in same turn.'],
 ['New accepted frame cannot extend old display lease.','Mask and foreground correspond to one privately captured transaction.','Shared CSS/mask/detail authority transfers only through currentness checks.','Intended invariant every inserted DOM resource has a cleanup owner is violated during construction RF02.'],
 'Normal dispose clears lifecycle, decoder, RAF/timers/listeners/client/blob URL/canvas/badge/mask. Constructor throw before global registration lacks rollback.',
 ['R01','R05','R11','R12','R19','R29'],
 'positive transactional publication; confirmed synthetic constructor ownership gap RF02',
 ['tests/real-sky/native-host-composition.test.mjs:14–149','tests/real-sky/cp9-presentation-cache.test.mjs:4–9','evidence/probes/rendering/protocol-probes.mjs constructorFailure'],
 'Synthetic2D context failure demonstrates unowned nodes; real browser frequency, DOM paint impact and failed offscreen allocation schedules are unmeasured.', ['RF02'])
M(11,'Solar cloud mask decode-before-publish transaction','partly explicit',
 [A('real-sky/native-composition.mjs',35,68,'NativeSolarMaskPublication')],
 'revision; pending Image candidate; displayed candidate; decoded candidate; disposed; original caller context.',
 ['empty','one pending decode','decoded but not committed','displayed','canceled','disposed'],
 ['publish refuses when disposed or already pending; cached decoded/displayed and opaque gradient commit synchronously.','new URL image uses anonymous mode and waits for decode; completion fenced by revision/disposed.','finish stores decoded, invokes original context callback, and marks displayed only if callback succeeds without revision change.','cancel increments revision, blanks pending src, drops pending/displayed; dispose additionally retires decoded.'],
 ['One active decode; later paint opportunities do not replace it.','Failed/rejected publication cannot become displayed.','Only constant-size decoded/displayed/pending slots; callback never reads newer transaction as if it were original.'],
 'Decode rejection clears pending and invokes caller failure. Caller scene/age invalidation or dispose cancels. No intrinsic wall-clock settlement deadline; frozen accepted UTC can prevent age cancellation.',
 ['R10','R12'],
 'positive safety; repeated-replacement starvation rejected; frozen-scene never-settling decode is unconfirmed liveness hypothesis RF04',
 ['tests/real-sky/native-solar-publication.test.mjs:17–91','tests/real-sky/native-preview-host.test.mjs:70,90,96','tests/real-sky/native-host-composition.test.mjs:89–120'],
 'No evidence that shipped browser Image.decode remains pending indefinitely. Native reproduction or platform guarantee is the decision-changing discriminator.', ['RF04'])
M(12,'Preview base, pending paint, current display and shared DOM handoff','implicit',
 [A('real-sky/native-preview-host.mjs',1,174,'startNativeSkyPreview/publish/paint/update/present/clear/dispose')],
 'value/pendingValue; baseBytes/frame; old moon bounds; RAF/nativeDriven; lastPaint; catalogue revisions; decoder; canvas; status.',
 ['bootstrap/head','preparing','decode pending','preview current','superseded by composed sky','paused/expired','disposed'],
 ['update captures physical input and geometry before fresh UTC, checks publishability including5ms*rate reserve, and bounds retry to one.','pending decode is kept while current, canceled on scene/age/headroom expiry; no new candidate replaces active decode.','publish checks catalogue/currentness before/after lunar detail; only final valid paint retires head and marks preview ready.','refined ownership cancels pending preview; native present hook takes over scheduling and cancels independent RAF.','clear removes preview-owned mask/detail and retirement style as ownership permits; failures retain only original current preview/head.'],
 ['Prepared or decoded candidate is not yet a visible-ready owner.','Bootstrap fallback remains independently valid after optional pack failure.','Preview/refined paths must never simultaneously claim composed pixels; detail original owner preserved on handoff.'],
 'Invalid/paused/expired preview withdraws; fresh update can recover. dispose removes loop/canvas/class. Explicit standalone dispose does not itself remove CSS mask/detail; normal shipped teardown/handoff callers clear ownership, so unproven separate API use not promoted.',
 ['R11','R13','R14','R15','R29'],
 'positive currentness/handoff controls; no new reproduced defect',
 ['tests/real-sky/native-preview-host.test.mjs:41–270','tests/real-sky/native-startup-handoff.test.cjs','tests/real-sky/native-head-handoff.cjs'],
 'Shared DOM ownership remains distributed across flags and global closures. Native sun flicker needs frame/class/mask trace and pixel capture; mocks do not establish visibility continuity.')
M(13,'Asynchronous preview catalogue admission revision','implicit',
 [A('real-sky/native-preview-host.mjs',159,171,'admitCatalogue'),A('real-sky/native-star-preview.mjs',1,43,'native preview catalogue validation/admission')],
 'catalogue; bootstrap identity; catalogueRevision; request generation; pending validation continuation.',
 ['bootstrap','validation pending','admitted replacement','failed/retained bootstrap','disposed/revoked'],
 ['request advances generation and validates pack asynchronously on a separate task.','completion checks request generation/disposal before adopting revision.','admitted revision invalidates prepared candidate; each publish compares original revision.','null reset restores bootstrap only when identity differs.'],
 ['Late catalogue A cannot repaint after B/reset/dispose.','Hash/schema failure cannot publish claimed identity.','Repeated unchanged bootstrap reset avoids pointless rebuild.'],
 'Validation failure leaves valid bootstrap authority; later valid request can recover. Async CPU validation itself cannot be aborted mid-computation.',
 ['R04','R12','R17'],
 'source-proven positive stale catalogue fence',
 ['tests/real-sky/native-preview-host.test.mjs:177–205,258–270','tests/real-sky/native-star-preview.test.mjs'],
 'No large malicious catalogue execution-time claim; size/hash admission is source-bound, not a calibrated native responsiveness measurement.')
M(14,'Document head background and initial lunar CSS lease','implicit',
 [A('real-sky/native-first-paint.mjs',1,49,'initial ordinary-clock background owner'),A('moon/src/moon-first-paint.mjs',6,60,'nativeInitialMoonHead/compose/background rule'),A('real-sky/native-preview-host.mjs',37,86,'head retention/retirement')],
 'SalahFirstPaint object with native snapshot, bootstrap frame, optional lunar result; style element/rule; retirement flag via removal; current closure.',
 ['ineligible simulation','eligible head candidate','head CSS displayed','preview replaces','expired/revoked'],
 ['ordinary clock entry creates sharedconfig UTC/perf snapshot and bootstrap stars/sky before full runtime.','optional initial lunar head uses actual opacity, canonical profile and exact admitted receiver.','failed first preview retains only still-current unpaused head; successful preview retires its style/global lease.','initial lunar result has separate one-shot adoption/retirement R21.'],
 ['Head must not adopt reference/simulated authority.','Failed later scene must not resurrect expired startup CSS.','First lunar opaque coverage and atmospheric foreground use same join contract as later detail.'],
 'Invalid assets/head generation records initial error instead of fabricating refined readiness; later bootstrap/runtime can recover. Document teardown ends lease.',
 ['R12','R21','R30','R15'],
 'positive startup lease and handoff; no new defect',
 ['tests/real-sky/native-first-paint.test.mjs','tests/real-sky/native-celestial-startup.test.mjs','tests/real-sky/native-startup-critical-path.test.mjs','tests/real-sky/moon_build_guard_test.py:77'],
 'Source order/assertions and DOM mocks do not establish first actual browser paint, all native startup sizes, or sun/cloud flicker.')
M(15,'Native snapshot adapter and single paint-hook installation','implicit',
 [A('real-sky/native-host-hooks.js',5,65,'SalahNativeSkyHost/capture/notify/QA wrapper')],
 'frozen adapter methods; native-owned config/time/weather/generation; injected callable hook; QA wrapper original function.',
 ['installed','capturing current snapshot','native-driven preview','document hidden/paused'],
 ['capture validates and copies current native state; geometry optional to avoid repeated layout and lunar texture work on identity checks.','notify requests refined work; native paint calls preview.present so independent preview RAF retires.','QA wraps existing diagnostic owner and may read lunar runtime state getter.'],
 ['Native remains sole phase/time/weather/observer owner; renderer adapter introduces no second physical clock.','No duplicate synchronous preview paint in notify.','Status reads are not proof of actual presented pixels.'],
 'Bad capture is rejected by downstream owners; document/runtime owns hook lifetime. Methods are global only within the native document.',
 ['R01','R12','R19','R35'],
 'source-proven positive authority boundary; diagnostic getter side effect documented',
 ['tests/real-sky/cp9-ownership-age.test.mjs','tests/real-sky/native-contract.test.mjs','tests/real-sky/native-preview-host.test.mjs:170'],
 'Lunar state getter can adopt pending initial preview, so diagnostics are not perfectly observational; production correctness still publication-fenced. No independent bug demonstrated.')
M(16,'Bounded camera geometry and lunar sampling geometry memoization','implicit cache protocol',
 [A('real-sky/native-preview.mjs',17,31,'displayGeometryCache/displayGeometry'),A('real-sky/native-preview.mjs',362,382,'lunarGeometryCache/native lunar geometry')],
 'two separately bounded four-entry FIFO maps; exact camera/grid keys; private rays/scales/readiness and direction/vector arrays.',
 ['missing geometry','lazy cells uncomputed','computed cell hit','map capacity reached/oldest eviction'],
 ['cache only supported bounded native camera/raster geometries; unsupported shapes compute directly.','exact camera/grid key hit reuses geometry; missing entries initialize lazy cells.','insertion at capacity evicts oldest, not arbitrary current physical values.'],
 ['No physical UTC, weather, illumination, exposure or admitted frame retained in these geometry caches.','Each map capacity4; lunar admitted grid bounded to68 steps.','Camera/geometry key changes force new geometry.'],
 'No async/cancellation. Invalid geometry rejected upstream; realm termination releases maps; old entries FIFO evicted.',
 ['R12 fields','R10 worker-native decomposition','R34 current model'],
 'positive bounded geometry-only reuse',
 ['tests/real-sky/native-preview.test.mjs:12–23','tests/real-sky/native-lunar-cache.test.mjs:26–27 includes eviction-removal mutant','tests/real-sky/native-lunar-fused.test.mjs'],
 'Bounded count is source/test evidence; total retained native heap and performance benefit not profiled here.')
M(17,'Preview raster private-byte custody and lazy linear fields','implicit cache protocol',
 [A('real-sky/native-star-preview.mjs',139,178,'preparedFields/joinNativePreview/lazy fields/region')],
 'WeakMap from raster to copied source bytes/private stellar plane; lazy decoded gas/linear arrays in returned getters; encoded threshold table separately R18.',
 ['validated source copy','encoded-only use','linear field materialized once','raster unreachable'],
 ['join validates full source arrays including unused tails and takes private copy.','gas/linear getter lazily decodes only when consumer requests fields, memoized for same returned raster.','region operations consume current exact foreground transfer; no reused physical frame authority.'],
 ['Caller mutation of original input bytes cannot silently alter already prepared transaction.','All source pixels validated, not only currently sampled region.','Weak keys do not root dead rasters.'],
 'Invalid source throws; owner failure path withdraws/retains prior current pixels. Resource lifetime ends with returned raster and dependent closures.',
 ['R12','R18','R29'],
 'positive immutable input and lazy allocation custody',
 ['tests/real-sky/native-star-preview.test.mjs:79–103'],
 'Returned mutable typed arrays are consumer-owned; internal consumers inspected treat admitted planes as immutable. Hostile caller mutation after exposure is not separately guarded.')
M(18,'Exact immutable encoding-table initialization','implicit cache protocol',
 [A('real-sky/native-host.mjs',11,48,'nativeDisplayEncodeCache/encodeNativeDisplay'),A('real-sky/native-encoding.mjs',1,42,'nativeEncodingThresholds'),A('real-sky/native-star-preview.mjs',19,25,'previewEdges/previewCode')],
 'once-built exact thresholds/buckets; native local previous-pixel interval; preview lazy edge table.',
 ['uninitialized','initialized immutable table','per-call interval hit/miss'],
 ['first encode builds oracle binary64 thresholds/buckets; subsequent pixels search exact interval.','same-call previous interval may shortcut comparison; changed input validates finite range and searches exact edges.','no per-frame/scene/UTC colour output memo.'],
 ['Cache accelerates exact code boundaries rather than approximating physical radiance.','Per-call stream shortcut cannot leak between frames.','Bad/overflow inputs still rejected on cache hit paths.'],
 'Synchronous; initialization errors propagate; realm lifetime table bounded. No async reentrancy under JS single-threaded module execution.',
 ['R10','R12','R17','R29'],
 'positive exactness and bounded initialization; no new defect',
 ['tests/real-sky/native-host-encoding.test.mjs:14–35','tests/real-sky/native-host-streams.test.mjs:7–31','tests/real-sky/native-encoding.test.mjs'],
 'Exact byte equality is not perception, tone-calibration or native performance certification. Module copies in worker/UI retain their own bounded tables.')
M(19,'Lunar host accepted, pending preview and current presentation transaction','implicit',
 [A('moon/src/moon-native.mjs',10,142,'capture/scope/matches/clear/adopt/presentation/poll'),A('moon/src/moon-native.mjs',198,230,'worker message admission'),A('moon/src/moon-precision.mjs',1,27,'phase budget and nativeCalendarMoonScene')],
 'serial/epoch; pending/accepted/waitingPreview; previous clock; referenceScene/profileMode; upper/calendar bytes; textureUp; status; phase threshold.',
 ['no surface','initial presentation','render pending','preview waiting for sky','current accepted preview','refined accepted','withdrawn','disposed'],
 ['capture derives exact scope from native generation/scene/observer/rate/profile/geometry and validates physical phase.','scope/clock/pause changes clear and increment epoch+serial; accepted match additionally enforces .0416 device-pixel phase-position budget.','poll coalesces pending; expired pending phase is canceled; sufficient refined phase quality avoids redundant work.','worker message requires current worker/id/scope plus matching physical scene; preview may wait until sky ownership admits its presentation.','adopt builds detail then stores provenance; read-time presentation/surface getters recheck and may adopt waiting initial preview.'],
 ['No stale accepted phase after seek/A→B→A even between polling ticks.','Fallback revokes prior surface rather than inventing legacy detail.','Failure retention uses original accepted geometric lease.','Accepted/displayed/pending are distinct; final result requires empirical-adaptive quality.'],
 'clear cancels worker despite possible postMessage exception; error closes worker and retains only current accepted surface. Timer250ms plus request hooks drive progress. Detail/runtime replacement ownership defect RF01 is outside ordinary worker retry.',
 ['R20','R21','R23','R28','R29','native phase/geometry owner'],
 'positive identity/geometric budget fences; confirmed replacement ownership defect RF01',
 ['tests/real-sky/moon_runtime_identity_test.py:8 source identity paths','tests/real-sky/native-moon-admission.test.mjs:6–14','tests/real-sky/moon-worker-fixture.test.mjs:14–20','evidence/probes/rendering/protocol-probes.mjs runtimeReplacement'],
 'Actual lunar WASM, omitted terrain texture transport, native first-paint visibility and repeated-runtime deployment frequency not executed here.', ['RF01'])
M(20,'Lunar runtime installation, worker source, bounded retry and deadlines','partly explicit',
 [A('moon/src/moon-native.mjs',1,13,'detail/runtime bootstrap ordering'),A('moon/src/moon-native.mjs',51,68,'closeWorker/failed'),A('moon/src/moon-native.mjs',180,230,'start and worker lifecycle'),A('moon/src/moon-native.mjs',239,280,'installWorkerSource/retry/dispose/deferred start')],
 'worker identity; blob URL; pinned source; ready; source/boot/render timers; startFrame; retryCount; errors capped8; disposed; global detail/runtime bindings.',
 ['waiting source','double-RAF start','booting','ready','request pending','unavailable','retrying <=3','disposed'],
 ['source install verifies exact UTF8 byte count and SHA; unchanged source is idempotent.','two RAFs permit initial scene opportunity; explicit retry/disposal revoke defer.','start owns new worker+URL and120s boot deadline; render owns240s deadline; callbacks require worker===w.','failure clears worker resources, preserves only current accepted surface, bounds errors; retry max3.','reinstallation first creates/publishes detail at line1 then disposes old runtime at line6; old dispose line273 dereferences global detail, destroying new owner.'],
 ['Every abandoned worker/blob URL is retired; old worker callbacks cannot affect replacement.','Source identity alone cannot be bypassed with a different worker body.','Installation intended invariant new runtime owns live new detail fails RF01.'],
 'retry restarts worker in same wrapper and does not trigger RF01; full wrapper re-evaluation does. Normal dispose closes worker/transport/timers/listener and detail, but uses dynamic global rather than captured owned resource.',
 ['R19','R22','R23','R29'],
 'confirmed synthetic replacement bug RF01; positive normal worker retry fences',
 ['tests/real-sky/moon_runtime_identity_test.py','tests/real-sky/moon_build_guard_test.py:58–103 protect generated duplicate/build boundaries','evidence/probes/rendering/protocol-probes.mjs runtimeReplacement'],
 'Build-time duplicate guards reduce likelihood of normal double execution; they do not make runtime replacement ordering correct. No production reinstallation frequency claimed.', ['RF01'])
M(21,'One-shot lunar initial-head eligibility and irreversible retirement','implicit',
 [A('moon/src/moon-native.mjs',13,13,'initialHeadEligible'),A('moon/src/moon-native.mjs',47,50,'revokeInitialHead/clear'),A('moon/src/moon-native.mjs',90,121,'takeInitialHead/initialPresentation')],
 'initialHeadEligible; first-paint moon result; stored UTC/perf/generation/profile/receiver provenance; initialError.',
 ['eligible original document','head available','adopted/current','irreversibly revoked','independent initial-render fallback'],
 ['takeInitialHead only ordinary generation0/rate1/calendar/no reference, matching time/perf continuity and admitted receiver/profile.','adoption consumes/nulls the head result.','invalidation/worker failure revokes eligibility and head result; A→B→A cannot regain startup authority.','when eligible head absent, current initial renderer may independently compute accepted phase and recheck scope.'],
 ['Startup cached result is a one-shot lease, not a general frame cache.','Reference mode, simulation and discontinuity cannot re-label startup pixels as current.'],
 'Initial errors recorded separately. Revoked head is terminal; current receiver render or refined worker may recover presentation.',
 ['R14','R19','R30'],
 'source-proven positive startup retirement',
 ['tests/real-sky/native-startup-handoff.test.cjs','tests/real-sky/initial_source_association_test.py','tests/real-sky/first_complete_scene_test.py'],
 'Native page-cache restore and visibility timing not exercised; one-shot eligibility intentionally sacrifices stale startup reuse after invalidation.')
M(22,'Lunar offline chunk DOM/script transport lease','implicit',
 [A('moon/src/moon-native.mjs',143,179,'offlineTransport')],
 'worker pointer; active script element/currentScript; chunk name/index; request timers; embedded inert chunk nodes; stopped state.',
 ['transport idle','chunk requested','script loading','chunk delivered','advancing next task','stopped/error'],
 ['worker asks exact known asset chunk; host checks ordering/name/index/type/final marker and bounds.','embedded nodes supply chunks; external script callback requires owning element/currentScript and still-current worker.','each next chunk scheduled through setTimeout0; stop removes active callback/element/timers.','inert embedded chunks remain available for bounded worker retry.'],
 ['Old script completion cannot feed a new worker.','Out-of-order/malformed data cannot silently concatenate into an accepted scientific asset.','Transport does not become a source substitution mechanism.'],
 'Any transport error reports to worker/host failure; closeWorker invokes stopOffline. Top boot deadline bounds never-settling chunk transport.',
 ['R20','R23','R26 asset hashes'],
 'source-proven positive transport identity/cancellation',
 ['tests/real-sky/moon_runtime_identity_test.py','tests/real-sky/moon_build_guard_test.py','tests/real-sky/initial_source_association_test.py'],
 'Large lunar terrain files are not available in this checkout. No full offline load/build/native storage-memory verification claimed.')
M(23,'Lunar top worker boot, newest-job pump and cancellation','implicit',
 [A('moon/src/moon-worker.mjs',1,75,'enginePromise/latest/running/serial/offlineParts/pump/onmessage')],
 'enginePromise; latest request; running flag; serial cancellation token; offlinePartsMap; shard mode engine/serial; sourceURL.',
 ['unbooted','waiting chunks/engine','pump idle','running current job','newest replacement queued','canceling','boot failed','terminated'],
 ['one boot builds exact assets and four-worker pool; duplicate boot rejected.','render increments serial, replaces latest, schedules pool cancel and pump.','pump serializes work, captures token, posts preview/final only while current.','cancel invalidates token, clears latest and cancels pool.','finally clears running and re-pumps if latest appeared during completion, preventing lost wakeup.','chunk parser enforces bounded ordered exact final content; shard messages use separate serial.'],
 ['At most one top-level active adaptive pipeline; newest slot can replace pending work.','Stale preview/final/error cannot publish for a newer serial.','Delayed engine initialization cannot lose cancellation/replacement demand.'],
 'Boot/chunk error rejects boot and posts error; host terminates on deadline/error. Map/engine resources die with worker realm. No own standalone per-job deadline: R20 supplies240s.',
 ['R20','R22','R24','R25','R28'],
 'positive no-lost-wakeup and token guards; no new defect',
 ['tests/real-sky/moon-worker-fixture.test.mjs','tests/real-sky/moon_runtime_identity_test.py','tests/real-sky/moon_continuity_observer_test.py'],
 'Host deadline is essential: reusing worker standalone would need its own liveness policy. Full real nested-worker cancellation timing not run.')
M(24,'Lunar shard RPC bridge promises and sticky failure','implicit',
 [A('moon/src/moon-pool.mjs',6,27,'rowBridge')],
 'worker; serial request ids; waitingMap resolve/reject/progress; sticky error; disposed ownership.',
 ['boot RPC pending','idle','render RPC pending','cancel requested','failed','disposed'],
 ['RPC attaches id and pending resolver before post; reply kind/id routes progress or completion.','worker error/messageerror fails every waiting request and remembers failure for subsequent calls.','cancel posts shard-cancel; disposal terminates and rejects all.'],
 ['Unknown/old replies cannot settle another request.','Transport failure cannot leave already registered promises awaiting ordinary worker replies.','Top-level pool controls when a canceled bridge may be reused.'],
 'No per-RPC local timeout. Pool waits all jobs and host boot/render timers terminate parent worker if a shard never settles.',
 ['R23','R25','R26','R20 external deadlines'],
 'positive settlement on explicit transport failure; local timeout omission qualified by outer deadline',
 ['tests/real-sky/moon-worker-fixture.test.mjs wrapper controls are related, not direct rowBridge hung-worker evidence','no isolated shard-RPC deadline test observed in supplied native suites'],
 'A silent shard stalls useful progress until120s/240s host bound; liveness is delegated, not intrinsically bounded by rowBridge. Native stall incidence unmeasured.')
M(25,'Lunar pool disjoint row ownership, sparse reuse and join barrier','partly explicit',
 [A('moon/src/moon-pool.mjs',29,99,'MoonPool/create/render/cancel')],
 'four row bridges; pool serial; material/current light key; source URL during initialization; disjoint row ranges; result aggregation.',
 ['creating all shards','ready','rendering ranges','canceling all','joining','cached physical scene','failed/disposed by owner'],
 ['create boots all shards; any boot failure disposes all; blob URL revoked in finally.','render builds exact scene key and allows sparse lighting reuse only same accepted key.','four disjoint row jobs run; one failure cancels siblings; allSettled barrier finishes before reuse.','join validates each row identity/range/shape/finiteness then assembles once and applies filter after join to avoid shard seams.','cancel increments serial and cancels all; failed/canceled work clears light reuse key.'],
 ['No overlapping row writers and no read of unfinished shards.','Canceled old results cannot become a new material/light cache.','Full arrays validated even when sparse mask would ignore entries.'],
 'Errors cancel siblings and await settlement; top worker/host deadline provides final termination if a shard is silent. Worker realm termination owns nested worker resources.',
 ['R23','R24','R26','R28'],
 'source-proven positive ownership/barrier; no new confirmed defect',
 ['tests/real-sky/moon-worker-fixture.test.mjs related integration','no full terrain/pool execution performed in this lane'],
 'Profile fingerprint await occurs after local cancellation check; outer worker token still rejects obsolete publication. No stale rendered result proved. Native nested-worker termination must be platform-verified if relied on for resource accounting.')
M(26,'Lunar engine exclusive execution, asset admission and camera/lighting caches','partly explicit',
 [A('moon/src/moon-engine.mjs',19,73,'scene/decode/create'),A('moon/src/moon-engine.mjs',75,133,'MoonEngine render/active/cameraKey/lightKey/step')],
 'WASM instance and owned allocation; decoded pinned layers; active flag; cameraKey; lightKey; cancellation callback; progress/yield deadline.',
 ['validating assets','engine ready','camera preparation','lighting','result validation','complete/cache valid','canceled/error'],
 ['create verifies manifest/WASM ABI/compressed and raw hashes, size/decompression bounds, then initializes private terrain.','render rejects reentry; clones/validates right-handed orthonormal physical scene.','camera miss clears key until whole camera pass complete; hit updates lights.','lighting key uses full accepted scene; sparse reuse only matching key; final key set after loop and cancel checks.','step checks cancel and yields after8ms work opportunity; catch clears lightKey; finally always releases active.'],
 ['One active render mutates engine memory.','Partial camera pass cannot be reused; completed camera after lighting cancel remains valid geometry.','Canceled/failed lighting cannot be reused as accepted illumination.','Asset bytes, decoded shape and all physical scene fields are admitted before work.'],
 'Cancel/error leaves engine reusable with appropriately invalidated keys. No public dispose for standalone engine; worker realm owns WASM/resource termination.',
 ['R24','R25','R27','R28'],
 'source-proven positive cache ownership and cancellation; missing full assets limits execution evidence',
 ['tests/real-sky/moon_runtime_identity_test.py','tests/real-sky/moon_build_guard_test.py:96–103 asset drift guards','full actual WASM/terrain validation not run here'],
 '8ms checks are cooperative scheduling opportunities, not guaranteed frame timing. Native resource exhaustion, decompression peak memory and platform WASM behavior unverified.')
M(27,'Lunar cooperative MessageChannel yield and wakeups','implicit',
 [A('moon/src/moon-engine.mjs',57,62,'yieldQueue/MessageChannel/pause')],
 'one module channel; FIFO resolver queue; referenced/unreferenced port status.',
 ['empty/unreferenced','resolver queued/port referenced','message dequeues resolver','empty again'],
 ['pause pushes resolver, refs port where supported, posts message.','message handler shifts exactly one resolver, resolves it, unrefs when queue empty.','engine cancellation checked at surrounding step boundaries; yielding itself only schedules continuation.'],
 ['A posted wakeup corresponds to one queued continuation.','Pending continuation keeps Node-style port alive; empty queue does not keep process alive.'],
 'No explicit queue cancellation; already posted turn resolves then engine observes cancel. Worker termination releases ports/continuations.',
 ['R26','R23 lifetime'],
 'source-proven positive wakeup ordering; no lost-wakeup schedule found',
 ['indirect engine use; no focused channel wakeup/termination test observed in supplied native suites'],
 'Scheduler guarantees are environment-dependent. A destroyed worker abandons pending promises intentionally with its realm; standalone external callers would need disposal semantics.')
M(28,'Lunar empirical adaptive refinement and final quality admission','explicit finite policy',
 [A('moon/src/moon-quality.mjs',27,46,'adaptiveMoon/refinement loop'),A('moon/src/moon-native.mjs',198,230,'preview/final quality gate')],
 'rule index; current/previous result; comparison history; active receiver mask; preview sent state; final quality label.',
 ['64-node first result','preview emitted','256/1024/4096/8192 refinements','converged empirical-adaptive','limit-reached'],
 ['successive render calls compare accepted outputs and focus next mask on unresolved/ambiguous receivers.','first result emits preview without large internal convergence fields; response surfaces retained for host.','ambiguous early receiver path requires further work; after minimum stages projected code difference<=.5 can terminate; no active comparison receivers can terminate.','final nonconvergence labelled limit-reached; native host rejects it as final refined success.'],
 ['Empirical convergence is explicitly labelled, not mathematical accuracy certification.','Preview does not claim final quality.','Canceled request serial prevents any stage publication.'],
 'Engine cancel propagates through render awaits; exhaustion explicit. Host may retain earlier current accepted surface while reporting refinement unavailable.',
 ['R23','R25','R26','R19'],
 'positive explicit finite-quality state machine; no new defect',
 ['tests/real-sky/moon-worker-fixture.test.mjs integration surface','tests/real-sky/moon_continuity_observer_test.py observer is not numerical oracle'],
 'Convergence masks/error estimator and exact quality policy were read, not empirically revalidated against full scientific assets. Existing mocks cannot certify lunar radiometry.')
M(29,'Lunar detail adoption, projection cache and DOM visibility owner','implicit',
 [A('moon/src/moon-detail.mjs',43,140,'startMoonDetail/geometry/compose/adopt/clear/dispose')],
 'current surface/prefix tables; last frame+geometry+cloud; prepared linear join; projected surface samples; disposed; canvas/cloud canvas; owner stats.',
 ['no surface','admitted but not visible','geometry available','projected/material cached','prepared atmospheric join','visible under preview/refined','cleared','disposed'],
 ['adopt resets caches, builds validated prefix tables and optional calendar table; failure clears and nulls all.','geometry requires current admitted runtime surface, moon-ready/mask visibility, valid no-shear transforms and bounded pixel area.','compose locates current sky owner, shares cloud capture exactly once, uses full input key for prepared output and narrower geometry/table pointers for projected material.','exact unchanged frame/key/cloud skips; new atmospheric frame recomputes join while reusing only geometry samples.','preview final currentness fence before pixels/style; clear hides/clears output but retains admitted surface tables; dispose removes canvas and tables.'],
 ['Source physical identity and actual table pointers distinguish materials with identical labels.','Projection cache cannot freeze sky/exposure/opacity/cloud changes.','Detail visibility requires current accepted surface and correct sky owner.','Disposed object cannot compose; however adopt has no disposed guard, magnifying RF01 owner mismatch.'],
 'Clear is reversible with retained surface; invalid adopt revokes entirely; dispose intended terminal. New runtime must receive a live captured detail owner, not dynamically disposed replacement.',
 ['R19','R10','R12','R20'],
 'positive exact reuse/publication fences; RF01 replacement lifetime coupling',
 ['tests/real-sky/moon-projection-cache.test.mjs:35–77 exact old/new output, stale, invalid adoption, disposal, staged preview control','evidence/probes/rendering/protocol-probes.mjs runtimeReplacement'],
 'No actual native DPR/transforms/timing/pixels asserted. Source counterexample concerns wrapper reinstallation; ordinary clear/adopt and worker retry tests remain positive.', ['RF01'])
M(30,'Admitted initial lunar receiver and canonical render closure','implicit resource admission',
 [A('moon/src/moon-initial.mjs',9,74,'createInitialMoon/render/consumeInitialMoon'),A('moon/src/moon-initial-compact.mjs',1,65,'decodeCompactInitialMoon')],
 'private decoded material/coverage/receiver records/index; immutable identity/profile descriptor; bounded closure; shared readonly coverage.',
 ['compressed input untrusted','exact decoded identity admitted','immutable receiver ready','canonical per-phase result'],
 ['compact decoder enforces compressed byte/hash/schema/packing/Huffman/Paeth bounds and final decoded hash.','createInitialMoon copies validates bounded arrays/records; exposes frozen identity plus render function.','render permits canonical fixed view/profile/calendar; computes current sun/earth illumination and new output arrays every call.','synchronous consume callback borrows tables without retaining duplicate data.'],
 ['Initial resource reuse does not reuse old physical phase or change runtime authority.','Reference/custom geometry cannot be silently served by canonical approximation.','No unbounded per-phase cache.'],
 'Any malformed data fails admission; owner records initialError and uses later valid availability. Closure lifetime follows document/initial renderer; no async partial publication.',
 ['R14','R21','R19','moon calendar/precision pure transforms'],
 'source-proven positive bounded resource admission; no new defect',
 ['tests/real-sky/initial_source_association_test.py','tests/real-sky/native-first-paint.test.mjs','tests/real-sky/moon_build_guard_test.py:96'],
 'Declared receiver tier is an approximation, not full terrain certification. No large scientific source files or native visual first-paint run available.')
M(31,'Module-lifetime spectral selection and B–V fit retention','implicit cache protocol',
 [A('real-sky/core/src/spectral.mjs',9,41,'sfCache/sfFitCache/sfFitColour/selectSpectrum'),A('real-sky/core/src/sky-background.mjs',29,33,'patatTwilight'),A('real-sky/core/src/sky-background.mjs',75,76,'createSkyModel twilightSpectrum'),A('real-sky/native-preview.mjs',334,336,'nativeAtmosphereFields twilight B–V')],
 'outer spectral selection Map capped12000; separate exact-B–V fitting Map with no cap; frozen95-sample fit/selection values.',
 ['colour absent','48-step fit computed','fit retained indefinitely','outer cache full but fit map still growing'],
 ['outer hit returns immutable selection; miss may fit exact B–V then store fit unconditionally.','outer cache stops adding at12000; inner cache has no coupled bound/eviction.','changing solar altitude feeds continuous twilight B–V in both physical model and UI preview.'],
 ['Intended bounded computational memoization is violated: fit map can retain one95-sample spectrum per distinct valid time-dependent colour.','Immutability protects values but not resource bound.'],
 'Only realm/module termination releases fit map; asset/runtime retry in same UI realm does not reset module cache. Worker restart resets worker copy.',
 ['R34','R12','R09'],
 'confirmed synthetic growth plus source-proven production continuous-input path RF03',
 ['evidence/probes/rendering/protocol-probes.mjs spectralRetention:12020 colours→12020 fits and12000 outer entries','no existing fit-cache capacity test observed'],
 'Real retained bytes, time until pressure and user-visible latency/GC effects were not measured; native duration/rate distributions remain unknown.', ['RF03'])
M(32,'Bounded legacy photometry spectral memo','implicit cache protocol',
 [A('real-sky/core/src/photometry.mjs',27,35,'spectra/spectrumForColour')],
 'string-keyed spectraMap capped2048;95-bin normalized shape and metadata.',
 ['miss','cached hit','capacity reached/non-retaining compute'],
 ['first distinct colour computes normalized spectrum and stores only below2048.','after capacity results still compute correctly without adding entries.','null colour uses declared unknown-neutral proxy.'],
 ['Strong cache retention bounded2048.','No UTC/frame authority in key or value.'],
 'Synchronous validation/normalization; caller errors propagate; module lifetime/realm termination releases cache.',
 ['legacy physical photometry consumers'],
 'positive bounded count; returned mutability is a contract limitation, not a proved shipped defect',
 ['native photometric rendering integration in parent cohort; no isolated mutation/capacity test observed here'],
 'Returned object/samples are mutable and repeated hit shares them. Internal inspected consumers treat them read-only; arbitrary caller mutation could poison later results but no production mutation path established.')
M(33,'Atmosphere validation capability and weak coefficient memo','implicit admission/cache protocol',
 [A('real-sky/core/src/atmosphere.mjs',7,21,'atmValidated/normaliseAtmosphere'),A('real-sky/core/src/sky-background.mjs',14,14,'bgCoeff'),A('real-sky/core/src/sky-background.mjs',47,51,'coefficient lookup keyed by normalized atmosphere')],
 'WeakSet of privately validated frozen atmosphere objects; WeakMap of spectral coefficients keyed by those objects.',
 ['untrusted input','validated frozen atmosphere','coefficient miss/hit','unreachable/collectable'],
 ['foreign object is fully validated and copied/frozen; only private WeakSet identity skips validation.','coefficient table computed once per admitted object, never by mutable user stamp alone.','new native weather/atmosphere object obtains separate coefficients; weak ownership allows collection.'],
 ['Caller mutation cannot change a normalized atmosphere.','__cp6Atmosphere property alone is not a capability.','Weak caches do not strongly accumulate past atmosphere objects.'],
 'Invalid conflicting transmission/optical-depth or out-of-range fields reject; new valid input recovers synchronously. No cancellation or explicit dispose required.',
 ['R34','R09'],
 'source-proven positive unforgeable validation and weak lifetime',
 ['tests/real-sky/native-preview.test.mjs physical preparation integration','no isolated spoofed-validation-marker probe performed in this lane'],
 'Reuse effectiveness depends on callers sharing normalized objects; repeated equivalent new objects recompute. No performance measurement or optimization request implied.')
M(34,'Per-physical-model solar sample grid lifetime','implicit cache protocol',
 [A('real-sky/core/src/sky-background.mjs',72,96,'createSkyModel/solarNode/solarAt/sample')],
 'one model closure containing physical state reference, frozen normalized atmosphere, twilight fit, option callbacks, bounded solar-node Map.',
 ['model created','node missing','node computed','node reused','model unreachable'],
 ['current physical model created from accepted state; solarNode memoizes exact ia/azimuth wrapped indices.','solarAt admits altitude0..18 grid bands and36 azimuth columns, interpolation samples up to684 distinct nodes.','new model creates new map; changing host UTC creates new model, not global time cache.'],
 ['Physical sampling cache lifetime is exactly one current model; geometry caches are separate.','At most19×36 solar nodes under admitted sample path.','Moon/natural/cloud terms evaluated from current model rather than frozen coarse solar grid.'],
 'Synchronous failure propagates to renderer unavailable. Releasing model releases grid; no temporal cancellation itself.',
 ['R31 twilight spectrum','R33 atmosphere','R09','R12'],
 'positive per-model bounded lifetime; mutable state API hypothesis not promoted',
 ['tests/real-sky/native-preview.test.mjs','tests/real-sky/native-lunar-component.test.mjs','tests/real-sky/native-lunar-fused.test.mjs'],
 'Returned model exposes same state reference; external mutation after cached nodes could mix epochs. Internal inspected callers create fresh state and do not mutate it during sampling, so no shipped schedule proved.')
M(35,'Native target-elevation acceptance lease','implicit authority protocol',
 [A('real-sky/native-host-hooks.js',4,8,'_cp9SiteElevation/acceptedElevation'),A('real-sky/native-host-hooks.js',17,36,'capture elevation selection/source label')],
 'one frozen height/generation/lat/lon tuple admitted by native target owner.',
 ['no accepted elevation','tuple admitted','tuple ineligible after target/generation/weather change','new tuple accepted'],
 ['acceptedElevation admits finite bounded height only for exact current runtime generation and coordinates.','capture uses tuple only with eligible selected weather and same generation/coordinates; otherwise explicit0m estimate/source label.','new accepted tuple replaces prior; A→B→A generation prevents reuse of A old record.'],
 ['Legacy scalar elevation is not accepted astronomical metadata.','Same numeric coordinates after generation change do not revive stale altitude custody.'],
 'Invalid acceptance returnsfalse without replacing tuple; current later native weather/elevation acceptance recovers. Tuple can remain retained but has no authority outside guard.',
 ['native weather acceptance owned by other lane','R15','R01'],
 'source-proven positive separate metadata lease',
 ['tests/real-sky/cp9-elevation.test.mjs'],
 'Network elevation provider acceptance itself is outside this lane. Static source labels do not establish correctness of measured terrain elevation.')
M(36,'Catalogue-bound diffuse resource capability and private sampler','implicit resource-admission protocol',
 [A('real-sky/core/src/diffuse-binding.mjs',4,18,'dsBindings/bindRegisteredStarlight/isBoundRegisteredStarlight'),A('real-sky/core/src/registered-starlight.mjs',35,60,'createRegisteredStarlightSampler'),A('real-sky/core/integration/physical-sky-bridge.mjs',5,18,'PhysicalSkyBridge registered input check'),A('real-sky/core/integration/resilient-sky-bridge.mjs',8,16,'binding→bridge WeakMap')],
 'private WeakSet of issued bindings; exact catalogue byte digest; deep-frozen parsed catalogue; private copied diffuse values/estimates/rings; immutable sampler closure.',
 ['untrusted catalogue/asset','hash-matched parsed data','issued same-realm capability','bound bridge reused','unreachable'],
 ['verify exact unmodified catalogue text hash against asset; validate catalogue and copy/freeze private data.','construct sampler with matching hash; only successful binding added to private WeakSet.','bridge accepts only issued binding and its associated catalogue, caches bridge weakly by binding identity.'],
 ['An object with correct-looking kind/hash fields cannot forge issued capability.','Catalogue and removed-source diffuse map cannot be silently mismatched.','Caller mutation of original parsed arrays cannot change private sampler.'],
 'Any mismatch rejects; R07 marks requested diffuse unavailable and R09 declares fallback. Capability lifetime follows strong caller refs; WeakSet/WeakMap do not retain retired resource alone.',
 ['R07','R09','R08'],
 'positive exact binding and lifetime protections; no new defect',
 ['tests/real-sky/native-engine.test.mjs integration','admission source read; no isolated forged-binding probe added here'],
 'Byte hash validates content identity, not publisher authenticity; pin/source provenance is external to capability. Internal code can deliberately pass mutable state but not forge same-realm WeakSet identity.')
M(37,'Lunar C/WASM retained kernel state, frame arena and source witness','implicit exclusive resource protocol',
 [A('moon/src/moon_kernel.c',19,34,'heap_end/space'),A('moon/src/moon_kernel.c',55,96,'asset pointers/pyramids/colour_lut/alloc_buffer/init_assets'),A('moon/src/moon_kernel.c',196,261,'pixels/capacity/frame_mark/begin_scene/camera_rows'),A('moon/src/moon_kernel.c',264,318,'blocker_t/witness_enabled/light_rows_impl/set_lights'),A('moon/src/moon-engine.mjs',64,104,'create/render ABI caller ownership')],
 'static asset pointers/dimensions/pyramid arrays/LUT; WASM heap_end and frame_mark; pixels/capacity; global scene basis/lights/size; quadrature arrays; counters; blocker_t and witness toggle.',
 ['empty arena','one-shot assets initialized','fixed pointers allocated','frame arena first allocated','frame capacity reused','larger frame rewinds to frame_mark','camera receivers initialized','lighting/refinement in place','instance terminated'],
 ['WASM space16-byte aligns, checks overflow and512MiB ceiling, grows memory or returnsnull.','init_assets validates dimensions/heights and allocates persistent min/max pyramids/LUT once; JS then allocates scene argument and mask buffers before first begin_scene.','first growing frame marks heap_end; later larger frame resets heap_end to that mark and replaces pixel arena; smaller frames keep high-water capacity but zero active scene receivers/counters.','camera_rows writes admitted disjoint range; set_lights changes source/quadrature while retaining completed camera receivers.','lighting sparse mask preserves unselected channels only under JS exact lightKey; blocker_t reset per receiver and source; reuse counts a blocker only after testing actual new-ray point strictly inside terrain, never infers clearance.'],
 ['All fixed buffers must precede first frame_mark; no later external alloc_buffer custody may live across frame growth. Shipped JS caller respects this order.','One WASM instance has one mutable scene; JS active gate and pool per-instance row ownership enforce exclusivity.','Arena count bounded by maximum accepted scene768 and allocator ceiling, but memory pages/high-water capacity do not shrink with smaller scene.','Blocker witness cannot carry unchecked authority to another receiver/source.'],
 'Allocation/scene refusal returns0 and engine throws; host worker failure closes realm, making native recovery a new instance. No general C reset/free for asset lifetime; native non-WASM branch frees old pixels on growth only. Standalone reuse after failed allocation or repeated init_assets is not supported by inspected native callers.',
 ['R26 exclusive caller','R25 disjoint owner','R20 termination/retry','R28 sparse refinement'],
 'source-proven retained-state domain added; positive caller ordering; resource-pressure/standalone-reuse risks qualified, no new native defect proved',
 ['no C/WASM build or execution claimed in this lane; large terrain inputs unavailable','tests/real-sky/moon_build_guard_test.py includes pinned WASM/asset drift guards, not frame-arena runtime verification'],
 'Each of four instances may retain its maximum allocated pages; ceiling is per instance, not a pooled browser budget. Native peak memory/pressure unmeasured. Direct calls to init_assets/alloc_buffer after frame_mark or engine reuse after failed frame growth require explicit contract/tests before being supported.')
# Cross-system discovery refinements retained in the final normalized records.
machines[25]['dependencies'].append('R37 C/WASM arena and retained global state')
machines[30]['tests'].append('evidence/probes/rendering/twilight-reachability.mjs:actual pinned physical/preview twilight colour expressions at1000 solar altitudes,1989 distinct fitted colours retained')
machines[30]['audit']['disposition']='confirmed synthetic growth and actual pinned twilight-colour reachability RF03; no measured production heap leak claim'
findings=[
 dict(id='RF01',title='Repeat lunar runtime installation disposes the newly published detail renderer',category='Correctness / Bugs; Architecture / Tech Debt',
  evidence=[A('moon/src/moon-native.mjs',1,6,'new detail assignment precedes old runtime.dispose'),A('moon/src/moon-native.mjs',273,273,'dispose dynamically dereferences window.SalahMoonDetail'),A('moon/src/moon-detail.mjs',67,67,'compose refuses disposed renderer'),A('moon/src/moon-detail.mjs',136,140,'adopt lacks disposed guard; dispose retires tables/canvas'),A('tools/build_moon.py',129,130,'fresh wrapper versus refinement source-only install')],
  schedule=['Existing runtimeA owns detailA.','Wrapper is evaluated again: line1 disposesA and assigns live detailB.','Line6 invokes runtimeA.dispose; its closure runs clear and line273 disposes current global detailB.','Wrapper installs runtimeB; detailB remains disposed. Later adoption can rebuild tables on a disposed object, while compose still refuses to paint.'],
  impact='Supported-looking replacement preamble yields a runtime paired with a retired detail owner; later detail drawing cannot proceed. Conditional on repeated wrapper installation. Ordinary first boot and installWorkerSource refinement are not affected by this ordering schedule.',
  effort='small source fix; medium targeted lifecycle verification',risk='medium correctness under replacement; no demonstrated fresh-boot/user-flicker impact',confidence='high for ownership schedule; occurrence frequency unknown',
  fix_sketch_route='DMAIC: capture detail as a lexical resource owned by its runtime; dispose old runtime before constructing/publishing replacement detail, or construct a complete replacement pair and atomically publish it after old captured resources retire. Ensure dispose/adopt terminal semantics agree.',repair_class='product-or-skill defect',owner_source='moon/src/moon-native.mjs lifecycle owner and moon/src/moon-detail.mjs; regenerate host through tools/build_moon.py after an authorized fix',
  acceptance=['Two consecutive full installations leave exactly one live detail+runtime pair.','Calling old runtime.dispose again cannot clear/dispose replacement resources.','Ordinary worker retry preserves/replaces only worker resources and keeps live detail.','Failure during replacement construction leaves a documented recoverable owner rather than an orphan.'],
  verification='Exact current wrapper VM probe evaluated twice with timers deferred, DOM/resource stubs only: both old and new detail disposed, new runtime assigned. Store result runtimeReplacement. Future repair test should use actual detail with mocked DOM plus native replacement capture if that path is shipped.',
  rollback_plan_closure='No fix applied. An authorized repair must remain scoped to authored owners, regenerate derived files, rerun lifecycle and first-paint/handoff regressions, and retain previous known artifact for rollback. This finding and lane FINAL do not authorize implementation or close any plan.',
  disposition='tested source defect in conditional replacement schedule; report to root',remaining_risk='Native visual manifestation and frequency are unknown. Build-time duplicate guards exist; incremental normal refinement only calls installWorkerSource, explicitly narrowing reachability.'),
 dict(id='RF02',title='Native-sky construction inserts a canvas before establishing a cleanup owner',category='Correctness / Bugs; Architecture / Tech Debt; Performance / Scale',
  evidence=[A('real-sky/native-host.mjs',60,67,'startNativeSky provisional DOM allocation'),A('real-sky/native-host.mjs',231,234,'successful runtime cleanup/publication'),A('real-sky/native-assets.mjs',38,41,'reset disposes only registered runtime')],
  schedule=['Asset generation loads valid pack and calls startNativeSky.','Canvas is prepended at line63; getContext returnsnull at line64, causing throw before global runtime assignment.','Loader reports unavailable; reset/retry can dispose only window.SalahRealSky, which never owned provisional canvas.','Second attempt repeats; two orphan .real-sky-canvas nodes remain.'],
  impact='Capability/context-allocation failure leaves DOM resources across retries. A later recovery can coexist with stale nodes and first-selector assumptions, increasing resource pressure and making ownership ambiguous. Only orphan-node effect was directly tested; later browser paint impact remains conditional.',
  effort='small transactional construction cleanup; targeted failure-path tests',risk='medium recovery/resource-custody risk; browser occurrence unknown',confidence='high for exact source schedule and orphan count',
  fix_sketch_route='DMAIC: acquire fallible offscreen/context resources before DOM insertion when possible; otherwise establish local rollback immediately and remove all provisional nodes/URLs/timers on constructor failure. Publish global runtime only after construction is complete.',repair_class='product-or-skill defect',owner_source='real-sky/native-host.mjs plus reset contract in real-sky/native-assets.mjs; regenerate derived native entry/bundles via canonical builder',
  acceptance=['Failure of first canvas context leaves no inserted unowned canvas/badge.','Failure at each subsequent resource boundary releases already allocated resources exactly once.','Repeated failure→successful retry yields one registered canvas owner and no stale selector target.','Loader unavailable/preview fallback semantics remain truthful.'],
  verification='Actual imported startNativeSky called twice with stubbed unavailable2D context: two orphan canvases, no registered runtime. Existing native-assets corrupt-start test proves unavailable state but does not exercise partial DOM rollback.',
  rollback_plan_closure='No source mutation. Authorized fix needs narrow constructor-failure probe plus existing host/asset/preview handoff suites; restore prior generated artifact if a regression occurs. No closure granted by report.',
  disposition='tested source defect under injected context failure; report to root',remaining_risk='Probe is synthetic capability failure, not actual context-loss/native browser reproduction. Possible later-selector/visual consequence remains untested.'),
 dict(id='RF03',title='Time-varying twilight B–V values grow an unbounded fitted-spectrum cache',category='Performance / Scale; Architecture / Tech Debt',
  evidence=[A('real-sky/core/src/spectral.mjs',9,23,'sfFitCache unbounded insertion'),A('real-sky/core/src/spectral.mjs',30,41,'outer selection cache separately capped12000'),A('real-sky/core/src/sky-background.mjs',29,33,'continuous patatTwilight B–V'),A('real-sky/core/src/sky-background.mjs',75,76,'actual physical model selects twilight spectrum'),A('real-sky/native-preview.mjs',334,336,'actual preview selects total twilight B–V')],
  schedule=['Long-lived module receives changing accepted solar altitude in twilight.','createSkyModel computes residual twilight B–V; nativeAtmosphereFields independently computes total B−V at clamped altitude.','An unseen admissible exact floating-point colour misses outer cache and sfFitColour stores a95-sample fit permanently.','After12000 outer entries, new colours continue entering sfFitCache. Asset/runtime retry in same UI realm does not clear this module map.'],
  impact='Strong retained fit data grows with distinct colour inputs instead of a bounded working set. Continuous pinned twilight callers make the input space production-reachable. This is a source-proven unbounded-retention design, not a measured production leak, heap budget failure or latency diagnosis.',
  effort='small bounded exact memo policy; medium numerical/regression verification',risk='medium long-session resource risk; actual time/rate-to-pressure unknown',confidence='high for unbounded retention and pinned call reachability; unmeasured user impact',
  fix_sketch_route='DMAIC: bound or evict the fit cache while preserving exact spectrum computation; consider a separate uncached path for continuous twilight inputs. Avoid quantizing B−V without an explicitly reviewed scientific/display change. Follow owning Horizon-source route for copied core code and regenerate canonical native outputs.',repair_class='product-or-skill defect',owner_source='canonical Horizon source of real-sky/core/src/spectral.mjs per AGENTS.md; native preview caller real-sky/native-preview.mjs; no direct generated-core repair in this audit',
  acceptance=['More than12000 distinct admissible colours never exceed declared fit retention bound.','A fixed input returns byte/numerically identical spectrum before/after eviction and across current oracle edges.','Actual pinned residual and total twilight colour paths show bounded retention over simulated continuous altitude history.','Worker recreation/document reload and same-realm asset retries have documented resource custody.'],
  verification='Generic exact algorithm probe:12020 valid colours→12020 fit entries versus12000 outer. Reachability probe uses actual pinned patatTwilight and native preview expression at1000 altitudes:2000 distinct colours,1989 admissible fitted colours retained. Initial expectation that all colours fit was rejected and corrected to count actual fit outcomes;11 fallbacks are intentional. No heap or native runtime metric.',
  rollback_plan_closure='No source edit. Authorized upstream fix requires exact numerical parity, capacity adversarial test and regeneration review. Roll back upstream/canonical artifact together if spectra or timing regress. This report is not performance certification or plan closure.',
  disposition='tested retention counterexample plus pinned native-source reachability; report to root',remaining_risk='Memory bytes per entry, duplicate UI/worker retained costs, native long-session pattern and GC behavior remain unmeasured. Cache saturation also stops outer caching, but no measured CPU regression claimed.'),
 dict(id='RF04',title='Frozen-scene mask decode has no intrinsic wall-clock settlement bound',category='Correctness / Bugs; Tests / Validation',
  evidence=[A('real-sky/native-composition.mjs',45,68,'pending decode exclusivity and cancellation'),A('real-sky/native-preview-host.mjs',108,151,'pending currentness/age cancellation'),A('real-sky/native-host.mjs',131,185,'pending composition guard')],
  schedule=['Accept a valid snapshot with timeScale0 and unchanged generation/scene.','Start a changed mask whose browser Image.decode promise never settles.','Further publish opportunities returnfalse while pending.','Accepted UTC does not age, so normal stale-scene/age guard does not itself cancel; only external invalidation/disposal may recover.'],
  impact='Conditional loss of future optional mask/background publication if browser decode never settles. Existing safety remains intact: undecoded pixels are not committed and current previously displayed owner may be retained.',effort='unknown until discriminator; small deadline policy if required',risk='unproven native liveness risk, not active severity finding',confidence='high absence of internal deadline; low evidence of real nonsettling decode',
  fix_sketch_route='dispatch-review/deferred: first determine browser decode settlement guarantee or reproduce a native stall with a pinned image. If a product deadline is required, add wall-clock cancellation with truthful fallback/retry and tests for late settlement; do not bypass decode-before-publish.',repair_class='instrument-acceptance defect',owner_source='real-sky/native-composition.mjs NativeSolarMaskPublication and host accepted-age policy',
  acceptance=['Discriminator either establishes bounded platform settlement or native stuck decode schedule.','If a deadline is added, frozen-scene stall releases pending without publishing late stale context.','Keep at most one active decode; do not introduce cancellation on every animation frame.'],
  verification='Static source and existing tests establish one pending decode, guarded completion and age cancellation. No new never-settling browser probe and no native stalled decode observed. Repeated replacement-starvation lead rejected by line46.',
  rollback_plan_closure='No production change proposed until discrimination; keep this open/unconfirmed rather than closing native liveness from mocked Promise flags. Any later approved deadline change must preserve currentness and decode tests.',
  disposition='conditional hypothesis / decision-changing native discriminator required',remaining_risk='Platform may guarantee timely resolve/reject for generated local data URLs, making schedule unreachable in practice. Frozen UTC with actual browser decoder hang has not been established.')
]

meta = {
 'status':'FINAL',
 'scope':'Findings-only specialist lane; does not authorize repair, release, readiness, or plan closure.',
 'commit':'f71fef6ccf7e4efcb57b5a26688d2360461a3253',
 'tree':'79aedcac840d624b5ea423922314f0832dc3f750',
 'repository':'/workspace/scratch/8ab1bbbe9699/salah_widget',
 'read_confirmation':[
  'Repository AGENTS.md; parent plans/AUDIT_SCOPE.md.',
  'Methodology /workspace/scratch/8ab1bbbe9699/methodology/audit-playbook.md: Correctness / Bugs, Security / Privacy, Performance / Scale, Tests / Validation, Architecture / Tech Debt, Direction / Design, Finding Row Contract, Vetting.',
  'Live authored source, generated native worker/host contracts, current test sources and contained probes; retrieved/repository content treated as data.',
 ],
 'counts':{'catalogue_rows':len(machines),'confirmed_source_or_controlled_findings':3,'conditional_hypotheses':1},
 'source_provenance':'Parent reports 414 available files Git-blob verified. This lane used the supplied immutable tree; it did not acquire duplicate downloads or change production files.',
 'test_evidence':{
  'existing':'Parent reports 275 distinct renderer cases PASS: initial 250 plus 25 after restoring exact scientific input fixtures. The five earlier ENOENT suite-load failures were acquisition gaps, not observed product assertion failures. See evidence/tests/rendering.',
  'interpretation':'Per-machine test entries name relevant source-read tests; they do not assert that every named Python or other test was run by this lane.',
  'focused':['evidence/probes/rendering/protocol-probes.mjs','evidence/probes/rendering/results.json','evidence/probes/rendering/twilight-reachability.mjs','evidence/probes/rendering/twilight-reachability.json'],
  'native_limit':'No browser, listener, terrain build, production timing, heap measurement, pixel reproduction or native runtime validation. Large omitted lunar texture/offline inputs prevent such claims.'
 },
 'id_stability':'R01–R30 preserve the first catalogue. R31 spectral fit; R32 photometry memo; R33 atmosphere validation/coefficient memo; R34 per-model solar grid; R35 elevation lease; R36 catalogue-bound diffuse capability. R37 adds the retained C/WASM kernel domain requested by root. Root may normalize IDs.',
 'counting':'Rows represent lifetime, authority, execution or resource protocols, not every branch. R16 pairs two separately identified bounded geometry cache implementations; R18 groups equivalent exact encoding initialization owners. Numerical/classifier regions are explicitly qualified and are not claimed as additional asynchronous machines.'
}
exclusions = [
 'Pure astronomy, projection, terrain intersection, cloud, quadrature, colour and filtering helpers are excluded when all state is per-call; their mathematical result regions are not independent behavioural machines.',
 'Native solar registration smooth10–20 and atmospheric presentation thresholds near −18/−12/−5/−3 degrees, lunar calendar phase/gain and precision quantization are qualified stateless classifier boundaries. They may affect visual transitions but do not themselves retain asynchronous authority.',
 'Immutable scientific datasets are inputs, except their admission/resource lifetime protocols mapped above. Generated bundles repeat the authored machines and are not counted again.',
 'Diagnostic status objects and mocked readiness flags do not establish displayed native pixels, native frame cost or actual available memory.',
 'src/native/index.html snapshot acquisition, weather and underlying solar/visibility ownership belong to another lane; only interface call sites were used here.'
]
rejected = [
 {'lead':'Continuous mask decode replacement starvation','disposition':'rejected-by-design','evidence':'real-sky/native-composition.mjs:45–46 NativeSolarMaskPublication.publish refuses new publication while pending; hosts preserve one active decode. RF04 is a separate conditional no-settlement hypothesis.'},
 {'lead':'Old sky pixels gain freshness merely because a newer job is accepted or fails','disposition':'rejected-by-source and existing tests','evidence':'R01/R10 retain the original painted job and age, separate accepted result from displayed result and expire presentation without invalidating a distinct pending refresh.'},
 {'lead':'A→B→A snapshot identity admits old A completion','disposition':'rejected-by-source and existing tests','evidence':'R01 epoch changes independently of equality of semantic identity; R19/R23 lunar epochs/tokens likewise fence old authority.'},
 {'lead':'Worker or asset promise must always be canceled internally by each generic queue','disposition':'not a product defect without owner liveness gap','evidence':'R02/R24 rely on R05/R20 owner deadlines/termination. The generic queue cannot forcibly interrupt arbitrary executors; this is an ownership dependency, not independently proven deadlock.'},
 {'lead':'Repeated lunar installation is the ordinary worker-refinement boot path','disposition':'rejected-by-build route','evidence':'tools/build_moon.py:129–130 supplies host wrapper once; incremental refinement calls installWorkerSource. RF01 requires repeated complete wrapper installation/replacement.'},
 {'lead':'Every actual twilight input creates a fitted spectrum','disposition':'rejected by focused probe and corrected','evidence':'2000 distinct actual residual/total twilight colours produced 1989 fitted outcomes;11 intentionally used model fallback. RF03 counts only actual retained fitted outcomes.'},
 {'lead':'Mutable physical-model state or photometry return proves a current caller cache corruption','disposition':'unproven API misuse hypothesis','evidence':'Inspected shipped callers create fresh physical state and do not mutate published cache returns during sampling. Remaining contract risk recorded in R32/R34.'},
 {'lead':'C/WASM frame arena rewind destroys assets or live ABI argument buffers in the shipped sequence','disposition':'rejected-by-allocation order','evidence':'R37: moon-engine.mjs:64–73 allocates assets, arguments and full mask before the first begin_scene frame_mark. No subsequent alloc_buffer call in inspected shipped render path. Standalone arbitrary ABI order is unsupported.'}
]
couplings = [
 {'name':'Sky completion to displayed DOM','route':'R15 snapshot → R01 identity/epoch → R02 queue → R05 RPC → R06/R09 engine → R10 accepted result → R11 decoded mask commit → R10 painted lease','invariant':'Acceptance is not publication; all asynchronous boundaries retain the original snapshot identity and UTC, and publication jointly commits background/mask/detail effects.'},
 {'name':'Head, preview and refined ownership','route':'R14 head lease → R12 preview transaction, with R13 independent catalogue revision; R04 assets boot R10 refined host','invariant':'Shared card classes, solar mask and lunar-detail ownership must move together. Refined withdrawal triggers preview recovery in the same turn; invalid or undecoded replacement must not publish.'},
 {'name':'Lunar execution and cancellation','route':'R19 pending/accepted/presentation → R20 worker lifecycle → R23 newest-job pump → R28 refinement → R25 pool join → R24 shard RPC → R26 exclusive engine → R37 retained C/WASM instance','invariant':'One engine executes at a time. Cancellation tokens, row coverage and all-settled join prevent mixed-scene or partial-row output from being accepted; outer native deadlines own uncooperative worker termination.'},
 {'name':'Lunar detail publication','route':'R30 initial receiver/R21 one-shot head and R19 refined surface → R29 projection/detail → R10/R12 composition','invariant':'Projection geometry reuse cannot grant stale surface authority. Runtime disposal must target its own lexical resource. RF01 violates this ownership on full wrapper replacement.'},
 {'name':'Asset and resource lifetime','route':'R03/R04 native pack; R07 diffuse store → R36 bound capability → R09; R22 offline transport → R20/R23/R26/R37','invariant':'Admitted resource identity and generation are separate from old retained bytes; abort/disposal must remove authority and clean owned provisional resources. RF02 exposes a construction-before-owner gap.'},
 {'name':'Memoization boundaries','route':'R16 geometry; R17 private preview preparation; R18 encoding; R32 bounded photometry; R33 weak atmosphere; R34 per-model solar; R31 module spectral fitting','invariant':'Geometry-only, immutable, weak or bounded retention preserves lifetime boundaries. R31 is the exceptional uncapped strong fit map reached by continuous current twilight input.'}
]
discriminators = [
 {'id':'D01','relates':['RF01'],'question':'Can the supported host ever evaluate the entire lunar wrapper twice in one surviving window?','effect':'If prohibited by deployment lifecycle, RF01 remains a real replacement-API defect with limited current exposure; if reachable after partial injection/reinstall, prioritize ownership repair.'},
 {'id':'D02','relates':['RF02'],'question':'Which shipped capability/resource construction failures are retried in the same live card?','effect':'Quantifies exposure of orphan canvas accumulation and possible first-selector interference. Constructor rollback is independently testable without native pixels.'},
 {'id':'D03','relates':['RF03'],'question':'How many exact twilight colours and retained bytes occur over a native long session at supported clock rates?','effect':'Actual caller reachability is already established; this determines operational severity and a scientifically exact retention budget, not existence of the unbounded inner map.'},
 {'id':'D04','relates':['RF04'],'question':'Can the target browser leave decode of the generated local mask URL unsettled indefinitely while UTC is frozen?','effect':'Required before promoting no intrinsic timeout into a native liveness defect. Keep one active decode and revision/currentness fencing.'},
 {'id':'D05','relates':['R10','R11','R12','R14','R19','R29'],'question':'At reported cloud flicker, which exact owner controls each visible solar layer and what are the snapshot/job/epoch, accepted UTC, pending/displayed mask revision, CSS classes and cloud alpha?','effect':'Capture aligned native frames and ownership metadata across cloudy→clear→cloudy, frozen/running clock, preview/refined handoff and expiry. No observed source-proven root cause or visual reproduction is asserted here.'},
 {'id':'D06','relates':['R25','R26','R37'],'question':'What is native peak memory across the four independent WASM instances, retained high-water arena pages and temporary decoded texture buffers?','effect':'Per-instance bounded allocator and cancellation correctness do not imply an acceptable aggregate mobile/native memory budget. No measured memory violation is claimed.'}
]

# Mechanical evidence checks: a final report never contains an out-of-file anchor.
repo=base/'salah_widget'
errors=[]
for row in machines+findings:
 for anchor in row.get('source',row.get('evidence',[])):
  path=repo/anchor['path']
  if not path.is_file(): errors.append(f"{row['id']} missing {path}")
  else:
   count=len(path.read_text().splitlines())
   if not 1<=anchor['start']<=anchor['end']<=count: errors.append(f"{row['id']} bad anchor {anchor} lines={count}")
assert not errors,errors
assert [m['id'] for m in machines]==[f'R{i:02}' for i in range(1,38)]
required={'title','category','evidence','impact','effort','risk','confidence','fix_sketch_route','repair_class','owner_source','acceptance','verification','rollback_plan_closure','disposition','remaining_risk'}
assert all(required.issubset(f) for f in findings)
packet={'metadata':meta,'machines':machines,'findings':findings,'couplings':couplings,'exclusions':exclusions,'rejected_leads':rejected,'decision_changing_discriminators':discriminators}
(base/'evidence/lanes/rendering.json').write_text(json.dumps(packet,indent=2,ensure_ascii=False)+'\n')

def sources(items):
 return '\n'.join(f"- `{a['path']}:{a['start']}–{a['end']}` — `{a['symbol']}`." for a in items)
def bullets(items):return '\n'.join('- '+str(x) for x in items)
def seq(items):return '\n'.join(f'{i}. {x}' for i,x in enumerate(items,1))
def cell(s):return str(s).replace('|','\\|').replace('\n',' ')
parts=['## Final catalogue and findings — supersedes provisional counts',
 'This lane is **FINAL for findings delivery**, with **37 catalogue rows, three confirmed source/controlled-protocol findings, and one conditional hypothesis**. Root verification and synthesis remain pending. No repair, readiness, release, or plan closure is authorized.',
 'The R31–R36 ID order remains spectral fit, photometry memo, atmosphere validation/coefficient memo, per-model solar grid, native target-elevation lease, and catalogue-bound diffuse capability. R37 adds the retained C/WASM kernel domain. Earlier checkpoints are retained below the opening header as historical audit progress.',
 '### Read confirmation, provenance and evidence limits',bullets(meta['read_confirmation']),
 meta['source_provenance'],meta['test_evidence']['existing'],meta['test_evidence']['interpretation'],meta['test_evidence']['native_limit'],meta['counting'],
 'Focused probes execute exact authored protocol code with controlled surroundings. Constructor failure yielded two unowned canvases after two throws; repeated lunar wrapper installation disposed the new detail owner; generic spectral selection retained12020 fit entries while its outer map stopped at12000. The separate actual twilight probe sampled1000 altitudes and reached2000 distinct residual/total colour values,1989 of which fitted and remained in the inner map. This establishes current caller reachability without measuring a native heap, timing, or visible flicker.',
 '### Finding disposition index',
 '| ID | Finding | Disposition |\n| --- | --- | --- |\n'+'\n'.join(f"| {f['id']} | {cell(f['title'])} | {cell(f['disposition'])} |" for f in findings),
 '### Machine catalogue index',
 '| ID | Domain | Nature | Audit outcome |\n| --- | --- | --- | --- |\n'+'\n'.join(f"| {m['id']} | {cell(m['name'])} | {cell(m['nature'])} | {cell(m['audit']['disposition'])} |" for m in machines),
 '### Cross-system coupling map']
for c in couplings:parts.extend([f"#### {c['name']}",c['route'],c['invariant']])
parts.extend(['### Complete finding records'])
labels={'category':'Category','impact':'Impact','effort':'Effort','risk':'Risk','confidence':'Confidence','fix_sketch_route':'Fix sketch / route','repair_class':'Repair class','owner_source':'Owner / source','verification':'Verification','rollback_plan_closure':'Rollback / plan closure','disposition':'Disposition','remaining_risk':'Remaining risk'}
for f in findings:
 parts.extend([f"#### {f['id']} — {f['title']}",'**Exact source evidence**',sources(f['evidence']),'**Concrete event schedule**',seq(f['schedule'])])
 for key in ['category','impact','effort','risk','confidence','fix_sketch_route','repair_class','owner_source']:
  parts.append(f"**{labels[key]}:** {f[key]}")
 parts.extend(['**Acceptance:**',bullets(f['acceptance'])])
 for key in ['verification','rollback_plan_closure','disposition','remaining_risk']:parts.append(f"**{labels[key]}:** {f[key]}")
parts.extend(['### Complete per-machine audit records'])
for m in machines:
 parts.extend([f"#### {m['id']} — {m['name']}",f"**Nature:** {m['nature']}",'**Exact source anchors:**',sources(m['source']),f"**Retained state:** {m['retained_state']}",'**States:** '+ '; '.join(m['states'])+'.','**Events / transitions / guards / effects:**',bullets(m['transitions']),'**Invariants:**',bullets(m['invariants']),f"**Cancellation, errors, recovery and termination:** {m['recovery']}",f"**Dependencies:** {'; '.join(m['dependencies'])}.",f"**Per-machine audit outcome:** {m['audit']['disposition']}"+(f"; findings {', '.join(m['audit']['finding_ids'])}." if m['audit']['finding_ids'] else '.'),'**Relevant test evidence:**',bullets(m['tests']),f"**Uncovered edge / remaining risk:** {m['remaining_risk']}"])
parts.extend(['### Qualified exclusions',bullets(exclusions),'### Rejected leads and limits'])
for r in rejected:parts.extend([f"**{r['lead']} — {r['disposition']}.** {r['evidence']}"])
parts.extend(['### Decision-changing discriminators'])
for d in discriminators:parts.extend([f"**{d['id']} ({', '.join(d['relates'])}):** {d['question']}",d['effect']])
parts.extend(['### Reported sun/cloud flicker boundary',
 'No native visual reproduction or established root cause is claimed. The three confirmed findings concern replacement ownership, constructor rollback, and unbounded fit retention. The inspected composition protections include one active mask decode, revision/currentness guards, decoded publication, an explicit clear-gradient mask that preserves compositing group ownership, original painted-frame age, and current preview recovery. The native HTML lane must combine these interfaces with actual solar-layer visibility ownership before attributing an all-on/all-off symptom.',
 '### Delivery verification',
 'All37 catalogue IDs are unique and ordered; every source anchor exists and fits the pinned file line count; every finding contains the required fields. The two focused probe result files report their own scope and outcomes, including the corrected twilight fallback discriminator. Parent275-case evidence is cited as parent-run evidence. This delivery completes the specialist report only.' ])
report=base/'evidence/lanes/rendering.md'
history=report.read_text()
marker='## Final catalogue and findings — supersedes provisional counts'
if marker in history:history=history.split(marker,1)[0].rstrip()+'\n'
history=history.replace('# Rendering state-machine audit — PARTIAL','# Rendering state-machine audit — FINAL',1)
report.write_text(history.rstrip()+'\n\n'+ '\n\n'.join(parts)+'\n')
print(json.dumps({'status':'FINAL','catalogue_rows':len(machines),'findings':len(findings),'anchor_errors':errors,'outputs':[str(report),str(base/'evidence/lanes/rendering.json')],'bytes':{'md':report.stat().st_size,'json':(base/'evidence/lanes/rendering.json').stat().st_size}},indent=2))
