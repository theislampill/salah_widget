// Read-only GR04 probe. Execute exact, unchanged source slices with controlled
// retained state. beginRequest records gate reachability and returns null, so
// no operation, attempt, timer, network request, response, or UI is created.
// The boundary rows are independent settled-state snapshots, not a simulation
// of successful acquisitions following earlier beginRequest observations.
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');

const SOURCE_COMMIT = 'f71fef6ccf7e4efcb57b5a26688d2360461a3253';
const SOURCE_SHA256 = '6054f1eb3e7f04aa5975707345810b64fc824bc99e17ce3798369a959a123fad';
const sourcePath = path.resolve(__dirname, '../../../salah_widget/src/native/index.html');
const source = fs.readFileSync(sourcePath, 'utf8');
const sha256 = value => crypto.createHash('sha256').update(value).digest('hex');
assert.equal(sha256(source), SOURCE_SHA256, 'Pinned canonical source must be unchanged');
const sourceSlices = [];
function exactSlice(name, startMarker, endMarker) {
  const start = source.indexOf(startMarker);
  assert(start >= 0, `${name}: start marker exists`);
  assert.equal(source.indexOf(startMarker, start + 1), -1, `${name}: unique start marker`);
  const end = endMarker === '\n' ? source.indexOf('\n', start) + 1 : source.indexOf(endMarker, start);
  assert(end > start, `${name}: end marker exists after start`);
  const code = source.slice(start, end);
  sourceSlices.push({name, start_line: source.slice(0, start).split('\n').length,
    end_line: source.slice(0, end - 1).split('\n').length, sha256: sha256(code),
    extraction: 'Verbatim source substring; no function-body edits or instrumentation'});
  return code;
}
const code = [
  exactSlice('weather constants', 'const _WX_CURRENT_TTL=', '\n'),
  exactSlice('weather code admission set', 'const _WX_CODES=', '\n'),
  exactSlice('radar constants', 'const _RADAR_Z=', '\n'),
  exactSlice('usableWeatherCoordinates', 'function usableWeatherCoordinates(', 'function wxNumber('),
  exactSlice('wxNumber', 'function wxNumber(', 'function wxValue('),
  exactSlice('weatherTargetSame', 'function weatherTargetSame(', 'let _wxTargetCache='),
  exactSlice('weatherEligibility', 'function weatherEligibility(', 'function selectedWeather('),
  exactSlice('selectedWeather', 'function selectedWeather(', '// A target describes the configured site'),
  exactSlice('fetchWeather', 'async function fetchWeather(){', '// RainViewer tiles retain mosaic provenance'),
  exactSlice('fetchRadar', 'async function fetchRadar(){', '// linear-interpolate the forecast track'),
].join('\n');
const script = new vm.Script(code, {filename: 'pinned-native-weather-radar-exact-source-slices.js'});

const T = Date.UTC(2026, 10, 6, 14, 0, 0);
const BACKWARD_CORRECTION_MS = 60 * 60 * 1000;
const sourceValidAt = T - 30 * 1000;
const allHarnesses = [];
function createHarness(trackPresent) {
  const clock = {wall: T, elapsed: 0, dateNowReads: 0, elapsedReads: 0};
  const calls = [];
  const forbiddenCalls = [];
  const target = Object.freeze({generation: 17, lat: 40.7128, lon: -74.006,
    intent: 'fixed-site', source: 'manual', accuracyM: null, acquiredAt: null});
  const weather = Object.freeze({code: 0, src: 'current', units: 'c', temp: 12,
    cloud: 20, provider: 'Open-Meteo', product: 'current weather model',
    currentValidAt: sourceValidAt, currentIntervalSec: 900, retrievedAt: T, target});
  // fetchWeather only inspects whether the track is present at its freshness
  // gate. No hourly-track interpolation/admission claim is made by this fixture.
  const track = trackPresent ? Object.freeze({target, ep: Object.freeze([T, T + 3600000])}) : null;
  const config = Object.freeze({lat: target.lat, lon: target.lon, tz: 'UTC',
    locationEvidence: Object.freeze({intent: 'fixed-site', source: 'manual'})});
  class ControlledDate extends Date {
    static now() { clock.dateNowReads++; return clock.wall; }
  }
  function forbidden(name) {
    return function () { forbiddenCalls.push(name); throw new Error(`Forbidden dependency reached: ${name}`); };
  }
  const ctx = {
    Date: ControlledDate, SIM: Object.freeze({wx: null}), ADVANCING: false, _clockPreview: false,
    CONFIG: config, _runtimeGeneration: target.generation,
    lat: target.lat, lon: target.lon, tz: 'UTC', units: 'c',
    weather, weatherTrack: track, wxBusy: false, radarBusy: false,
    lastWxAt: T, lastWxTry: T, lastRadarAt: T,
    currentWeatherTarget() { return target; },
    beginRequest(kind) {
      assert(['weather', 'radar'].includes(kind), 'Known acquisition owner');
      calls.push({kind, wall: clock.wall, elapsed: clock.elapsed});
      return null; // Stop at the boundary: reaching this spy is not a dispatched request.
    },
    _RAFNOW() { clock.elapsedReads++; return clock.elapsed; },
    performance: {now() { clock.elapsedReads++; return clock.elapsed; }},
  };
  for (const name of ['beginAttempt', 'finishAttempt', 'finishRequest', 'captureWeatherTarget',
    'wxFetchJson', 'wxRadarSample', 'fetch', 'Image', 'XMLHttpRequest', 'setTimeout',
    'beginRuntimeGeneration', 'resetForNewLocation', 'bindConfig']) ctx[name] = forbidden(name);
  vm.createContext(ctx);
  script.runInContext(ctx, {timeout: 1000});
  const retained = () => ({generation: ctx._runtimeGeneration, lat: ctx.lat, lon: ctx.lon,
    tz: ctx.tz, units: ctx.units, wxBusy: ctx.wxBusy, radarBusy: ctx.radarBusy,
    lastWxAt: ctx.lastWxAt, lastWxTry: ctx.lastWxTry, lastRadarAt: ctx.lastRadarAt});
  const initialRetained = retained();
  const h = {ctx, clock, calls, forbiddenCalls, trackPresent, initialRetained,
    assertRetained() {
      assert.deepEqual(retained(), initialRetained, 'No generation, ownership, or cooldown reset/mutation');
      assert.equal(ctx.CONFIG, config, 'No configuration replacement');
      assert.equal(ctx.weather, weather, 'Retained current record is unchanged');
      assert.equal(ctx.weatherTrack, track, 'Retained track presence is unchanged');
      assert.equal(ctx.currentWeatherTarget(), target, 'Same target and target-generation identity');
      assert.deepEqual(forbiddenCalls, [], 'No attempts, network, timers, configuration resets, or other forbidden work');
      assert.equal(clock.elapsedReads, 0, 'The four source functions do not consult elapsed time at these gates');
    }};
  allHarnesses.push(h);
  return h;
}

async function observe(h, test) {
  h.clock.wall = T + test.wallOffset;
  h.clock.elapsed = test.elapsed;
  const wallIso = new Date(h.clock.wall).toISOString();
  assert.equal(wallIso.slice(0, 10), new Date(T).toISOString().slice(0, 10), 'Same UTC civil day');
  const start = h.calls.length;
  // Use the exact source defaults so Date.now is read inside the actual functions.
  const eligibility = h.ctx.weatherEligibility(h.ctx.weather);
  const selected = h.ctx.selectedWeather();
  await h.ctx.fetchWeather();
  await h.ctx.fetchRadar();
  const reached = h.calls.slice(start).map(call => call.kind);
  assert.equal(eligibility.eligible, test.eligible, `${test.name}: weather eligibility`);
  assert.equal(selected === h.ctx.weather, test.eligible, `${test.name}: selected current record`);
  assert.deepEqual(reached, test.reached, `${test.name}: beginRequest gate boundary`);
  if (!test.eligible) {
    assert(eligibility.receiptAgeMs < 0, `${test.name}: receipt becomes future-dated`);
    assert(eligibility.sourceAgeMs < 0, `${test.name}: source timestamp becomes future-dated`);
  }
  h.assertRetained();
  return {case: test.name, wall_utc: wallIso, wall_delta_from_T_ms: test.wallOffset,
    controlled_elapsed_ms: test.elapsed, hourly_track_present: h.trackPresent,
    weather_eligibility: {eligible: eligibility.eligible, source_age_ms: eligibility.sourceAgeMs,
      receipt_age_ms: eligibility.receiptAgeMs, reason: eligibility.reason},
    selected_current_record: selected === h.ctx.weather,
    reached_beginRequest: reached, request_or_network_dispatched: false,
    retained_owner_and_configuration_unchanged: true};
}
const rollbackCases = [
  {name: 'settled_before_correction', wallOffset: 1000, elapsed: 1000, eligible: true, reached: []},
  {name: 'immediately_after_one_hour_backward_correction', wallOffset: 1000 - BACKWARD_CORRECTION_MS,
    elapsed: 1000, eligible: false, reached: []},
  {name: 'sixty_seconds_elapsed_after_correction', wallOffset: 61000 - BACKWARD_CORRECTION_MS,
    elapsed: 61000, eligible: false, reached: []},
  {name: 'six_hundred_seconds_elapsed_after_correction', wallOffset: 601000 - BACKWARD_CORRECTION_MS,
    elapsed: 601000, eligible: false, reached: []},
];
const boundaries = [
  {name: 'one_ms_before_original_weather_boundary', wallOffset: 59999, eligible: true, reached: []},
  {name: 'original_T_plus_60s_weather_boundary', wallOffset: 60000, eligible: true, reached: ['weather']},
  {name: 'one_ms_before_original_radar_boundary', wallOffset: 599999, eligible: true, reached: ['weather']},
  {name: 'original_T_plus_600s_radar_boundary', wallOffset: 600000, eligible: true, reached: ['weather', 'radar']},
];

(async () => {
  const groups = [];
  for (const trackPresent of [false, true]) {
    const h = createHarness(trackPresent);
    const observations = [];
    for (const test of rollbackCases) observations.push(await observe(h, test));
    groups.push({group: trackPresent ? 'rollback_same_owner_full_track' : 'rollback_same_owner_current_only',
      method: 'Sequential clock changes in one settled-owner context; no configuration reset or successful acquisition',
      observations});
  }
  for (const correction of [BACKWARD_CORRECTION_MS, 0]) {
    const observations = [];
    const tests = correction ? boundaries : [rollbackCases[0], ...boundaries];
    for (const test of tests) {
      const h = createHarness(false);
      observations.push(await observe(h, {...test, elapsed: test.wallOffset + correction}));
    }
    groups.push({group: correction ? 'rollback_original_wall_time_boundaries' : 'normal_no_rollback_boundaries',
      method: 'Independent settled-owner snapshots with current record and no hourly track; beginRequest spy never creates an operation',
      observations});
  }
  const fullTrackObservations = [];
  for (const test of [
    {name: 'normal_full_track_at_60s_keeps_fresh_weather', wallOffset: 60000, elapsed: 60000,
      eligible: true, reached: []},
    {name: 'normal_full_track_at_600s_keeps_fresh_weather_but_reaches_radar', wallOffset: 600000,
      elapsed: 600000, eligible: true, reached: ['radar']},
  ]) fullTrackObservations.push(await observe(createHarness(true), test));
  groups.push({group: 'normal_full_track_freshness_countercontrol',
    method: 'The separate fifteen-minute weather freshness gate may still block weather after the retry cooldown expires',
    observations: fullTrackObservations});

  for (const h of allHarnesses) h.assertRetained();
  assert.equal(sha256(fs.readFileSync(sourcePath)), SOURCE_SHA256, 'Source remains unchanged after the probe');
  const result = {
    probe_status: 'assertions_passed', product_readiness_verdict: 'not assessed',
    finding: 'A backward wall-clock correction rejects the retained current-weather record while the weather/radar cooldown gates suppress acquisition despite elapsed-time opportunities',
    source: {path: 'salah_widget/src/native/index.html', supplied_commit_pin: SOURCE_COMMIT,
      sha256: SOURCE_SHA256, expected_hash_matches: true, slices: sourceSlices},
    probe: {path: 'evidence/probes/root/clock-discontinuity.cjs',
      sha256: sha256(fs.readFileSync(__filename)), runtime: process.version},
    fixture: {T_utc: new Date(T).toISOString(), last_weather_attempt_utc: new Date(T).toISOString(),
      last_weather_receipt_utc: new Date(T).toISOString(), last_radar_attempt_utc: new Date(T).toISOString(),
      current_source_valid_utc: new Date(sourceValidAt).toISOString(), timezone: 'UTC',
      backward_correction_ms: BACKWARD_CORRECTION_MS, generation: 17,
      live_mode: true, weather_busy: false, radar_busy: false,
      current_target_stub: 'Fixed matching target; exact source weatherTargetSame compares generation/coordinates',
      retained_record_scope: 'Fixture satisfies the tested source eligibility predicates; provider admission and transport are outside this probe',
      beginRequest_spy: 'Records which owner reaches acquisition, then returns null; no request is issued and no attempt timestamps are renewed'},
    observations: groups,
    summary: {observation_count: groups.reduce((n, g) => n + g.observations.length, 0),
      beginRequest_gate_reaches: allHarnesses.reduce((n, h) => n + h.calls.length, 0),
      forbidden_dependency_calls: allHarnesses.reduce((n, h) => n + h.forbiddenCalls.length, 0),
      elapsed_clock_reads_by_tested_functions: allHarnesses.reduce((n, h) => n + h.clock.elapsedReads, 0),
      source_unchanged: true, same_target_generation_and_configuration: true},
    interpretation: [
      'Current weather is eligible and selected before correction and becomes ineligible/unselected immediately afterward in both track states.',
      'After sixty and six hundred seconds of controlled elapsed time following rollback, neither acquisition owner reaches beginRequest.',
      'With no hourly track, weather reaches beginRequest exactly at original wall T+60s; radar exactly at original wall T+600s. One millisecond earlier, each respective gate remains closed.',
      'The same wall thresholds are reached after only 60s/600s of elapsed time without rollback; the rollback boundary snapshots require 3660s/4200s from T.',
      'A fresh current record with an hourly track still blocks normal weather reacquisition after 60s/600s, which is the independent freshness gate, not a failed retry-boundary control.',
    ],
    limits: [
      'Synthetic controlled-clock execution of exact source functions, not a native browser, OS clock, provider, network, or performance experiment.',
      'The caller refresh loop is not executed; the probe invokes the source acquisition functions at modeled refresh opportunities.',
      'beginRequest is a stop spy, so reached_beginRequest means passing source pre-acquisition gates, not issuing or completing a request.',
      'Later boundary cases are independent snapshots of retained settled state; they do not assume successful acquisition after earlier observations.',
      'No configuration reset, preview change, active transport, day rollover, DST transition, or response adoption is exercised.',
      'No changes to application sources, projection, lane packets, or machine counts; no corrective implementation or global product PASS is claimed.',
    ],
  };
  process.stdout.write(JSON.stringify(result, null, 2) + '\n');
})().catch(error => { process.stderr.write(`${error.stack || error}\n`); process.exitCode = 1; });
