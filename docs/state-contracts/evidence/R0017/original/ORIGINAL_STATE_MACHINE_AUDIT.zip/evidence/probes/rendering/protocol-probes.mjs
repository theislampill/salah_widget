import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const root='/workspace/scratch/8ab1bbbe9699/salah_widget';
const result={commit:'f71fef6ccf7e4efcb57b5a26688d2360461a3253',scope:'Synthetic protocol probes against exact authored source; no native runtime, pixels, timing or memory measurement'};
// A real module call; construction is stopped at the first failing resource.
const nodes=[];
globalThis.window={SalahNativeSkyHost:{}};
globalThis.document={querySelector(){return {prepend(n){nodes.unshift(n)},append(n){nodes.push(n)}}},createElement(tag){return {tag,className:'',setAttribute(){},getContext(){return null}}}};
const {startNativeSky}=await import(pathToFileURL(root+'/real-sky/native-host.mjs'));
for(let i=0;i<2;i++)assert.throws(()=>startNativeSky({},'',true),/Canvas 2D unavailable/);
assert.equal(nodes.filter(n=>n.className==='real-sky-canvas').length,2);
assert.equal(window.SalahRealSky,undefined);
result.constructorFailure={attempts:2,unownedCanvasCount:2,registeredRuntime:false,assertions:'pass'};
// Evaluate the exact wrapper twice with scheduling disabled, retaining old runtime.
const details=[];
const world={window:{__SALAH_MOON_EMBEDDED__:true},document:{baseURI:'about:blank',currentScript:null,createElement(){return {}},addEventListener(){},removeEventListener(){}},startMoonDetail(){const d={disposed:false,clears:0,dispose(){this.disposed=true},clear(){this.clears++}};details.push(d);return d},setInterval(){return 1},clearInterval(){},setTimeout(){return 1},clearTimeout(){},requestAnimationFrame(){return 1},cancelAnimationFrame(){},URL};
vm.createContext(world);
const native=fs.readFileSync(root+'/moon/src/moon-native.mjs','utf8');
vm.runInContext(native,world,{filename:'moon/src/moon-native.mjs'});
assert.equal(details[0].disposed,false);
const oldRuntime=world.window.SalahMoonRuntime;
vm.runInContext(native,world,{filename:'moon/src/moon-native.mjs'});
assert.equal(details[0].disposed,true);
assert.equal(details[1].disposed,true);
assert.notEqual(world.window.SalahMoonRuntime,oldRuntime);
result.runtimeReplacement={oldDetailDisposed:details[0].disposed,newDetailDisposed:details[1].disposed,newRuntimeInstalled:true,assertions:'pass'};
// Only instrument otherwise private size observability; source algorithm unchanged.
const spectralFile=root+'/real-sky/core/src/spectral.mjs';
let source=fs.readFileSync(spectralFile,'utf8').replace(/from '\.\/([^']+)'/g,(_,p)=>`from '${pathToFileURL(root+'/real-sky/core/src/'+p).href}'`);
source+='\nexport function auditCacheSizes(){return {outer:sfCache.size,fit:sfFitCache.size};}\n';
const spectral=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
const samples=12020;
for(let i=0;i<samples;i++)spectral.selectSpectrum({bv:.25+i/1000000});
const sizes=spectral.auditCacheSizes();
assert.equal(sizes.outer,12000);assert.equal(sizes.fit,samples);
result.spectralRetention={distinctAdmissibleColours:samples,outerCacheEntries:sizes.outer,fitCacheEntries:sizes.fit,assertions:'pass'};
const out='/workspace/scratch/8ab1bbbe9699/evidence/probes/rendering/results.json';fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
