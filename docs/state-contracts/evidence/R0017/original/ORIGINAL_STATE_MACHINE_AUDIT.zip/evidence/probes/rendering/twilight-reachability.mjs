import fs from 'node:fs';import {pathToFileURL} from 'node:url';import assert from 'node:assert/strict';
const root='/workspace/scratch/8ab1bbbe9699/salah_widget';
const {patatTwilight}=await import(pathToFileURL(root+'/real-sky/core/src/sky-background.mjs'));
let source=fs.readFileSync(root+'/real-sky/core/src/spectral.mjs','utf8').replace(/from '\.\/([^']+)'/g,(_,p)=>`from '${pathToFileURL(root+'/real-sky/core/src/'+p).href}'`);
source+='\nexport function auditCacheSizes(){return {outer:sfCache.size,fit:sfFitCache.size};}\n';
const m=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
const physical=new Set(),preview=new Set(),fitted=new Set();
function visit(bv){const v=m.selectSpectrum({bv});if(v.kind==='B-V-constrained-continuum')fitted.add(bv);}
for(let i=0;i<1000;i++){
 const altitude=-5-10*i/1000;
 const fit=patatTwilight(altitude);
 physical.add(fit.bv);visit(fit.bv);
 const bv=fit.totalBMag-fit.totalVMag;preview.add(bv);visit(bv);
}
const result={scope:'Actual pinned patatTwilight and nativeAtmosphereFields B-V expression,1000 distinct solar altitudes from -5 inclusive to -15 exclusive; private map-size export only, no native render/heap claim',physicalUniqueColours:physical.size,previewUniqueColours:preview.size,unionUniqueColours:new Set([...physical,...preview]).size,fittedUniqueColours:fitted.size,retained:m.auditCacheSizes(),probeCorrection:'Initial equality to every distinct input was rejected (1989 fits versus2000 colours): some empirical colours fall outside the fitting model and deliberately use a fallback. Correct discriminator counts actual fitted outcomes, preserving that design.'};
assert(result.retained.fit>1000);assert.equal(result.retained.fit,result.fittedUniqueColours);
fs.writeFileSync('/workspace/scratch/8ab1bbbe9699/evidence/probes/rendering/twilight-reachability.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
