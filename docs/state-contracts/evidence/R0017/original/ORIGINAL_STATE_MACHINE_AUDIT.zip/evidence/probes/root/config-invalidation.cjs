// Read-only audit probe: execute the unchanged owner function with effect spies.
// This establishes the selected invalidation branch, not provider or pixel behavior.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const source = fs.readFileSync(new URL('../../../salah_widget/src/native/index.html', `file://${__dirname}/`), 'utf8');
const start = source.indexOf('async function applyConfig(cfg, opts){');
const end = source.indexOf('// Diagnostic control of the EXISTING native clock', start);
assert(start >= 0 && end > start);
const body = source.slice(start, end);
const base = {lat:40,lon:-74,tz:'America/New_York',label:'Example',method:2,school:0,time:'12',units:'f',datefmt:'mdy',lp:0,seed:1,appearance:'glass',locationEvidence:null};
(async () => {
  const observations = [];
  for (const [field,value] of [['appearance','contrast'],['time','24'],['datefmt','dmy'],['label','Renamed'],['method',3],['lat',41]]) {
    const effects = [];
    const ctx = {CONFIG:{...base},window:{},document:{querySelector:()=>({dataset:{}})},_runtimeGeneration:0,lat:base.lat,lon:base.lon,
      beginRuntimeGeneration(){ effects.push('new-runtime-generation'); ctx._runtimeGeneration++; },
      bindConfig(cfg){ effects.push('bind-config'); ctx.CONFIG=cfg; },
      resetForNewLocation(){ effects.push('withdraw-and-reset-location-state'); },
      simulationReady(){return true;},render(){effects.push('render');},
      startWeather(){effects.push('start-weather');},async loadPrayerData(){effects.push('load-prayer');},
      startRenderLoop(){effects.push('start-render-loop');}};
    vm.createContext(ctx); vm.runInContext(body,ctx);
    await ctx.applyConfig({...base,[field]:value},{});
    observations.push({field,effects});
    if(field==='appearance') assert.deepEqual(effects,[]);
    else assert.deepEqual(effects,['new-runtime-generation','bind-config','withdraw-and-reset-location-state','start-weather','load-prayer','start-render-loop']);
  }
  process.stdout.write(JSON.stringify({source:'src/native/index.html:3496-3527',method:'unchanged source function; effect spies',observations},null,2)+'\n');
})();
