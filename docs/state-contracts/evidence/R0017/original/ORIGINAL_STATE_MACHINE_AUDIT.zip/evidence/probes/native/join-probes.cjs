'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const crypto=require('node:crypto');
const Module=require('node:module');
const repo='/workspace/scratch/8ab1bbbe9699/salah_widget';
const sourcePath=path.join(repo,'src/native/index.html');
const source=fs.readFileSync(sourcePath,'utf8');
const {harness,ordinary,clone}=require(path.join(repo,'tests/r0002-harness.cjs'));
const result={source:sourcePath,sha256:crypto.createHash('sha256').update(source).digest('hex'),scope:'Exact source functions, contained VM clocks/network/DOM/canvas; no native browser/pixel qualification',probes:[]};
function prayerCase(reordered){
  const h=harness({source,epoch:'2026-09-07T23:00:00Z'});
  const current=clone(ordinary),next=clone(ordinary);
  next.date.gregorian.date='08-09-2026';next.date.gregorian.day='08';
  if(reordered){current.timings.Isha='00:30';next.timings.Isha='00:31';}
  const a=h.run(`admitPrayerRecord(${JSON.stringify(current)},'07-09-2026')`);
  const b=h.run(`admitPrayerRecord(${JSON.stringify(next)},'08-09-2026')`);
  assert(a.ok&&b.ok,'both actual ingress admissions must accept the input');
  h.run(`today=admitPrayerRecord(${JSON.stringify(current)},'07-09-2026').data;tomorrow=admitPrayerRecord(${JSON.stringify(next)},'08-09-2026').data;_prayerRecordsGeneration=_runtimeGeneration;lastDate='07-09-2026';`);
  const m=h.run('model()');
  const first=Object.entries(next.timings).filter(([name])=>['Fajr','Sunrise','Dhuhr','Asr','Maghrib','Isha'].includes(name)).sort((a,b)=>a[1].localeCompare(b[1]))[0];
  return {reordered,accepted:true,firstNextDay:{key:first[0],time:first[1]},actual:{key:m.nextKey,time:m.nextTime,leftMin:m.leftMin,nextDate:m.nextDateStr,currentKey:m.currentKey}};
}
(async()=>{
  const normal=prayerCase(false),reordered=prayerCase(true);
  assert.equal(normal.actual.key,normal.firstNextDay.key);
  assert.equal(reordered.actual.key,'Fajr');
  assert.equal(reordered.firstNextDay.key,'Isha');
  assert.equal(reordered.actual.leftMin,360);
  result.probes.push({id:'NF01',status:'reproduced',control:normal,case:reordered,expectedCountdownMinutes:91,excessMinutes:269});
  process.env.SALAH_WEATHER_SOURCE=sourcePath;
  process.env.SALAH_CONFIG_SOURCE=path.join(repo,'src/native/config.js');
  const fixturePath=path.join(repo,'tests/r000c-weather.test.cjs');
  const fixtureText=fs.readFileSync(fixturePath,'utf8').replace("region('let _starEls=[],', 'function projectStars(date){')","region('let _starCat=null, _starEls=[],', 'function projectStars(date){')");
  result.harnessAdaptations=['Adjusted weather harness star declaration selector from generated stub to exact src/native declaration; no owner behavior replaced'];
  const boundary=fixtureText.indexOf("test('control: actual fresh acquisition");
  assert(boundary>0);
  const compiled=new Module(fixturePath,module);compiled.filename=fixturePath;compiled.paths=Module._nodeModulePaths(path.dirname(fixturePath));
  compiled._compile(fixtureText.slice(0,boundary)+'\nmodule.exports={fixture,healthy,NOW};',fixturePath);
  const {fixture,NOW}=compiled.exports;
  const f=fixture();await f.fetchWeather();
  const run=code=>vm.runInContext(code,f.context,{timeout:1000});
  // The weather-only fixture omits unrelated clock declaration used only by QA.
  if(run('typeof _skyInitialDocument')==='undefined')run('let _skyInitialDocument=false;');
  run('paint(atmosphere(model()));paintClouds(simNow()/1000);');
  const capture=()=>run(`({cov:[cloudState.covLow,cloudState.covMid,cloudState.covHigh],ready:_cloudReady,modelCode:weatherDecision().modelCode,fx:$('.c').dataset.fx,precip:$('.c').dataset.precip,header:$('#wt').textContent,densitySum:Array.from(_colDens||[]).reduce((a,b)=>a+b,0)})`);
  const initial=capture();assert(initial.cov.some(x=>x>0));
  // Drive the actual no-model production branch. Other date/location DOM consumers
  // are isolated doubles; no weather owner/expiry/painter logic is copied or patched.
  f.context.prayers=['Fajr','Sunrise','Dhuhr','Asr','Maghrib','Isha'];
  f.context.setLocLabel=()=>{};f.context.renderCalendarDates=()=>{};f.context.selectCalendarDisplay=()=>null;
  f.context.model=()=>null;
  const begin=source.indexOf('function withdrawPrayerPresentation(){');
  const end=source.indexOf('function updateSimClock(n)',begin);
  assert(begin>0&&end>begin);
  run(source.slice(begin,end));
  f.clock.now=NOW+901000;
  run('render();paintClouds(simNow()/1000);');
  const missingPrayer=capture();assert.equal(missingPrayer.modelCode,null);assert(missingPrayer.cov.some(x=>x>0));assert.equal(missingPrayer.precip,'off');
  f.context.model=()=>({nowMin:1275,noon:720});
  run('paint(atmosphere(model()));paintClouds(simNow()/1000);');
  const completeAtmosphere=capture();assert(completeAtmosphere.cov.every(x=>x===0));
  result.probes.push({id:'NF02',status:'reproduced',initial,afterExpiryWithoutPrayer:missingPrayer,controlAfterCompleteAtmosphere:completeAtmosphere,fixtureLimit:'No real canvas pixels; optional native sky host omitted. Source inspection shows its no-timetable celestial path also never calls applyCloudState unless scene identity changes.'});
  fs.writeFileSync('/workspace/scratch/8ab1bbbe9699/evidence/probes/native/join-results.json',JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify(result,null,2));
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
