# Independent review of the GDOPL projection

## Review boundary and conclusion

**Disposition recommendation: retain the projection, with the targeted revisions below before the final synthesis.** Its main schedules are concrete and falsifiable at the pinned source. The proposed field is a whole-project objective/constraint structure, and it does not mistake a list of finite-state machines for an adopted optimization algorithm. The principal gaps are the configuration dependency table, the attribution of retry cooldowns to monotonic time, and the finding-class taxonomy.

This is an independent, read-only peer review by `/root/gdopl_review`. The parent owns acceptance, severity, consolidation, implementation authorization, and final closure. No application edits, builds, installs, commits, publication, issues, or new application tests were performed. No formal governor-route acceptance, certified fresh-context independence, product readiness, or closure verdict is asserted.

Source basis: imported `theislampill/salah_widget` at `f71fef6ccf7e4efcb57b5a26688d2360461a3253`; methodology at `e78f7cb21af4197d490f10bc95917a4c75f748aa`. The four supplied packet hashes matched at the start and again immediately before writing these notes:

| Immutable packet | SHA256 |
|---|---|
| `evidence/GDOPL_PROJECTION.md` | `f20c9ffa718f8f138fd403408777a4c9a9e3334278f313efeff44100889d62ed` |
| `evidence/root_findings.json` | `0e6f6fb080a63921fe8934c84ca3c0ce3594017b615ba01c78de5fabb27b3ff4` |
| `evidence/lanes/native.json` | `9b63c880054d46be6f9482c48c971f0e0576efee8c5f2989903e6bd25e212dc5` |
| `evidence/lanes/configuration.json` | `5c68a802585ddb6413bbc5f88166d4a36eff1bdd71793281c59219b1cd7f55ba` |

Ten selected source files were compared with `evidence/source_hashes.json`. All match their recorded hashes; this review did not independently refetch the remote repository. The checks and limitations are in `evidence/lanes/gdopl-review-source-checks.json`. The finalized rendering report was supporting evidence only, outside this immutable packet.

## Concerns and recommended disposition

| ID | Status | Concern | Confidence | Recommended action |
|---|---|---|---|---|
| GR01 | PASS | GDOPL definition, hard constraints, inner traces versus outer optimization | High | Retain |
| GR02 | PASS | Concrete cross-machine schedules derive from actual source | High on paths; no native incidence estimate | Retain source/evidence qualifications |
| GR03 | GAP-REVISE | Configuration matrix still combines distinct weather/radar dependencies and lacks an acquisition-evidence-only row | High | Clarify dependency contracts before proposing independent revisions |
| GR04 | GAP-REVISE | Monotonic-time table overstates current retry-clock uniformity; wall-clock rollback is a missed conflict | High on conditional source path | Correct the table and record the bounded schedule |
| GR05 | GAP-REVISE | Fourteen supplied finding rows use informal `repair_class` values instead of the methodology taxonomy | High | Normalize final synthesis; preserve detailed labels separately |
| GR06 | PASS | Rejected elevation lead: actual physical-renderer custody already defeats the apparent stale scalar path | High | Preserve as a countercontrol, not a product defect |
| GR07 | PASS | Accepted, displayed, source-owned, generated, and frozen boundaries remain distinct | High | Retain; do not import the unsupported Horizon owner name |
| GR08 | OWNER-DECISION | Priorities, weights, scientific-source changes, frozen V1 repair, worker/cache policy | High on authority boundary | Keep as unadopted variations pending the appropriate authority/evidence |
| GR09 | BLOCKED | Native visual, heap/performance, Windows, full offline-build conclusions | High that evidence is absent here | No PASS inference from static or synthetic evidence |
| GR10 | GAP-REVISE | Optional strengthening: frozen scene identity does not bound image-decode settlement | High on source liveness gap; no browser hang reproduction | Reconcile the final RF04 row into the project field or explicitly defer |

### GR01 — Correct conceptual projection

`GDOPL_PROJECTION.md:3–28,104–110` uses **Gradient Descent Over (the) Project Lagrangian** exactly, treats the runtime as a constrained hybrid product, and puts authority, truthful provenance, accepted obligations, and source ownership outside compensable tradeoffs. Its directional vector is explicitly unweighted and unmeasured. It distinguishes candidate changes to architecture from runtime events and recognizes existing epochs, leases, queues, and accepted/displayed state. This meets the requested abstraction without claiming a solver, measured descent, or optimum.

The compact per-component descriptions also avoid requiring every pure transformation to become a separate machine. Keep that restraint: extra revisions and universal state enums can increase the number of consistency rules before there is evidence of benefit.

### GR02 — The major schedules are source-grounded

| Projection claim | Direct source check | Assessment and limit |
|---|---|---|
| Expired weather can leave cloud coverage when the timetable model is absent | `src/native/index.html:2142–2157` excludes civil day from a live scene identity; `2220–2224` can return no model; `3257–3262` takes the no-model render branch; `2821–2841` omits the normal cloud-state application; `3024–3041` contains the ordinary withdrawal path | The cross-domain join is real. A lifecycle-valid live scene does not by itself grant current weather permission to every consumer. The supplied NF02 probe supports the branch effect; no native pixel magnitude is asserted. |
| Cross-midnight successor chooses named Fajr although admission permits reordered clocks | `src/native/index.html:990–1009,2225–2252` | Current-day selection is sorted, but the successor-day branch chooses Fajr. NF01's reordered example is therefore an admitted-input counterexample, without asserting provider prevalence. Include equal-time, missing-successor, timezone, and before-first-event controls in any future repair. |
| A label/time/date edit invokes unrelated acquisition and scene reset | `src/native/index.html:3484–3527` | Only the guarded appearance branch avoids `beginRuntimeGeneration`, `bindConfig`, and reset/reacquisition. Provider-adopted timezone is a real reason that a smaller branch must avoid wholesale rebinding. |
| Builder writes can renavigate an unchanged preview | `src/native/builder.html:211–224` | Preview URL construction increments a revision and `update` writes `iframe.src`; output identity and preview navigation identity can use different admission rules. Preserve the separate explicit reload action. No browser cost measurement is implied. |
| Reinstalling Moon runtime can dispose the replacement detail instance | `moon/src/moon-native.mjs:1,6,273` | New global detail publication precedes disposing the prior runtime, whose disposal resolves the current global detail. Captured-instance disposal is the relevant contract. This is a repeat-install schedule, not a claim of ordinary first-boot failure. |
| PowerShell treats an interrupted destination as reusable cache | `install.ps1:345–360` | Existing-path return precedes a download written directly to that destination. Interrupted bytes plus a later invocation is the relevant schedule. Windows execution was not performed; the claim is about the source path and the supporting lane evidence. |

These are specific joins between state owners, rather than generic advice to add an FSM. The cost dimensions in the candidate table follow those joins: avoiding redundant work, limiting obsolete presentation, retaining cleanup ownership, and distinguishing validated artifacts from mere existence. Their numerical costs remain unmeasured.

### GR03 — Preserve the useful configuration tradeoffs more precisely

**Claim:** `GDOPL_PROJECTION.md:46–57`, especially the combined `Weather/radar acquisition` column and the temperature-units row.

Weather and radar should not be a single temperature-sensitive acquisition domain. Weather captures units and timezone and requests `temperature_unit` (`src/native/index.html:1374–1379`); `wxUnitsMatch` validates temperature/dew-point metadata (`1234–1247`). Radar captures coordinates and target provenance (`1445–1451`) and derives its tile URL from coordinates (`1462–1466`). Its acquisition does not consume temperature units. Leaving both under “reacquire or convert” can carry the original unnecessary radar work into the proposed refinement.

**Correction:** split weather and radar columns, or say explicitly: a units-only edit may reacquire weather or use a defined lossless conversion/admission contract; preserve coordinate-based radar acquisition and its original provenance when its target is unchanged. Do not claim arbitrary units conversion is already accepted. Preserve method/school independence only until another actually changed field, including an adopted provider timezone, requires reconciliation.

Add an **accepted acquisition-evidence change at unchanged coordinates** row. `captureWeatherTarget` retains intent, source, accuracy, original acquisition time, provider, area, and bounds (`1306–1316`); point-claim authority consumes location provenance (`1546–1553`). `weatherTargetSame` currently relies on generation and coordinates (`1318`), so narrower revisions must continue to distinguish evidence replacement. The existing broad configuration branch already handles this conservatively; this is a proposed-contract omission, not a new current-state bug. A display save must not renew a GPS fix's `acquiredAt` or silently turn coarse/unknown evidence into point evidence.

The existing warning about **provider-adopted live timezone is correct**. Cache hints and accepted live timezone have distinct roles (`674–686,3443,3458–3464`). A label/time/date edit must not rebind the saved hint over the accepted provider zone. Keep the existing broad location generation as a fallback while proving smaller dependencies.

A lower-priority clarification concerns the grouped `Light pollution/seed` row: light pollution is rebound from configuration, whereas cloud seed reads boot query state (`src/native/index.html:680–686,2562,2575`). If runtime seed changes are contemplated, identify their actual consumer/owner and rebinding semantics first. The table is explicitly proposed, so this is not evidence that it falsely claims such mutation already exists.

### GR04 — High-value missed constraint: clock recovery across freshness and refresh scheduling

**Claim:** `GDOPL_PROJECTION.md:36` lists “retry cooldown” among current monotonic-time examples without qualification.

Prayer retry uses `_RAFNOW()` (`src/native/index.html:1170–1173`), and the visible loop offers weather refresh opportunities using `_RAFNOW()` (`3632–3642`). However, weather's request gate uses `Date.now() - lastWxTry < 60*1000` (`1368–1378`), and radar uses `Date.now() - lastRadarAt < _RADAR_REFRESH` (`1445–1451`). Weather eligibility separately rejects negative source/receipt ages (`1291–1299`).

**Conditional schedule, derived from source and not newly executed:** in a live session with usable coordinates and no later configuration reset, a weather/radar request records wall time T. Choose T and the correction within the same civil day to avoid conflating this with rollover. The system clock is then corrected backward by one hour while elapsed time continues. The previous weather record's receipt is in the future, so current-weather eligibility fails. Subsequent periodic refresh opportunities still reach request functions, but their wall-clock differences remain negative and satisfy the cooldown return. Weather retry remains suppressed until the wall clock passes T plus one minute; radar until T plus its refresh interval. This is a system-clock correction, not an ordinary DST or timezone-offset change.

**Correction:** qualify the current example as “prayer retry cooldown” and identify the mixed scheduling clocks as a candidate conflict. Preserve UTC/source timestamps for provenance and interval selection; use independently owned elapsed scheduling bounds or an explicit clock-discontinuity recovery rule for cooldowns. A scheduling-clock change must not certify old source data as current. Future controls should include backward/forward corrections, unchanged generation, an actual target reset, and quiet ordinary operation. This variation would alter canonical `src/native/index.html`, not generated copies.

This is the highest-value additional cross-domain constraint found here: **freshness rejection must not disable the mechanism that can acquire replacement evidence merely because the two owners use incompatible notions of elapsed time**. No claim about user frequency, measured outage, or browser behavior is made.

### GR05 — Normalize the methodology classification field

`methodology/audit-playbook.md:288–308` specifies repair class as `product-or-skill defect`, `instrument/acceptance defect`, `STIMULUS defect`, `transport-infrastructure`, or `environment`. The immutable packet has fourteen finding rows, and none uses those values:

- Root F01/F02 use `state ownership and invalidation scope` / `evaluator fitness`.
- Native NF01/NF02 use owner-logic and consumer-invalidation descriptions.
- Configuration F01–F10 use informal repair descriptions such as `Boundary admission and transactional file repair` and `Frozen compatibility repair only`.

**Correction:** in the final synthesized catalogue, classify root F02 as `instrument/acceptance defect`; the supplied product-source defects belong under `product-or-skill defect` if the parent adopts them as findings. Keep the existing descriptive strings in a separate subtype or fix-route field. Frozen V1 authority remains a separate authorization/disposition field. Do not mutate this immutable packet to make the review pass.

This is a reporting-conformance gap, not evidence that the underlying source findings are false. It matters because evaluator repair, product repair, environmental absence, and stimuli defects must remain distinguishable in the project field.

### GR06 — Rejected lead: legacy elevation scalar does not establish stale physical-renderer elevation

Initial local inspection suggested an ownership leak: `siteElev` is set from weather (`src/native/index.html:1213,1392`), omitted from `resetForNewLocation` (`3484–3493`), and feeds legacy star-opacity/blur calculations (`2885–2887,2994`). That observation alone is insufficient for a current physical-renderer defect.

The authoritative composition route defeats that proposed claim; the pinned generated entry also contains the handoff, separate owner, and emptied legacy layers, and its generated CSS hides those layers:

- `tools/build_native.py:50–65,82` removes the legacy synthetic star implementations, empties their layers, and hides those layers.
- `tools/build_native.py:66–72` injects a guarded `acceptedElevation` handoff and the native host hooks.
- `real-sky/native-host-hooks.js:2–8` stores a separate bounded elevation record with generation and coordinates.
- `real-sky/native-host-hooks.js:17–20,36` reads that record only with selected weather and matching generation/coordinates; otherwise the renderer gets an explicit zero-height fallback with provenance.

**Disposition:** reject the claimed stale astronomical-height path. Do not promote the legacy scalar to a new high-value defect or count it as missing ownership without a remaining actual consumer trace. Preserve this countercontrol in the final audit reasoning: source-template reachability and generated current-consumer reachability are different evidence states. No claim is made that every legacy debug value is reset.

### GR07 — Authority and evidence states are adequately separated

`GDOPL_PROJECTION.md:13,17–28,104–110` correctly distinguishes acceptance from actual display, and test results from visual/native evidence. `real-sky/native-host.mjs:99–138,208–217` keeps accepted job/frame and painted job/frame separate and checks currentness independently around asynchronous composition. A new accepted job is not inherently permission to renew an old displayed job's age.

The generic source-owner route in the projection is consistent with `AGENTS.md:6–24,197`: canonical native source and integration modules are editable owners; generated output, copied `real-sky/core`, and immutable `vendor/real-sky` are not direct patch targets; frozen V1 requires explicit owner authority. The renderer's unsupported phrase “canonical Horizon source” must not be imported into the final report. Parent has already identified this wording correction. Use “canonical scientific source owner/upstream under a separately accepted ownership route” without inventing a repository or owner.

### GR08 — Decisions remain with the owner

Weights, priorities, a particular optimizer, reduced worker/cache policies, and any accepted scientific-source or frozen V1 change remain unadopted. The projection is right to compare bounded variants within hard constraints. Fewer workers can improve aggregate resource pressure while harming useful-presentation latency; smaller caches can bound retention while increasing expensive recomputation. Neither direction is automatically a project improvement.

Root F01's fix sketch names several distinct revisions, while `GDOPL_PROJECTION.md:59` correctly warns against introducing many before proving dependencies. Reconcile the final wording as “derive the minimum necessary revisions; start with guarded display-only paths.” Do not make four independent revision counters an acceptance requirement just because they are convenient to list.

### GR09 — Empirical acceptance is unavailable here

No native browser pixels, heap/performance measurement, Windows execution, or full offline build were available to this review. Supporting source tests and synthetic schedules can establish branch behavior, admission, identity, or retention properties; they do not establish perceived visual quality, memory growth in a running browser, aggregate CPU improvement, Windows behavior, or full build acceptance.

The test-instrument findings and negative aggregate results must remain visible. Repairing a stale evaluator is distinct from proving the product passes the repaired evaluator. The current packet does not justify a blanket test PASS. This is an evidence boundary already mostly preserved by the projection, not a request for broader tests in this review.

### GR10 — Optional strengthening from finalized rendering evidence: decode liveness under a frozen clock

`real-sky/native-composition.mjs:45–68` has an asynchronous image-decode publication state with cancellation/currentness fencing but no intrinsic elapsed settlement deadline. A frozen scene can keep the same accepted UTC/identity (`real-sky/native-lifecycle.mjs:49–63,81`), so correct scene-currentness alone does not imply decode will settle. The final rendering RF04 row identifies this join; it was not part of the immutable draft contract.

**Suggested field addition:** progress or timeout ownership for the decode/publication attempt must use a suitable elapsed bound independently of scene UTC, while never making an obsolete frame eligible. Include explicit terminals such as cancelled, decode failed, and current accepted-but-undisplayed. Do not treat this as proof that browsers actually hang on these payloads; it is a source-level missing settlement bound. Parent can carry the RF04 schedule into the final projection or explicitly defer it.

## Parent handoff

The supported conceptual structure and concrete schedules can be retained. Recommended final revisions are GR03–GR05, with GR10 as a useful integration of the now-final renderer lane. GR04 supplies the strongest new cross-domain constraint. GR06 is a rejected lead with an explicit canonical-consumer countercontrol. No app repair is proposed as already authorized or performed; no issue publication or audit closure is claimed.
