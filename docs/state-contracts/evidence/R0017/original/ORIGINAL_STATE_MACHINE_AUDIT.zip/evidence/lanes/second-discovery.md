# Independent second discovery pass

**Result: one owner was missing from the frozen 82-row population; it is the same C/WASM domain now recorded as late R37. Count it once, giving 83 reconciled owners unless root has other deltas. No further distinct owner or new product defect was established in this pass.**

The independent candidate is named **S01 only as a discovery alias**. It was found by tracing retained C globals, allocator marks, ABI calls and the JS caller before reading the late R37 row. After root reported R37, the two were reconciled. The frozen first-pass file remains unchanged at SHA256 `c83afcfdf9e8590f75e49a30291cc995a2570e7a417cad02dc5951c4e027e529`.

The other decision-changing result is a contract correction: **R26 must not say that every cancel/error leaves the lunar engine reusable.** Ordinary cancellation and failed native allocation have different recovery boundaries. Current native failure handling closes the worker; that protects the shipped path but does not prove standalone reuse after allocation refusal.

## Scope, authority and method

Snapshot: `theislampill/salah_widget@f71fef6ccf7e4efcb57b5a26688d2360461a3253`, imported source rather than a Git checkout. This is a read-only child audit/projection under IMPLEMENTAUDIT, with no source mutation, build, installation, commit, push, issue, external message or lifecycle/closure authority. The requested deliverables are this Markdown report and its JSON counterpart, both outside the app.

The pass started from reverse event, effect, retained resource, persistence and cleanup sites. Regex census files supplied navigation, not proof. The deciding test for a machine was whether state survives calls and changes a later event’s admissibility, scheduling, publication or resource custody. I then reconciled source observations against the frozen population, and finally against late R37 and the explicit V1 compatibility mappings. Findings from other lanes were not used to originate the independent candidate.

After a host compaction, the installed skill’s Git-bound controller discovery was attempted through Bash and refused because the snapshot has no Git repository. No controller, receipt or root lifecycle state was invented or changed. This lane continued only the parent-authorized source analysis and evidence output, with frozen population and selected source identities rechecked.

## S01 → R37: retained C/WASM resource owner

The source owner is `moon/src/moon_kernel.c:18–34,55–96,196–261,264–318`; the native caller is `moon/src/moon-engine.mjs:64–104,128–130`. A single WASM instance retains admitted terrain/colour pointers, derived pyramids and LUT, `heap_end`, `frame_mark`, `pixels`, `capacity`, scene vectors, source quadrature and counters. These values connect separate exported calls and affect the next allowed operation. They are not merely numerical loop variables.

| Aspect | Source-supported contract |
|---|---|
| States | Empty instance → asset admission → fixed buffers allocated → first frame allocation → camera receivers → lighting/refinement; capacity reuse or growth; refusal/partial state; realm termination. |
| Events | `alloc_buffer`, `init_assets`, `begin_scene`, camera rows, source/rule change, lighting rows, current-buffer readback, worker error/termination. |
| Guards | 16-byte alignment; overflow/512 MiB allocation ceiling; asset shape/height limits; admitted geometry and size8–768; JS `active`; row interval and exact cache identities. |
| Effects | Grow linear memory, install persistent pointers, rewind/reallocate the frame arena on growth, zero scene receivers, update lighting in place, copy outputs into transferable arrays. |
| Invariants | Fixed buffers precede `frame_mark`; one instance owns one mutable scene; views after possible growth use current `memory.buffer`; partial work receives no accepted publication authority. |
| Recovery | Cancellation releases `active` and revokes lighting cache authority. Native allocation refusal requires failure containment/new-instance recovery, not an unconditional reusable-engine claim. |
| Dependencies | R26 exclusive caller, R24 sticky bridge failure, R25 row ownership, R20 host closure/retry, R28 refinement. |
| Evidence limit | Source and caller ordering, not a C/WASM execution or source-to-binary equivalence proof. |

The current JS creation sequence allocates terrain/colour, initializes derived assets, and allocates its argument/mask buffers before the first frame. That satisfies the inspected permanent-pointer ordering. A future external `alloc_buffer` after the first frame mark could be overwritten by a larger frame’s rewind; no such current authored runtime call was found. The native non-WASM branch uses `malloc` and frees old pixel storage on growth, which is a different physical allocation strategy within this same resource domain.

`blocker_t` is reset per receiver/source; a reused distance becomes a blocker only after testing the actual new ray’s point inside terrain. It is therefore a nested optimization, not another cross-scene machine. Quadrature arrays persist and are included in R37; the root-solving loops used to fill them are within-call computation.

**Disposition:** S01 is merged with late R37. Preserve the frozen82 and record a one-owner delta. The JSON has `new_machines: []` because there is no additional owner beyond reconciled R37.

## Apparent omissions reconciled

| Candidate surface | Existing owner(s) | Resolution |
|---|---|---|
| C/WASM arena and retained asset/frame state | R37 | Independent S01 is absent from the frozen catalogue but identical in ownership to late R37. One final domain, not R37 plus S01. |
| Spectral selection, exact B-V fits and photometry caches | R31, R32 | Module retention changes later work. Already explicit owners; continuous twilight reaches the fit cache. Independent unbounded-fit observation corroborates RF03, rather than creating another cache machine. |
| Atmosphere admission, coefficient WeakMap and per-model solar grid | R33, R34 | Separate identity lifetimes were already enumerated; no omitted global scene cache inferred from local grid allocation. |
| Display/lunar preview geometry retention | R16 | Bounded geometry memoization already owns the retained Maps; helper math is not another machine. |
| Lazy decode/materialization and encoding-table initialization | R17, R18 | Uninitialized/initialized tables and private-byte materialization affect subsequent calls but have existing owners; generated copies do not add owners. |
| MessageChannel wake queue and port reference lifetime | R27 | Queue length, resolve ordering and ref/unref are retained scheduling state; R27 explicitly captures them. |
| CSS/class publication, head background lease and detail adoption | N17, R10, R11, R12, R14, R29 | Computed opacity/transform and class gates are publication state under existing host/surface leases. CSS easing is not independently counted for every transitioning property. Browser presented state remains a real acceptance surface, not proved by JS truth alone. |
| Elevation acceptance and global host snapshot publication | R15, R35 | Height is leased to generation and exact target; capture, notification and diagnostic joining belong to the adapter. R35 already makes that ownership explicit. |
| Frozen V1 loop, clouds, countdown fit and lightning variants | N19 family, N15 family, N18 family, N16 family, C17, C18, C19, C21 | Configuration lane inherited_protocols explicitly records these V1 variants and their source lines. This is a family mapping, not a claim that current generation/context-reset guards exist in V1; acquisition/clock divergences remain C17-C21. |
| Synthetic star source and legacy lunar maps | N14, N11, C23, C22 | Current builder substitutes the native star owner and Moon injection makes legacy maps dormant. Frozen V1 retains separate compatibility implementations. Presence in authored source alone is not current entrypoint reachability. |
| Script/inline asset ownership, timeouts and page lifecycle | R03, R04, R22 | Generations, abort, script-element identity, pagehide/pageshow and disposal already own late delivery. Removed network scripts can finish; this does not itself prove a new state owner or stale content publication. |
| Worker transferable arrays and row material ownership | R06, R23, R24, R25, R26 | Buffer detachment is an effect of existing worker/result transitions. WASM-owned storage is copied to result arrays before transfer; row joins admit identities and value shapes. No additional reusable transferable-buffer pool was discovered. |
| Admission/capability identities and bridge association | N04, R33, R36 | WeakMap/WeakSet membership carries authority, but the owning acquisition/resource capability is already represented. Separate membership operations are not additional machines. |
| Storage outcomes, resolved configuration and user location edits | N01, N04, N08, N20, N21, N22, C01, C05, C06, C15, C16, C20 | Persistent values, private-storage failure, edit revisions and asynchronous input ownership already have native/config/builder owners. Diagnostic counters alone add no independent admission protocol. |
| Installer staging, download cache, unpacking and manual import | C08, C09, C10, C11, C12 | Filesystem staging/retention and platform differences are already distinct. No execution was performed; profile discovery is read evidence, not permission to install or write the user home. |
| Native/Moon generator output stages and Pages receipt | C13, C14, C24 | Sequential artifact production and qualification receipt are process/physical state. Their owner is generator or CI workflow; generated bundles, root index and offline expansion are not independently authored machines. |
| Jekyll exclusion and Tabliss preset data | C12, C24 delivery boundary | Static host/deployment input, no retained transition owner in these files. Tabliss extension runtime is an external dependency outside this snapshot audit. |
| Digest, numerical solver, quadrature and per-ray loop variables | R37 only for cross-call scene/quadrature/witness configuration | Within-call iterations do not retain independent next-event authority. Quadrature arrays belong to the retained scene resource owner. blocker_t is reset per receiver/source and accepted only after actual new-ray terrain test; no extra cross-scene witness machine is warranted. |

The V1 distinction matters: the explicit `configuration.json.inherited_protocols` records loop/visibility at `v1/index.html:2224–2282`, cloud retained buffers at1503–1547, countdown sizing at1911–1951, and lightning bucket state at1976/2029–2033. Their family mapping does **not** grant V1 current-generation guards or modern cloud-context resets. C17–C21 retain its acquisition/clock divergences. No new V1 count is needed merely because those mappings are outside the compact frozen name list.

Source presence also differs from current entrypoint authority. `tools/build_native.py:49–64` substitutes the native synthetic star owner. Moon generation installs the actual Moon owner and leaves legacy maps dormant. Root generated bundles do not replace those authored ownership proofs. Frozen V1 is a separate compatibility surface, not another generated duplicate.

## Cross-machine schedules and their limits

### SC01 — Frame-growth refusal followed by direct engine reuse

A completed smaller scene has capacity and cameraKey. → A larger admitted scene reaches begin_scene and the allocation fails after N changes and pixels is assigned null. → The JS throw occurs before cameraKey=null; catch clears lightKey and finally releases active. → A direct standalone caller that reuses the instance can match the old cameraKey or attempt a smaller scene against retained capacity, although valid pixel storage was not re-established.

Source-supported recovery-contract hazard; current native non-AbortError path makes shard failure sticky and closes the worker. Not a demonstrated native corruption or a new machine. Correct R26 all-errors-reusable language; new-instance recovery is the warranted contract for native refusal.

**Remaining limit:** Actual allocation failure/compiled binary behavior not executed; standalone reuse support would need its own authoritative requirement and narrow test.

### SC02 — Changing accepted twilight repeatedly grows exact-colour cache

Successive accepted snapshots change solar altitude. → Physical model and native preview derive varying twilight B-V values. → selectSpectrum misses exact keys and sfFitColour retains each admissible fit. → The outer 12000-entry guard does not bound sfFitCache; worker restarts cannot free an independent same-document module cache.

Independently corroborates existing R31/RF03. Do not duplicate the finding, re-run renderer probes, or call source cardinality a measured browser heap leak.

**Remaining limit:** Real long-session heap bytes, GC behavior and user-visible latency remain unmeasured.

### SC03 — Visibility, cancellation and late worker response across ownership change

A worker owns an in-flight scene when visibility/target or page lifecycle changes. → Host invalidation increments serial/epoch and cancels or terminates work. → A removed script or already queued worker result arrives later. → Publication must still match current worker, pending identity, epoch and target; transport completion is insufficient.

Existing ownership gates address the schedule at source level. Browser freeze/BFCache scheduling and visual retirement are excluded from an execution-success claim.

**Remaining limit:** No native browser lifecycle execution or pixels in this lane.

### SC04 — Interrupted sequential generation leaves a mixed working payload

Generator writes copied core and worker/bundle/data outputs. → Later document/offline/Moon work fails or is interrupted. → Earlier files in the destination already changed. → Only a subsequently qualified complete payload is eligible for publication; direct partial-directory consumption is not certified by write order.

Existing C13/C14 process-state boundary, not a new machine. Read-only audit did not run either generator and does not claim transactional build/install/deployment.

**Remaining limit:** No filesystem interruption, Windows staging or CI execution in this lane.

SC01 is the strongest additional claim correction. At `moon_kernel.c:234–242`, `N` changes before allocation and `pixels=space(...)` can become null while the old `capacity` survives. At `moon-engine.mjs:91`, a refusal throws before `cameraKey=null`; catch/finally only clear `lightKey` and release `active`. A direct retry can therefore not rely on the earlier camera/resource invariant. In the actual native chain, `moon-pool.mjs:18–26` makes non-AbortError sticky, and `moon-native.mjs:53–67,195–198` closes the current worker after a matching error. This is a bounded contract correction, not evidence that the current native UI publishes corrupted output.

SC02 independently corroborates RF03: the outer spectral Map stops adding at12000, while `sfFitCache.set(bv,fit)` has no corresponding bound (`spectral.mjs:9,21–23,32–41`). The twilight caller is visible in `sky-background.mjs:29–33,75–76` and `native-preview.mjs:334–336`. Existing renderer probes already cover cardinality and actual colour reachability, so this lane did not repeat them or claim measured native heap impact.

## IMPLEMENTAUDIT finding records

### SD-F01 — Frozen 82-owner population omitted the retained C/WASM resource domain

**Category:** Architecture; Coverage / Tests

**Impact:** An audit limited to JS active/cache flags can omit allocator lifetime, permanent-vs-frame pointer custody, partial admission, high-water memory and source/quadrature state. The frozen catalogue is incomplete by one resource domain.

**Effort:** Small audit-record amendment; no production change required.

**Risk:** Coverage/claim risk. No severity escalation to a demonstrated native rendering failure.

**Confidence:** High: cross-call static storage, allocation branches and ABI getters/callers are explicit.

**Smallest safe change:** Retain the frozen digest-bound 82 rows, record late R37 with source provenance, and join independent discovery alias S01 to R37 once. Update the reconciled catalogue count to 83.

**Fix sketch:** Add an explicit delta record from the frozen population; do not rewrite the freeze or double-count the independent observation.

**Repair class:** instrument-acceptance defect

**Route:** reconcile

**Owner/source:** Audit population ledger and rendering lane R37; product owner moon/src/moon_kernel.c with caller moon/src/moon-engine.mjs.

**Acceptance:**

- Frozen catalogue digest remains c83afcfdf9e8590f75e49a30291cc995a2570e7a417cad02dc5951c4e027e529 and count82.
- Reconciled population contains exactly one C/WASM arena owner (R37), count83 absent other root discoveries.
- JS R26 and R37 name their dependency and distinguish resource failure from ordinary cancellation.

**Verification:** Read-only static C/JS trace; final digest and candidate key-source hashes checked. Late renderer R37 was inspected only for reconciliation after independent candidate discovery. No new test/build/production effect.

**Rollback:** Only audit artifacts were authored. If root changes the population convention, preserve the independent evidence and mark the alias superseded; never remove the immutable freeze.

**Disposition:** changed: proposed correction already matched by late R37; root must integrate without duplication

**Remaining risk:** 83 is a bounded mapped population, not mathematical completeness over unverified source/assets or all environment behavior.

### SD-F02 — R26 recovery wording must exclude failed native frame allocation

**Category:** Correctness / Contracts; Evidence / Claims

**Impact:** The blanket statement that cancel/error leaves an engine reusable is stronger than the kernel and caller establish. It could incorrectly justify standalone retry on a partially mutated arena. The current host protects its path by sticky shard failure and worker closure.

**Effort:** Small report wording/cross-reference correction. A product-level general-recovery change is deferred.

**Risk:** Medium contract-misuse risk for direct engine/ABI consumers; no proven current native output defect.

**Confidence:** High for source ordering and overbroad recovery claim; unverified for runtime resource-pressure occurrence.

**Smallest safe change:** Qualify R26 recovery to distinguish ordinary cancellation/cache invalidation from begin_scene/allocation refusal; cite R37 and current worker termination as the recovery boundary.

**Fix sketch:** Do not mutate source in this audit. If standalone reuse after native refusal becomes a required feature, define poisoned-instance or transactional arena behavior before implementation and verify the failed-growth-then-smaller-frame sequence.

**Repair class:** instrument-acceptance defect

**Route:** reconcile; product repair deferred

**Owner/source:** Audit rendering R26/R37 recovery field; moon/src/moon-engine.mjs:89-104,130; moon/src/moon_kernel.c:234-242.

**Acceptance:**

- R26 no longer promises reusability after every error.
- The native safety argument includes sticky non-AbortError shard failure and host closeWorker.
- No test PASS, source-to-WASM equivalence, or actual resource exhaustion is inferred from this static trace.

**Verification:** Source read of begin_scene, render try/catch/finally, shard error bridge and host error handler. No failure injection or compilation was performed.

**Rollback:** No source edit. Any later generalized-recovery patch would require narrow allocation-failure evidence and canonical generated-payload review; this lane does not authorize it.

**Disposition:** deferred to root for report correction; no mutation authority

**Remaining risk:** The supplied binary and browser memory-failure behavior require separate bounded qualification. Nonallocation refusal schedules and other external ABI consumers were not exhaustively enumerated.

## Reverse census closure

| Reverse family | Mapped owners | Closure boundary |
|---|---|---|
| UI/DOM/global publication and CSS | N06, N07, N13, N17, N18, N19, N20, N21, R10, R11, R12, R14, R15, R29, C05, C06 | Retained target, presented surface, CSS gate, disclosure/focus and font/geometry state mapped; no independent new family. |
| Timers, requests, cancellation, retries and lifecycle | N03, N04, N05, N08, N09, N10, N19, R02, R03, R04, R05, R19, R20, R22, R23, R24, R27, C02, C03, C04 | Request/body settlement and cleanup authority traced to existing owner. No zero-result regex treated as absence proof. |
| Persistence and user configuration | N01, N22, C01, C05, C06, C07, C15, C16, C20 | Storage outcome, edit revision and asynchronous completion mapped; frozen compatibility remains separate. |
| Retained caches, materialization and capabilities | R07, R08, R09, R16, R17, R18, R26, R31, R32, R33, R34, R35, R36 | Retention/action-changing state counted once by owner; R31 resource-growth behavior already RF03. |
| Workers, transferred buffers and native resources | R06, R20, R23, R24, R25, R26, R28, R37 | One independent frozen-population omission maps to late R37. Buffer handoff/row join remain subordinate effects of existing workers. |
| Frozen V1 animation/resource variants | C17, C18, C19, C21, C22, C23, explicit inherited_protocols in configuration.json | Loop/cloud/countdown/lightning variants positively mapped; no silent import of modern guards into V1. |
| Generator, installer and delivery state | C08, C09, C10, C11, C12, C13, C14, C24 | Physical staging/retain/unpack/output sequencing and CI receipt mapped; no generator or installer executed. |
| Pure numerical/within-call computation and static data | nested under resource owners where relevant | Excluded as separate machine only after checking lifetime: local solver loops, digests, per-ray witness iteration, static preset and Jekyll exclusion. Retained kernel arrays remain R37. |

This closes the inspected reverse-census candidates by owner or explicit exclusion. It does not establish that every state in every source, generated byte, dependency, platform or numerical execution has been exhausted.

## Material coverage and exclusions

The material traces cover current native configuration/clock/acquisition/render/settings/visibility sinks; config and builder input ownership; real-sky adapter, assets, preview/head/full publication and caches; copied-core queue/capability/resource retention; Moon C/JS/worker/pool/detail/yield; frozen V1 variants; and installer/generator/Pages process boundaries. The exact source references and alias decisions are in the JSON. Whole-file console output was sometimes bounded, so the report claims targeted owner/caller/cleanup inspection rather than semantic inspection of every manifest line.

The live evidence ledger has **419 Git-blob-verified files out of640 selected manifest entries**; 221 entries remain unverified. Its485 hash-record rows are not485 verified blobs. Large native-data/offline/chunk payloads are generator-reconciled; the81.7 MB offline document is not fully byte-qualified here. Vendor demos/tools/fixtures, external Tabliss/browser/OS runtimes, actual network/CI execution, native browser pixels/layout/fonts, BFCache/freeze, decoder settlement, native memory pressure and Windows filesystem behavior retain explicit limits.

`_config.yml:1–4` only excludes a retained native evidence directory from Jekyll. The Tabliss preset is static embed/host-default data. Neither creates an in-snapshot transition owner; external host runtime behavior is outside the source boundary.

## Verification and handoff

The frozen catalogue SHA256 was rechecked unchanged, and **32 source files referenced by the reconciliation were reread and matched to their recorded verified SHA256**. This is source identity verification, not rerunning correctness tests. This lane ran zero runtime tests, builds or installs, and authored no application source changes. Root-reported538 native and275 distinct renderer checks remain parent evidence; they are not presented as independently executed here.

Root should integrate the single R37 delta, keep S01 as a merged discovery alias, qualify R26 recovery, and retain the source/platform exclusions. All lane findings have an explicit terminal disposition within this child scope: the population correction is reconciled, the report wording correction is handed back, and runtime/visual qualification remains unverified. The governor retains audit readiness and closure authority.
