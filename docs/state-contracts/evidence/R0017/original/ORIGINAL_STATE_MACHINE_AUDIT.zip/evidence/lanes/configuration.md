# Configuration state machine lane
Report state: PARTIAL


## Provisional catalogue checkpoint

Source pin: `f71fef6ccf7e4efcb57b5a26688d2360461a3253`; imported blob snapshot, not a Git checkout. Report state remains **PARTIAL**. Root-provided named cohorts passed: intent 21/21, reset 9/9, clipboard 11/11, effects 3/3, radio 8/8. These are schedule/source tests, not native UI or deployment qualification.

| ID | Provisional protocol | Surface |
|---|---|---|
| C01 | Configuration persistence and mode resolution | current shared config; V1 base family mapped |
| C02 | Coarse provider cascade and deadline ownership | current config; older V1 deadline variant noted |
| C03 | Geocoder aggregate completion | shared config; V1 inherited |
| C04 | Browser fix and permission completion | shared config; evidence differences noted |
| C05 | Builder mode/form/output/preview revision | builder |
| C06 | Builder edit owner, candidate cycle and auto-fill | builder |
| C07 | Clipboard attempt and feedback expiry | builder |
| C08 | Installer discovery, selection, preview and manual handoff | Bash/PowerShell family, differences explicit |
| C09 | Private staging custody and exit cleanup | Bash |
| C10 | Download, validation, retain and extraction admission | Bash |
| C11 | Persistent shared cache and unpack lifecycle | PowerShell |
| C12 | Preset rewrite and handoff | Bash/PowerShell divergent admission |
| C13 | Native generation publication sequence | build_native |
| C14 | Moon preflight, expansion and output sequence | build_moon |
| C15 | One-time root-to-V1 configuration import | frozen V1 |
| C16 | Unfenced live configuration apply | frozen V1 |
| C17 | Unfenced prayer cache/fetch/tomorrow/rollover | frozen V1 |
| C18 | Unfenced weather current/track acquisition | frozen V1 |
| C19 | Unfenced radar frame acquisition | frozen V1 |
| C20 | Legacy modal editing, search/GPS/reset | frozen V1 |

Legacy clock, PBR texture bootstrap and star projection are under final retained-state sweep. Pure normalizers/transforms will be mapped as dependencies, not counted as standalone machines. Provisional key issue: PowerShell `Download-Asset` downloads directly to its reusable final cache path and trusts any existing path; a failed partial download can be adopted on the next run. Bash validates and promotes a temporary file, and therefore has a different contract. PowerShell preset parsing also warns yet returns the invalid file for import. No app files have been modified and no install/build/browser has run.


# Final bounded configuration and delivery audit

**Report state: FINAL — lane handoff only. This report does not authorize edits, release, deployment, or closure.**

Pinned source: `f71fef6ccf7e4efcb57b5a26688d2360461a3253`. Source root: `/workspace/scratch/8ab1bbbe9699/salah_widget`. The workspace is an imported blob snapshot, not a Git checkout; source identity is bounded by the parent’s ledger. There are **24 catalogue entries**, plus four inherited family mappings that are not inflated into duplicate machines. IDs are lane-local for parent normalization.

## Findings and decisions

| ID | Finding | Evidence strength / disposition |
|---|---|---|
| F01 | PowerShell adopts failed partial downloads as cached success | CONFIRMED SOURCE; recommended bounded repair, no edits authorized |
| F02 | PowerShell deletes previous unpacked payload before replacement succeeds | CONFIRMED SOURCE; bounded repair |
| F03 | PowerShell returns malformed preset JSON for manual import | CONFIRMED SOURCE; no native PS test |
| F04 | Coarse provider coordinates are silently clamped into an accepted site | CONFIRMED BY PROBE |
| F05 | Builder reloads unchanged preview for each input and change event | CONFIRMED BY PROBE; performance opportunity |
| F06 | Geocoder transport failure is reported with the same state as no matches | CONFIRMED BY PROBE; lower-priority bounded repair |
| F07 | Frozen v1 location changes do not invalidate earlier data or settings work | CONFIRMED SOURCE; DEFERRED OWNER AUTHORITY |
| F08 | Frozen v1 Reset claims deletion after storage removal fails | CONFIRMED BY PROBE; DEFERRED OWNER AUTHORITY |
| F09 | Frozen v1 coarse lookup retires timeout before body completion | CONFIRMED BY PROBE; DEFERRED OWNER AUTHORITY |
| F10 | Malformed Firefox metadata loses the unknown discovery state | CONFIRMED SOURCE; bounded repair |

The primary actionable current-surface findings are F01–F06 and F10. Frozen findings F07–F09 are explicit compatibility risks only; immutable preservation and separate owner authority dominate any local repair. G01 is a bounded generator-publication recommendation already contained by disposable-build policy. Parent owns the shared current applyConfig/reset-runtime finding.

## Catalogue and per-machine inspection

### C01 — Configuration persistence and mode resolution

**Nature:** partly-explicit. **Audit disposition:** INSPECTED: mode policy is intentional; admission clamping issue is recorded at C02. No additional mode conflict confirmed.

**Exact evidence:** `src/native/config.js:88-219` `parseHash/normalize/serialize/loadLocal/saveLocal/clearLocal`; `src/native/config.js:298-327` `resolve/applyHashPrefs`; `v1/config.js:247-269` `resolve compatibility family`

**Retained state:** Versioned localStorage record, source/origin, savedAt, locationEvidence; local/preferLocal/hash/bare mode and explicit hash preference presence.

**States:** absent; valid saved; unreadable/invalid saved; hardcoded; local; preferLocal; bare

**Transitions, guards and effects:**
- resolve: local selects saved or detection; preferLocal selects saved then baked coordinates then detection; coordinate hash selects hardcoded; absent coordinates/flags selects bare
- save normalizes/stamps and attempts one record write; browser acquisition is persisted with legacy-compatible source plus provenance
- clear removes current key and returns success/error; serialize controls preference and coordinate inclusion

**Invariants:** Saved preferences intentionally win in local/preferLocal; no implicit merge of fresh embed defaults over an existing viewer record; Storage errors return an explicit result; normalization is not an independent machine; acquisition metadata does not establish a live sensor

**Errors, expiry, cancellation, recovery and termination:** Parse/version/storage failures yield no saved config; save/clear return errors to caller. No timed expiry of stored location; new caller action is recovery.

**Dependencies:** localStorage; URLSearchParams; builder C05; native runtime caller owned by parent; C02/C04 provenance

**Supporting checks:** Parent: intent21/21, reset9/9, preferences cohort has fixture drift; read tests/r0010-preferences.cjs for saved-preference precedence

**Remaining risk / gap:** Native storage restrictions and multi-document concurrent writes were not exercised; invalid numeric source admission must be fixed at boundaries without changing legacy normalization indiscriminately.

### C02 — Coarse location provider cascade and whole-body deadline

**Nature:** partly-explicit. **Audit disposition:** CONFIRMED FINDINGS F04 (invalid coordinates admitted), F09 (frozen v1 body deadline). Current stalled-body fallback probe passes.

**Exact evidence:** `src/native/config.js:230-270` `coarseDetect`; `v1/config.js:189-221` `coarseDetect older deadline variant`

**Retained state:** Provider index, AbortController, deadline timer, work/deadline promise race and eventual result.

**States:** GeoJS pending; ipinfo pending; accepted; failed

**Transitions, guards and effects:**
- start GeoJS; non-OK, parse error or deadline advances to ipinfo; exhaustion returns failed
- successful parser output passes only null/NaN gate then normalize clamps coordinates and returns success
- current deadline owns headers, body and parse; frozen v1 clears deadline on headers

**Invariants:** Exactly one adopted result per invocation; stale underlying work cannot start a second fallback in current code; Provider-derived coordinates should identify a valid measured position before normalization

**Errors, expiry, cancellation, recovery and termination:** Current abort plus rejection timer bounds body wait; timers cleared on settlement. No caller cancellation argument; builder discards stale completion. Frozen v1 can remain pending on stalled JSON body.

**Dependencies:** fetch; AbortController; timer; provider schemas; C06 owner fence

**Supporting checks:** evidence/probes/configuration/results.json (source-bound VM doubles; no native browser/network/install qualification)

**Remaining risk / gap:** External availability, true geographic accuracy and browser abort implementation were not tested.

### C03 — Forward geocoder aggregate completion

**Nature:** implicit. **Audit disposition:** CONFIRMED F06: failure/no-match distinction is lost. Abort-ignorant body hang is an explicitly unverified transport limitation, not a native reproduction.

**Exact evidence:** `src/native/config.js:333-376` `candidate parsing/dedupe/geocodeSearch`; `v1/config.js:271-331` `search helpers/geocodeSearch`

**Retained state:** Parallel Nominatim and optional Canadian postal lookup promises; shared abort timer; collected candidate array.

**States:** short query; providers pending; candidates; empty result

**Transitions, guards and effects:**
- query shorter than two characters returns empty
- query starts Nominatim and Canadian FSA fallback when applicable; Promise.all waits; errors map to empty arrays
- dedupe and home-country ordering return candidate list; finally clears timer

**Invariants:** No application location is applied by this helper; caller owns adoption; Transport failure and genuine zero matches currently have identical outward shape

**Errors, expiry, cancellation, recovery and termination:** Abort after eight seconds; catch returns empty. There is no independent rejecting deadline if a fetch/body ignores abort. Retry is a new query; no explicit cancellation API.

**Dependencies:** fetch; Nominatim; Zippopotam.us; C06 current owner; C20 old owner

**Supporting checks:** evidence/probes/configuration/results.json (source-bound VM doubles; no native browser/network/install qualification)

**Remaining risk / gap:** Candidate range/finite validation is weak like C02; current fixtures do not establish provider or accessibility behavior.

### C04 — Browser location and permission request completion

**Nature:** partly-explicit. **Audit disposition:** INSPECTED: current evidence and caller fencing are coherent; V1 weaker presentation/adoption recorded under C20.

**Exact evidence:** `src/native/config.js:58-85` `locationEvidence/browserLocationEvidence/placeLocationEvidence`; `src/native/config.js:273-286` `geolocate/permissionState`; `v1/config.js:223-245` `older geolocate/permissionState`

**Retained state:** One geolocation callback promise and permission-query promise; acquisition timestamp and accuracy in current result.

**States:** unsupported; requesting; fix; denied/error; permission known/unknown

**Transitions, guards and effects:**
- unsupported API resolves error; browser success returns coordinates/evidence; browser error maps code
- request defaults to ten-second timeout and maximum cached age ten minutes; permission query failure becomes unknown
- current evidence normalizer demotes unsupported historical browser claims; V1 lacks evidence fields

**Invariants:** A cached browser fix is not a live GPS claim; owner must be checked after every await in the caller

**Errors, expiry, cancellation, recovery and termination:** Browser owns timeout/callback lifecycle; no caller abort primitive. Permission failure is unknown. Synchronous provider exceptions can reject the wrapper promise.

**Dependencies:** navigator.geolocation; navigator.permissions; C06/C20 ownership

**Supporting checks:** Parent intent/reset cohorts; static callback review

**Remaining risk / gap:** No native permission prompt, hardware position, iframe permissions or secure-context test.

### C05 — Builder mode, form, serialization, preview and output revision

**Nature:** partly-explicit. **Audit disposition:** CONFIRMED F05: identical input/change pair causes two preview navigations with unchanged serialized hash. Output encoding/precedence is intentional.

**Exact evidence:** `src/native/builder.html:198-254` `formConfig/hash/url/previewUrl/snippet/update/setMode`; `src/native/builder.html:345-390` `date-format/open/reload/installCmd`

**Retained state:** embedMode, form fields, builderLocation provenance, preview revision counter, generated snippet and installer payload.

**States:** portable; local; edited; preview navigating

**Transitions, guards and effects:**
- mode click/arrow selects enabled radio and updates mode prose, iframe permission and serializer
- input and change each synchronously regenerate output and navigate preview with a new revision
- reload forces preview; open uses stable URL; installer carries the current serialized hash; date pattern synchronizes select/custom field

**Invariants:** Output, open URL and installer hash share the serializer; iframe remains325x530; Local omits location and explicitly includes selected method/units/appearance; saved runtime preferences may still win by design

**Errors, expiry, cancellation, recovery and termination:** No preview load/error acknowledgment or preview cancellation state. Field values are normalized; a subsequent edit replaces output. Open/download navigation is manual handoff.

**Dependencies:** C01 serializer; C06 edit ownership; C07 copy; generated root index consumer

**Supporting checks:** evidence/probes/configuration/results.json (source-bound VM doubles; no native browser/network/install qualification); Parent radio8/8, effects3/3, intent21/21; read preferences tests

**Remaining risk / gap:** The navigation count is measured in a DOM double; bandwidth/CPU savings and visual behavior are projections requiring native validation.

### C06 — Builder edit ownership, candidate cycle and automatic fills

**Nature:** partly-explicit. **Audit disposition:** INSPECTED: no new ownership bug confirmed; shared fencing covers competing location routes.

**Exact evidence:** `src/native/builder.html:258-343` `searchReset/captureOwner/currentOwner/search/reverse/coordinate edits`; `src/native/builder.html:437-473` `locate/detectArea/boot`

**Retained state:** edit and sequence counters, debounce/revert/reverse timers, candidate list/index/query/owner, labelAuto/methodAuto, home country, location evidence.

**States:** idle; debounced; lookup pending; single/multiple candidate; browser fix pending; reverse pending; startup coarse pending; stale completion

**Transitions, guards and effects:**
- label/coordinate edits reset timers and invalidate older owners; captures bind edit plus sequence
- forward completion requires current owner; candidates cycle only for same query/owner; coordinates invalidate acquisition provenance
- browser, reverse and startup coarse completion require current owner; automatic label/method change only while auto flags remain true

**Invariants:** A completion from an older user intent cannot overwrite a newer draft; display-name edits preserve acquisition evidence intentionally

**Errors, expiry, cancellation, recovery and termination:** Failure feedback expires only for current owner; stale work is ignored but generally not aborted. Reverse lookup has no timeout, so retained transport may outlive the draft; later edit invalidates adoption.

**Dependencies:** C02 coarse; C03 search; C04 browser fix; BigDataCloud reverse; C05 output

**Supporting checks:** Parent intent21/21/reset9/9; source ordering inspection

**Remaining risk / gap:** Provider requests persist after invalidation. Bounded transport cancellation could reduce work but must preserve the ownership checks.

### C07 — Clipboard attempts, fallback and expiring feedback

**Nature:** partly-explicit. **Audit disposition:** INSPECTED: no new defect; success is conditional on API/fallback outcome.

**Exact evidence:** `src/native/builder.html:392-435` `copyText/copyState/copyAction`

**Retained state:** Per-button attempt counter, feedback timer, busy button, payload and manual recovery field.

**States:** idle; clipboard pending; fallback copying; success feedback; manual recovery

**Transitions, guards and effects:**
- click captures payload/current attempt, disables button, clears old feedback
- clipboard success or exception is fenced; fallback textarea/execCommand only proceeds for current attempt
- matching completion enables button, updates status/focus, starts attempt-owned expiry; failure exposes selected manual payload

**Invariants:** Older attempt cannot erase feedback or focus from a newer attempt; temporary textarea is removed even on exception

**Errors, expiry, cancellation, recovery and termination:** Clipboard rejection uses fallback; fallback false/throw becomes explicit manual copy. Timers are cleared on new attempt and fenced at expiry.

**Dependencies:** navigator.clipboard; document.execCommand; DOM focus/selection; C05 payload

**Supporting checks:** Parent clipboard11/11; static review

**Remaining risk / gap:** Native clipboard permission and actual system clipboard content were not tested; each button intentionally has an independent owner.

### C08 — Installer discovery, selection, dry preview and manual handoff

**Nature:** partly-explicit. **Audit disposition:** INSPECTED with F10: malformed Firefox metadata loses unknown state. Final manual-pending prose is explicit; no claim of automated browser installation.

**Exact evidence:** `install.sh:248-384` `profile discovery/Firefox metadata`; `install.sh:565-767` `install/handoff/main`; `install.ps1:177-301` `profile/status discovery`; `install.ps1:444-614` `Install-ForTarget/main`

**Retained state:** Discovered profile records, legacy eligibility, selected targets, source choice, dry/no-open flags and staged outputs.

**States:** discover; eligible/legacy; preview; choose; stage; manual install/import pending; failed

**Transitions, guards and effects:**
- discover browser profiles and extension markers; legacy targets skipped; dry preview terminates without staging/network
- Bash requires TTY, validates explicit selection and source; PowerShell filters selection and defaults non-2 source to GitHub
- successful staging opens/copies instructions; store fallback remains manual; no browser installation completion is attested

**Invariants:** Preview cannot mutate or return cached installation paths; a staged file is not an installed browser extension; Unknown discovery must not be mistaken for known absence

**Errors, expiry, cancellation, recovery and termination:** BashEOF and invalid selection fail; GitHub errors may offer store handoff. PowerShell broad catches warn/fallback and main still reaches Done/manual-pending text. Malformed Firefox metadata becomes false flags in both implementations.

**Dependencies:** OS/browser profile files; C09-C12; parent installer tests

**Supporting checks:** Read source and existing PowerShell test scope; parent broad runner owns execution

**Remaining risk / gap:** Actual browser discovery/locked profile behavior untested. No native PowerShell available in this lane; no real-home install performed.

### C09 — Bash private staging custody and exit cleanup

**Nature:** partly-explicit. **Audit disposition:** INSPECTED: strong guarded staging design; no new bug confirmed.

**Exact evidence:** `install.sh:80-180` `path_identity/trusted_parent/verify_root/guard_owned_path/staging/cleanup`; `install.sh:180-226` `finish/traps/open/copy guards`

**Retained state:** Verified physical parent/root paths, dev/inode/owner/mode identities, private WORK and retained bundle paths, trap/exit status.

**States:** not staged; private roots established; guarded writes; cleanup; retained manual bundle

**Transitions, guards and effects:**
- interactive eligible selection creates unique0700 roots under trusted parents
- every owned path operation rechecks custody/type/no symlink traversal
- EXIT/INT/TERM cleanup removes ephemeral WORK only if identity still matches; changed custody skips deletion with warning; retained bundle survives

**Invariants:** Never delete or write a path after custody changed; dry mode cannot stage; Retention is intentional manual-install support, not failed rollback

**Errors, expiry, cancellation, recovery and termination:** Guard failure aborts; trap releases descriptor; cleanup custody failure warns without deleting. Signals map to130/143; private retained bundle is disclosed on failure.

**Dependencies:** Bash/POSIX tooling; filesystem identity; C10/C12

**Supporting checks:** Static guard/ordering review only; root owns supplied installer tests

**Remaining risk / gap:** Race resistance is bounded by shell path checks; no real filesystem race injection or platform install qualification.

### C10 — Bash asset download, validation, retention and extraction

**Nature:** partly-explicit. **Audit disposition:** INSPECTED: current admission/rollback behavior contrasts safely with C11; remaining bounds are disclosed, not reproduced exploits.

**Exact evidence:** `install.sh:386-531` `select_asset/download/validate_zip/retain/extract`

**Retained state:** Selected release/asset, temporary download, verified archive, retained copy and fresh extraction directory.

**States:** release lookup; download partial; validated archive; retained; extracting; manifest admitted; failed

**Transitions, guards and effects:**
- asset name/family selection; curl downloads to private partial, validates complete ZIP, then promotes
- retained copy similarly uses partial/validation; extract preflights every member for path/type/duplicate safety before exclusive writes
- manifest must exist and parse as JSON object before handoff

**Invariants:** Partial download is never the reusable final archive; unsafe archive member is rejected before extraction

**Errors, expiry, cancellation, recovery and termination:** Errors fail current stage and trap cleans WORK; bundle partials remain explicitly retained. Download has no whole-transfer timeout; ZIP size/expanded-size ceilings are absent.

**Dependencies:** GitHub release API/asset; curl; Python zipfile/json; C09 custody

**Supporting checks:** Static source; no download/extraction invocation

**Remaining risk / gap:** Large/corrupt/hostile archive scale behavior and native tool failures not executed; externally served release identity is not cryptographically pinned by this script.

### C11 — PowerShell shared cache and unpack lifecycle

**Nature:** implicit. **Audit disposition:** CONFIRMED SOURCE FINDINGS F01 and F02; not a native reproduction.

**Exact evidence:** `install.ps1:41-48` `StagingRoot/Initialize-Staging`; `install.ps1:303-380` `LatestRelease/Download-Asset/Expand-ChromiumAsset`

**Retained state:** Predictable TEMP/SalahWidgetInstaller roots, script-cached latest release, tag/name cached path, reusable unpack path.

**States:** cache absent; direct final download; cache exists; unpack removed/recreated; manifest found; failure retained

**Transitions, guards and effects:**
- latest release is cached in process; any existing destination path is declared downloaded
- download writes directly to reusable destination; a failed write can leave a partial cache entry
- unpack recursively deletes existing same-name directory before new extraction; first manifest path is accepted without JSON admission

**Invariants:** Reusable state should be admitted only after full successful preparation; prior usable unpack state should survive replacement failure

**Errors, expiry, cancellation, recovery and termination:** Download/extract throws into caller fallback; no transactional promotion or explicit cache invalidation/cleanup. Next run trusts leftover destination. Dry-run guards exist.

**Dependencies:** PowerShell Invoke-WebRequest/Expand-Archive; shared temp filesystem; C08

**Supporting checks:** Exact source trace345-380; no pwsh executable available; existing dry/stream-shape tests do not cover this failure schedule

**Remaining risk / gap:** Windows reparse-point/ACL exploitability and active browser lock behavior remain unverified; definite source ordering does delete existing unpack before replacement admission.

### C12 — Preset acquisition, hash rewrite and manual import admission

**Nature:** implicit. **Audit disposition:** CONFIRMED F03: PS invalid JSON proceeds to import instructions. Global text replacement/schema weakness retained as an inferred lead, not separately promoted.

**Exact evidence:** `install.sh:533-563` `download_preset`; `install.sh:618-676` `show_import`; `install.ps1:383-442` `Download-Preset/Show-ImportInstructions`

**Retained state:** Configured preset URL/hash, downloaded bytes, rewritten bytes, final staged path and manual import instructions.

**States:** not configured; download pending; rewritten; parseable; invalid; manual import pending

**Transitions, guards and effects:**
- replace all literal local=1 occurrences with chosen hash if supplied
- Bash downloads/rewrite/parses temporary then promotes; malformed JSON rejects
- PowerShell writes direct final, parse failure only warns and still returns path; handoff accepts the path

**Invariants:** Only an admitted preset should be offered as importable; a replace success message should reflect actual intended widget URL update

**Errors, expiry, cancellation, recovery and termination:** Bash failure returns no path and retained bundle allows inspection; PS outer download failure returns null but inner parse failure does not. No schema/target-count validation in either implementation.

**Dependencies:** C05 serialized hash; preset schema/external URL; C09 or C11 filesystem

**Supporting checks:** Source383-414 compared with Bash533-563

**Remaining risk / gap:** Did not fetch or import external presets. Valid but unexpected JSON can pass both scripts; target-specific schema validation is a bounded follow-up.

### C13 — Native generation output publication sequence

**Nature:** partly-explicit. **Audit disposition:** INSPECTED: partial-output risk source-proven, contained operationally by disposable build policy; bounded staging/preflight recommendation G01, not a performed change.

**Exact evidence:** `tools/build_native.py:7-44` `build root/vendor/worker/host/bootstrap sequence`; `tools/build_native.py:47-112` `config/builder/index/offline publication and moon invocation`; `tools/native_core_horizon.py:1-26` `digest guarded horizon transform`; `tools/native_star_bootstrap.py:1-28` `compact star bootstrap transform`

**Retained state:** Filesystem outputs from earlier phases, selected physical checkpoint, source digests and expansion phase.

**States:** vendor inputs; worker/host/bootstrap written; config/builder copied; index guards; index/CSS/offline written; Moon expansion; reported

**Transitions, guards and effects:**
- copy/transform pinned core and concatenate units; write worker/host/data
- copy author config/builder to root; replace native index legacy star/hook boundaries, inject scripts; write root index/offline
- invoke C14 last, then report generated output identity

**Invariants:** Author sources, generated consumers and pinned upstream transform identities must remain explicit; Failure after an early write must not be mistaken for a coherent complete generated set

**Errors, expiry, cancellation, recovery and termination:** Assertions/digest guards stop on mismatch, but writes already performed are not rolled back. Some replacement sites have exact-count guards, others use unchecked replace. Project directs builds in disposable copies.

**Dependencies:** src/native author files; real-sky/native and vendor units; C14; parent boundary audit

**Supporting checks:** Static build/transform inspection; parent owns exact root generated-object verification

**Remaining risk / gap:** No full build run. Texture/offline payload omissions prevent claiming generation/deployment qualification; root owns independent generator-boundary findings.

### C14 — Moon generation preflight and expansion sequence

**Nature:** partly-explicit. **Audit disposition:** INSPECTED: strong preflight identity checks; transaction residual shared with G01. Pure transforms are dependencies, not extra machines.

**Exact evidence:** `tools/build_moon.py:11-43` `constants/validate_initial_source_compatibility`; `tools/build_moon.py:44-151` `native_lunar_owner/build_moon`; `tools/compact_receivers.py:87-134` `compact_receivers`

**Retained state:** Captured index/offline source strings, source/asset/kernel/initial/compact identities, chunk manifest and emitted artifacts.

**States:** unexpanded input; preflight admitted; worker/chunks emitted; host/compact emitted; entry expansion; BUILD receipt

**Transitions, guards and effects:**
- reject already expanded/missing or misordered boundaries before writes
- admit exact payload sizes/digests and approved source-association drift; compact receiver has distinct decoded identity
- write worker/chunks/host/compact files, inject entry scripts, finally write BUILD identity receipt

**Invariants:** No duplicate expansion; lossy compact receiver must not claim its parent decoded identity; allowed ancestry drift is exact, not arbitrary

**Errors, expiry, cancellation, recovery and termination:** Preflight rejects mismatch; later I/O errors can leave partial generated artifacts. Rerunning on partially expanded index can reject and requires restoring disposable input.

**Dependencies:** C13 unexpanded entry; pinned Moon assets/kernel; source association; compact receiver pure transform

**Supporting checks:** Static only; full packed textures not acquired/executed

**Remaining risk / gap:** No build, native render, decode-performance or visual accuracy qualification.

### C15 — Frozen v1 one-time root configuration import

**Nature:** partly-explicit. **Audit disposition:** INSPECTED: latch policy intentional; no independent finding asserted merely because it precedes validation.

**Exact evidence:** `v1/config.js:132-177` `loadLocal/saveLocal/clearLocal`

**Retained state:** V1 config key and one-time imported-root latch; historical root config input.

**States:** no V1/latch; latch set; valid imported; no import; V1 record cleared

**Transitions, guards and effects:**
- when V1 absent and latch absent, set latch before inspecting root record; import only valid version1 record
- later loads never retry root import once latch set; existing V1 record wins
- clear sets latch then removes V1 key, preserving root key

**Invariants:** Reset must not later re-seed V1 from another surface; immutable root-to-V1 compatibility behavior is retained

**Errors, expiry, cancellation, recovery and termination:** Storage exceptions return null/error. A transient failure after latch write can suppress later import; this ordering also intentionally prevents future root reseeding.

**Dependencies:** localStorage; C01 base normalization; tools/verify_v1.py immutable surface verifier

**Supporting checks:** Source inspection; no historical suite rerun

**Remaining risk / gap:** Frozen surface: changes need separate owner authority and compatibility test plan.

### C16 — Frozen v1 configuration apply and boot without generation ownership

**Nature:** implicit. **Audit disposition:** CONFIRMED SOURCE F07: old operations can repopulate new-location state. Frozen V1 compatibility-only disposition.

**Exact evidence:** `v1/index.html:593-632` `bindConfig/initial resolve`; `v1/index.html:2122-2223` `startWeather/loadPrayerData/resetForNewLocation/applyConfig/boot`

**Retained state:** Mutable CONFIG, location/preferences, detection status, current data globals and loop-started flag.

**States:** resolve; coarse pending; configured; saving; resetting; fetching; rendering; manual location needed

**Transitions, guards and effects:**
- apply optionally persists, binds globals, clears datasets and starts weather/prayer; loop start is idempotent
- reset clears visible/cache state but neither cancels nor epochs existing network operations
- coarse boot completion binds after await without a user-edit ownership token

**Invariants:** A response derived from a previous configuration must not mutate a newer configuration or cache under its key

**Errors, expiry, cancellation, recovery and termination:** Save failure is surfaced while in-memory config still applies; data failures leave error/stale paths; old pending operations remain live.

**Dependencies:** C15 persistence; C17/C18/C19 pending work; C20 settings

**Supporting checks:** Exact mutable-global/await trace; native current apply reset finding belongs to root

**Remaining risk / gap:** No browser reproduction; externally scheduled operation timing is modeled by source, not measured. Do not silently backport.

### C17 — Frozen v1 prayer cache, retry, tomorrow and rollover

**Nature:** partly-explicit. **Audit disposition:** CONFIRMED SOURCE F07 prayer trace; no current-runtime duplicate machine claimed.

**Exact evidence:** `v1/index.html:734-759` `cacheKey/loadCache/saveCache/fetchTimings`; `v1/index.html:1186-1189` `prayer retained state`; `v1/index.html:1976-1990` `render tomorrow prefetch`; `v1/index.html:2143-2156` `loadPrayerData`; `v1/index.html:2224-2282` `rollover within loop`

**Retained state:** today/tomorrow,lastDate,fetchingTomorrow, prayerStale,rolloverBusy,nextTry and localStorage cache; mutable tz.

**States:** cached; fetch retry1/2/3; today admitted; tomorrow pending; rollover stale; rollover pending

**Transitions, guards and effects:**
- cache date match immediately renders; fetch retries with900/1800ms delays and accepts timings without current-date/owner/schema fencing
- fetchTimings updates global timezone; completion saves using current mutable cacheKey
- after evening, missing tomorrow triggers a retry chain; failure clears flag so another render retries; rollover has60second retry guard

**Invariants:** Date, location, method, school, timezone and cache-key identity must travel with each admitted result

**Errors, expiry, cancellation, recovery and termination:** No fetch timeout/abort; three attempts then caller catch; today missing gives error, rollover keeps stale display. Old completion can clear busy flags or overwrite current data.

**Dependencies:** C16 globals; AlAdhan; C21 time; localStorage

**Supporting checks:** Static trace URL capture -> await -> global tz/saveCache; root current prayer lane owns modern protocol

**Remaining risk / gap:** FrozenV1, permissive provider/date sinks and unbounded waits remain; no network or schema fuzz suite run.

### C18 — Frozen v1 weather current/forecast acquisition

**Nature:** partly-explicit. **Audit disposition:** CONFIRMED SOURCE F07 weather trace; zero-coordinate omission recorded as compatibility limitation.

**Exact evidence:** `v1/index.html:761-808` `weather/loadWx/fetchWeather`; `v1/index.html:845-886` `wxAt/syncWeather`

**Retained state:** weather,weatherTrack,siteElev,lastWxAt,lastWxTry,wxBusy and location-keyed stored sample.

**States:** no sample; cached; busy; fresh; throttled; stale; forecast simulation

**Transitions, guards and effects:**
- load sample under six hours; request if not busy, not fresh15min, and last attempt at least60sec
- fetch captures URL; completion writes elevation/current sample and caches using current mutable coordinates; hourly epoch conversion uses current tz
- simulation override bypasses network; advancing simulation mutates from forecast track

**Invariants:** Busy/fresh flags and accepted data should belong to one location generation; zero-valued latitude/longitude are valid coordinates

**Errors, expiry, cancellation, recovery and termination:** catch is silent, finally clears wxBusy; no timeout. Reset changes timestamps/data but does not clear pending busy ownership. Coordinate0 is excluded by truthiness guard.

**Dependencies:** C16/C21; Open-Meteo; localStorage; C19 precipitation gate

**Supporting checks:** Static lines773-805; no broad legacy tests rerun

**Remaining risk / gap:** Future cached timestamps and old-track/current-tz mixes not dynamically reproduced. Frozen owner approval required.

### C19 — Frozen v1 radar manifest, tile and freshness acquisition

**Nature:** implicit. **Audit disposition:** CONFIRMED SOURCE F07 stale adoption surface; frame-age interpretation retained as compatibility risk, not new current finding.

**Exact evidence:** `v1/index.html:809-843` `weatherRadar/radarPrecipNow/fetchRadar`

**Retained state:** weatherRadar,lastRadarAt,radarBusy, chosen provider frame and pending Image/canvas read.

**States:** throttled; manifest pending; tile pending; sample accepted; stale/none

**Transitions, guards and effects:**
- ten-minute throttle is stamped before manifest request; last past frame selected
- coordinates are read after manifest await, then image tile/canvas alpha sample determines precipitation
- receipt wall time is stamped on acceptance;20min expiry uses receipt time rather than source frame time

**Invariants:** Accepted tile must belong to current location and source-frame age must not be disguised as receipt freshness

**Errors, expiry, cancellation, recovery and termination:** Image error becomes zero sample; image success/body fetch has no independent timeout; catch retains previous result and finally clears busy. Reset does not invalidate old request; coordinate0 guard also suppresses valid sites.

**Dependencies:** RainViewer manifest/tile; canvas CORS; C16/C18

**Supporting checks:** Static async coordinate/time ordering

**Remaining risk / gap:** No native canvas/CORS/fresh-frame qualification; frozen approval boundary applies.

### C20 — Frozen v1 modal editing, lookup, GPS and Reset

**Nature:** implicit. **Audit disposition:** CONFIRMED F08 by source-bound failed-removal probe; F07 ownership risk by source. ImmutableV1 deferred to owner.

**Exact evidence:** `v1/index.html:2283-2451` `settings state/search/apply/commit/usePrecise/reset/open/close`

**Retained state:** wired flag,last focus,search sequence,candidates/index,homeCC,location source and dirty draft.

**States:** closed; open clean; dirty; search pending; candidate cycle; GPS pending; reset pending; commit

**Transitions, guards and effects:**
- open populates and increments search sequence; close commits dirty config then hides
- manual coordinate edits or changed query do not fence earlier lookup; candidate Enter can cycle old list; GPS/permission await has no session owner
- Reset ignores clearLocal result, clears stored error and claims success; later coarse completion can replace newer draft

**Invariants:** Closed/replaced draft must not receive old completion; claimed deletion must agree with actual storage removal; old browser origin is not evidence of live GPS

**Errors, expiry, cancellation, recovery and termination:** Invalid commit preserves prior config silently; geolocation error displays status; reset coarse failure still says cleared. No cancellation on close; delayed focus lacks open-session guard.

**Dependencies:** C15; C03/C04; C16; localStorage/DOM

**Supporting checks:** evidence/probes/configuration/results.json (source-bound VM doubles; no native browser/network/install qualification); Static selection/GPS/close sequencing

**Remaining risk / gap:** No native focus or permission verification; changing immutable files is not authorized.

### C21 — Frozen v1 real/simulated clock anchor compatibility variant

**Nature:** partly-explicit. **Audit disposition:** INSPECTED compatibility difference; not counted as another current clock family. Material V1 variant retained, not a current implementation finding.

**Exact evidence:** `v1/index.html:699-731` `TIMESCALE/initSim/simNow/partsInTz`; `src/native/index.html:875-962` `modern clock family mapping only`

**Retained state:** Perf anchor, epoch base, configured timezone, timescale and advancing mode.

**States:** unanchored; wall-like advancing; fixed simulation; fast simulation; timezone re-anchor

**Transitions, guards and effects:**
- first call/timezone change captures Date.now or simulation HHMM; subsequent epoch is base plus monotonic elapsed multiplied by timescale
- invalid timezone falls back to browser local Date parts
- real default also uses monotonic anchor rather than following corrected wall clock

**Invariants:** Displayed calendar/prayer state should use the intended timezone/epoch; simulation must remain explicit

**Errors, expiry, cancellation, recovery and termination:** Timezone change reanchors; no wall-clock jump/suspend reconciliation beyond monotonic clock behavior. Invalid timezone becomes local display rather than fail-closed.

**Dependencies:** performance.now; Date/Intl; C17/C18/loop

**Supporting checks:** Static equations/exception path

**Remaining risk / gap:** Native sleep/resume/platform monotonic behavior and DST boundary tests not run; timezone fallback can present a plausible unintended clock.

### C22 — Frozen v1 Moon texture readiness and pending render cache

**Nature:** implicit. **Audit disposition:** INSPECTED compatibility-only resource failure limitation. Current generated Moon replaces this authority via C14, so no duplicate native Moon ownership is claimed.

**Exact evidence:** `v1/index.html:953-1022` `loadMoonMaps/renderMoonPBR`; `v1/index.html:1023-1082` `renderMoon/geometry context`

**Retained state:** Albedo/normal pixel arrays, ready flag, latest pending request, canvas buffer and last rendered fraction/waxing key.

**States:** textures pending; one texture ready; both ready; pending latest render; render cache hit; painted

**Transitions, guards and effects:**
- two image onload callbacks extract pixels; both ready flush only latest pending request
- render before ready replaces pending parameters; ready render reuses buffer and skips phase change under0.004 with same waxing
- image/canvas failure does not set a settled failure flag

**Invariants:** Pending render should eventually have ready or failure outcome; phase-cache identity belongs to actual painted output

**Errors, expiry, cancellation, recovery and termination:** Only synchronous image setup is caught; no image onerror/deadline or async canvas failure recovery. Page reload is practical recovery.

**Dependencies:** inline base64 texture bytes; Image/canvas; C21/Moon math

**Supporting checks:** Source callback/readiness review; no texture decode or visual rendering

**Remaining risk / gap:** Frozen inline texture corruption/device canvas failure untested; source only proves missing error transition.

### C23 — Frozen v1 synthetic star catalogue and projection cadence

**Nature:** implicit. **Audit disposition:** INSPECTED: materially distinct immutable legacy visual machine. Current generated entry removes this block and consumes native catalogue pipeline.

**Exact evidence:** `v1/index.html:1083-1170` `star catalogue/buildStars/projectStars`; `v1/index.html:1982-1986` `render projection guard`; `tools/build_native.py:49-64` `generated-current replacement of legacy star block`

**Retained state:** Deterministically generated420-star catalogue, DOM stars, bright/glint indices, projected flag and day/advance cadence.

**States:** unbuilt; built; projected; reprojection required

**Transitions, guards and effects:**
- boot seeded pseudo-random catalogue, creates elements and initial projection
- configuration reset/day change invalidates projected flag; advancing simulation projects on render
- ordinary real-time render leaves already-projected stars fixed between invalidation events; moon position updates independently

**Invariants:** Synthetic decorative catalogue is a legacy visual protocol, not the current native catalogue authority

**Errors, expiry, cancellation, recovery and termination:** No independent async operation; construction/projection exception is not locally recovered. Reset/reload reprojects/rebuilds.

**Dependencies:** C21 epoch; geometry/moonSky; DOM; seeded RNG helper

**Supporting checks:** Exact generator replacement review plus old retained-state loop

**Remaining risk / gap:** No visual comparison or astronomical accuracy certification; do not infer authoritative stars from the old synthetic construction.

### C24 — PR62 Pages payload qualification workflow and retained receipt

**Nature:** already-explicit. **Audit disposition:** INSPECTED delivery protocol. Verifier alone is single-pass and not separately counted; workflow retains action-distinguishing state. No live CI execution claim.

**Exact evidence:** `.github/workflows/r0017-pages-payload.yml:1-38` `measure job`; `tools/verify_r0017_pages_payload.py:30-124` `verify/main/finally receipt`

**Retained state:** PR/head identity, job result, generated _site, initialized FAIL receipt, accumulated identity/size measurements, retained artifact.

**States:** not PR62/skipped; checkout; Jekyll build; verify; PASS/FAIL receipt; artifact retention

**Transitions, guards and effects:**
- pull_request main only and PRnumber62 guard; pinned checkout of head with limited depth/no credentials; pinned Jekyll build
- verifier requires approved ancestry/allowed changes, exact exclusion/image/runtime identities, protected file byte equality and total<=1GB
- receipt initialized FAIL; finally writes it even on verification exception; upload always attempts and fails if absent; PASS only at end

**Invariants:** Qualification artifact is evidence, not deployment/closure authority; exact current source and complete built output must be established

**Errors, expiry, cancellation, recovery and termination:** Ten-minute job timeout; script exception fails job but retains available FAIL receipt. Build/checkout failure means verifier never ran; always-upload then reports missing artifact rather than fabricating PASS.

**Dependencies:** GitHub CI event state; git history; Docker image inspection; tools/cp9/runtime_identity.py; complete _site

**Supporting checks:** Read exact workflow/script; no build/CI run

**Remaining risk / gap:** Imported snapshot has no Git metadata/complete payload, so cannot execute qualification. Hard-coded explanatory zero reference counts are not live dependency scans; root owns deployment evidence.

## Inherited machine families and source-to-consumer mapping

### Current native document loop/visibility/reduced-motion family

**Evidence:** v1/index.html:2224-2282 startLoop; src/native/index.html:3622-3663 current mapping

**State and transitions:** loopStarted, RAF handle, visibility/intersection, last second/date/weather/cloud ticks and diagnostic counters. start once; visible+on-screen schedules, hidden cancels; per-second render,30second weather,cloud cadence; last-date triggers C17

**Disposition:** INSPECTED compatibility mapping; not another machine count. V1 lacks modern generation/lifecycle guards; C17/C21 capture material divergences.

**Gap:** Native freeze/page lifecycle not exercised; root owns current lifecycle qualification.

### Current cloud geometry/smoothing/cache family

**Evidence:** v1/index.html:1503-1547,1798-1809; src/native/index.html:2144-2155,2548-2563,3024 mapping

**State and transitions:** fixed initial cloud seed, cloudReady, coverage/targets, canvas/context/output density and dirty flag. first deck snaps then subsequent coverage eases; paint updates dirty buffer; location reset in V1 does not reset fixed seed/deck context

**Disposition:** INSPECTED compatibility mapping; current family gains context reset. No duplicate current renderer machine counted.

**Gap:** Pure shader/math loops and texture visuals not qualified; fixed initial seed may be intentional aesthetic continuity, not promoted as bug.

### Current countdown text measurement/cache family

**Evidence:** v1/index.html:1911-1951; current src/native/index.html:3144-3152 mapping

**State and transitions:** canvas measurement and current fit sizing/cache. render measures/fits available text, updates CSS; modern source additionally invalidates font-dependent state

**Disposition:** READ/PARTIAL compatibility mapping; no standalone finding; current owner must reconcile exact generated reachability.

**Gap:** No native font loading/layout test; not a release-quality claim.

### Current thunder/lightning bucket family

**Evidence:** v1/index.html:1976,2029-2033; src/native/index.html:3246-3252/render mapping

**State and transitions:** last bolt bucket and generated bolt geometry. thunder+new2.6second bucket regenerates bolt; current weather gate decides thunder

**Disposition:** INSPECTED inherited family mapping; pure geometry helper not separate machine.

**Gap:** No visual/reduced-motion validation. Old weather ownership issues already recorded C18/C19.

| Source | Generated consumer / ownership |
|---|---|
| src/native/config.js | Copied to root config.js by build_native.py:47; inlined into offline entry by102-107. Shared by builder/current runtime. |
| src/native/builder.html | Copied to root builder.html by47; iframe/open/installer use serialized current root entry. |
| src/native/index.html | Transformed by build_native.py:48-81 and expanded by build_moon.py:139-144 into root index.html/offline. Legacy synthetic stars and old Moon render authority are not current generated authorities. |
| native core/host units and guarded horizon/star transforms | worker/native-sky/bootstrap/preview/native-data outputs, exact identities and import stripping owned by build_native.py. |
| native Moon owner/worker/host units + packed assets/kernel/compact receiver | Native Moon worker/host/chunks/manifest and BUILD receipt; parent asset/renderer lanes own native consumption. |
| v1/config.js and v1/index.html | Immutable retained page surface, own storage/import protocol. No generated-current repair recommendation authorizes modifying V1. |
| root installers | Manual platform installation/import handoff, invoked by builder-generated shell/PS commands against main URLs; no pinned release or browser-success attestation. |
| r0017 Pages workflow | PR62 qualification only; CI artifact has PASS/FAIL receipt, no deployment step. |

## Full finding contract

### F01 — PowerShell adopts failed partial downloads as cached success

**Category:** Correctness / Bugs; Security / Privacy

**Evidence:** install.ps1:345-360 Download-Asset; install.ps1:444-538 caller fallback

**Event Trace:** Run A writes partial final destination then Invoke-WebRequest throws. File remains. Run B Test-Path succeeds, says Already downloaded, returns partial without validating it.

**Impact:** Corrupt/untrusted residual bytes are offered to manual install; retries do not recover automatically. A predictable cache also lacks explicit custody admission.

**Effort:** M

**Risk:** Medium implementation risk: cache/path behavior changes require Windows compatibility tests

**Confidence:** High source-proven; native execution unverified

**Fix Route:** DMAIC: stage unique private partial, validate ZIP/signature/schema as appropriate, promote only after success; retain explicit failure state

**Repair Class:** Boundary admission and transactional file repair

**Owner:** Installer maintainer (role inferred)

**Acceptance:** Failure after any byte count cannot make next run return success; prior valid cache remains usable; dry mode unchanged.

**Verification:** Isolated Windows filesystem test with failing downloader plus second invocation; malicious/reparse cache path rejection; no real-home installation.

**Rollback:** Revert source change and discard only newly owned failed staging; preserve prior validated archive.

**Disposition:** CONFIRMED SOURCE; recommended bounded repair, no edits authorized

**Remaining Risk:** Provider authenticity and archive scale bounds remain separate controls.

### F02 — PowerShell deletes previous unpacked payload before replacement succeeds

**Category:** Correctness / Bugs; Architecture / Tech Debt

**Evidence:** install.ps1:41-48 staging roots; install.ps1:363-380 Expand-ChromiumAsset

**Event Trace:** A previously returned unpack path exists; repeat call recursively removes it; new extraction/manifest check fails. The previously usable directory is gone.

**Impact:** An unpacked extension path previously handed to the user can be destroyed by failed retry. Shared predictable location and absent custody checks widen the filesystem risk.

**Effort:** M

**Risk:** Medium: Windows rename/lock semantics need native tests

**Confidence:** High deletion ordering; exploitability unverified

**Fix Route:** DMAIC: unique owned extraction staging, full admission, then controlled promotion/handoff; preserve existing usable path until ready

**Repair Class:** Rollback/custody repair

**Owner:** Installer maintainer (role inferred)

**Acceptance:** Any extraction/admission failure leaves prior handoff usable; no traversal/reparse target is removed; manifest parses before handoff.

**Verification:** Fault inject extraction and manifest failure in disposable Windows root; verify old sentinel unchanged and no outside writes.

**Rollback:** Keep prior directory; revert promotion pointer/path only, never blanket-delete shared cache.

**Disposition:** CONFIRMED SOURCE; bounded repair

**Remaining Risk:** Native ACL/reparse/browser-file-lock behavior not exercised.

### F03 — PowerShell returns malformed preset JSON for manual import

**Category:** Correctness / Bugs; Direction / Design

**Evidence:** install.ps1:394-409 Download-Preset; install.ps1:417-442 Show-ImportInstructions; install.sh:533-563 contrasting admission

**Event Trace:** Download succeeds; ConvertFrom-Json throws; inner catch warns; function returns presetFile; caller provides import/open instructions.

**Impact:** Success-path handoff includes a file known to be invalid; user recovery requires interpreting a warning despite concrete import instructions.

**Effort:** S

**Risk:** Low if null/error contract maintained

**Confidence:** High source-proven

**Fix Route:** DMAIC: make parse failure a failed stage and return no importable path; validate intended preset structure before promotion

**Repair Class:** Error propagation/admission repair

**Owner:** Installer maintainer (role inferred)

**Acceptance:** Malformed JSON cannot reach import instructions; status identifies failure; valid preset still carries intended widget hash.

**Verification:** Source-bound PowerShell function test with malformed body; valid control; output-stream shape and dry-run guard regressions.

**Rollback:** Revert bounded function change; retained invalid candidate may remain explicitly diagnostic only.

**Disposition:** CONFIRMED SOURCE; no native PS test

**Remaining Risk:** Parseable unexpected schema and global raw hash replacement remain follow-up risks.

### F04 — Coarse provider coordinates are silently clamped into an accepted site

**Category:** Correctness / Bugs; Direction / Design

**Evidence:** src/native/config.js:258-264 coarseDetect; src/native/config.js:110-130 normalize; evidence/probes/configuration/results.json (source-bound VM doubles; no native browser/network/install qualification)

**Event Trace:** Provider reports999,999. Null/NaN gate passes. normalize clamps to90,180. Function returns ok:true from first provider; fallback never runs.

**Impact:** Downstream prayer/weather calculations receive a geographically unrelated but plausible valid tuple and provenance claims provider success.

**Effort:** S

**Risk:** Low-to-medium: reject invalid provider values at acquisition boundary without changing legacy serializer semantics

**Confidence:** High: actual source mocked-response probe

**Fix Route:** DMAIC: finite/range-check parsed provider coordinates before normalization; malformed provider result must advance fallback

**Repair Class:** Input admission repair

**Owner:** Configuration maintainer (role inferred)

**Acceptance:** NaN,Infinity,lat outside[-90,90],lon outside[-180,180] rejected; zero and valid boundary coordinates accepted; fallback semantics preserved.

**Verification:** Source-bound invalid/valid provider table plus stalled-body fallback regression; builder ownership cohorts.

**Rollback:** Revert only acquisition gate; preserve stored/config compatibility unless separately approved.

**Disposition:** CONFIRMED BY PROBE

**Remaining Risk:** Forward geocoder/browser/storage admission deserves matching boundary review; provider accuracy cannot be guaranteed by range checks.

### F05 — Builder reloads unchanged preview for each input and change event

**Category:** Performance / Scale; Architecture / Tech Debt

**Evidence:** src/native/builder.html:212-224 previewUrl/update; src/native/builder.html:253-254 event bindings; evidence/probes/configuration/results.json (source-bound VM doubles; no native browser/network/install qualification)

**Event Trace:** Method remains4. Dispatch input then change. Serialized output hash stays identical, preview revision increases twice, each update assigns iframe src.

**Impact:** Redundant full generated-entry navigations can restart rendering/bootstrap/network work; rapid text editing compounds cost. Only navigation count measured.

**Effort:** S

**Risk:** Medium UI risk if over-debounced; output must remain immediate

**Confidence:** High navigation reproduction; resource savings projected

**Fix Route:** DMAIC: keep serializer/output immediate, dedupe preview by semantic URL and coalesce editing updates; explicit Reload remains forcing action

**Repair Class:** Bounded scheduling efficiency

**Owner:** Builder maintainer (role inferred)

**Acceptance:** Unchanged input/change pair navigates at most once (ideally zero); latest changed draft preview eventually matches output; explicit reload still forces.

**Verification:** DOM schedule count and output/preview-coherence tests, then native latest-draft/keyboard check; no fabricated timing benchmark.

**Rollback:** Remove scheduling/dedupe wrapper; retain existing serializer and owner fences.

**Disposition:** CONFIRMED BY PROBE; performance opportunity

**Remaining Risk:** A native loading/CPU/network measurement is needed to quantify benefit; whole-site refactor unnecessary.

### F06 — Geocoder transport failure is reported with the same state as no matches

**Category:** Correctness / Bugs; Direction / Design

**Evidence:** src/native/config.js:360-376 geocodeSearch; src/native/builder.html:300-310 search; evidence/probes/configuration/results.json (source-bound VM doubles; no native browser/network/install qualification)

**Event Trace:** All provider fetches reject; per-provider catches return[]; aggregate returns[]; builder renders location-not-found messaging.

**Impact:** User cannot distinguish service failure from an invalid place query; guidance suggests changing input when retry/manual coordinates may be appropriate.

**Effort:** S

**Risk:** Low-to-medium API shape risk; preserve compatibility for current consumers

**Confidence:** High shape probe and source UI trace

**Fix Route:** DMAIC: expose bounded result status/partial provider errors through an additive API or compatible wrapper, while keeping owner fence

**Repair Class:** Failure-state observability

**Owner:** Configuration/builder maintainers (roles inferred)

**Acceptance:** Valid zero-match, all-provider failure, partial success and abort are distinct for current UI without breaking frozenV1.

**Verification:** Provider result matrix, stale completion ownership and candidate cycling tests.

**Rollback:** Revert additive status API/UI consumer together; retain legacy array API if shared externally.

**Disposition:** CONFIRMED BY PROBE; lower-priority bounded repair

**Remaining Risk:** Browser transport/native timeout semantics untested; do not promise total deadline from abort alone.

### F07 — Frozen v1 location changes do not invalidate earlier data or settings work

**Category:** Correctness / Bugs; Architecture / Tech Debt

**Evidence:** v1/index.html:743-758 fetchTimings; v1/index.html:771-805 fetchWeather; v1/index.html:816-840 fetchRadar; v1/index.html:2143-2181 apply/reset; v1/index.html:2302-2451 settings

**Event Trace:** Start request at locationA; apply locationB resets globals but retains pending operation. A completion assigns global tz/weather/today or fields; cache key is recomputed from B. Old settings search/GPS/reset may also overwrite a newer draft.

**Impact:** Cross-location mixed state/cache and user-intent loss on an immutable compatibility surface. Current root has modern owner/generation protocols and must not be conflated.

**Effort:** M

**Risk:** High compatibility/authority risk for frozen artifact

**Confidence:** High source trace; no native reproduction

**Fix Route:** deferred: document compatibility limitation; any repair requires separate owner authority and a new compatibility/immutable-version decision

**Repair Class:** Frozen compatibility repair only

**Owner:** FrozenV1 owner, separately authorized

**Acceptance:** If authorized on a new surface, all network/draft results bind immutable location/session/generation and cannot adopt after reset; historical bytes remain preserved unless owner explicitly directs otherwise.

**Verification:** Adversarial A/B completion order per prayer/weather/radar/search/GPS/reset, cache-key assertion, V1 preservation verifier on retained historical artifact.

**Rollback:** Preserve exact pinned V1 artifact and return to it; never claim report approval authorizes changing frozen bytes.

**Disposition:** CONFIRMED SOURCE; DEFERRED OWNER AUTHORITY

**Remaining Risk:** Current tests do not imply legacy safety; asynchronous transport cancellation alone would not solve adoption identity.

### F08 — Frozen v1 Reset claims deletion after storage removal fails

**Category:** Correctness / Bugs; Direction / Design

**Evidence:** v1/index.html:2421-2427 _resetLocal; v1/config.js:172-176 clearLocal; evidence/probes/configuration/results.json (source-bound VM doubles; no native browser/network/install qualification)

**Event Trace:** clearLocal returns failure for denied removal; _resetLocal ignores result, nulls storage error and says Local settings cleared. Coarse lookup fails; old record remains and final message still says cleared.

**Impact:** Reload can restore settings the UI said were erased; privacy/control status is false.

**Effort:** S

**Risk:** High authority risk on immutableV1; low code scope if separate authorized successor

**Confidence:** High: actual _resetLocal plus actual V1 storage helper in VM probe

**Fix Route:** deferred: preserve immutable artifact, document failure mode; separately authorized successor should branch on clear result before reset/detection

**Repair Class:** Truthful storage transition repair

**Owner:** FrozenV1 owner, separately authorized

**Acceptance:** Failed removal retains truthful error and does not claim cleared; successful reset invalidates prior draft/network owners.

**Verification:** Failed latch/remove operations separately, coarse success/failure and newer draft during reset; no native storage claim from doubles.

**Rollback:** Retain immutable prior version; rollback authorized successor independently.

**Disposition:** CONFIRMED BY PROBE; DEFERRED OWNER AUTHORITY

**Remaining Risk:** Device/browser storage restriction behavior not tested; old in-memory config can remain even when persistence succeeds.

### F09 — Frozen v1 coarse lookup retires timeout before body completion

**Category:** Correctness / Bugs; Performance / Scale

**Evidence:** v1/config.js:207-221 coarseDetect; src/native/config.js:248-268 corrected current family; evidence/probes/configuration/results.json (source-bound VM doubles; no native browser/network/install qualification)

**Event Trace:** First provider headers arrive, then JSON body never settles. V1 clears timer at headers; fallback never starts. Current race rejects at whole-body deadline and advances.

**Impact:** Legacy startup/reset detection may remain pending indefinitely despite configured timeout.

**Effort:** S

**Risk:** High frozen-authority risk; bounded modern fix already exists

**Confidence:** High source-bound deadline probe

**Fix Route:** deferred: record immutable compatibility limit; authorized successor can reuse whole-work deadline contract

**Repair Class:** Async deadline ownership

**Owner:** FrozenV1 owner, separately authorized

**Acceptance:** Every provider invocation settles/advances after whole-body deadline even when abort is ignored; late body cannot adopt.

**Verification:** Headers/body delay and abort-ignorant body schedules; successful provider control.

**Rollback:** Preserve frozen artifact; rollback only separately authorized successor.

**Disposition:** CONFIRMED BY PROBE; DEFERRED OWNER AUTHORITY

**Remaining Risk:** Mocked scheduler demonstrates ownership difference, not a measured production outage.

### F10 — Malformed Firefox metadata loses the unknown discovery state

**Category:** Correctness / Bugs; Security / Privacy

**Evidence:** install.sh:273-320 firefox metadata parsing; install.ps1:231-267 Firefox status parsing

**Event Trace:** Profile metadata exists but fails JSON parsing. Catch/fallback produces no-extension/no-legacy flags. Main target becomes eligible as if absence were established.

**Impact:** Installer can direct a user toward installation/import despite uncertainty about legacy extension ownership; scripts do not automatically overwrite browser settings.

**Effort:** S

**Risk:** Low-to-medium compatibility risk: unknown state needs clear nonblocking/manual handling

**Confidence:** High source path; actual corruption scenario not executed

**Fix Route:** DMAIC: preserve known-present/known-absent/unknown status; unknown should require explicit manual review or safe skip rather than false absence

**Repair Class:** Discovery-state truthfulness

**Owner:** Installer maintainer (role inferred)

**Acceptance:** Missing file, malformed file and parse success yield distinct state; legacy present remains skipped; dry preview clearly reports uncertainty.

**Verification:** Disposable profile fixtures for missing/malformed/valid legacy/current metadata on both platforms.

**Rollback:** Revert status model plus callers together; no browser profile mutation required.

**Disposition:** CONFIRMED SOURCE; bounded repair

**Remaining Risk:** No browser profile locking/schema-version qualification; cautious handling must not turn discovery errors into blanket inability to use manual route.

## Cross-machine GDOPL constraints and bounded variations

1. Preserve truth at acquisition boundaries: reject impossible provider coordinates before normalization and report provider failure distinctly. Keep current edit/generation ownership even if transport cancellation is added.
2. Improve builder scheduling locally: keep generated output current on every edit, dedupe/coalesce preview navigation, preserve mode precedence and explicit Reload. This is a candidate efficiency gain with measured navigation count and unmeasured resource benefit.
3. Reuse the Bash staging invariants conceptually in PowerShell without merging both installers into a large shared framework: owned private attempts, explicit failure, admission before promotion, previous usable payload retention, honest manual-pending completion.
4. Treat generator outputs as one publication set. Current disposable-build practice contains partial writes; preflight replacement counts and verify output manifest before promotion. No completed-source or native-render claim follows from a successful helper probe.
5. Protect authority and compatibility: frozenV1 findings are documentation/owner decisions, not automatic backports. Keep root generated and legacy provenance separate, and do not count inherited protocols twice.
6. Delivery evidence remains scoped: PR62 workflow records actual built payload and protected consumers; hard-coded explanatory reference counts do not become new live dependency-analysis evidence.

## Probe outcomes

- {"check": "coarse provider invalid coordinate admission", "result": "confirmed", "supplied": [999, 999], "adopted": [90, 180], "providerCalls": 1}
- {"check": "builder unchanged input/change preview revision", "result": "confirmed", "sameSerializedHash": true, "previewNavigationsAdded": 2}
- {"check": "headers-before-body deadline", "source": "src/native/config.js", "settledAfterDeadline": true, "bodyRequests": 2, "result": "current fallback owns deadline"}
- {"check": "headers-before-body deadline", "source": "v1/config.js", "settledAfterDeadline": false, "bodyRequests": 1, "result": "frozen v1 deadline retired at headers"}
- {"check": "v1 reset failed removal", "result": "confirmed", "savedRecordRetained": true, "storageErrorCleared": true, "messages": [{"text": "Local settings cleared.", "error": false}, {"text": "Local settings cleared — enter your location.", "error": true}]}
- {"check": "geocoder failed transport shape", "result": "confirmed", "returnedCandidates": [], "classification": "same shape as valid zero matches"}

The probe file is `evidence/probes/configuration/protocol-probes.cjs`; it executes exact source behavior against deterministic doubles, uses no external sinks, and writes only its results. Parent cohorts reported passing: intent21/21, reset9/9, clipboard11/11, effects3/3, radio8/8. Preferences/storage fixture drift is owned by root. These cohorts were not rerun here. No broad-runner elapsed duration is used.

## Read confirmation

- AGENTS.md (project instructions)
- ../plans/AUDIT_SCOPE.md (entire audit boundary/machine definition)
- ../methodology/audit-playbook.md: Correctness / Bugs; Security / Privacy; Performance / Scale; Tests / Validation; Architecture / Tech Debt; Direction / Design; Finding Row Contract; Vetting (plus prioritization)
- src/native/config.js (full behavior-bearing source)
- src/native/builder.html (markup/privacy plus complete behavior script)
- install.sh (full source)
- install.ps1 (full source)
- tools/build_native.py (full)
- tools/build_moon.py (full)
- tools/native_core_horizon.py (full)
- tools/native_star_bootstrap.py (full)
- tools/compact_receivers.py (full)
- tools/verify_v1.py (full)
- v1/config.js (full)
- v1/index.html behavior sections593-650,699-886,953-1189,1190-1228,1499-1547,1798-1835,1911-1951,1976-2451; inline image payloads/CSS/pure render mathematics not a visual inspection
- .github/workflows/r0017-pages-payload.yml (full)
- tools/verify_r0017_pages_payload.py (full)
- tests/r000f-fixture.cjs (source-bound fixture)
- tests/r0010-preferences.cjs (full)
- Selected current src/native/index.html symbols only for family/generated-consumer mapping; parent lanes own complete current runtime review

## Scope exclusions and remaining limits

- Pure normalize/serialize/date formatting/geometry functions are transition helpers, not independent state machines.
- native_core_horizon, native_star_bootstrap and compact_receivers are pure guarded transforms inside C13/C14.
- tools/verify_v1.py is a single-pass immutable-surface verifier, not another retained protocol.
- verify_r0017_pages_payload.py is counted within C24 CI event/receipt lifecycle, not separately.
- Current generated entry removes legacy synthetic star authority and expands current Moon authority; frozen v1 remains separate immutable compatibility surface.
- Diagnostic snapshots are derived observations; no separate execution authority.
- No source mutation, build, install, browser, native permission, real network or clipboard action occurred.
- Parent reports414 exact verified files and excludes large/offline payloads; this lane does not claim complete build/deployment qualification.
- PowerShell findings are source-proven; pwsh unavailable. Bash custody/extraction not invoked.
- Synthetic probes verify branch/ordering only. No elapsed-time benchmark; root reported broad-runner duration instrumentation defect.
- Fresh independent omission sweep requested by root remains outside this lane.
- Partial inherited countdown mapping remains a named verification gap for the current runtime owner.
- No secret values reproduced; no embedded repository instructions were used to expand authority.

Source identity readback: 14 cited paths compared with parent ledger; mismatches: 0. This comparison is not independent acquisition of the pinned commit.

**FINAL_LANE_HANDOFF_NOT_CLOSURE**
