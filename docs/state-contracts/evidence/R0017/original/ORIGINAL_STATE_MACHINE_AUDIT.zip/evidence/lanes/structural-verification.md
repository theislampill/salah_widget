# Structural integration verification

**Status: mechanical verification complete with two report-only corrections.** Root retains content acceptance and closure authority. No app files, lane reports or frozen population were modified.

## Results

- **83 machine records / 83 unique IDs:** native22, rendering37, configuration24.
- **0 missing required semantic fields; 0 unknown dependency IDs.** Each record has source evidence, retained state, states, transitions, invariants, recovery, dependencies, disposition and remaining risk.
- **190 structured source anchors:** every path exists and every range is valid; symbols are present.
- **70 free-text path/line citations:** one needs the qualified path shown below; all resolved ranges are valid.
- **138 distinct cited repository files:** size, SHA-256 and Git-blob SHA-1 match the parent ledger; zero mismatches and zero unledgered cited files.
- All three lane report files and the source ledger remained byte-identical during this check.
- Frozen population remains **82**; current records add only **R37**. The frozen file remained unchanged.

## Report-only corrections

1. **SV01 — qualified source citation.** `rendering.json /rejected_leads/7/evidence` names `moon-engine.mjs:64–73`. The independently confirmed exact path is `moon/src/moon-engine.mjs:64–73`, which defines `MoonEngine.create` and its asset/argument/mask allocations. Its bytes match the parent ledger. Root can normalize this citation in the derived report.
2. **SV02 — unsupported upstream name.** Rendering RF03 names Horizon in its ownership route. Root supplied the correction: use canonical scientific source/upstream under an explicit accepted ownership route. This checker confirmed the text locations but does not select or authorize an owner.

## Deferred inherited-family mapping resolved

| Configuration mapping | Native owner | Verification |
|---|---|---|
| Loop / visibility / reduced motion | N19 | Family and source ranges agree. |
| Cloud smoothing / population / paint cache | N15 | Family and source ranges agree; legacy differences remain qualified. |
| Countdown fit / font readiness | N18 | Exact legacy/current logic inspected; generated `index.html` retains definition at6553 and call at6660. Prior mapping gap resolved. |
| Lightning bucket / precipitation population | N16 | Native catalogue owns the bucket and truth-gate dependency. |

Current and frozen implementations are not claimed behaviorally identical. No inherited family is added to the machine count. Font pixels and the possible fit-key incompleteness remain outside this mechanical check.

## Representation notes and limits

Configuration records place disposition in an audit string; the other lanes use `audit.disposition`. All are present, but a strict common schema would need normalization in the derived report. Nature strings likewise use explicit/partly-explicit labels with qualifiers.

This is structural and byte-identity evidence, not a proof of app correctness, native rendering, test pass, delivery qualification, or closure. No broad tests or platform actions were performed. Detailed anchors, input hashes, identity checks, issue locations and bounds are in `structural-verification.json`.
