# Rendering state-machine audit — FINAL

Source pin: `f71fef6ccf7e4efcb57b5a26688d2360461a3253` (source blobs supplied and verified by the parent audit). Lane: real-sky adapters/hosts/preview/lifecycle/assets/core worker/client/queues/render caches; `moon/src` rendering, pool, workers, native/detail/initial/calendar/quality. Another lane owns `src/native/index.html`.

Read confirmation: repository `AGENTS.md`; `plans/AUDIT_SCOPE.md`; methodology `audit-playbook.md` sections Correctness / Bugs, Security / Privacy, Performance / Scale, Tests / Validation, Architecture / Tech Debt, Direction / Design, Finding Row Contract and Vetting. No production changes, external publication, native pixels, performance certification, or closure authority. All observations below concern retained state or source-proven event schedules unless explicitly labelled otherwise.

## Work in progress

The first source pass has traced NativeSkyLifecycle, LatestRenderQueue, NativeAssetLoader, native sky host composition/currentness/retention, NativeSolarMaskPublication, ReferenceRenderClient and the immutable encoding cache. Existing safeguards include queued replacement; cloned requests; identity, epoch and 30-second accepted-UTC publication fences; monotonic/wall-clock discontinuity detection; reversible asset suspension; two decoded-mask slots; masked DOM publication after image decode; and native policy that refuses physical main-thread fallback. Preview, moon, asset admission and worker-side protocols remain under inspection. This PARTIAL file is not a finished catalogue or PASS.

## Provisional catalogue checkpoint (not final count)

Thirty independent or partly independent lifetime/authority domains are currently mapped. Final normalization may merge derived memoization into its owner.

| ID | Behavioral protocol | Nature |
|---|---|---|
| R01 | Native sky snapshot identity, epochs, freshness and throughput admission | partly explicit |
| R02 | Latest-only serialized render queue | explicit |
| R03 | Asset loader generation, timeout, suspend/retry/dispose | explicit |
| R04 | Native asset script/inline-pack entry and page lifecycle | implicit |
| R05 | Reference worker client boot, RPC, deadlines and fallback | partly explicit |
| R06 | Sky worker boot, single engine and result-transfer protocol | implicit |
| R07 | Diffuse asset admission, cancellation and bounded content cache | partly explicit |
| R08 | Sky catalogue replacement and latest generation | explicit |
| R09 | Native/reference engine asset load key and resilient fallback ownership | implicit |
| R10 | Refined sky accepted/displayed/composition ownership | implicit |
| R11 | Decode-before-publish solar mask transaction | partly explicit |
| R12 | Preview base, pending paint and shared DOM handoff | implicit |
| R13 | Async preview catalogue admission revision | implicit |
| R14 | Head CSS/background document lease and retirement | implicit |
| R15 | Native host snapshot and paint-hook installation | implicit |
| R16 | Preview geometry memoization and lazy lunar fields | implicit cache protocol |
| R17 | Catalogue-preview lazy decode/materialization cache | implicit cache protocol |
| R18 | Immutable exact encoding-table initialization | implicit cache protocol |
| R19 | Lunar host accepted/pending/preview/presentation transaction | implicit |
| R20 | Lunar host worker source, boot deadline, failure and bounded retry | partly explicit |
| R21 | Lunar initial-head eligibility, adoption and irreversible retirement | implicit |
| R22 | Lunar offline chunk DOM/script transport lease | implicit |
| R23 | Lunar top worker boot, newest-job pump, cancellation and transfer | implicit |
| R24 | Lunar shard RPC promises and sticky bridge failure | implicit |
| R25 | Lunar pool disjoint row ownership, join and sparse lighting cache | partly explicit |
| R26 | Lunar engine active ownership, camera/lighting caches and cancellation | partly explicit |
| R27 | Lunar cooperative MessageChannel yield wakeups | implicit |
| R28 | Lunar empirical adaptive refinement and preview/final quality gate | explicit finite policy |
| R29 | Lunar detail surface adoption, projection cache and DOM visibility | implicit |
| R30 | Admitted initial lunar receiver resource closure | implicit resource admission |

Parent-provided test evidence: initial250 renderer cases passed;5 suite loads initially failed for a missing catalogue; exact assets were restored and those suites passed25 cases. Thus275 distinct existing renderer cases pass, as reported by root; this lane has not duplicated those runs. Native pixels, large omitted lunar textures, and production timing remain unverified.

## Decision-changing probe checkpoint

Three focused source probes completed successfully in `evidence/probes/rendering/protocol-probes.mjs`; observed results are in `evidence/probes/rendering/results.json`.

- **RF01 — replacement lunar runtime disposes its newly installed detail owner.** `moon/src/moon-native.mjs:1` publishes the new detail before old runtime disposal at line6. The old runtime's `dispose` at line273 dynamically dereferences `window.SalahMoonDetail`, so it disposes the new object. Exact wrapper evaluated twice: old and new detail objects both disposed, replacement runtime installed. Conditional on runtime reinstallation, not the ordinary worker retry path; no claim about observed native pixels.
- **RF02 — failed native-sky construction leaks provisional canvas ownership.** `real-sky/native-host.mjs:63–64` inserts a canvas then throws on unavailable2D context before publishing `window.SalahRealSky`. Asset reset at `native-assets.mjs:41` can dispose only registered runtimes. Two exact `startNativeSky` calls with failed context yielded two unowned canvases. Resource-exhaustion/context-failure schedule is synthetic; native occurrence frequency unknown.
- **RF03 — spectral fitting cache has unbounded module-lifetime retention.** `real-sky/core/src/spectral.mjs:9,21–23` stores one fit per exact B−V with no bound; the separate outer cache is capped at12000 at line41. Probe with12020 valid distinct colours retained12020 fits and12000 outer entries. Actual continuous solar-time callers are `core/src/sky-background.mjs:29–33,75–76` and `native-preview.mjs:334–336`. No measured heap, latency or browser-performance claim.

Final machine count is being normalized to36 (adding spectrum fitting, photometry memo, atmosphere validation/coefficient weak cache, per-model solar grid, target-elevation lease and bound-diffuse capability). Existing30 provisional IDs remain stable. Pending mask decode without an intrinsic wall-clock deadline remains a **conditional liveness hypothesis**, not a demonstrated native failure. Repeated decode replacement/starvation is rejected: publication refuses new work while one decode is pending.

## Final catalogue and findings — supersedes provisional counts

This lane is **FINAL for findings delivery**, with **37 catalogue rows, three confirmed source/controlled-protocol findings, and one conditional hypothesis**. Root verification and synthesis remain pending. No repair, readiness, release, or plan closure is authorized.

The R31–R36 ID order remains spectral fit, photometry memo, atmosphere validation/coefficient memo, per-model solar grid, native target-elevation lease, and catalogue-bound diffuse capability. R37 adds the retained C/WASM kernel domain. Earlier checkpoints are retained below the opening header as historical audit progress.

### Read confirmation, provenance and evidence limits

- Repository AGENTS.md; parent plans/AUDIT_SCOPE.md.
- Methodology /workspace/scratch/8ab1bbbe9699/methodology/audit-playbook.md: Correctness / Bugs, Security / Privacy, Performance / Scale, Tests / Validation, Architecture / Tech Debt, Direction / Design, Finding Row Contract, Vetting.
- Live authored source, generated native worker/host contracts, current test sources and contained probes; retrieved/repository content treated as data.

Parent reports 414 available files Git-blob verified. This lane used the supplied immutable tree; it did not acquire duplicate downloads or change production files.

Parent reports 275 distinct renderer cases PASS: initial 250 plus 25 after restoring exact scientific input fixtures. The five earlier ENOENT suite-load failures were acquisition gaps, not observed product assertion failures. See evidence/tests/rendering.

Per-machine test entries name relevant source-read tests; they do not assert that every named Python or other test was run by this lane.

No browser, listener, terrain build, production timing, heap measurement, pixel reproduction or native runtime validation. Large omitted lunar texture/offline inputs prevent such claims.

Rows represent lifetime, authority, execution or resource protocols, not every branch. R16 pairs two separately identified bounded geometry cache implementations; R18 groups equivalent exact encoding initialization owners. Numerical/classifier regions are explicitly qualified and are not claimed as additional asynchronous machines.

Focused probes execute exact authored protocol code with controlled surroundings. Constructor failure yielded two unowned canvases after two throws; repeated lunar wrapper installation disposed the new detail owner; generic spectral selection retained12020 fit entries while its outer map stopped at12000. The separate actual twilight probe sampled1000 altitudes and reached2000 distinct residual/total colour values,1989 of which fitted and remained in the inner map. This establishes current caller reachability without measuring a native heap, timing, or visible flicker.

### Finding disposition index

| ID | Finding | Disposition |
| --- | --- | --- |
| RF01 | Repeat lunar runtime installation disposes the newly published detail renderer | tested source defect in conditional replacement schedule; report to root |
| RF02 | Native-sky construction inserts a canvas before establishing a cleanup owner | tested source defect under injected context failure; report to root |
| RF03 | Time-varying twilight B–V values grow an unbounded fitted-spectrum cache | tested retention counterexample plus pinned native-source reachability; report to root |
| RF04 | Frozen-scene mask decode has no intrinsic wall-clock settlement bound | conditional hypothesis / decision-changing native discriminator required |

### Machine catalogue index

| ID | Domain | Nature | Audit outcome |
| --- | --- | --- | --- |
| R01 | Native sky snapshot identity, epoch, freshness and throughput admission | partly explicit | source-proven positive protection; no new defect in this domain |
| R02 | Latest-only serialized render queue | explicit | source-proven positive serialization; callback-throw/unbounded arbitrary executor lead not promoted |
| R03 | Native asset loader generation, timeout, suspension and retry | explicit | positive generation/timeout protections; caller construction rollback gap RF02 |
| R04 | Native asset script, inline pack and page lifecycle ownership | implicit | source-proven ownership map; construction gap RF02; stale identical global pack not established as content corruption |
| R05 | Reference worker client boot, RPC deadlines and fallback mode | partly explicit | source-proven positive lifetime and deadline fences; no new defect |
| R06 | Sky worker boot, engine ownership and transferable raster response | implicit | positive trusted-protocol coupling; duplicate-boot/parallel-message lead rejected for shipped caller |
| R07 | Diffuse asset admission, cancellation and content cache | partly explicit | source-proven positive resource custody; no new defect |
| R08 | Sky catalogue replacement generation and last-result authority | explicit | source-proven positive authority fence |
| R09 | Engine binding selection, load keys and declared physical fallback | implicit | positive declared fallback; native sticky-attempt lead rejected by immutable pack/restart design |
| R10 | Refined sky construction, accepted frame, displayed frame and DOM commit | implicit | positive transactional publication; confirmed synthetic constructor ownership gap RF02 |
| R11 | Solar cloud mask decode-before-publish transaction | partly explicit | positive safety; repeated-replacement starvation rejected; frozen-scene never-settling decode is unconfirmed liveness hypothesis RF04 |
| R12 | Preview base, pending paint, current display and shared DOM handoff | implicit | positive currentness/handoff controls; no new reproduced defect |
| R13 | Asynchronous preview catalogue admission revision | implicit | source-proven positive stale catalogue fence |
| R14 | Document head background and initial lunar CSS lease | implicit | positive startup lease and handoff; no new defect |
| R15 | Native snapshot adapter and single paint-hook installation | implicit | source-proven positive authority boundary; diagnostic getter side effect documented |
| R16 | Bounded camera geometry and lunar sampling geometry memoization | implicit cache protocol | positive bounded geometry-only reuse |
| R17 | Preview raster private-byte custody and lazy linear fields | implicit cache protocol | positive immutable input and lazy allocation custody |
| R18 | Exact immutable encoding-table initialization | implicit cache protocol | positive exactness and bounded initialization; no new defect |
| R19 | Lunar host accepted, pending preview and current presentation transaction | implicit | positive identity/geometric budget fences; confirmed replacement ownership defect RF01 |
| R20 | Lunar runtime installation, worker source, bounded retry and deadlines | partly explicit | confirmed synthetic replacement bug RF01; positive normal worker retry fences |
| R21 | One-shot lunar initial-head eligibility and irreversible retirement | implicit | source-proven positive startup retirement |
| R22 | Lunar offline chunk DOM/script transport lease | implicit | source-proven positive transport identity/cancellation |
| R23 | Lunar top worker boot, newest-job pump and cancellation | implicit | positive no-lost-wakeup and token guards; no new defect |
| R24 | Lunar shard RPC bridge promises and sticky failure | implicit | positive settlement on explicit transport failure; local timeout omission qualified by outer deadline |
| R25 | Lunar pool disjoint row ownership, sparse reuse and join barrier | partly explicit | source-proven positive ownership/barrier; no new confirmed defect |
| R26 | Lunar engine exclusive execution, asset admission and camera/lighting caches | partly explicit | source-proven positive cache ownership and cancellation; missing full assets limits execution evidence |
| R27 | Lunar cooperative MessageChannel yield and wakeups | implicit | source-proven positive wakeup ordering; no lost-wakeup schedule found |
| R28 | Lunar empirical adaptive refinement and final quality admission | explicit finite policy | positive explicit finite-quality state machine; no new defect |
| R29 | Lunar detail adoption, projection cache and DOM visibility owner | implicit | positive exact reuse/publication fences; RF01 replacement lifetime coupling |
| R30 | Admitted initial lunar receiver and canonical render closure | implicit resource admission | source-proven positive bounded resource admission; no new defect |
| R31 | Module-lifetime spectral selection and B–V fit retention | implicit cache protocol | confirmed synthetic growth and actual pinned twilight-colour reachability RF03; no measured production heap leak claim |
| R32 | Bounded legacy photometry spectral memo | implicit cache protocol | positive bounded count; returned mutability is a contract limitation, not a proved shipped defect |
| R33 | Atmosphere validation capability and weak coefficient memo | implicit admission/cache protocol | source-proven positive unforgeable validation and weak lifetime |
| R34 | Per-physical-model solar sample grid lifetime | implicit cache protocol | positive per-model bounded lifetime; mutable state API hypothesis not promoted |
| R35 | Native target-elevation acceptance lease | implicit authority protocol | source-proven positive separate metadata lease |
| R36 | Catalogue-bound diffuse resource capability and private sampler | implicit resource-admission protocol | positive exact binding and lifetime protections; no new defect |
| R37 | Lunar C/WASM retained kernel state, frame arena and source witness | implicit exclusive resource protocol | source-proven retained-state domain added; positive caller ordering; resource-pressure/standalone-reuse risks qualified, no new native defect proved |

### Cross-system coupling map

#### Sky completion to displayed DOM

R15 snapshot → R01 identity/epoch → R02 queue → R05 RPC → R06/R09 engine → R10 accepted result → R11 decoded mask commit → R10 painted lease

Acceptance is not publication; all asynchronous boundaries retain the original snapshot identity and UTC, and publication jointly commits background/mask/detail effects.

#### Head, preview and refined ownership

R14 head lease → R12 preview transaction, with R13 independent catalogue revision; R04 assets boot R10 refined host

Shared card classes, solar mask and lunar-detail ownership must move together. Refined withdrawal triggers preview recovery in the same turn; invalid or undecoded replacement must not publish.

#### Lunar execution and cancellation

R19 pending/accepted/presentation → R20 worker lifecycle → R23 newest-job pump → R28 refinement → R25 pool join → R24 shard RPC → R26 exclusive engine → R37 retained C/WASM instance

One engine executes at a time. Cancellation tokens, row coverage and all-settled join prevent mixed-scene or partial-row output from being accepted; outer native deadlines own uncooperative worker termination.

#### Lunar detail publication

R30 initial receiver/R21 one-shot head and R19 refined surface → R29 projection/detail → R10/R12 composition

Projection geometry reuse cannot grant stale surface authority. Runtime disposal must target its own lexical resource. RF01 violates this ownership on full wrapper replacement.

#### Asset and resource lifetime

R03/R04 native pack; R07 diffuse store → R36 bound capability → R09; R22 offline transport → R20/R23/R26/R37

Admitted resource identity and generation are separate from old retained bytes; abort/disposal must remove authority and clean owned provisional resources. RF02 exposes a construction-before-owner gap.

#### Memoization boundaries

R16 geometry; R17 private preview preparation; R18 encoding; R32 bounded photometry; R33 weak atmosphere; R34 per-model solar; R31 module spectral fitting

Geometry-only, immutable, weak or bounded retention preserves lifetime boundaries. R31 is the exceptional uncapped strong fit map reached by continuous current twilight input.

### Complete finding records

#### RF01 — Repeat lunar runtime installation disposes the newly published detail renderer

**Exact source evidence**

- `moon/src/moon-native.mjs:1–6` — `new detail assignment precedes old runtime.dispose`.
- `moon/src/moon-native.mjs:273–273` — `dispose dynamically dereferences window.SalahMoonDetail`.
- `moon/src/moon-detail.mjs:67–67` — `compose refuses disposed renderer`.
- `moon/src/moon-detail.mjs:136–140` — `adopt lacks disposed guard; dispose retires tables/canvas`.
- `tools/build_moon.py:129–130` — `fresh wrapper versus refinement source-only install`.

**Concrete event schedule**

1. Existing runtimeA owns detailA.
2. Wrapper is evaluated again: line1 disposesA and assigns live detailB.
3. Line6 invokes runtimeA.dispose; its closure runs clear and line273 disposes current global detailB.
4. Wrapper installs runtimeB; detailB remains disposed. Later adoption can rebuild tables on a disposed object, while compose still refuses to paint.

**Category:** Correctness / Bugs; Architecture / Tech Debt

**Impact:** Supported-looking replacement preamble yields a runtime paired with a retired detail owner; later detail drawing cannot proceed. Conditional on repeated wrapper installation. Ordinary first boot and installWorkerSource refinement are not affected by this ordering schedule.

**Effort:** small source fix; medium targeted lifecycle verification

**Risk:** medium correctness under replacement; no demonstrated fresh-boot/user-flicker impact

**Confidence:** high for ownership schedule; occurrence frequency unknown

**Fix sketch / route:** DMAIC: capture detail as a lexical resource owned by its runtime; dispose old runtime before constructing/publishing replacement detail, or construct a complete replacement pair and atomically publish it after old captured resources retire. Ensure dispose/adopt terminal semantics agree.

**Repair class:** product-or-skill defect

**Owner / source:** moon/src/moon-native.mjs lifecycle owner and moon/src/moon-detail.mjs; regenerate host through tools/build_moon.py after an authorized fix

**Acceptance:**

- Two consecutive full installations leave exactly one live detail+runtime pair.
- Calling old runtime.dispose again cannot clear/dispose replacement resources.
- Ordinary worker retry preserves/replaces only worker resources and keeps live detail.
- Failure during replacement construction leaves a documented recoverable owner rather than an orphan.

**Verification:** Exact current wrapper VM probe evaluated twice with timers deferred, DOM/resource stubs only: both old and new detail disposed, new runtime assigned. Store result runtimeReplacement. Future repair test should use actual detail with mocked DOM plus native replacement capture if that path is shipped.

**Rollback / plan closure:** No fix applied. An authorized repair must remain scoped to authored owners, regenerate derived files, rerun lifecycle and first-paint/handoff regressions, and retain previous known artifact for rollback. This finding and lane FINAL do not authorize implementation or close any plan.

**Disposition:** tested source defect in conditional replacement schedule; report to root

**Remaining risk:** Native visual manifestation and frequency are unknown. Build-time duplicate guards exist; incremental normal refinement only calls installWorkerSource, explicitly narrowing reachability.

#### RF02 — Native-sky construction inserts a canvas before establishing a cleanup owner

**Exact source evidence**

- `real-sky/native-host.mjs:60–67` — `startNativeSky provisional DOM allocation`.
- `real-sky/native-host.mjs:231–234` — `successful runtime cleanup/publication`.
- `real-sky/native-assets.mjs:38–41` — `reset disposes only registered runtime`.

**Concrete event schedule**

1. Asset generation loads valid pack and calls startNativeSky.
2. Canvas is prepended at line63; getContext returnsnull at line64, causing throw before global runtime assignment.
3. Loader reports unavailable; reset/retry can dispose only window.SalahRealSky, which never owned provisional canvas.
4. Second attempt repeats; two orphan .real-sky-canvas nodes remain.

**Category:** Correctness / Bugs; Architecture / Tech Debt; Performance / Scale

**Impact:** Capability/context-allocation failure leaves DOM resources across retries. A later recovery can coexist with stale nodes and first-selector assumptions, increasing resource pressure and making ownership ambiguous. Only orphan-node effect was directly tested; later browser paint impact remains conditional.

**Effort:** small transactional construction cleanup; targeted failure-path tests

**Risk:** medium recovery/resource-custody risk; browser occurrence unknown

**Confidence:** high for exact source schedule and orphan count

**Fix sketch / route:** DMAIC: acquire fallible offscreen/context resources before DOM insertion when possible; otherwise establish local rollback immediately and remove all provisional nodes/URLs/timers on constructor failure. Publish global runtime only after construction is complete.

**Repair class:** product-or-skill defect

**Owner / source:** real-sky/native-host.mjs plus reset contract in real-sky/native-assets.mjs; regenerate derived native entry/bundles via canonical builder

**Acceptance:**

- Failure of first canvas context leaves no inserted unowned canvas/badge.
- Failure at each subsequent resource boundary releases already allocated resources exactly once.
- Repeated failure→successful retry yields one registered canvas owner and no stale selector target.
- Loader unavailable/preview fallback semantics remain truthful.

**Verification:** Actual imported startNativeSky called twice with stubbed unavailable2D context: two orphan canvases, no registered runtime. Existing native-assets corrupt-start test proves unavailable state but does not exercise partial DOM rollback.

**Rollback / plan closure:** No source mutation. Authorized fix needs narrow constructor-failure probe plus existing host/asset/preview handoff suites; restore prior generated artifact if a regression occurs. No closure granted by report.

**Disposition:** tested source defect under injected context failure; report to root

**Remaining risk:** Probe is synthetic capability failure, not actual context-loss/native browser reproduction. Possible later-selector/visual consequence remains untested.

#### RF03 — Time-varying twilight B–V values grow an unbounded fitted-spectrum cache

**Exact source evidence**

- `real-sky/core/src/spectral.mjs:9–23` — `sfFitCache unbounded insertion`.
- `real-sky/core/src/spectral.mjs:30–41` — `outer selection cache separately capped12000`.
- `real-sky/core/src/sky-background.mjs:29–33` — `continuous patatTwilight B–V`.
- `real-sky/core/src/sky-background.mjs:75–76` — `actual physical model selects twilight spectrum`.
- `real-sky/native-preview.mjs:334–336` — `actual preview selects total twilight B–V`.

**Concrete event schedule**

1. Long-lived module receives changing accepted solar altitude in twilight.
2. createSkyModel computes residual twilight B–V; nativeAtmosphereFields independently computes total B−V at clamped altitude.
3. An unseen admissible exact floating-point colour misses outer cache and sfFitColour stores a95-sample fit permanently.
4. After12000 outer entries, new colours continue entering sfFitCache. Asset/runtime retry in same UI realm does not clear this module map.

**Category:** Performance / Scale; Architecture / Tech Debt

**Impact:** Strong retained fit data grows with distinct colour inputs instead of a bounded working set. Continuous pinned twilight callers make the input space production-reachable. This is a source-proven unbounded-retention design, not a measured production leak, heap budget failure or latency diagnosis.

**Effort:** small bounded exact memo policy; medium numerical/regression verification

**Risk:** medium long-session resource risk; actual time/rate-to-pressure unknown

**Confidence:** high for unbounded retention and pinned call reachability; unmeasured user impact

**Fix sketch / route:** DMAIC: bound or evict the fit cache while preserving exact spectrum computation; consider a separate uncached path for continuous twilight inputs. Avoid quantizing B−V without an explicitly reviewed scientific/display change. Follow owning Horizon-source route for copied core code and regenerate canonical native outputs.

**Repair class:** product-or-skill defect

**Owner / source:** canonical Horizon source of real-sky/core/src/spectral.mjs per AGENTS.md; native preview caller real-sky/native-preview.mjs; no direct generated-core repair in this audit

**Acceptance:**

- More than12000 distinct admissible colours never exceed declared fit retention bound.
- A fixed input returns byte/numerically identical spectrum before/after eviction and across current oracle edges.
- Actual pinned residual and total twilight colour paths show bounded retention over simulated continuous altitude history.
- Worker recreation/document reload and same-realm asset retries have documented resource custody.

**Verification:** Generic exact algorithm probe:12020 valid colours→12020 fit entries versus12000 outer. Reachability probe uses actual pinned patatTwilight and native preview expression at1000 altitudes:2000 distinct colours,1989 admissible fitted colours retained. Initial expectation that all colours fit was rejected and corrected to count actual fit outcomes;11 fallbacks are intentional. No heap or native runtime metric.

**Rollback / plan closure:** No source edit. Authorized upstream fix requires exact numerical parity, capacity adversarial test and regeneration review. Roll back upstream/canonical artifact together if spectra or timing regress. This report is not performance certification or plan closure.

**Disposition:** tested retention counterexample plus pinned native-source reachability; report to root

**Remaining risk:** Memory bytes per entry, duplicate UI/worker retained costs, native long-session pattern and GC behavior remain unmeasured. Cache saturation also stops outer caching, but no measured CPU regression claimed.

#### RF04 — Frozen-scene mask decode has no intrinsic wall-clock settlement bound

**Exact source evidence**

- `real-sky/native-composition.mjs:45–68` — `pending decode exclusivity and cancellation`.
- `real-sky/native-preview-host.mjs:108–151` — `pending currentness/age cancellation`.
- `real-sky/native-host.mjs:131–185` — `pending composition guard`.

**Concrete event schedule**

1. Accept a valid snapshot with timeScale0 and unchanged generation/scene.
2. Start a changed mask whose browser Image.decode promise never settles.
3. Further publish opportunities returnfalse while pending.
4. Accepted UTC does not age, so normal stale-scene/age guard does not itself cancel; only external invalidation/disposal may recover.

**Category:** Correctness / Bugs; Tests / Validation

**Impact:** Conditional loss of future optional mask/background publication if browser decode never settles. Existing safety remains intact: undecoded pixels are not committed and current previously displayed owner may be retained.

**Effort:** unknown until discriminator; small deadline policy if required

**Risk:** unproven native liveness risk, not active severity finding

**Confidence:** high absence of internal deadline; low evidence of real nonsettling decode

**Fix sketch / route:** dispatch-review/deferred: first determine browser decode settlement guarantee or reproduce a native stall with a pinned image. If a product deadline is required, add wall-clock cancellation with truthful fallback/retry and tests for late settlement; do not bypass decode-before-publish.

**Repair class:** instrument-acceptance defect

**Owner / source:** real-sky/native-composition.mjs NativeSolarMaskPublication and host accepted-age policy

**Acceptance:**

- Discriminator either establishes bounded platform settlement or native stuck decode schedule.
- If a deadline is added, frozen-scene stall releases pending without publishing late stale context.
- Keep at most one active decode; do not introduce cancellation on every animation frame.

**Verification:** Static source and existing tests establish one pending decode, guarded completion and age cancellation. No new never-settling browser probe and no native stalled decode observed. Repeated replacement-starvation lead rejected by line46.

**Rollback / plan closure:** No production change proposed until discrimination; keep this open/unconfirmed rather than closing native liveness from mocked Promise flags. Any later approved deadline change must preserve currentness and decode tests.

**Disposition:** conditional hypothesis / decision-changing native discriminator required

**Remaining risk:** Platform may guarantee timely resolve/reject for generated local data URLs, making schedule unreachable in practice. Frozen UTC with actual browser decoder hang has not been established.

### Complete per-machine audit records

#### R01 — Native sky snapshot identity, epoch, freshness and throughput admission

**Nature:** partly explicit

**Exact source anchors:**

- `real-sky/native-lifecycle.mjs:9–93` — `NativeSkyLifecycle`.
- `real-sky/native-contract.mjs:3–25` — `nativeIdentity/nativeJob/nativeResultCurrent`.

**Retained state:** epoch; observed wall/monotonic clock; identity; latest/pending/displayed jobs; lastSubmit; duration WeakMap; disposed; availability.

**States:** unobserved; pending; ready/current; paused; invalidated; rate-throughput unavailable; disposed.

**Events / transitions / guards / effects:**

- observe validates snapshot; identity, pause, clock discontinuity bump epoch and revoke display.
- request coalesces same pending UTC, throttles by rate, clones through queue; forced request does not duplicate identical pending work.
- result requires matching latest job, epoch, identity, UTC age <=30000ms and ready raster; slow fast-clock result records throughput unavailability.
- display expiry withdraws display without bumping epoch, preserving a separately submitted fresh refresh.

**Invariants:**

- An accepted completion cannot regain authority after A→B→A because epoch is separate from identity.
- Paint age comes from original job UTC; failure or newly accepted work cannot rejuvenate older displayed pixels.

**Cancellation, errors, recovery and termination:** Invalid/paused input withdraws; current request failure invokes current error path only; disposal invalidates and disposes queue. Queue execution settlement is externally bounded by worker client.

**Dependencies:** R02 queue; R05 client; R10 actual DOM publication; native host snapshot owner R15.

**Per-machine audit outcome:** source-proven positive protection; no new defect in this domain.

**Relevant test evidence:**

- tests/real-sky/native-lifecycle.test.mjs:13–30
- tests/real-sky/native-rate-availability.test.mjs:12–50
- parent aggregate275 existing renderer cases PASS

**Uncovered edge / remaining risk:** Epoch/clock/currentness correctness inspected and exercised by existing mocks. Native event-loop stalls and high-rate visible continuity require native capture, not flags.

#### R02 — Latest-only serialized render queue

**Nature:** explicit

**Exact source anchors:**

- `real-sky/core/src/latest-render-queue.mjs:1–31` — `LatestRenderQueue`.

**Retained state:** next sequence; busy flag; one pending slot holding cloned request plus promise resolvers; disposed.

**States:** idle; executing; executing plus newest pending; disposed.

**Events / transitions / guards / effects:**

- submit increments sequence and resolves replaced pending work as superseded; structuredClone establishes input ownership.
- drain executes one item; publish only latest sequence and not disposed.
- finally clears busy and drains newest pending even after rejection.
- dispose invalidates generation and resolves queued item; active item completes without publication.

**Invariants:**

- At most one active execution and one queued replacement.
- Late success/error cannot publish after a newer submission.
- Every ordinary execution path releases busy in finally.

**Cancellation, errors, recovery and termination:** Executor errors reject the matching promise; callbacks participate in error path. Active uncooperative executor cannot be forcibly canceled by this generic queue; owner client deadlines supply liveness.

**Dependencies:** R01; R05.

**Per-machine audit outcome:** source-proven positive serialization; callback-throw/unbounded arbitrary executor lead not promoted.

**Relevant test evidence:**

- tests/real-sky/native-rate-availability.test.mjs:28,50 exercise coalescing/reload disposal
- tests/real-sky/native-lifecycle.test.mjs:18–19 stale completion/error schedules

**Uncovered edge / remaining risk:** Arbitrary onError throwing could escape normal promise settlement, but production callbacks inspected did not establish that schedule; generic API contract remains worth documenting.

#### R03 — Native asset loader generation, timeout, suspension and retry

**Nature:** explicit

**Exact source anchors:**

- `real-sky/native-assets.mjs:4–33` — `NativeAssetLoader`.

**Retained state:** generation; AbortController; timeout; disposed/suspended flags; state; reset/load/start hooks.

**States:** idle; loading; ready; unavailable; suspended; disposed.

**Events / transitions / guards / effects:**

- retry aborts prior generation, resets renderer, races load against bounded timeout.
- load resolution checks generation/disposal/suspension before start and ready.
- suspend increments generation before abort; resume retries once from suspension.
- dispose revokes pending and is terminal.

**Invariants:**

- Late A completion/rejection cannot overwrite B.
- No timed-out load may invoke start.
- Timeout value bounded1..120000ms; default15000ms.

**Cancellation, errors, recovery and termination:** Error becomes explicit unavailable; retry is authorized recovery; timers/controller cleared in finally. Hooks do not automatically roll back side effects of a partly executed start.

**Dependencies:** R04 script transport; R10 host construction.

**Per-machine audit outcome:** positive generation/timeout protections; caller construction rollback gap RF02; findings RF02.

**Relevant test evidence:**

- tests/real-sky/native-assets.test.mjs:6–12
- tests/real-sky/cp9-page-lifecycle.test.mjs:6–9

**Uncovered edge / remaining risk:** Corrupt-start test proves no false-ready state, not cleanup of DOM allocated before a throw. See RF02.

#### R04 — Native asset script, inline pack and page lifecycle ownership

**Nature:** implicit

**Exact source anchors:**

- `real-sky/native-assets.mjs:38–77` — `startNativeSkyAssets`.

**Retained state:** initial inline pack captured once; loader; badge; current script handlers/element; pagehide/pageshow listeners; deferred two-frame start.

**States:** inline retained; script loading; pack admitted; renderer started; page suspended; resuming; disposed.

**Events / transitions / guards / effects:**

- entry consumes/deletes global pack; loader reset disposes registered runtime, resets frame, requests preview catalogue reset.
- each generation owns a fresh script URL; onload consumes pack and removes handlers/element; abort rejects.
- successful load starts independent preview catalogue admission and refined runtime.
- pagehide suspends; persisted pageshow resumes; dispose removes listeners and deferred frames.

**Invariants:**

- Per-generation element identity/abort limits stale script callbacks.
- Page suspension revokes deferred startup before it can construct a renderer.
- Bootstrap preview is an independent availability owner.

**Cancellation, errors, recovery and termination:** Network/script/pack errors become loader unavailable. Retry refetches pinned local script; no source substitution. Only registered runtime is reset, leaving RF02 provisional DOM outside custody.

**Dependencies:** R03; R13; R14; R10.

**Per-machine audit outcome:** source-proven ownership map; construction gap RF02; stale identical global pack not established as content corruption; findings RF02.

**Relevant test evidence:**

- tests/real-sky/native-assets.test.mjs:14–21
- tests/real-sky/cp9-page-lifecycle.test.mjs:9
- tests/real-sky/native-preview-host.test.mjs:258–270

**Uncovered edge / remaining risk:** Browser script execution after element removal may assign a global pinned pack; all generations fetch identical pinned bytes, so semantic stale-target publication was not proved.

#### R05 — Reference worker client boot, RPC deadlines and fallback mode

**Nature:** partly explicit

**Exact source anchors:**

- `real-sky/core/src/reference-worker-client.mjs:1–53` — `ReferenceRenderClient`.
- `real-sky/native-worker-policy.mjs:1–7` — `requireNativeWorker`.

**Retained state:** worker; ready promise/resolver; boot timer; serial; pendingMap; mode; warnings; lazy fallback; disposed.

**States:** booting; worker ready; worker request pending; fallback; failed/native unavailable; disposed.

**Events / transitions / guards / effects:**

- construction creates worker, installs listeners, posts boot and starts timeout.
- ready settles gate; render waits for ready, checks disposal and limits native worker pending requests.
- response id resolves exactly one pending request and clears timer.
- fatal/startup/error/render timeout fails pending work, terminates worker and transitions fallback.
- native fallback factory throws, preserving UI responsiveness instead of synchronous physical rendering.

**Invariants:**

- Ready promise settles on boot success, failure and disposal.
- Pending RPCs are rejected and timers cleared when worker is abandoned.
- Native worker loss does not cause hidden main-thread physics.

**Cancellation, errors, recovery and termination:** Reference fallback can lazily render after one task yield; native remains unavailable until outer asset/runtime retry. Dispose terminates and rejects all pending promises; no in-place worker recreation.

**Dependencies:** R06; R09; R03 restart.

**Per-machine audit outcome:** source-proven positive lifetime and deadline fences; no new defect.

**Relevant test evidence:**

- tests/real-sky/cp9-worker-policy.test.mjs:4–5
- tests/real-sky/native-host-composition.test.mjs:129 failure retention

**Uncovered edge / remaining risk:** Warnings lack a general cap but this instance normally transitions away from its worker once. Duplicate post-failure callbacks were not shown to yield product-scale growth.

#### R06 — Sky worker boot, engine ownership and transferable raster response

**Nature:** implicit

**Exact source anchors:**

- `real-sky/native-worker.js:1773–1774` — `nativeWorkerEngine/self.onmessage`.
- `tools/build_native.py:29–31` — `native worker wrapper generation`.
- `real-sky/core/src/reference-engine.mjs:38–44` — `rasterTransferables`.

**Retained state:** module-scoped engine; message id; active async render continuation; per-result transfer list seenSet.

**States:** unbooted; booted; rendering; result/error posted; realm terminated.

**Events / transitions / guards / effects:**

- boot creates engine and posts ready.
- render awaits engine.render and returns id-bound result or error.
- result transfer walker emits each ArrayBuffer only once despite aliased typed arrays.
- unhandled rejection posts fatal; owning client terminates realm on failure.

**Invariants:**

- Caller queue/client supply single execution; worker wrapper itself is not a concurrent job scheduler.
- Transferred raster buffers are retired from worker ownership after response; metadata is cloned.

**Cancellation, errors, recovery and termination:** Errors remain explicit. Termination and restart belong to R05/R03; direct duplicate boot or parallel unsolicited messages are outside the shipped client protocol.

**Dependencies:** R02; R05; R09.

**Per-machine audit outcome:** positive trusted-protocol coupling; duplicate-boot/parallel-message lead rejected for shipped caller.

**Relevant test evidence:**

- tests/real-sky/native-engine.test.mjs
- tests/real-sky/native-worker-lunar-display.test.mjs
- tests/real-sky/cp9-worker-policy.test.mjs

**Uncovered edge / remaining risk:** Directly exporting this wrapper as a general multi-caller worker would require its own admission/boot idempotence; that use is not established here.

#### R07 — Diffuse asset admission, cancellation and content cache

**Nature:** partly explicit

**Exact source anchors:**

- `real-sky/core/src/diffuse-assets.mjs:14–69` — `parseDiffuseManifest/DiffuseAssetStore/readBoundedUTF8`.

**Retained state:** immutable manifest/catalogue; exact catalogue text; three-entry hash-key cache; serial; abortcontroller; state; disposed.

**States:** idle; loading with binding revoked; ready; superseded; unavailable; disposed.

**Events / transitions / guards / effects:**

- load advances generation and aborts prior read, immediately removes current binding authority.
- reload removes matching hash cache; misses bounded-read and verify exact bytes/hash/schema/grid/id before binding.
- generation checked after read and before cache/state publication.
- failure publishes unavailable only for current generation; disposal aborts/clears text/cache and revokes state.

**Invariants:**

- At most the three pinned manifest asset hashes retained.
- Wrong catalogue, grid or bytes cannot create a registered binding.
- Old loader failure cannot remove new ready binding.

**Cancellation, errors, recovery and termination:** Ordinary later load retries unavailable; explicit reload evicts good cached tier; DOM/native timeout is supplied by outer client/loader.

**Dependencies:** R36 capability; R09.

**Per-machine audit outcome:** source-proven positive resource custody; no new defect.

**Relevant test evidence:**

- tests/real-sky/native-engine.test.mjs exercises unavailable metadata/native tier
- tests/real-sky/native-assets.test.mjs covers outer failure/retry, not every store interleaving

**Uncovered edge / remaining risk:** No new store-specific adversarial probe run in this lane; manifest trust is a pin/provenance boundary, not authenticity from a hash alone.

#### R08 — Sky catalogue replacement generation and last-result authority

**Nature:** explicit

**Exact source anchors:**

- `real-sky/core/src/scene.mjs:11–21` — `SkyController`.

**Retained state:** validated catalogue; generation; last; error.

**States:** unavailable; replacement pending; ready catalogue; projection ready/error.

**Events / transitions / guards / effects:**

- replaceAsync increments generation, clears catalogue/last before await.
- success validates catalogue then checks generation; stale failure ignored.
- clear increments generation and removes catalogue/last.
- update computes fresh projection from current observer or unavailable result.

**Invariants:**

- A→B→A ordering cannot restore an old async load.
- Failure is empty sources, never a fictional sky.
- last is diagnostic current computation, not a stale frame fallback.

**Cancellation, errors, recovery and termination:** New replacement is recovery; invalid projection yields unavailable; no own time scheduler or disposal needed beyond owner lifetime.

**Dependencies:** R09 PhysicalSkyBridge.

**Per-machine audit outcome:** source-proven positive authority fence.

**Relevant test evidence:**

- tests/real-sky/native-engine.test.mjs integration; no isolated SkyController schedule test observed among supplied native suites

**Uncovered edge / remaining risk:** Synchronous validation of a late large catalogue still costs CPU before its generation guard; no magnitude/production trace established.

#### R09 — Engine binding selection, load keys and declared physical fallback

**Nature:** implicit

**Exact source anchors:**

- `real-sky/native-engine.mjs:8–27` — `NativeSkyEngine`.
- `real-sky/core/src/reference-engine.mjs:7–35` — `ReferenceSkyEngine`.
- `real-sky/core/integration/resilient-sky-bridge.mjs:7–18` — `ResilientPhysicalSkyBridge`.
- `real-sky/core/integration/physical-sky-bridge.mjs:5–18` — `PhysicalSkyBridge`.

**Retained state:** native pack/loaded flag/store/bridge; reference loadKey+disposed; resilient base bridge plus binding→bridge WeakMap and last diagnostics.

**States:** assets not attempted; registered diffuse ready; declared CP6 fallback; disabled diffuse; disposed.

**Events / transitions / guards / effects:**

- native loads requested embedded tier once; failed asset still marks attempt complete.
- reference reloads on changed tier/fault/revision OR non-ready store; failure is retryable next render.
- resilient chooses only current ready binding, otherwise computes a new CP6 frame at accepted observer and labels fallback.
- native requires cloudTransmission1/cloudGlow0; deep-night decomposition executes in worker.

**Invariants:**

- Asset failure cannot relabel invalid observer/physics as valid.
- Fallback recomputes current physical state; bridge.last does not serve old pixels.
- Native foreground owns cloud attenuation exactly once.

**Cancellation, errors, recovery and termination:** Native failed embedded tier remains fallback until full pack/runtime retry; deliberate immutable-pack policy, not claimed automatic in-engine recovery. Reference retries unavailable. Dispose clears pack/store/last; weak bridge entries can die with binding.

**Dependencies:** R07; R08; R36; R03 retry; R10 foreground.

**Per-machine audit outcome:** positive declared fallback; native sticky-attempt lead rejected by immutable pack/restart design.

**Relevant test evidence:**

- tests/real-sky/native-engine.test.mjs
- tests/real-sky/native-worker-lunar-display.test.mjs
- tests/real-sky/native-preservation.test.mjs

**Uncovered edge / remaining risk:** Runtime injection of repaired assetTexts into a previously attempted native engine is unsupported; supporting it would require a new revision protocol.

#### R10 — Refined sky construction, accepted frame, displayed frame and DOM commit

**Nature:** implicit

**Exact source anchors:**

- `real-sky/native-host.mjs:60–234` — `startNativeSky/clear/publishPrepared/compose/accept/dispose`.
- `real-sky/native-composition.mjs:108–167` — `NativeForegroundCapture/sameNativePresentation`.

**Retained state:** inserted canvas/badge; frame/job vs paintedFrame/paintedJob; pendingJob; last exact foreground capture/mask/rows; decoded publication; RAF/interval/client/workerURL.

**States:** constructing; waiting; accepted but not displayed; mask decode pending; displayed current; retaining old displayed; withdrawn to preview; disposed.

**Events / transitions / guards / effects:**

- construction disposes old owner then allocates DOM before runtime is registered.
- accept stores validated current result; worker-native deep-night preparation required.
- compose captures fresh native foreground; exact same-frame/rows/maskKey/full-byte equality may skip redraw.
- publish checks captured job/frame identity/currentness before and after fallible lunar detail, then commits pixels/mask/class and painted provenance.
- failure may retain only original paintedJob if still current; clear withdraws and asks preview update in same turn.

**Invariants:**

- New accepted frame cannot extend old display lease.
- Mask and foreground correspond to one privately captured transaction.
- Shared CSS/mask/detail authority transfers only through currentness checks.
- Intended invariant every inserted DOM resource has a cleanup owner is violated during construction RF02.

**Cancellation, errors, recovery and termination:** Normal dispose clears lifecycle, decoder, RAF/timers/listeners/client/blob URL/canvas/badge/mask. Constructor throw before global registration lacks rollback.

**Dependencies:** R01; R05; R11; R12; R19; R29.

**Per-machine audit outcome:** positive transactional publication; confirmed synthetic constructor ownership gap RF02; findings RF02.

**Relevant test evidence:**

- tests/real-sky/native-host-composition.test.mjs:14–149
- tests/real-sky/cp9-presentation-cache.test.mjs:4–9
- evidence/probes/rendering/protocol-probes.mjs constructorFailure

**Uncovered edge / remaining risk:** Synthetic2D context failure demonstrates unowned nodes; real browser frequency, DOM paint impact and failed offscreen allocation schedules are unmeasured.

#### R11 — Solar cloud mask decode-before-publish transaction

**Nature:** partly explicit

**Exact source anchors:**

- `real-sky/native-composition.mjs:35–68` — `NativeSolarMaskPublication`.

**Retained state:** revision; pending Image candidate; displayed candidate; decoded candidate; disposed; original caller context.

**States:** empty; one pending decode; decoded but not committed; displayed; canceled; disposed.

**Events / transitions / guards / effects:**

- publish refuses when disposed or already pending; cached decoded/displayed and opaque gradient commit synchronously.
- new URL image uses anonymous mode and waits for decode; completion fenced by revision/disposed.
- finish stores decoded, invokes original context callback, and marks displayed only if callback succeeds without revision change.
- cancel increments revision, blanks pending src, drops pending/displayed; dispose additionally retires decoded.

**Invariants:**

- One active decode; later paint opportunities do not replace it.
- Failed/rejected publication cannot become displayed.
- Only constant-size decoded/displayed/pending slots; callback never reads newer transaction as if it were original.

**Cancellation, errors, recovery and termination:** Decode rejection clears pending and invokes caller failure. Caller scene/age invalidation or dispose cancels. No intrinsic wall-clock settlement deadline; frozen accepted UTC can prevent age cancellation.

**Dependencies:** R10; R12.

**Per-machine audit outcome:** positive safety; repeated-replacement starvation rejected; frozen-scene never-settling decode is unconfirmed liveness hypothesis RF04; findings RF04.

**Relevant test evidence:**

- tests/real-sky/native-solar-publication.test.mjs:17–91
- tests/real-sky/native-preview-host.test.mjs:70,90,96
- tests/real-sky/native-host-composition.test.mjs:89–120

**Uncovered edge / remaining risk:** No evidence that shipped browser Image.decode remains pending indefinitely. Native reproduction or platform guarantee is the decision-changing discriminator.

#### R12 — Preview base, pending paint, current display and shared DOM handoff

**Nature:** implicit

**Exact source anchors:**

- `real-sky/native-preview-host.mjs:1–174` — `startNativeSkyPreview/publish/paint/update/present/clear/dispose`.

**Retained state:** value/pendingValue; baseBytes/frame; old moon bounds; RAF/nativeDriven; lastPaint; catalogue revisions; decoder; canvas; status.

**States:** bootstrap/head; preparing; decode pending; preview current; superseded by composed sky; paused/expired; disposed.

**Events / transitions / guards / effects:**

- update captures physical input and geometry before fresh UTC, checks publishability including5ms*rate reserve, and bounds retry to one.
- pending decode is kept while current, canceled on scene/age/headroom expiry; no new candidate replaces active decode.
- publish checks catalogue/currentness before/after lunar detail; only final valid paint retires head and marks preview ready.
- refined ownership cancels pending preview; native present hook takes over scheduling and cancels independent RAF.
- clear removes preview-owned mask/detail and retirement style as ownership permits; failures retain only original current preview/head.

**Invariants:**

- Prepared or decoded candidate is not yet a visible-ready owner.
- Bootstrap fallback remains independently valid after optional pack failure.
- Preview/refined paths must never simultaneously claim composed pixels; detail original owner preserved on handoff.

**Cancellation, errors, recovery and termination:** Invalid/paused/expired preview withdraws; fresh update can recover. dispose removes loop/canvas/class. Explicit standalone dispose does not itself remove CSS mask/detail; normal shipped teardown/handoff callers clear ownership, so unproven separate API use not promoted.

**Dependencies:** R11; R13; R14; R15; R29.

**Per-machine audit outcome:** positive currentness/handoff controls; no new reproduced defect.

**Relevant test evidence:**

- tests/real-sky/native-preview-host.test.mjs:41–270
- tests/real-sky/native-startup-handoff.test.cjs
- tests/real-sky/native-head-handoff.cjs

**Uncovered edge / remaining risk:** Shared DOM ownership remains distributed across flags and global closures. Native sun flicker needs frame/class/mask trace and pixel capture; mocks do not establish visibility continuity.

#### R13 — Asynchronous preview catalogue admission revision

**Nature:** implicit

**Exact source anchors:**

- `real-sky/native-preview-host.mjs:159–171` — `admitCatalogue`.
- `real-sky/native-star-preview.mjs:1–43` — `native preview catalogue validation/admission`.

**Retained state:** catalogue; bootstrap identity; catalogueRevision; request generation; pending validation continuation.

**States:** bootstrap; validation pending; admitted replacement; failed/retained bootstrap; disposed/revoked.

**Events / transitions / guards / effects:**

- request advances generation and validates pack asynchronously on a separate task.
- completion checks request generation/disposal before adopting revision.
- admitted revision invalidates prepared candidate; each publish compares original revision.
- null reset restores bootstrap only when identity differs.

**Invariants:**

- Late catalogue A cannot repaint after B/reset/dispose.
- Hash/schema failure cannot publish claimed identity.
- Repeated unchanged bootstrap reset avoids pointless rebuild.

**Cancellation, errors, recovery and termination:** Validation failure leaves valid bootstrap authority; later valid request can recover. Async CPU validation itself cannot be aborted mid-computation.

**Dependencies:** R04; R12; R17.

**Per-machine audit outcome:** source-proven positive stale catalogue fence.

**Relevant test evidence:**

- tests/real-sky/native-preview-host.test.mjs:177–205,258–270
- tests/real-sky/native-star-preview.test.mjs

**Uncovered edge / remaining risk:** No large malicious catalogue execution-time claim; size/hash admission is source-bound, not a calibrated native responsiveness measurement.

#### R14 — Document head background and initial lunar CSS lease

**Nature:** implicit

**Exact source anchors:**

- `real-sky/native-first-paint.mjs:1–49` — `initial ordinary-clock background owner`.
- `moon/src/moon-first-paint.mjs:6–60` — `nativeInitialMoonHead/compose/background rule`.
- `real-sky/native-preview-host.mjs:37–86` — `head retention/retirement`.

**Retained state:** SalahFirstPaint object with native snapshot, bootstrap frame, optional lunar result; style element/rule; retirement flag via removal; current closure.

**States:** ineligible simulation; eligible head candidate; head CSS displayed; preview replaces; expired/revoked.

**Events / transitions / guards / effects:**

- ordinary clock entry creates sharedconfig UTC/perf snapshot and bootstrap stars/sky before full runtime.
- optional initial lunar head uses actual opacity, canonical profile and exact admitted receiver.
- failed first preview retains only still-current unpaused head; successful preview retires its style/global lease.
- initial lunar result has separate one-shot adoption/retirement R21.

**Invariants:**

- Head must not adopt reference/simulated authority.
- Failed later scene must not resurrect expired startup CSS.
- First lunar opaque coverage and atmospheric foreground use same join contract as later detail.

**Cancellation, errors, recovery and termination:** Invalid assets/head generation records initial error instead of fabricating refined readiness; later bootstrap/runtime can recover. Document teardown ends lease.

**Dependencies:** R12; R21; R30; R15.

**Per-machine audit outcome:** positive startup lease and handoff; no new defect.

**Relevant test evidence:**

- tests/real-sky/native-first-paint.test.mjs
- tests/real-sky/native-celestial-startup.test.mjs
- tests/real-sky/native-startup-critical-path.test.mjs
- tests/real-sky/moon_build_guard_test.py:77

**Uncovered edge / remaining risk:** Source order/assertions and DOM mocks do not establish first actual browser paint, all native startup sizes, or sun/cloud flicker.

#### R15 — Native snapshot adapter and single paint-hook installation

**Nature:** implicit

**Exact source anchors:**

- `real-sky/native-host-hooks.js:5–65` — `SalahNativeSkyHost/capture/notify/QA wrapper`.

**Retained state:** frozen adapter methods; native-owned config/time/weather/generation; injected callable hook; QA wrapper original function.

**States:** installed; capturing current snapshot; native-driven preview; document hidden/paused.

**Events / transitions / guards / effects:**

- capture validates and copies current native state; geometry optional to avoid repeated layout and lunar texture work on identity checks.
- notify requests refined work; native paint calls preview.present so independent preview RAF retires.
- QA wraps existing diagnostic owner and may read lunar runtime state getter.

**Invariants:**

- Native remains sole phase/time/weather/observer owner; renderer adapter introduces no second physical clock.
- No duplicate synchronous preview paint in notify.
- Status reads are not proof of actual presented pixels.

**Cancellation, errors, recovery and termination:** Bad capture is rejected by downstream owners; document/runtime owns hook lifetime. Methods are global only within the native document.

**Dependencies:** R01; R12; R19; R35.

**Per-machine audit outcome:** source-proven positive authority boundary; diagnostic getter side effect documented.

**Relevant test evidence:**

- tests/real-sky/cp9-ownership-age.test.mjs
- tests/real-sky/native-contract.test.mjs
- tests/real-sky/native-preview-host.test.mjs:170

**Uncovered edge / remaining risk:** Lunar state getter can adopt pending initial preview, so diagnostics are not perfectly observational; production correctness still publication-fenced. No independent bug demonstrated.

#### R16 — Bounded camera geometry and lunar sampling geometry memoization

**Nature:** implicit cache protocol

**Exact source anchors:**

- `real-sky/native-preview.mjs:17–31` — `displayGeometryCache/displayGeometry`.
- `real-sky/native-preview.mjs:362–382` — `lunarGeometryCache/native lunar geometry`.

**Retained state:** two separately bounded four-entry FIFO maps; exact camera/grid keys; private rays/scales/readiness and direction/vector arrays.

**States:** missing geometry; lazy cells uncomputed; computed cell hit; map capacity reached/oldest eviction.

**Events / transitions / guards / effects:**

- cache only supported bounded native camera/raster geometries; unsupported shapes compute directly.
- exact camera/grid key hit reuses geometry; missing entries initialize lazy cells.
- insertion at capacity evicts oldest, not arbitrary current physical values.

**Invariants:**

- No physical UTC, weather, illumination, exposure or admitted frame retained in these geometry caches.
- Each map capacity4; lunar admitted grid bounded to68 steps.
- Camera/geometry key changes force new geometry.

**Cancellation, errors, recovery and termination:** No async/cancellation. Invalid geometry rejected upstream; realm termination releases maps; old entries FIFO evicted.

**Dependencies:** R12 fields; R10 worker-native decomposition; R34 current model.

**Per-machine audit outcome:** positive bounded geometry-only reuse.

**Relevant test evidence:**

- tests/real-sky/native-preview.test.mjs:12–23
- tests/real-sky/native-lunar-cache.test.mjs:26–27 includes eviction-removal mutant
- tests/real-sky/native-lunar-fused.test.mjs

**Uncovered edge / remaining risk:** Bounded count is source/test evidence; total retained native heap and performance benefit not profiled here.

#### R17 — Preview raster private-byte custody and lazy linear fields

**Nature:** implicit cache protocol

**Exact source anchors:**

- `real-sky/native-star-preview.mjs:139–178` — `preparedFields/joinNativePreview/lazy fields/region`.

**Retained state:** WeakMap from raster to copied source bytes/private stellar plane; lazy decoded gas/linear arrays in returned getters; encoded threshold table separately R18.

**States:** validated source copy; encoded-only use; linear field materialized once; raster unreachable.

**Events / transitions / guards / effects:**

- join validates full source arrays including unused tails and takes private copy.
- gas/linear getter lazily decodes only when consumer requests fields, memoized for same returned raster.
- region operations consume current exact foreground transfer; no reused physical frame authority.

**Invariants:**

- Caller mutation of original input bytes cannot silently alter already prepared transaction.
- All source pixels validated, not only currently sampled region.
- Weak keys do not root dead rasters.

**Cancellation, errors, recovery and termination:** Invalid source throws; owner failure path withdraws/retains prior current pixels. Resource lifetime ends with returned raster and dependent closures.

**Dependencies:** R12; R18; R29.

**Per-machine audit outcome:** positive immutable input and lazy allocation custody.

**Relevant test evidence:**

- tests/real-sky/native-star-preview.test.mjs:79–103

**Uncovered edge / remaining risk:** Returned mutable typed arrays are consumer-owned; internal consumers inspected treat admitted planes as immutable. Hostile caller mutation after exposure is not separately guarded.

#### R18 — Exact immutable encoding-table initialization

**Nature:** implicit cache protocol

**Exact source anchors:**

- `real-sky/native-host.mjs:11–48` — `nativeDisplayEncodeCache/encodeNativeDisplay`.
- `real-sky/native-encoding.mjs:1–42` — `nativeEncodingThresholds`.
- `real-sky/native-star-preview.mjs:19–25` — `previewEdges/previewCode`.

**Retained state:** once-built exact thresholds/buckets; native local previous-pixel interval; preview lazy edge table.

**States:** uninitialized; initialized immutable table; per-call interval hit/miss.

**Events / transitions / guards / effects:**

- first encode builds oracle binary64 thresholds/buckets; subsequent pixels search exact interval.
- same-call previous interval may shortcut comparison; changed input validates finite range and searches exact edges.
- no per-frame/scene/UTC colour output memo.

**Invariants:**

- Cache accelerates exact code boundaries rather than approximating physical radiance.
- Per-call stream shortcut cannot leak between frames.
- Bad/overflow inputs still rejected on cache hit paths.

**Cancellation, errors, recovery and termination:** Synchronous; initialization errors propagate; realm lifetime table bounded. No async reentrancy under JS single-threaded module execution.

**Dependencies:** R10; R12; R17; R29.

**Per-machine audit outcome:** positive exactness and bounded initialization; no new defect.

**Relevant test evidence:**

- tests/real-sky/native-host-encoding.test.mjs:14–35
- tests/real-sky/native-host-streams.test.mjs:7–31
- tests/real-sky/native-encoding.test.mjs

**Uncovered edge / remaining risk:** Exact byte equality is not perception, tone-calibration or native performance certification. Module copies in worker/UI retain their own bounded tables.

#### R19 — Lunar host accepted, pending preview and current presentation transaction

**Nature:** implicit

**Exact source anchors:**

- `moon/src/moon-native.mjs:10–142` — `capture/scope/matches/clear/adopt/presentation/poll`.
- `moon/src/moon-native.mjs:198–230` — `worker message admission`.
- `moon/src/moon-precision.mjs:1–27` — `phase budget and nativeCalendarMoonScene`.

**Retained state:** serial/epoch; pending/accepted/waitingPreview; previous clock; referenceScene/profileMode; upper/calendar bytes; textureUp; status; phase threshold.

**States:** no surface; initial presentation; render pending; preview waiting for sky; current accepted preview; refined accepted; withdrawn; disposed.

**Events / transitions / guards / effects:**

- capture derives exact scope from native generation/scene/observer/rate/profile/geometry and validates physical phase.
- scope/clock/pause changes clear and increment epoch+serial; accepted match additionally enforces .0416 device-pixel phase-position budget.
- poll coalesces pending; expired pending phase is canceled; sufficient refined phase quality avoids redundant work.
- worker message requires current worker/id/scope plus matching physical scene; preview may wait until sky ownership admits its presentation.
- adopt builds detail then stores provenance; read-time presentation/surface getters recheck and may adopt waiting initial preview.

**Invariants:**

- No stale accepted phase after seek/A→B→A even between polling ticks.
- Fallback revokes prior surface rather than inventing legacy detail.
- Failure retention uses original accepted geometric lease.
- Accepted/displayed/pending are distinct; final result requires empirical-adaptive quality.

**Cancellation, errors, recovery and termination:** clear cancels worker despite possible postMessage exception; error closes worker and retains only current accepted surface. Timer250ms plus request hooks drive progress. Detail/runtime replacement ownership defect RF01 is outside ordinary worker retry.

**Dependencies:** R20; R21; R23; R28; R29; native phase/geometry owner.

**Per-machine audit outcome:** positive identity/geometric budget fences; confirmed replacement ownership defect RF01; findings RF01.

**Relevant test evidence:**

- tests/real-sky/moon_runtime_identity_test.py:8 source identity paths
- tests/real-sky/native-moon-admission.test.mjs:6–14
- tests/real-sky/moon-worker-fixture.test.mjs:14–20
- evidence/probes/rendering/protocol-probes.mjs runtimeReplacement

**Uncovered edge / remaining risk:** Actual lunar WASM, omitted terrain texture transport, native first-paint visibility and repeated-runtime deployment frequency not executed here.

#### R20 — Lunar runtime installation, worker source, bounded retry and deadlines

**Nature:** partly explicit

**Exact source anchors:**

- `moon/src/moon-native.mjs:1–13` — `detail/runtime bootstrap ordering`.
- `moon/src/moon-native.mjs:51–68` — `closeWorker/failed`.
- `moon/src/moon-native.mjs:180–230` — `start and worker lifecycle`.
- `moon/src/moon-native.mjs:239–280` — `installWorkerSource/retry/dispose/deferred start`.

**Retained state:** worker identity; blob URL; pinned source; ready; source/boot/render timers; startFrame; retryCount; errors capped8; disposed; global detail/runtime bindings.

**States:** waiting source; double-RAF start; booting; ready; request pending; unavailable; retrying <=3; disposed.

**Events / transitions / guards / effects:**

- source install verifies exact UTF8 byte count and SHA; unchanged source is idempotent.
- two RAFs permit initial scene opportunity; explicit retry/disposal revoke defer.
- start owns new worker+URL and120s boot deadline; render owns240s deadline; callbacks require worker===w.
- failure clears worker resources, preserves only current accepted surface, bounds errors; retry max3.
- reinstallation first creates/publishes detail at line1 then disposes old runtime at line6; old dispose line273 dereferences global detail, destroying new owner.

**Invariants:**

- Every abandoned worker/blob URL is retired; old worker callbacks cannot affect replacement.
- Source identity alone cannot be bypassed with a different worker body.
- Installation intended invariant new runtime owns live new detail fails RF01.

**Cancellation, errors, recovery and termination:** retry restarts worker in same wrapper and does not trigger RF01; full wrapper re-evaluation does. Normal dispose closes worker/transport/timers/listener and detail, but uses dynamic global rather than captured owned resource.

**Dependencies:** R19; R22; R23; R29.

**Per-machine audit outcome:** confirmed synthetic replacement bug RF01; positive normal worker retry fences; findings RF01.

**Relevant test evidence:**

- tests/real-sky/moon_runtime_identity_test.py
- tests/real-sky/moon_build_guard_test.py:58–103 protect generated duplicate/build boundaries
- evidence/probes/rendering/protocol-probes.mjs runtimeReplacement

**Uncovered edge / remaining risk:** Build-time duplicate guards reduce likelihood of normal double execution; they do not make runtime replacement ordering correct. No production reinstallation frequency claimed.

#### R21 — One-shot lunar initial-head eligibility and irreversible retirement

**Nature:** implicit

**Exact source anchors:**

- `moon/src/moon-native.mjs:13–13` — `initialHeadEligible`.
- `moon/src/moon-native.mjs:47–50` — `revokeInitialHead/clear`.
- `moon/src/moon-native.mjs:90–121` — `takeInitialHead/initialPresentation`.

**Retained state:** initialHeadEligible; first-paint moon result; stored UTC/perf/generation/profile/receiver provenance; initialError.

**States:** eligible original document; head available; adopted/current; irreversibly revoked; independent initial-render fallback.

**Events / transitions / guards / effects:**

- takeInitialHead only ordinary generation0/rate1/calendar/no reference, matching time/perf continuity and admitted receiver/profile.
- adoption consumes/nulls the head result.
- invalidation/worker failure revokes eligibility and head result; A→B→A cannot regain startup authority.
- when eligible head absent, current initial renderer may independently compute accepted phase and recheck scope.

**Invariants:**

- Startup cached result is a one-shot lease, not a general frame cache.
- Reference mode, simulation and discontinuity cannot re-label startup pixels as current.

**Cancellation, errors, recovery and termination:** Initial errors recorded separately. Revoked head is terminal; current receiver render or refined worker may recover presentation.

**Dependencies:** R14; R19; R30.

**Per-machine audit outcome:** source-proven positive startup retirement.

**Relevant test evidence:**

- tests/real-sky/native-startup-handoff.test.cjs
- tests/real-sky/initial_source_association_test.py
- tests/real-sky/first_complete_scene_test.py

**Uncovered edge / remaining risk:** Native page-cache restore and visibility timing not exercised; one-shot eligibility intentionally sacrifices stale startup reuse after invalidation.

#### R22 — Lunar offline chunk DOM/script transport lease

**Nature:** implicit

**Exact source anchors:**

- `moon/src/moon-native.mjs:143–179` — `offlineTransport`.

**Retained state:** worker pointer; active script element/currentScript; chunk name/index; request timers; embedded inert chunk nodes; stopped state.

**States:** transport idle; chunk requested; script loading; chunk delivered; advancing next task; stopped/error.

**Events / transitions / guards / effects:**

- worker asks exact known asset chunk; host checks ordering/name/index/type/final marker and bounds.
- embedded nodes supply chunks; external script callback requires owning element/currentScript and still-current worker.
- each next chunk scheduled through setTimeout0; stop removes active callback/element/timers.
- inert embedded chunks remain available for bounded worker retry.

**Invariants:**

- Old script completion cannot feed a new worker.
- Out-of-order/malformed data cannot silently concatenate into an accepted scientific asset.
- Transport does not become a source substitution mechanism.

**Cancellation, errors, recovery and termination:** Any transport error reports to worker/host failure; closeWorker invokes stopOffline. Top boot deadline bounds never-settling chunk transport.

**Dependencies:** R20; R23; R26 asset hashes.

**Per-machine audit outcome:** source-proven positive transport identity/cancellation.

**Relevant test evidence:**

- tests/real-sky/moon_runtime_identity_test.py
- tests/real-sky/moon_build_guard_test.py
- tests/real-sky/initial_source_association_test.py

**Uncovered edge / remaining risk:** Large lunar terrain files are not available in this checkout. No full offline load/build/native storage-memory verification claimed.

#### R23 — Lunar top worker boot, newest-job pump and cancellation

**Nature:** implicit

**Exact source anchors:**

- `moon/src/moon-worker.mjs:1–75` — `enginePromise/latest/running/serial/offlineParts/pump/onmessage`.

**Retained state:** enginePromise; latest request; running flag; serial cancellation token; offlinePartsMap; shard mode engine/serial; sourceURL.

**States:** unbooted; waiting chunks/engine; pump idle; running current job; newest replacement queued; canceling; boot failed; terminated.

**Events / transitions / guards / effects:**

- one boot builds exact assets and four-worker pool; duplicate boot rejected.
- render increments serial, replaces latest, schedules pool cancel and pump.
- pump serializes work, captures token, posts preview/final only while current.
- cancel invalidates token, clears latest and cancels pool.
- finally clears running and re-pumps if latest appeared during completion, preventing lost wakeup.
- chunk parser enforces bounded ordered exact final content; shard messages use separate serial.

**Invariants:**

- At most one top-level active adaptive pipeline; newest slot can replace pending work.
- Stale preview/final/error cannot publish for a newer serial.
- Delayed engine initialization cannot lose cancellation/replacement demand.

**Cancellation, errors, recovery and termination:** Boot/chunk error rejects boot and posts error; host terminates on deadline/error. Map/engine resources die with worker realm. No own standalone per-job deadline: R20 supplies240s.

**Dependencies:** R20; R22; R24; R25; R28.

**Per-machine audit outcome:** positive no-lost-wakeup and token guards; no new defect.

**Relevant test evidence:**

- tests/real-sky/moon-worker-fixture.test.mjs
- tests/real-sky/moon_runtime_identity_test.py
- tests/real-sky/moon_continuity_observer_test.py

**Uncovered edge / remaining risk:** Host deadline is essential: reusing worker standalone would need its own liveness policy. Full real nested-worker cancellation timing not run.

#### R24 — Lunar shard RPC bridge promises and sticky failure

**Nature:** implicit

**Exact source anchors:**

- `moon/src/moon-pool.mjs:6–27` — `rowBridge`.

**Retained state:** worker; serial request ids; waitingMap resolve/reject/progress; sticky error; disposed ownership.

**States:** boot RPC pending; idle; render RPC pending; cancel requested; failed; disposed.

**Events / transitions / guards / effects:**

- RPC attaches id and pending resolver before post; reply kind/id routes progress or completion.
- worker error/messageerror fails every waiting request and remembers failure for subsequent calls.
- cancel posts shard-cancel; disposal terminates and rejects all.

**Invariants:**

- Unknown/old replies cannot settle another request.
- Transport failure cannot leave already registered promises awaiting ordinary worker replies.
- Top-level pool controls when a canceled bridge may be reused.

**Cancellation, errors, recovery and termination:** No per-RPC local timeout. Pool waits all jobs and host boot/render timers terminate parent worker if a shard never settles.

**Dependencies:** R23; R25; R26; R20 external deadlines.

**Per-machine audit outcome:** positive settlement on explicit transport failure; local timeout omission qualified by outer deadline.

**Relevant test evidence:**

- tests/real-sky/moon-worker-fixture.test.mjs wrapper controls are related, not direct rowBridge hung-worker evidence
- no isolated shard-RPC deadline test observed in supplied native suites

**Uncovered edge / remaining risk:** A silent shard stalls useful progress until120s/240s host bound; liveness is delegated, not intrinsically bounded by rowBridge. Native stall incidence unmeasured.

#### R25 — Lunar pool disjoint row ownership, sparse reuse and join barrier

**Nature:** partly explicit

**Exact source anchors:**

- `moon/src/moon-pool.mjs:29–99` — `MoonPool/create/render/cancel`.

**Retained state:** four row bridges; pool serial; material/current light key; source URL during initialization; disjoint row ranges; result aggregation.

**States:** creating all shards; ready; rendering ranges; canceling all; joining; cached physical scene; failed/disposed by owner.

**Events / transitions / guards / effects:**

- create boots all shards; any boot failure disposes all; blob URL revoked in finally.
- render builds exact scene key and allows sparse lighting reuse only same accepted key.
- four disjoint row jobs run; one failure cancels siblings; allSettled barrier finishes before reuse.
- join validates each row identity/range/shape/finiteness then assembles once and applies filter after join to avoid shard seams.
- cancel increments serial and cancels all; failed/canceled work clears light reuse key.

**Invariants:**

- No overlapping row writers and no read of unfinished shards.
- Canceled old results cannot become a new material/light cache.
- Full arrays validated even when sparse mask would ignore entries.

**Cancellation, errors, recovery and termination:** Errors cancel siblings and await settlement; top worker/host deadline provides final termination if a shard is silent. Worker realm termination owns nested worker resources.

**Dependencies:** R23; R24; R26; R28.

**Per-machine audit outcome:** source-proven positive ownership/barrier; no new confirmed defect.

**Relevant test evidence:**

- tests/real-sky/moon-worker-fixture.test.mjs related integration
- no full terrain/pool execution performed in this lane

**Uncovered edge / remaining risk:** Profile fingerprint await occurs after local cancellation check; outer worker token still rejects obsolete publication. No stale rendered result proved. Native nested-worker termination must be platform-verified if relied on for resource accounting.

#### R26 — Lunar engine exclusive execution, asset admission and camera/lighting caches

**Nature:** partly explicit

**Exact source anchors:**

- `moon/src/moon-engine.mjs:19–73` — `scene/decode/create`.
- `moon/src/moon-engine.mjs:75–133` — `MoonEngine render/active/cameraKey/lightKey/step`.

**Retained state:** WASM instance and owned allocation; decoded pinned layers; active flag; cameraKey; lightKey; cancellation callback; progress/yield deadline.

**States:** validating assets; engine ready; camera preparation; lighting; result validation; complete/cache valid; canceled/error.

**Events / transitions / guards / effects:**

- create verifies manifest/WASM ABI/compressed and raw hashes, size/decompression bounds, then initializes private terrain.
- render rejects reentry; clones/validates right-handed orthonormal physical scene.
- camera miss clears key until whole camera pass complete; hit updates lights.
- lighting key uses full accepted scene; sparse reuse only matching key; final key set after loop and cancel checks.
- step checks cancel and yields after8ms work opportunity; catch clears lightKey; finally always releases active.

**Invariants:**

- One active render mutates engine memory.
- Partial camera pass cannot be reused; completed camera after lighting cancel remains valid geometry.
- Canceled/failed lighting cannot be reused as accepted illumination.
- Asset bytes, decoded shape and all physical scene fields are admitted before work.

**Cancellation, errors, recovery and termination:** Cancel/error leaves engine reusable with appropriately invalidated keys. No public dispose for standalone engine; worker realm owns WASM/resource termination.

**Dependencies:** R24; R25; R27; R28; R37 C/WASM arena and retained global state.

**Per-machine audit outcome:** source-proven positive cache ownership and cancellation; missing full assets limits execution evidence.

**Relevant test evidence:**

- tests/real-sky/moon_runtime_identity_test.py
- tests/real-sky/moon_build_guard_test.py:96–103 asset drift guards
- full actual WASM/terrain validation not run here

**Uncovered edge / remaining risk:** 8ms checks are cooperative scheduling opportunities, not guaranteed frame timing. Native resource exhaustion, decompression peak memory and platform WASM behavior unverified.

#### R27 — Lunar cooperative MessageChannel yield and wakeups

**Nature:** implicit

**Exact source anchors:**

- `moon/src/moon-engine.mjs:57–62` — `yieldQueue/MessageChannel/pause`.

**Retained state:** one module channel; FIFO resolver queue; referenced/unreferenced port status.

**States:** empty/unreferenced; resolver queued/port referenced; message dequeues resolver; empty again.

**Events / transitions / guards / effects:**

- pause pushes resolver, refs port where supported, posts message.
- message handler shifts exactly one resolver, resolves it, unrefs when queue empty.
- engine cancellation checked at surrounding step boundaries; yielding itself only schedules continuation.

**Invariants:**

- A posted wakeup corresponds to one queued continuation.
- Pending continuation keeps Node-style port alive; empty queue does not keep process alive.

**Cancellation, errors, recovery and termination:** No explicit queue cancellation; already posted turn resolves then engine observes cancel. Worker termination releases ports/continuations.

**Dependencies:** R26; R23 lifetime.

**Per-machine audit outcome:** source-proven positive wakeup ordering; no lost-wakeup schedule found.

**Relevant test evidence:**

- indirect engine use; no focused channel wakeup/termination test observed in supplied native suites

**Uncovered edge / remaining risk:** Scheduler guarantees are environment-dependent. A destroyed worker abandons pending promises intentionally with its realm; standalone external callers would need disposal semantics.

#### R28 — Lunar empirical adaptive refinement and final quality admission

**Nature:** explicit finite policy

**Exact source anchors:**

- `moon/src/moon-quality.mjs:27–46` — `adaptiveMoon/refinement loop`.
- `moon/src/moon-native.mjs:198–230` — `preview/final quality gate`.

**Retained state:** rule index; current/previous result; comparison history; active receiver mask; preview sent state; final quality label.

**States:** 64-node first result; preview emitted; 256/1024/4096/8192 refinements; converged empirical-adaptive; limit-reached.

**Events / transitions / guards / effects:**

- successive render calls compare accepted outputs and focus next mask on unresolved/ambiguous receivers.
- first result emits preview without large internal convergence fields; response surfaces retained for host.
- ambiguous early receiver path requires further work; after minimum stages projected code difference<=.5 can terminate; no active comparison receivers can terminate.
- final nonconvergence labelled limit-reached; native host rejects it as final refined success.

**Invariants:**

- Empirical convergence is explicitly labelled, not mathematical accuracy certification.
- Preview does not claim final quality.
- Canceled request serial prevents any stage publication.

**Cancellation, errors, recovery and termination:** Engine cancel propagates through render awaits; exhaustion explicit. Host may retain earlier current accepted surface while reporting refinement unavailable.

**Dependencies:** R23; R25; R26; R19.

**Per-machine audit outcome:** positive explicit finite-quality state machine; no new defect.

**Relevant test evidence:**

- tests/real-sky/moon-worker-fixture.test.mjs integration surface
- tests/real-sky/moon_continuity_observer_test.py observer is not numerical oracle

**Uncovered edge / remaining risk:** Convergence masks/error estimator and exact quality policy were read, not empirically revalidated against full scientific assets. Existing mocks cannot certify lunar radiometry.

#### R29 — Lunar detail adoption, projection cache and DOM visibility owner

**Nature:** implicit

**Exact source anchors:**

- `moon/src/moon-detail.mjs:43–140` — `startMoonDetail/geometry/compose/adopt/clear/dispose`.

**Retained state:** current surface/prefix tables; last frame+geometry+cloud; prepared linear join; projected surface samples; disposed; canvas/cloud canvas; owner stats.

**States:** no surface; admitted but not visible; geometry available; projected/material cached; prepared atmospheric join; visible under preview/refined; cleared; disposed.

**Events / transitions / guards / effects:**

- adopt resets caches, builds validated prefix tables and optional calendar table; failure clears and nulls all.
- geometry requires current admitted runtime surface, moon-ready/mask visibility, valid no-shear transforms and bounded pixel area.
- compose locates current sky owner, shares cloud capture exactly once, uses full input key for prepared output and narrower geometry/table pointers for projected material.
- exact unchanged frame/key/cloud skips; new atmospheric frame recomputes join while reusing only geometry samples.
- preview final currentness fence before pixels/style; clear hides/clears output but retains admitted surface tables; dispose removes canvas and tables.

**Invariants:**

- Source physical identity and actual table pointers distinguish materials with identical labels.
- Projection cache cannot freeze sky/exposure/opacity/cloud changes.
- Detail visibility requires current accepted surface and correct sky owner.
- Disposed object cannot compose; however adopt has no disposed guard, magnifying RF01 owner mismatch.

**Cancellation, errors, recovery and termination:** Clear is reversible with retained surface; invalid adopt revokes entirely; dispose intended terminal. New runtime must receive a live captured detail owner, not dynamically disposed replacement.

**Dependencies:** R19; R10; R12; R20.

**Per-machine audit outcome:** positive exact reuse/publication fences; RF01 replacement lifetime coupling; findings RF01.

**Relevant test evidence:**

- tests/real-sky/moon-projection-cache.test.mjs:35–77 exact old/new output, stale, invalid adoption, disposal, staged preview control
- evidence/probes/rendering/protocol-probes.mjs runtimeReplacement

**Uncovered edge / remaining risk:** No actual native DPR/transforms/timing/pixels asserted. Source counterexample concerns wrapper reinstallation; ordinary clear/adopt and worker retry tests remain positive.

#### R30 — Admitted initial lunar receiver and canonical render closure

**Nature:** implicit resource admission

**Exact source anchors:**

- `moon/src/moon-initial.mjs:9–74` — `createInitialMoon/render/consumeInitialMoon`.
- `moon/src/moon-initial-compact.mjs:1–65` — `decodeCompactInitialMoon`.

**Retained state:** private decoded material/coverage/receiver records/index; immutable identity/profile descriptor; bounded closure; shared readonly coverage.

**States:** compressed input untrusted; exact decoded identity admitted; immutable receiver ready; canonical per-phase result.

**Events / transitions / guards / effects:**

- compact decoder enforces compressed byte/hash/schema/packing/Huffman/Paeth bounds and final decoded hash.
- createInitialMoon copies validates bounded arrays/records; exposes frozen identity plus render function.
- render permits canonical fixed view/profile/calendar; computes current sun/earth illumination and new output arrays every call.
- synchronous consume callback borrows tables without retaining duplicate data.

**Invariants:**

- Initial resource reuse does not reuse old physical phase or change runtime authority.
- Reference/custom geometry cannot be silently served by canonical approximation.
- No unbounded per-phase cache.

**Cancellation, errors, recovery and termination:** Any malformed data fails admission; owner records initialError and uses later valid availability. Closure lifetime follows document/initial renderer; no async partial publication.

**Dependencies:** R14; R21; R19; moon calendar/precision pure transforms.

**Per-machine audit outcome:** source-proven positive bounded resource admission; no new defect.

**Relevant test evidence:**

- tests/real-sky/initial_source_association_test.py
- tests/real-sky/native-first-paint.test.mjs
- tests/real-sky/moon_build_guard_test.py:96

**Uncovered edge / remaining risk:** Declared receiver tier is an approximation, not full terrain certification. No large scientific source files or native visual first-paint run available.

#### R31 — Module-lifetime spectral selection and B–V fit retention

**Nature:** implicit cache protocol

**Exact source anchors:**

- `real-sky/core/src/spectral.mjs:9–41` — `sfCache/sfFitCache/sfFitColour/selectSpectrum`.
- `real-sky/core/src/sky-background.mjs:29–33` — `patatTwilight`.
- `real-sky/core/src/sky-background.mjs:75–76` — `createSkyModel twilightSpectrum`.
- `real-sky/native-preview.mjs:334–336` — `nativeAtmosphereFields twilight B–V`.

**Retained state:** outer spectral selection Map capped12000; separate exact-B–V fitting Map with no cap; frozen95-sample fit/selection values.

**States:** colour absent; 48-step fit computed; fit retained indefinitely; outer cache full but fit map still growing.

**Events / transitions / guards / effects:**

- outer hit returns immutable selection; miss may fit exact B–V then store fit unconditionally.
- outer cache stops adding at12000; inner cache has no coupled bound/eviction.
- changing solar altitude feeds continuous twilight B–V in both physical model and UI preview.

**Invariants:**

- Intended bounded computational memoization is violated: fit map can retain one95-sample spectrum per distinct valid time-dependent colour.
- Immutability protects values but not resource bound.

**Cancellation, errors, recovery and termination:** Only realm/module termination releases fit map; asset/runtime retry in same UI realm does not reset module cache. Worker restart resets worker copy.

**Dependencies:** R34; R12; R09.

**Per-machine audit outcome:** confirmed synthetic growth and actual pinned twilight-colour reachability RF03; no measured production heap leak claim; findings RF03.

**Relevant test evidence:**

- evidence/probes/rendering/protocol-probes.mjs spectralRetention:12020 colours→12020 fits and12000 outer entries
- no existing fit-cache capacity test observed
- evidence/probes/rendering/twilight-reachability.mjs:actual pinned physical/preview twilight colour expressions at1000 solar altitudes,1989 distinct fitted colours retained

**Uncovered edge / remaining risk:** Real retained bytes, time until pressure and user-visible latency/GC effects were not measured; native duration/rate distributions remain unknown.

#### R32 — Bounded legacy photometry spectral memo

**Nature:** implicit cache protocol

**Exact source anchors:**

- `real-sky/core/src/photometry.mjs:27–35` — `spectra/spectrumForColour`.

**Retained state:** string-keyed spectraMap capped2048;95-bin normalized shape and metadata.

**States:** miss; cached hit; capacity reached/non-retaining compute.

**Events / transitions / guards / effects:**

- first distinct colour computes normalized spectrum and stores only below2048.
- after capacity results still compute correctly without adding entries.
- null colour uses declared unknown-neutral proxy.

**Invariants:**

- Strong cache retention bounded2048.
- No UTC/frame authority in key or value.

**Cancellation, errors, recovery and termination:** Synchronous validation/normalization; caller errors propagate; module lifetime/realm termination releases cache.

**Dependencies:** legacy physical photometry consumers.

**Per-machine audit outcome:** positive bounded count; returned mutability is a contract limitation, not a proved shipped defect.

**Relevant test evidence:**

- native photometric rendering integration in parent cohort; no isolated mutation/capacity test observed here

**Uncovered edge / remaining risk:** Returned object/samples are mutable and repeated hit shares them. Internal inspected consumers treat them read-only; arbitrary caller mutation could poison later results but no production mutation path established.

#### R33 — Atmosphere validation capability and weak coefficient memo

**Nature:** implicit admission/cache protocol

**Exact source anchors:**

- `real-sky/core/src/atmosphere.mjs:7–21` — `atmValidated/normaliseAtmosphere`.
- `real-sky/core/src/sky-background.mjs:14–14` — `bgCoeff`.
- `real-sky/core/src/sky-background.mjs:47–51` — `coefficient lookup keyed by normalized atmosphere`.

**Retained state:** WeakSet of privately validated frozen atmosphere objects; WeakMap of spectral coefficients keyed by those objects.

**States:** untrusted input; validated frozen atmosphere; coefficient miss/hit; unreachable/collectable.

**Events / transitions / guards / effects:**

- foreign object is fully validated and copied/frozen; only private WeakSet identity skips validation.
- coefficient table computed once per admitted object, never by mutable user stamp alone.
- new native weather/atmosphere object obtains separate coefficients; weak ownership allows collection.

**Invariants:**

- Caller mutation cannot change a normalized atmosphere.
- __cp6Atmosphere property alone is not a capability.
- Weak caches do not strongly accumulate past atmosphere objects.

**Cancellation, errors, recovery and termination:** Invalid conflicting transmission/optical-depth or out-of-range fields reject; new valid input recovers synchronously. No cancellation or explicit dispose required.

**Dependencies:** R34; R09.

**Per-machine audit outcome:** source-proven positive unforgeable validation and weak lifetime.

**Relevant test evidence:**

- tests/real-sky/native-preview.test.mjs physical preparation integration
- no isolated spoofed-validation-marker probe performed in this lane

**Uncovered edge / remaining risk:** Reuse effectiveness depends on callers sharing normalized objects; repeated equivalent new objects recompute. No performance measurement or optimization request implied.

#### R34 — Per-physical-model solar sample grid lifetime

**Nature:** implicit cache protocol

**Exact source anchors:**

- `real-sky/core/src/sky-background.mjs:72–96` — `createSkyModel/solarNode/solarAt/sample`.

**Retained state:** one model closure containing physical state reference, frozen normalized atmosphere, twilight fit, option callbacks, bounded solar-node Map.

**States:** model created; node missing; node computed; node reused; model unreachable.

**Events / transitions / guards / effects:**

- current physical model created from accepted state; solarNode memoizes exact ia/azimuth wrapped indices.
- solarAt admits altitude0..18 grid bands and36 azimuth columns, interpolation samples up to684 distinct nodes.
- new model creates new map; changing host UTC creates new model, not global time cache.

**Invariants:**

- Physical sampling cache lifetime is exactly one current model; geometry caches are separate.
- At most19×36 solar nodes under admitted sample path.
- Moon/natural/cloud terms evaluated from current model rather than frozen coarse solar grid.

**Cancellation, errors, recovery and termination:** Synchronous failure propagates to renderer unavailable. Releasing model releases grid; no temporal cancellation itself.

**Dependencies:** R31 twilight spectrum; R33 atmosphere; R09; R12.

**Per-machine audit outcome:** positive per-model bounded lifetime; mutable state API hypothesis not promoted.

**Relevant test evidence:**

- tests/real-sky/native-preview.test.mjs
- tests/real-sky/native-lunar-component.test.mjs
- tests/real-sky/native-lunar-fused.test.mjs

**Uncovered edge / remaining risk:** Returned model exposes same state reference; external mutation after cached nodes could mix epochs. Internal inspected callers create fresh state and do not mutate it during sampling, so no shipped schedule proved.

#### R35 — Native target-elevation acceptance lease

**Nature:** implicit authority protocol

**Exact source anchors:**

- `real-sky/native-host-hooks.js:4–8` — `_cp9SiteElevation/acceptedElevation`.
- `real-sky/native-host-hooks.js:17–36` — `capture elevation selection/source label`.

**Retained state:** one frozen height/generation/lat/lon tuple admitted by native target owner.

**States:** no accepted elevation; tuple admitted; tuple ineligible after target/generation/weather change; new tuple accepted.

**Events / transitions / guards / effects:**

- acceptedElevation admits finite bounded height only for exact current runtime generation and coordinates.
- capture uses tuple only with eligible selected weather and same generation/coordinates; otherwise explicit0m estimate/source label.
- new accepted tuple replaces prior; A→B→A generation prevents reuse of A old record.

**Invariants:**

- Legacy scalar elevation is not accepted astronomical metadata.
- Same numeric coordinates after generation change do not revive stale altitude custody.

**Cancellation, errors, recovery and termination:** Invalid acceptance returnsfalse without replacing tuple; current later native weather/elevation acceptance recovers. Tuple can remain retained but has no authority outside guard.

**Dependencies:** native weather acceptance owned by other lane; R15; R01.

**Per-machine audit outcome:** source-proven positive separate metadata lease.

**Relevant test evidence:**

- tests/real-sky/cp9-elevation.test.mjs

**Uncovered edge / remaining risk:** Network elevation provider acceptance itself is outside this lane. Static source labels do not establish correctness of measured terrain elevation.

#### R36 — Catalogue-bound diffuse resource capability and private sampler

**Nature:** implicit resource-admission protocol

**Exact source anchors:**

- `real-sky/core/src/diffuse-binding.mjs:4–18` — `dsBindings/bindRegisteredStarlight/isBoundRegisteredStarlight`.
- `real-sky/core/src/registered-starlight.mjs:35–60` — `createRegisteredStarlightSampler`.
- `real-sky/core/integration/physical-sky-bridge.mjs:5–18` — `PhysicalSkyBridge registered input check`.
- `real-sky/core/integration/resilient-sky-bridge.mjs:8–16` — `binding→bridge WeakMap`.

**Retained state:** private WeakSet of issued bindings; exact catalogue byte digest; deep-frozen parsed catalogue; private copied diffuse values/estimates/rings; immutable sampler closure.

**States:** untrusted catalogue/asset; hash-matched parsed data; issued same-realm capability; bound bridge reused; unreachable.

**Events / transitions / guards / effects:**

- verify exact unmodified catalogue text hash against asset; validate catalogue and copy/freeze private data.
- construct sampler with matching hash; only successful binding added to private WeakSet.
- bridge accepts only issued binding and its associated catalogue, caches bridge weakly by binding identity.

**Invariants:**

- An object with correct-looking kind/hash fields cannot forge issued capability.
- Catalogue and removed-source diffuse map cannot be silently mismatched.
- Caller mutation of original parsed arrays cannot change private sampler.

**Cancellation, errors, recovery and termination:** Any mismatch rejects; R07 marks requested diffuse unavailable and R09 declares fallback. Capability lifetime follows strong caller refs; WeakSet/WeakMap do not retain retired resource alone.

**Dependencies:** R07; R09; R08.

**Per-machine audit outcome:** positive exact binding and lifetime protections; no new defect.

**Relevant test evidence:**

- tests/real-sky/native-engine.test.mjs integration
- admission source read; no isolated forged-binding probe added here

**Uncovered edge / remaining risk:** Byte hash validates content identity, not publisher authenticity; pin/source provenance is external to capability. Internal code can deliberately pass mutable state but not forge same-realm WeakSet identity.

#### R37 — Lunar C/WASM retained kernel state, frame arena and source witness

**Nature:** implicit exclusive resource protocol

**Exact source anchors:**

- `moon/src/moon_kernel.c:19–34` — `heap_end/space`.
- `moon/src/moon_kernel.c:55–96` — `asset pointers/pyramids/colour_lut/alloc_buffer/init_assets`.
- `moon/src/moon_kernel.c:196–261` — `pixels/capacity/frame_mark/begin_scene/camera_rows`.
- `moon/src/moon_kernel.c:264–318` — `blocker_t/witness_enabled/light_rows_impl/set_lights`.
- `moon/src/moon-engine.mjs:64–104` — `create/render ABI caller ownership`.

**Retained state:** static asset pointers/dimensions/pyramid arrays/LUT; WASM heap_end and frame_mark; pixels/capacity; global scene basis/lights/size; quadrature arrays; counters; blocker_t and witness toggle.

**States:** empty arena; one-shot assets initialized; fixed pointers allocated; frame arena first allocated; frame capacity reused; larger frame rewinds to frame_mark; camera receivers initialized; lighting/refinement in place; instance terminated.

**Events / transitions / guards / effects:**

- WASM space16-byte aligns, checks overflow and512MiB ceiling, grows memory or returnsnull.
- init_assets validates dimensions/heights and allocates persistent min/max pyramids/LUT once; JS then allocates scene argument and mask buffers before first begin_scene.
- first growing frame marks heap_end; later larger frame resets heap_end to that mark and replaces pixel arena; smaller frames keep high-water capacity but zero active scene receivers/counters.
- camera_rows writes admitted disjoint range; set_lights changes source/quadrature while retaining completed camera receivers.
- lighting sparse mask preserves unselected channels only under JS exact lightKey; blocker_t reset per receiver and source; reuse counts a blocker only after testing actual new-ray point strictly inside terrain, never infers clearance.

**Invariants:**

- All fixed buffers must precede first frame_mark; no later external alloc_buffer custody may live across frame growth. Shipped JS caller respects this order.
- One WASM instance has one mutable scene; JS active gate and pool per-instance row ownership enforce exclusivity.
- Arena count bounded by maximum accepted scene768 and allocator ceiling, but memory pages/high-water capacity do not shrink with smaller scene.
- Blocker witness cannot carry unchecked authority to another receiver/source.

**Cancellation, errors, recovery and termination:** Allocation/scene refusal returns0 and engine throws; host worker failure closes realm, making native recovery a new instance. No general C reset/free for asset lifetime; native non-WASM branch frees old pixels on growth only. Standalone reuse after failed allocation or repeated init_assets is not supported by inspected native callers.

**Dependencies:** R26 exclusive caller; R25 disjoint owner; R20 termination/retry; R28 sparse refinement.

**Per-machine audit outcome:** source-proven retained-state domain added; positive caller ordering; resource-pressure/standalone-reuse risks qualified, no new native defect proved.

**Relevant test evidence:**

- no C/WASM build or execution claimed in this lane; large terrain inputs unavailable
- tests/real-sky/moon_build_guard_test.py includes pinned WASM/asset drift guards, not frame-arena runtime verification

**Uncovered edge / remaining risk:** Each of four instances may retain its maximum allocated pages; ceiling is per instance, not a pooled browser budget. Native peak memory/pressure unmeasured. Direct calls to init_assets/alloc_buffer after frame_mark or engine reuse after failed frame growth require explicit contract/tests before being supported.

### Qualified exclusions

- Pure astronomy, projection, terrain intersection, cloud, quadrature, colour and filtering helpers are excluded when all state is per-call; their mathematical result regions are not independent behavioural machines.
- Native solar registration smooth10–20 and atmospheric presentation thresholds near −18/−12/−5/−3 degrees, lunar calendar phase/gain and precision quantization are qualified stateless classifier boundaries. They may affect visual transitions but do not themselves retain asynchronous authority.
- Immutable scientific datasets are inputs, except their admission/resource lifetime protocols mapped above. Generated bundles repeat the authored machines and are not counted again.
- Diagnostic status objects and mocked readiness flags do not establish displayed native pixels, native frame cost or actual available memory.
- src/native/index.html snapshot acquisition, weather and underlying solar/visibility ownership belong to another lane; only interface call sites were used here.

### Rejected leads and limits

**Continuous mask decode replacement starvation — rejected-by-design.** real-sky/native-composition.mjs:45–46 NativeSolarMaskPublication.publish refuses new publication while pending; hosts preserve one active decode. RF04 is a separate conditional no-settlement hypothesis.

**Old sky pixels gain freshness merely because a newer job is accepted or fails — rejected-by-source and existing tests.** R01/R10 retain the original painted job and age, separate accepted result from displayed result and expire presentation without invalidating a distinct pending refresh.

**A→B→A snapshot identity admits old A completion — rejected-by-source and existing tests.** R01 epoch changes independently of equality of semantic identity; R19/R23 lunar epochs/tokens likewise fence old authority.

**Worker or asset promise must always be canceled internally by each generic queue — not a product defect without owner liveness gap.** R02/R24 rely on R05/R20 owner deadlines/termination. The generic queue cannot forcibly interrupt arbitrary executors; this is an ownership dependency, not independently proven deadlock.

**Repeated lunar installation is the ordinary worker-refinement boot path — rejected-by-build route.** tools/build_moon.py:129–130 supplies host wrapper once; incremental refinement calls installWorkerSource. RF01 requires repeated complete wrapper installation/replacement.

**Every actual twilight input creates a fitted spectrum — rejected by focused probe and corrected.** 2000 distinct actual residual/total twilight colours produced 1989 fitted outcomes;11 intentionally used model fallback. RF03 counts only actual retained fitted outcomes.

**Mutable physical-model state or photometry return proves a current caller cache corruption — unproven API misuse hypothesis.** Inspected shipped callers create fresh physical state and do not mutate published cache returns during sampling. Remaining contract risk recorded in R32/R34.

**C/WASM frame arena rewind destroys assets or live ABI argument buffers in the shipped sequence — rejected-by-allocation order.** R37: moon-engine.mjs:64–73 allocates assets, arguments and full mask before the first begin_scene frame_mark. No subsequent alloc_buffer call in inspected shipped render path. Standalone arbitrary ABI order is unsupported.

### Decision-changing discriminators

**D01 (RF01):** Can the supported host ever evaluate the entire lunar wrapper twice in one surviving window?

If prohibited by deployment lifecycle, RF01 remains a real replacement-API defect with limited current exposure; if reachable after partial injection/reinstall, prioritize ownership repair.

**D02 (RF02):** Which shipped capability/resource construction failures are retried in the same live card?

Quantifies exposure of orphan canvas accumulation and possible first-selector interference. Constructor rollback is independently testable without native pixels.

**D03 (RF03):** How many exact twilight colours and retained bytes occur over a native long session at supported clock rates?

Actual caller reachability is already established; this determines operational severity and a scientifically exact retention budget, not existence of the unbounded inner map.

**D04 (RF04):** Can the target browser leave decode of the generated local mask URL unsettled indefinitely while UTC is frozen?

Required before promoting no intrinsic timeout into a native liveness defect. Keep one active decode and revision/currentness fencing.

**D05 (R10, R11, R12, R14, R19, R29):** At reported cloud flicker, which exact owner controls each visible solar layer and what are the snapshot/job/epoch, accepted UTC, pending/displayed mask revision, CSS classes and cloud alpha?

Capture aligned native frames and ownership metadata across cloudy→clear→cloudy, frozen/running clock, preview/refined handoff and expiry. No observed source-proven root cause or visual reproduction is asserted here.

**D06 (R25, R26, R37):** What is native peak memory across the four independent WASM instances, retained high-water arena pages and temporary decoded texture buffers?

Per-instance bounded allocator and cancellation correctness do not imply an acceptable aggregate mobile/native memory budget. No measured memory violation is claimed.

### Reported sun/cloud flicker boundary

No native visual reproduction or established root cause is claimed. The three confirmed findings concern replacement ownership, constructor rollback, and unbounded fit retention. The inspected composition protections include one active mask decode, revision/currentness guards, decoded publication, an explicit clear-gradient mask that preserves compositing group ownership, original painted-frame age, and current preview recovery. The native HTML lane must combine these interfaces with actual solar-layer visibility ownership before attributing an all-on/all-off symptom.

### Delivery verification

All37 catalogue IDs are unique and ordered; every source anchor exists and fits the pinned file line count; every finding contains the required fields. The two focused probe result files report their own scope and outcomes, including the corrected twilight fallback discriminator. Parent275-case evidence is cited as parent-run evidence. This delivery completes the specialist report only.
