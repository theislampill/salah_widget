# Native behavioral state-machine audit

**Status: FINAL specialist handoff.** This closes this lane’s evidence delivery only. It does not authorize implementation, declare release readiness, or close the project audit.

Source: `theislampill/salah_widget` at `f71fef6ccf7e4efcb57b5a26688d2360461a3253`; native SHA-256 `6054f1eb3e7f04aa5975707345810b64fc824bc99e17ce3798369a959a123fad`.

## Outcome

The catalogue contains **22 distinct behavioral machines/contract entries**. Two defects were reproduced using unchanged owner functions and controls, and independently rerun by the parent. One additional configuration-invalidation finding is formally owned by the parent. Each machine below has an individual disposition, retained state, transitions, invariants, recovery and verification gap.

**NF01:** accepted reordered next-day clocks can select Fajr after an earlier prayer. The admitted synthetic trace selects05:00/360minutes instead of00:31/91minutes. **NF02:** while the prayer model is unavailable, expired weather is withdrawn from header/precipitation but cloud coverage/density remains retained and paintable.

22 catalogue entries include one dormant generated-compatibility owner (N11) and one active generated-contract entry whose native source star implementation is replaced (N14). This is not22 active independent render loops.

## Scope and evidence limits

Native boot/config-apply, clock/day, prayer transport/cache/admission/model, calendar/dialog, weather/current/forecast/evidence/header/radar, sky/moon contracts, cloud/effects, layout, lifecycle/settings/persistence; config.js and builder implementation are other lane, renderer internals other lane.

No native browser, screenshots, clip, host listener, install, build qualification or large omitted asset validation. Generated defect regions were compared as exact text. No network provider prevalence claim.

Known installed IMPLEMENTAUDIT --current-controller could not run in the immutable non-Git snapshot (exit128). No controller/repo was initialized or modified. Root reconciled the read-only audit object; this child uses the ordinary inspection/handoff route and claims no verified controller transition.

No application source, generator, configuration, committed state or publication was changed. The only authored outputs are this lane report, its searchable JSON and bounded scratch probes. No secrets were found in the inspected native state; no sensitive diagnostic values are reproduced.

## Machine index

| ID | Machine | Nature / runtime | Audit disposition |
|---|---|---|---|
| N01 | Configuration resolution, boot and apply generation | implicit; active | inspected-protection; cross-machine efficiency candidate referred to root |
| N02 | Civil/simulation clock, timezone inverse and invalid-scene recovery | partly-explicit; active | inspected-protection |
| N03 | Request ownership and bounded attempt leases | explicit; active | inspected-protection |
| N04 | Current prayer acquisition, admission/cache and adopted-zone reconciliation | partly-explicit; active | inspected-protection; NF01 is a downstream consumer violation, not a reason to reject valid reordered input |
| N05 | Prayer day rollover, next-day prefetch and cooldown | implicit; active | inspected-protection; cross-machine NF02 trigger |
| N06 | Prayer model, next-event countdown and DOM publication | implicit; active | reproduced defect NF01; other stated guards inspected |
| N07 | Calendar publication and date disclosure | implicit; active | inspected-protection |
| N08 | Weather acquisition, current/forecast records and persistent cache | partly-explicit; active | inspected-protection |
| N09 | Weather truth/source selection, fixture expiry and header publication | partly-explicit; active | inspected-protection; cross-machine NF02 shows incomplete propagation to one consumer |
| N10 | Radar diagnostic transport, image lease and expiry | implicit; active | inspected-protection |
| N11 | Legacy lunar texture/canvas fallback readiness (dormant generated owner) | implicit; dormant-generated-compatibility | compatibility-only inspection; excluded from active generated renderer finding count |
| N12 | Native lunar geometry production and actual-consumption receipts | partly-explicit; active | inspected-protection; renderer-side acceptance remains other lane |
| N13 | Sky scene identity, first-document warrant and renderer-surface commit | partly-explicit; active | inspected-protection; exact boundary explains NF02 reachability |
| N14 | Star projection/catalogue contract and held appearance | implicit; generated-contract-active; native-source-implementation-replaced | generated substitution reconciled; no active synthetic-star defect |
| N15 | Cloud population, motion integration, coverage and paint cache | partly-explicit; active | reproduced cross-machine defect NF02; bounded motion protections inspected |
| N16 | Precipitation population, cloud-origin gating and lightning strike bucket | implicit; active | inspected-protection; historical selector failure rejected as fixture drift |
| N17 | Atmosphere publication, optical fade state and last-consumed diagnostics | implicit with derived regions; active | inspected-protection; no additional independent classifier machines |
| N18 | Countdown font readiness, rail sampling and geometry-fit cache | implicit; active | inspected-protection; incomplete fit-key dependency is an unverified visual hypothesis |
| N19 | Singleton render loop, visibility, provider cadence and motion lifecycle | implicit; active | inspected-protection; exception recovery gap unverified |
| N20 | Settings disclosure, focus ownership, dirty form and close-save | implicit; active | inspected-protection; close-save behavior accepted as explicit design |
| N21 | Settings place search, GPS, candidate cycling and reset intent ownership | partly-explicit; active | inspected-protection |
| N22 | Persistence outcome and persistent warning publication | partly-explicit; active | inspected-protection |

## Reproduced findings

### NF01 — Cross-midnight target hardcodes Fajr after accepting reordered prayer clocks

**Category:** Correctness / Bugs — prayer chronology

**Disposition / severity:** reproduced-defect; implementation-deferred; high conditional correctness impact

**Machines:** N04, N05, N06

**Evidence**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:990–1009` — admitPrayerRecord accepts equal/reordered clocks
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:2232–2245` — model sorts current day but hardcodes next-day Fajr
- `/workspace/scratch/8ab1bbbe9699/evidence/probes/native/join-probes.cjs` — NF01 exact-function/admission probe
- `/workspace/scratch/8ab1bbbe9699/evidence/probes/native/join-results.json` — NF01 reproduced/control result
- `/workspace/scratch/8ab1bbbe9699/evidence/probes/native/generated-joins.json` — exact source region occurs unchanged in pinned generated index

**Concrete trace**

- Seed actual-admitted UTC records for07-09-2026 and08-09-2026 with ordinary Fajr05:00, Sunrise06:00, Dhuhr12:00, Asr15:30, Maghrib18:00, but today Isha00:30 and tomorrow Isha00:31.
- At07-09-2026 23:00 UTC the current-day sorted model identifies Maghrib as the latest elapsed event.
- model selects tomorrow Fajr05:00 and publishes360minutes remaining, although the earliest admitted next-day event is Isha00:31,91minutes away.
- The normal-clock control correctly selects Fajr05:00 with360minutes. Synthetic input is admitted by the production acceptance contract; real provider prevalence was not measured.

**Impact:** The next prayer name, target epoch, countdown and interval/progress can point past an earlier admitted prayer; the probe overstates the remaining interval by269minutes. A schema explicitly supporting equal/reordered clocks must preserve that chronology across the date boundary.

**Effort:** Small owner-function change plus focused boundary regression; moderate validation effort because prayer/calendar semantics and ties must remain stable.

**Repair risk:** A rushed repair can alter tie ordering, before-first current row, missing-tomorrow behavior, DST exact inverse or progress intervals. Do not reject supported reordered inputs merely to avoid the defect.

**Confidence:** High for admitted-input behavior and generated parity; no claim about frequency in real provider feeds or native visual appearance.

**Fix route:** Future authorized source repair in model: derive the earliest next event from admitted next-day times using date-aware epochs, retaining exact-zone conversion, stable tie policy and absence handling. Regenerate through tools/build_native.py after source verification; no generated-only patch.

**Repair class:** Owner logic / cross-day transition correction

**Owner:** Native prayer-model owner; root integrates final work order

**Acceptance**

- Ordinary chronology control remains unchanged.
- Reordered admitted tomorrow event earlier than Fajr becomes the actual next target with91minutes in the stated fixture.
- Equal-clock ties are deterministic; before-first and after-last current rows/intervals remain explicit.
- Missing/rejected tomorrow record remains unavailable; no guessed schedule or Hijri roll-forward.
- DST folds/gaps, midnight and year boundaries retain exact accepted UTC semantics.

**Rollback:** No application change made. If a future repair regresses behavior, revert its atomic source+generator output change and added expectations together; preserve evidence of this defect. Do not alter the pinned evidence snapshot.

**Deferred rationale:** Read-only audit scope does not authorize implementation, publication or closure.

**Remaining risk:** Real-provider incidence, complete high-latitude/rotation/tie corpus and native pixels are unverified. Existing passing ordinary-clock tests do not exclude this admitted reordered transition.

**Verification**

- local: Successful Node v24 run of join-probes.cjs; seed passed the actual admitPrayerRecord; ordinary and reordered controls inspected.
- independent: Root reports an independent unchanged rerun succeeded and verified exact model source/generated region.
- required_future: Add targeted date-boundary model tests, rerun relevant countdown/timezone/day cohorts, then inspect actual native name/countdown/arc and calendar presentation.

### NF02 — Weather expiry leaves cloud coverage published while the prayer model is unavailable

**Category:** Correctness / Bugs — stale evidence propagation

**Disposition / severity:** reproduced-defect; implementation-deferred; medium

**Machines:** N06, N09, N13, N15, N17

**Evidence**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:2142–2144` — skySceneIdentity excludes civil day
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:2819–2842` — paintCelestialWithoutTimetable only resets clouds on changed scene identity
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3024–3042` — applyCloudState explicit unavailable-weather withdrawal
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3247–3262` — render no-model branch bypasses applyCloudState
- `/workspace/scratch/8ab1bbbe9699/evidence/probes/native/join-probes.cjs` — NF02 exact render/withdrawal/painter calls
- `/workspace/scratch/8ab1bbbe9699/evidence/probes/native/join-results.json` — NF02 expired no-model versus withdrawal control
- `/workspace/scratch/8ab1bbbe9699/evidence/probes/native/generated-joins.json` — all three affected owner regions occur unchanged in pinned generated index

**Concrete trace**

- A same-location live scene has a valid timetable and admitted cloudy/thunder model state, coverage[0.92,0.90,0.60] and a painted cloud density profile.
- At ordinary civil midnight, no admitted next-day timetable/cache is available and recovery fails. The live sky identity does not include civil day, so the no-prayer helper does not reset cloud state.
- If no qualifying weather refresh replaces the data, its900second lease expires. This may also occur on returning from a hidden interval.
- The no-model render branch correctly withdraws prayer content and lets weatherDecision/header/effects become unavailable, but never calls applyCloudState.
- Probe at age901seconds shows modelCode null, header empty and precipitation off, while _cloudReady remains true and all three coverages and density sum1167.9425904750824 remain unchanged.
- Calling the existing complete atmosphere/cloud withdrawal path as control makes readiness false, coverageszero and densityzero.

**Impact:** Expired weather-derived cloud material remains publishable despite an unavailable truth decision. Independent provider expiry becomes accidentally conditional on prayer availability. Header/precipitation withdrawal working correctly does not remove the stale optical cloud consumer.

**Effort:** Small targeted withdrawal/publication change with focused joint-state tests; native visual validation remains required.

**Repair risk:** Resetting the entire sky would disturb cloud population/motion, first-document warrant and independent celestial rendering. Equating unavailable with observed clear weather would introduce a different truthfulness defect.

**Confidence:** High for reachable same-identity source path and reproduced retained state/raster calls; no native pixel, on-device timing or actual weather-feed claim.

**Fix route:** Future authorized source repair should propagate unavailable weather to cloud coverage even when no prayer model exists, while preserving independent physical sun/moon, population identity and motion phase. Use the current withdrawal semantics directly; do not fabricate a prayer model to access them.

**Repair class:** Consumer invalidation / cross-machine expiry propagation

**Owner:** Native atmosphere/cloud publication owner with prayer-render integration

**Acceptance**

- Same-target midnight with missing timetable and expired weather clears coverage, readiness and density on the next visible publication opportunity.
- No-model celestial preview remains functional and current; no stale timetable or fabricated clear observation appears.
- Fresh qualifying weather with missing prayer data follows a deliberate documented consumer policy.
- Ordinary healthy easing, initial deck snap, advancing preview and reduced-motion held axes remain unchanged.
- Real native absence/recovery and full-motion clips confirm no stale cloud image, jump or unintended scene rebuild.

**Rollback:** No application change made. Future rollback must revert the single source withdrawal change and generated output coherently without removing existing expiry safeguards or preserving stale material intentionally.

**Deferred rationale:** Read-only audit scope; the finding is evidence for root prioritization and a future work order, not permission to implement or close.

**Remaining risk:** VM probe used DOM/canvas call stubs and a controlled model-unavailable boundary; it did not capture native pixels. The midnight route is source-proven and independently corroborated; exact timing in real browsers/providers remains to be tested.

**Verification**

- local: Successful Node v24 exact-function probe recorded retained coverage/density after no-model expiry and a working withdrawal control. Related production regions were not altered.
- independent: Root independently reran join-probes.cjs successfully and verified stable live scene identity plus all cited owner regions.
- required_future: Add a joint midnight/prayer-unavailable/weather-expired case using admitted records and scheduled no-model recovery; run cloud-expiry/weather/day cohorts and the native visual/motion contract.

## Related parent-owned finding

**root-F01:** Non-location display-format/label changes take broad applyConfig invalidation

**Evidence**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3478–3527` — resetForNewLocation and nonappearance applyConfig route

Root independently confirmed formatting/label-only broad reset with its own unchanged-function probe. This lane records the cost/ownership coupling and does not create a duplicate finding or prescribe an unqualified narrow-cache key.

## Per-machine audit

### N01 — Configuration resolution, boot and apply generation

**Nature / runtime:** implicit; active

**Source**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:667–704` — bindConfig; CONFIG; legacy resolver fallback
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3478–3527` — buildSceneOnce; resetForNewLocation; applyConfig
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3546–3616` — boot

**Retained state**

- CONFIG and live scalar bindings; frozen _cacheTz; _cfgMode/_needsDetect/_hashCfg/_cfgFlags; autodetect status; _sceneBuilt; captured boot/apply generation; DOM appearance and initial scene classes

**States**

- unresolved/bare
- local coarse detection pending
- usable target pending initial admission
- scene built once
- boot yielded
- providers pending
- render loop active
- superseded
- invalid simulation/incomplete target
- appearance-only update

**Events / transitions / guards / effects**

- resolve at script evaluation → bind configuration and mode; shared module validates, legacy fallback is conditional compatibility
- boot captures generation → begin initial scene → optionally await coarse detection; stale generation cannot bind results
- usable target → build deterministic scene once, render pending prayer/header and preview → consume initial-document warrant → two rAFs plus MessageChannel task → recheck generation → start weather/radar and await prayer → recheck before loop start
- appearance-only apply → update CONFIG and dataset without request invalidation; other apply → beginRuntimeGeneration → bind → reset location-owned presentation → start weather/prayer → eligible completion starts singleton loop

**Invariants**

- An obsolete boot/apply continuation cannot become current after A→B→A. A declared appearance-only change preserves provider-adopted timezone and request ownership. Scene construction is idempotent across configuration updates.

**Cancellation / expiry / error / recovery / termination**

- Incomplete/invalid targets remain unavailable and expose settings where mode permits. Invalidating generation cancels request attempts; coarse detection is logically discarded by generation checks. Failed/no coarse result reports status, opens settings, starts available loop. Scene-built flag is set only after both builders return. Page lifetime is the terminal owner.

**Dependencies**

- N02 clock readiness
- N03 generation and cancellation
- N04 prayer admission
- N08 weather
- N13 first-document warrant
- N19 singleton loop
- config.js resolution and geolocation (other lane)
- generated preview/real-sky hooks

**Disposition:** inspected-protection; cross-machine efficiency candidate referred to root

**Correctness / concrete inspection:** Generation checks surround asynchronous boot detection, post-yield provider start and prayer completion. The appearance-only branch compares semantic fields before source/persistence metadata changes, avoiding the historical timezone rollback. Broader display-format/time/unit changes still take the complete reset branch; root is independently adjudicating their unnecessary invalidation cost.

**Security / privacy:** Boot coarse location is delegated to config.js; no precise-position permission is silently acquired here. Fragment labels reach textContent. No authority is taken from remote content.

**Performance / scale:** One-time builders and early preview allow independent celestial startup. The nonappearance route can refetch prayer/weather and invalidate scene resources for changes that may not alter their inputs; preserve hard ownership while narrowing invalidation only if parent confirms.

**Architecture / debt:** Several small retained flags encode a transaction spread between bindConfig/reset/load/boot. The existing generation is already an explicit ownership boundary; treat display invalidation as separate from network identity rather than replacing it wholesale.

**Direction / design:** Preserve truthful pending rows, independent celestial preview and initial-frame warrant. No suggested repair may reveal a stale target while waiting for a cosmetic refresh.

**Relevant existing tests**

- tests/r0003-ownership.test.cjs
- tests/r0004-boot-day.test.cjs
- tests/r0004-currentness-controls.test.cjs
- tests/native-appearance-currentness.test.cjs
- tests/real-sky/native-startup-critical-path.test.mjs

**Tests / validation scope:** Relevant tests are pointers to existing coverage, not assertions that each file passed. Parent owns broad regression adjudication. Locally executed join probes are identified explicitly.

**Verification gap / remaining risk:** No real browser scheduling or first-painted-pixel proof. Legacy module-missing configuration differs from normalized path. Parent owns broad-reset defect decision; no duplicate finding asserted here.

### N02 — Civil/simulation clock, timezone inverse and invalid-scene recovery

**Nature / runtime:** partly-explicit; active

**Source**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:864–989` — simNow; initSim; zoneDay; epochForTzTime; simulationReady
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3533–3544` — SalahClock.set

**Retained state**

- TIMESCALE/ADVANCING/FOLLOW_WALL_CLOCK/_clockPreview; monotonic origin _rafT0 and _simBase/_simTz; _simValid/_simInvalidTz; cached parts formatter; four-entry _zoneDays Map; _simHidden Map and previous simclock display

**States**

- live wall clock
- frozen explicit local time
- advancing explicit clock
- runtime paused preview
- invalid local-time projection
- recovered after zone/anchor change
- hidden dependent presentation

**Events / transitions / guards / effects**

- fragment clock configuration → select wall/frozen/advancing origin; simulated wall time must have one exact inverse in its zone
- timezone day profile → enumerate bounded UTC minutes → zero/multiple matches reject gaps/folds instead of choosing arbitrary UTC
- simulationReady false → remember inline visibility and hide dependent layers/rows; valid recovery restores prior inline values
- SalahClock.set validates supported finite UTC and nonnegative finite rate → explicit live/preview transition → invalidate real-sky/preview/native scene → refresh prayer/render and notify; return to live replaces preview weather through normal cache/admission

**Invariants**

- One epoch feeds prayer, calendar, atmosphere and moon. Request deadlines use monotonic real time independently of timeScale. Ambiguous/nonexistent local clock times are unavailable, not silently moved. Clock control does not turn forecast data into a current observation.

**Cancellation / expiry / error / recovery / termination**

- Invalid simulation is sticky for the same invalid zone until zone/anchor change. Rebase resets origins rather than accumulating hidden elapsed simulation. Profile cache evicts old entries at four. The public setter throws/rejects invalid input before changing state. Page teardown ends caches.

**Dependencies**

- Intl Gregorian/Latin projection support
- N01 adopted timezone
- N03 monotonic deadlines
- N05 day recovery
- N09 weather lane
- N12 moon epoch identity
- N15 cloud anchor
- renderer invalidation hooks

**Disposition:** inspected-protection

**Correctness / concrete inspection:** The exact-inverse converter rejects DST folds and gaps. UTC construction uses setUTCFullYear to preserve small years in the core inverse. partsInTz has a host-local fallback on formatter failure, but normalized configuration/admitted prayer zones and simulation guards constrain that path; no ordinary invalid-zone counterexample was established. tomorrowStr is a compatibility helper, not a separate retained-state machine.

**Security / privacy:** Intl is used locally. No external timezone content becomes executable. Invalid values do not gain publication authority.

**Performance / scale:** A new inverse profile scans 4,321 UTC minutes; four profiles bound retained memory, but cold conversion is synchronous main-thread work. Bounded CPU admission is still checked against lease deadlines afterward.

**Architecture / debt:** Explicit clock API and derived boolean flags share one origin. Cache key includes calendar day and zone. Independent control flags make preview/live distinction auditable.

**Direction / design:** Preserve prayer exactness across DST and Gregorian years, and preserve explicit simulation labels. Do not trade rejection for a convenient guessed local offset.

**Relevant existing tests**

- tests/r0007-countdown.cjs
- tests/r0008-timezone.cjs
- tests/r0020-clock.cjs
- tests/real-sky/native-rate-availability.test.mjs

**Tests / validation scope:** Relevant tests are pointers to existing coverage, not assertions that each file passed. Parent owns broad regression adjudication. Locally executed join probes are identified explicitly.

**Verification gap / remaining risk:** Intl behavior across all supported browsers/historical offset transitions was not exercised here. Cold profile cost needs browser timing if performance becomes a user-visible issue; no new defect asserted.

### N03 — Request ownership and bounded attempt leases

**Nature / runtime:** explicit; active

**Source**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:1012–1094` — _requestSlots; beginRequest; beginAttempt; fetchTimings; beginRuntimeGeneration
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:1336–1367` — wxFetchJson; wxAttemptState

**Retained state**

- runtime generation; monotonic operation/attempt serials; four request slots; operation-captured target/cache keys; active attempt controller, deadline, timer, expired flag and cancel closure; weather diagnostic last-result records; prayer retries budget

**States**

- slot idle
- operation owns slot
- attempt active
- response body pending
- retry backoff
- timed out/cancelled
- stale generation/slot
- completed/released

**Events / transitions / guards / effects**

- beginRequest claims only the requested kind’s empty slot and captures generation/config identity
- beginAttempt attaches one bounded deadline and AbortController; eligibility requires current operation, exact attempt identity and time before deadline
- fetchTimings keeps one operation across at most three total attempts, including timezone-corrected day; failures back off, late body/fetch settlements cannot publish
- wxFetchJson one-shot finish detaches timer/cancel and observes late settlements; generation reset clears slots before cancelling old work; finishRequest only releases its own slot

**Invariants**

- Cancellation and publication eligibility are separate. Same target after A→B→A is a different generation. An old finally cannot clear a replacement operation. Parsing/admission time counts toward deadline. Weather, radar and prayer do not share one global busy flag.

**Cancellation / expiry / error / recovery / termination**

- Deadline rejects/aborts once; stale fulfilment/rejection is contained. Retry backoff sleep is not physically cancelled but rechecks eligibility before dispatch. Owner-only finally releases busy/current slots. Generation change resets stale cooldown/busy state.

**Dependencies**

- N01 generation changes
- N02 performance clock
- N04/N05 prayer transport
- N08 weather
- N10 radar
- AbortController/fetch/body promises

**Disposition:** inspected-protection

**Correctness / concrete inspection:** Source explicitly guards after fetch, after JSON body, after expensive admission, before persistence and on release. A late response to a previously identical target cannot pass generation identity. Timed-out promises retain handlers, avoiding an unhandled late rejection. Parent’s isolated R0005 retry passed unchanged; the concurrent 300ms VM timeout is not evidence of this machine failing.

**Security / privacy:** Each API request target is derived from configured scalar inputs. Response data must pass downstream structural admission; request completion alone is never a trust grant.

**Performance / scale:** Four kind-specific slots bound active operation count; each attempt has a 10s bound. Logical cancellation may leave provider or image work consuming resources until underlying platform settlement; publication remains safe. Backoff wakeups are finite.

**Architecture / debt:** This is already an explicit protocol embedded in the script. Preserve it as a shared lease service in any GDOPL extraction; do not substitute booleans for owner identities.

**Direction / design:** Keep cancellation cheap and stale publication impossible without forcing independent data providers to wait for each other.

**Relevant existing tests**

- tests/r0003-ownership.test.cjs
- tests/r0004-currentness-controls.test.cjs
- tests/r0005-adoption.test.cjs
- tests/r001f-deadline.cjs
- tests/r000d-weather.test.cjs

**Tests / validation scope:** Relevant tests are pointers to existing coverage, not assertions that each file passed. Parent owns broad regression adjudication. Locally executed join probes are identified explicitly.

**Verification gap / remaining risk:** Native networking abort behavior and exact timing are not proved by VM doubles. Parent is classifying stale extraction failures in historical scripts. No new lease defect found.

### N04 — Current prayer acquisition, admission/cache and adopted-zone reconciliation

**Nature / runtime:** partly-explicit; active

**Source**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:990–1127` — admitPrayerRecord; _prayerAdmissions; readPrayerCache; savePrayerCache
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:1145–1178` — adoptPrayerBundle
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3436–3474` — loadPrayerData

**Retained state**

- today and tomorrow records; lastDate; adopted tz versus frozen cache-key tz; _prayerRecordsGeneration; _prayerAdmissions WeakMap; selected localStorage envelope; current request operation; corrected-day/retry budget; render-dirty and moon/star invalidation flags

**States**

- no admitted current record
- cache candidate
- cache usable for current civil day
- network candidate
- timezone adopted/day unresolved
- one corrected-day request
- current admitted
- unavailable/offline
- superseded

**Events / transitions / guards / effects**

- network/cache candidate → strict six clocks, optional Sunset, exact Gregorian date and valid IANA zone admission; malformed optional Hijri becomes unavailable
- load selected cache only → validate each record, adopt known zone, recompute requested local day and render usable data
- network response is eligible → adopt metadata zone → recompute day from simNow in that zone; if different, request corrected day once within original three-attempt budget
- eligible exact current day → publish today/generation/date, reset matching cooldown, save admitted data and invalidate dependent geometry; failure retains only a still-current valid record

**Invariants**

- No malformed, wrong-day, wrong-zone or old-generation record is current. Equal/reordered finite clocks remain admissible. Cache hydration never bypasses the same admission. An AH failure cannot poison valid prayer times or manufacture a date. Cache namespace remains the user’s selected configuration key.

**Cancellation / expiry / error / recovery / termination**

- Network retries/deadlines use N03. Cache parse/storage exceptions are caught. A still-usable cache can continue across network failure; stale current data is withdrawn by N05. Reconciliation does not loop unboundedly across provider zones. WeakMap entries follow record lifetime.

**Dependencies**

- N01 bind/cache key
- N02 exact day conversion
- N03 current-operation lease
- N05 rollover
- N06 model
- N07 calendar
- localStorage

**Disposition:** inspected-protection; NF01 is a downstream consumer violation, not a reason to reject valid reordered input

**Correctness / concrete inspection:** Admission preserves the declared polar/reordered contract. The next-day model later violates that contract (NF01), while this producer correctly admits the probe. Cache admission and publication are separate; selected record identity is rechecked before use. A mutated admitted record object would invalidate WeakMap assumptions, but no production mutator of admitted timing fields was found.

**Security / privacy:** Provider label/date text is rendered through textContent or escaping. Local storage is untrusted input and re-admitted. Remote fields do not authorize local actions.

**Performance / scale:** WeakMap avoids repeated parsing/validation for immutable record identities. Cache may save both days but is not unbounded; no scan of arbitrary storage keys.

**Architecture / debt:** Producer owns metadata-zone adoption and currentness, with a stable selected cache key. The clock and requested-day reconciliation are intentionally coupled; keep that ownership explicit.

**Direction / design:** Do not fix downstream order selection by inventing/reordering the provider’s dates or prohibiting legitimate polar clocks.

**Relevant existing tests**

- tests/r0002-admission.test.cjs
- tests/r0005-adoption.test.cjs
- tests/r0005-day-return.test.cjs
- tests/r0004-boot-day.test.cjs
- tests/hotfix-prayer-weather.test.cjs

**Tests / validation scope:** Relevant tests are pointers to existing coverage, not assertions that each file passed. Parent owns broad regression adjudication. Locally executed join probes are identified explicitly.

**Verification gap / remaining risk:** Provider coverage/reality is not established by admitted synthetic payloads. Native persistence and quota behavior were not exercised. Immutability is conventional rather than enforced by freezing.

### N05 — Prayer day rollover, next-day prefetch and cooldown

**Nature / runtime:** implicit; active

**Source**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:1128–1205` — currentPrayerDay; nextPrayerDay; prefetchPrayerDay; maintainPrayerDay; _prayerCooldown
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:2197–2207` — today/tomorrow; fetchingTomorrow; rollover flags
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3638–3645` — render loop maintains civil day

**Retained state**

- today/tomorrow; lastDate; per-kind day cooldown timestamps; _rolloverBusy/_rolloverNextTry; fetchingTomorrow; stale flag; current/prefetch request owners; generation stamp

**States**

- today current, tomorrow absent
- next-day prefetch active
- tomorrow admitted
- civil day changed
- promoted next day
- recovery pending
- cooldown after failure
- no current data
- stale asynchronous response

**Events / transitions / guards / effects**

- maintenance recomputes civil day every loop; current record already matches → preserve it
- day changes → promote exact admitted tomorrow or hydrate exact cache; otherwise mark stale/withdraw current consumers and start bounded current recovery
- prefetch starts only for exact next day and only when no owned prefetch/cooldown blocks it
- prefetch settlement is classified against current civil day again: formerly tomorrow may now become current; next-day zone mismatch cannot rebind current zone
- failed per-day recovery → 60s monotonic cooldown; success resets relevant cooldown and requests next future day when needed

**Invariants**

- Civil midnight is an ownership event, not just a label change. A late prefetch can promote only if its date/zone is current at settlement. A next-day record cannot change present timezone. Concurrent current/prefetch completions cannot overwrite a ready current record arbitrarily.

**Cancellation / expiry / error / recovery / termination**

- No data → truthful unavailable rows and independent weather/celestial rendering. Failed recovery retries after cooldown, not every frame. Generation invalidation cancels both kinds. Exact date helpers handle month/year rollovers.

**Dependencies**

- N02 civil date
- N03 kind leases
- N04 admitted records/cache
- N06 unavailable rendering
- N07 next-day Hijri
- N19 loop cadence

**Disposition:** inspected-protection; cross-machine NF02 trigger

**Correctness / concrete inspection:** The source protects the midnight interval and permits a late owned next-day result to become today. The no-current state is a legitimate long-lived outage state; it is exactly the state in which N15 cloud expiry is bypassed (NF02). This is not a reason to retain yesterday’s prayer rows.

**Security / privacy:** Untrusted cache/network records undergo exact date/zone admission. Cooldown metadata is in memory and does not increase external permission.

**Performance / scale:** At most one current and one prefetch operation; 60s retry backoff prevents an offline frame-rate request storm. Maintenance remains synchronous and bounded.

**Architecture / debt:** Several flags mirror slots/cooldowns; future extraction should encode recovery and prefetch as parallel regions under the civil-day identity rather than merge them into one global loading state.

**Direction / design:** Retain both truthful prayer withdrawal and independent weather cleanup during outages; never solve coupling by keeping stale prayer data current.

**Relevant existing tests**

- tests/r0004-boot-day.test.cjs
- tests/r0005-day-return.test.cjs
- tests/r0006-recovery.test.cjs
- tests/r0003-ownership.test.cjs

**Tests / validation scope:** Relevant tests are pointers to existing coverage, not assertions that each file passed. Parent owns broad regression adjudication. Locally executed join probes are identified explicitly.

**Verification gap / remaining risk:** Targeted NF02 uses model-unavailable as a controlled boundary; a full native midnight/offline reproduction remains an acceptance case. Clock jumps across multiple days depend on the same exact-day checks; no new day-owner defect found.

### N06 — Prayer model, next-event countdown and DOM publication

**Nature / runtime:** implicit; active

**Source**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:2213–2265` — prayerDayFields; model
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:2269–2393` — drawArc
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3246–3298` — withdrawPrayerPresentation; render; _lastRender

**Retained state**

- accepted today/tomorrow and generation; derived current/next event for current epoch; last rendered receipt; dirty/render-second controls; prior progress width and transition style; row classes, arc markup and accessible countdown text

**States**

- current timetable absent
- current timetable accepted but next exact epoch unavailable
- countdown available
- next event within today
- after last current-day waypoint
- Sunrise → Forenoon derived interval
- withdrawn
- last-render receipt published

**Events / transitions / guards / effects**

- valid current day/zone/generation → sort six events by clock minutes → choose first later event
- after today’s last event → validate tomorrow’s date but unconditionally choose Fajr; exact unique local inverse supplies nextEpoch
- nextEpoch absent/nonfuture → Countdown unavailable; valid epoch → UTC-based remaining time and wall-cycle progress
- render unavailable → clear name/next/arc/rows/bar and receipt; render valid → update texts/row classes/theme and capture actual consumed timetable/epoch/generation
- first progress hydration temporarily disables width transition; subsequent progress transitions remain under CSS motion/fast policy

**Invariants**

- Displayed next event should be the chronological first accepted future event, including across midnight. Countdown uses actual target UTC rather than nominal wall-clock difference. A receipt must describe the frame consumed, not a later recomputation.

**Cancellation / expiry / error / recovery / termination**

- Next-day missing or DST ambiguous → no fabricated countdown. Current data invalid → complete withdrawal. Recovery on next admitted record invalidates render. No independent timer; N19 drives publication.

**Dependencies**

- N02 clock/inverse
- N04/N05 accepted day records
- N07 calendar
- N17 theme publication
- N18 geometry fitting
- N19 render scheduling

**Disposition:** reproduced defect NF01; other stated guards inspected

**Correctness / concrete inspection:** NF01: source sorts today, but lines2244–2245 hardcode tomorrow.Fajr. With both actual ingress admissions successful, 23:00 + tomorrow Isha00:31/Fajr05:00 gives Fajr/360m instead of Isha/91m. Normal-order control gives correct Fajr/360m. This is a synthetic accepted-envelope counterexample, not evidence that a live provider returned it. Before today’s first event, currentKey also defaults Isha; reordered historical identity is not fully represented.

**Security / privacy:** Arc/prayer labels are fixed names and admitted clocks; date display escapes provider data. No clock string is executed.

**Performance / scale:** Per-second publication rewrites small arc/rows; list has six items. Geometry fitting is separately cached. This audit does not propose broad DOM optimization without measured native cost.

**Architecture / debt:** Model is a derived region until it publishes retained DOM/receipt. The after-last transition is special-cased differently from the within-day sorted selector; a chronological event selection contract is the narrow repair boundary.

**Direction / design:** Repair must preserve equal clocks, polar cases, unique UTC inverse, Sunrise ring/Forenoon behavior and arc geometry. Rejecting legitimate reordered data would violate the producer contract.

**Relevant existing tests**

- tests/r0002-admission.test.cjs
- tests/r0007-countdown.cjs
- tests/r0018-prayer-row-status.test.cjs
- tests/r000a-markers.test.cjs
- tests/real-sky/native-prayer-arc-samples.test.cjs

**Tests / validation scope:** Relevant tests are pointers to existing coverage, not assertions that each file passed. Parent owns broad regression adjudication. Locally executed join probes are identified explicitly.

**Verification gap / remaining risk:** New local proof: evidence/probes/native/join-probes.cjs → NF01. Native visual/semantic acceptance after a future fix remains required. Timeline progress uses a wall cycle even when next epoch is unavailable; no separate defect is asserted without a stricter presentation contract.

### N07 — Calendar publication and date disclosure

**Nature / runtime:** implicit; active

**Source**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:768–862` — calendarFields; selectCalendarDisplay; renderCalendarDates; bindDateDisclosure
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:576–588` — calendar/date-disclosure markup

**Retained state**

- _lastDateTruth painted receipt; _dateDisclosureBound; _dateInitiator; native dialog.open and focus target; rendered summary/title; admitted current/next AH records

**States**

- date unavailable
- pre-Maghrib current AH
- post-Maghrib next AH admitted
- post-Maghrib next AH unavailable
- optional tomorrow preview
- disclosure closed/open

**Events / transitions / guards / effects**

- exact current Gregorian day/zone is admitted → compute summary; no accepted record → unavailable
- Maghrib boundary → use only explicitly admitted next civil day’s Hijri fields; missing next AH stays unavailable, never incremented arithmetically
- render → escape provider text and update visible/accessible summaries plus _lastDateTruth
- one-time binding → either date trigger opens native modal and retains initiator; close button/native Escape → close event restores connected initiator focus and clears reference

**Invariants**

- Gregorian/Hijri domains validate separately. A prayer record’s date and zone own calendar publication. No guessed Hijri roll-forward. DOM receipt describes actual displayed choice. Focus restoration cannot target a detached initiator.

**Cancellation / expiry / error / recovery / termination**

- Missing/malformed optional Hijri is explicitly unavailable while prayer remains usable. Subsequent admitted next record or clock transition recovers date. Dialog state follows native close events; listener binding is idempotent. No independent fetch/timeout.

**Dependencies**

- N02 epoch and Gregorian day
- N04 admitted date records
- N05 next-day availability
- N06 current model Maghrib boundary
- native HTMLDialogElement

**Disposition:** inspected-protection

**Correctness / concrete inspection:** The successor AH is selected only from an exact admitted next-day record. Structural AH validation does not assume astronomical month length or derive a new AH date. Render-time text is escaped; both date triggers restore their own recorded focus. Disclosure native/browser behavior is not emulated by VM recordingDocument.

**Security / privacy:** Provider strings are escaped through escHtml/textContent. Opening explanatory text gives no authorization to remote content.

**Performance / scale:** Projection is small and bounded; idempotent event wiring avoids duplicate close/open effects. Retained receipt is one value, not an event log.

**Architecture / debt:** The calendar classifier is a derived region; the retained publication plus native dialog/focus protocol makes this one co-owned behavioral machine. Keep AH source provenance with the painted result.

**Direction / design:** Preserve Maghrib policy, no invented AH values, unclipped footer and native keyboard accessibility.

**Relevant existing tests**

- tests/r0009-date-selection.cjs
- tests/r0019-date-disclosure.cjs
- tests/r0001-date-sinks.cjs
- tests/r0002-admission.test.cjs

**Tests / validation scope:** Relevant tests are pointers to existing coverage, not assertions that each file passed. Parent owns broad regression adjudication. Locally executed join probes are identified explicitly.

**Verification gap / remaining risk:** Historical date/disclosure test extraction currently has parent-adjudicated failures. Source inspection is not native modal focus, viewport or footer-pixel acceptance; no new calendar defect asserted.

### N08 — Weather acquisition, current/forecast records and persistent cache

**Nature / runtime:** partly-explicit; active

**Source**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:1207–1404` — admitWeatherRecord; admitWeatherTrack; weatherEligibility; captureWeatherTarget; loadWx; fetchWeather
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:1481–1505` — wxAt; syncWeather
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3419–3434` — startWeather

**Retained state**

- weather current record; weatherTrack ordered epochs/quantities; source and received timestamps; lastWxAt/lastWxTry/wxBusy; siteElev; _wxTargetCache; selected storage envelope; captured target/units/request zone; generation-owned weather lease

**States**

- no data
- cache candidate
- fresh admitted current
- forecast track independently admitted
- current unavailable while track exists
- request pending
- response rejected
- retry cooldown
- explicit SIM/forecast playback

**Events / transitions / guards / effects**

- load current key → parse and re-admit cached scalar/track data under captured target and units; six-hour cache retention does not extend current freshness
- refresh requires coordinates, live acquisition mode, no owned request and freshness/retry guards → one bounded transport attempt
- response units/zone/shape and all required finite ranges pass → independently admit current and ordered aligned hourly track; final lease check → publish/cache and dirty render
- current eligibility requires matching generation/coordinates and nonnegative source/receipt ages ≤15min; normal live selectedWeather never substitutes hourly data
- explicit preview uses wxAt interpolation/nearest category and forecast provenance; returning live clears/reloads through current admission; simWx has an explicit simulation lane

**Invariants**

- A received response is not freshness. Forecast never overwrites live current. Missing optional quantities remain unavailable, not fabricated zero. Cache and network use the same admission rules. Coordinates/location evidence retain original custody and age.

**Cancellation / expiry / error / recovery / termination**

- Malformed body/zone/units or timeout → owner released, existing current retained only if still eligible; retry no sooner than60s. Current expiry removes selection even if cached for longer. Generation reset clears current/track state. Unavailable optional temperature does not discard admitted cloud quantities.

**Dependencies**

- N01 units/config
- N02 forecast clock
- N03 attempt lease
- N09 truth decision and header
- N15 cloud field
- N17 atmosphere
- config.js locationEvidence
- generated acceptedElevation hook

**Disposition:** inspected-protection

**Correctness / concrete inspection:** The code separates current and hourly record admission and checks response timezone consistency before using ambiguous wall timestamps. Both receipt age and provider time must be fresh. Missing temperature can coexist with valid cloud cover. Generated build adds acceptedElevation only after eligible adoption and selected current state (tools/build_native.py:66–70), not on a stale response.

**Security / privacy:** Requests expose configured location to the declared weather provider as intended. Body fields are typed/range admitted; text is not executed. Cache is untrusted and re-admitted. No secrets found in this owner.

**Performance / scale:** One weather operation at a time with10s body lease and60s retry bound. Hourly arrays are linear validation/interpolation; no explicit length cap exists beyond provider response sizing, a potential response-size resource limit if that trust boundary changes.

**Architecture / debt:** Current and forecast are distinct state regions with shared transport, not competing writers of one live truth. Preserve this distinction during any extraction.

**Direction / design:** Retain labelled model conditions and supporting admitted quantity policy; never transform hourly forecast into on-site observation authority.

**Relevant existing tests**

- tests/r000c-weather.test.cjs
- tests/r000d-weather.test.cjs
- tests/r0024-weather.test.cjs
- tests/r0024-response-zone.test.cjs
- tests/r0024-cloud-expiry.test.cjs
- tests/real-sky/cp9-elevation.test.mjs

**Tests / validation scope:** Relevant tests are pointers to existing coverage, not assertions that each file passed. Parent owns broad regression adjudication. Locally executed join probes are identified explicitly.

**Verification gap / remaining risk:** Provider service availability/coverage and native CORS/storage behavior were not qualified. Response-size cap is a bounded architectural risk, not a demonstrated failure. NF02 concerns cloud consumer withdrawal, not freshness admission.

### N09 — Weather truth/source selection, fixture expiry and header publication

**Nature / runtime:** partly-explicit; active

**Source**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:1544–1763` — weatherSynthetic; admitWeatherFixture; reconcileWeatherEvidence; weatherDecision; weatherInformation; paintWeatherHeader

**Retained state**

- weatherSynthetic (null in ordinary runtime; fixtures have no normal setter); _wxDecisionCache with expiry boundary; _weatherInformationCache; _lastWeatherHeader; current target/evidence identity; displayed icon, temperature, weather-info description and DOM attributes

**States**

- live no current
- fresh model-estimated current
- explicit forecast/SIM preview
- qualified synthetic present wet/dry/unknown/conflict
- nearby/approach/forecast derived regions
- expired evidence
- cached decision until earliest boundary
- header published/cleared

**Events / transitions / guards / effects**

- capture target → reconcile independently admitted current/fixture/forecast facts and provenance
- synthetic fixture accepts only named QA scope/provider, exact target/generation, qualified point observation, bounded source/receipt/validity and device age/accuracy; ordinary runtime retains null fixture
- decision cache key includes source objects/identity/lane; expiration is minimum of relevant source/receipt/spatial/forecast boundaries; expiry forces recomputation
- fresh live current model may permit model rain/snow only with quantity; lightning requires explicit eligible present evidence or explicit simulated thunder
- header projection → one paint updates icon, temperature and accessible explanatory text; unavailable current removes stale current header even without prayer model

**Invariants**

- Current condition, model-effect permission and direct-observation authority remain distinct. Uncalibrated radar grants none. A cached decision cannot outlive its earliest warrant. Preview remains labelled. Measurement describes interval amount, never invents instant intensity.

**Cancellation / expiry / error / recovery / termination**

- Expired or mismatched evidence is withdrawn on the next decision. Unknown/conflict is not coerced to dry. Source cache eviction/replacement is bounded to one value. Header can recover independently from prayer admission.

**Dependencies**

- N08 admitted weather
- N10 radar diagnostic only
- N02 preview lane
- N01 location evidence identity
- N15/N16 effect consumers
- N17 diagnostics

**Disposition:** inspected-protection; cross-machine NF02 shows incomplete propagation to one consumer

**Correctness / concrete inspection:** The NF02 probe confirms header clears when modelCode becomes null, even while cloud coverage retains an older value elsewhere. This is useful isolation evidence: eligibility/decision/header behave as written. Synthetic present fixture is a dormant controlled-test region, not a deployed observation provider or a separately counted machine.

**Security / privacy:** Source names, capability fields and spatial/temporal evidence are strictly admitted. The human-facing description is text, not HTML from a provider. Device timestamps are copied rather than renewed by settings persistence.

**Performance / scale:** Single-entry decision/information/header memoization avoids repeated long description construction while respecting expiry. Temperature/icon equality alone is not the cache key, so provenance/age changes can invalidate.

**Architecture / debt:** Pure categorical functions are derived regions within a retained decision/publication protocol. Make consumer expiry propagation explicit without merging model data and observation claims.

**Direction / design:** Truthfulness is a hard constraint: no generic state-machine rewrite may collapse current, forecast, radar and direct evidence into a single weather status.

**Relevant existing tests**

- tests/r0024-information.test.cjs
- tests/r0024-weather.test.cjs
- tests/r000c-weather.test.cjs
- tests/r0024-cloud-expiry.test.cjs

**Tests / validation scope:** Relevant tests are pointers to existing coverage, not assertions that each file passed. Parent owns broad regression adjudication. Locally executed join probes are identified explicitly.

**Verification gap / remaining risk:** Source/stub evidence cannot qualify icon descriptions or optical readability in a real native page. Device/location provenance implementation itself is owned by config lane.

### N10 — Radar diagnostic transport, image lease and expiry

**Nature / runtime:** implicit; active

**Source**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:1405–1478` — weatherRadar; radarEvidence; wxRadarSample; fetchRadar; radarPrecipNow

**Retained state**

- weatherRadar frame/receipt/sample/target; lastRadarAt/radarBusy; metadata and image attempts; temporary Image plus handlers and canvas sample; diagnostic request receipt

**States**

- no sample
- metadata fetching
- metadata admitted
- image loading/decoding
- bounded sample available
- image/body timeout
- sample stale
- refresh cooldown
- superseded

**Events / transitions / guards / effects**

- usable location and10min refresh guard → claim radar operation and bounded manifest attempt
- choose latest eligible frame → new bounded image attempt → decode at captured tile coordinates → sample7×7 only while same owner/attempt remains eligible
- one-shot finish clears timer/cancel and detaches image handlers; owner finally releases radarBusy
- sample is exposed only while source frame and receipt ages are ≤20min and exact target still current; radarPrecipNow always returns0

**Invariants**

- Radar color/alpha is diagnostic, never a quantitative precipitation or lightning claim. Both metadata and image decode belong to one captured target. A late image cannot publish after cancellation/timeout.

**Cancellation / expiry / error / recovery / termination**

- Manifest/image/CORS/canvas error → no sample and finite cooldown. Generation cancels publication. Image network request may physically finish after handlers are detached. Expiry hides stale evidence; no special prayer dependency.

**Dependencies**

- N03 request/image lease
- N08 target coordinates
- N09 diagnostics/provenance
- Image/canvas/CORS
- RainViewer manifest/tile hosts

**Disposition:** inspected-protection

**Correctness / concrete inspection:** The two-stage request budget prevents an unbounded body or image wait. Frame time is checked separately from index generation. Uncalibrated palette/alpha remains quarantined even with positive pixels; no permissions flow from this sample into live weather effects.

**Security / privacy:** Manifest-provided host/path creates an external image-request boundary with anonymous CORS. Source only checks their types, not a fixed allowlist; this is trust in the selected public provider, not a demonstrated injection/credential leak. No secret values are emitted.

**Performance / scale:** At most one radar operation; 7×7 sampling is bounded. Failure records refresh time so persistent failure does not retry every frame. Detached image may still consume network until browser cancellation/settlement.

**Architecture / debt:** Metadata and image are sequential substates; keeping them under one operation avoids cross-location tile admission. Diagnostic sample should not become an implicit authority later.

**Direction / design:** Retain radar quarantine until a qualified quantity/coverage decoder exists; do not infer on-site rain from a colored tile.

**Relevant existing tests**

- tests/r000c-weather.test.cjs
- tests/r000d-weather.test.cjs
- tests/r0017-transport.cjs

**Tests / validation scope:** Relevant tests are pointers to existing coverage, not assertions that each file passed. Parent owns broad regression adjudication. Locally executed join probes are identified explicitly.

**Verification gap / remaining risk:** No real cross-origin image/canvas behavior or provider host compromise test. Exact native resource reclamation after detachment remains a browser concern; no current product defect asserted.

### N11 — Legacy lunar texture/canvas fallback readiness (dormant generated owner)

**Nature / runtime:** implicit; dormant-generated-compatibility

**Source**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:1812–1945` — legacy texture loader; _pbrReady/_pbrPending/_pbrFailed; renderMoonPBR; renderMoonCalendarFallback
- `/workspace/scratch/8ab1bbbe9699/salah_widget/tools/build_moon.py:120–137` — generated modern runtime/refinement integration

**Retained state**

- _mAlb/_mNrm; legacy canvas/context/output; _pbrReady/_pbrPending/_pbrFailed; _fallbackReady; cached phase/wax/up/albedo render arguments; Image callback closures

**States**

- legacy maps loading
- one map decoded
- both maps ready
- pending render parameters
- legacy render cached
- legacy fallback failed/ready
- modern runtime present → callback no-op/delegation

**Events / transitions / guards / effects**

- source-only loader creates two data-image decodes; both success → PBR ready → consume latest pending request; error → terminal legacy failure and calendar fallback
- renderMoonPBR sees modern SalahMoonRuntime → request modern surface and return; image success/error callbacks also return if modern runtime exists
- source-only PBR request before maps ready stores newest parameters; after readiness renderer caches arguments; modern host surface readiness is independently queried

**Invariants**

- Legacy decoded data is not modern terrain readiness. Generated app must not replace a missing modern surface with the old approximate texture. Latest pending request wins while legacy maps decode.

**Cancellation / expiry / error / recovery / termination**

- Standalone legacy error selects fallback; no retry or image timeout exists in that dormant path. Modern runtime suppresses both callbacks and owns its own recovery. The page owns canvases/cache lifetime.

**Dependencies**

- N12 geometry input
- N13 visible surface contract
- modern moon runtime installed by generator
- data-image decoding/canvas

**Disposition:** compatibility-only inspection; excluded from active generated renderer finding count

**Correctness / concrete inspection:** Both callbacks explicitly short-circuit on SalahMoonRuntime, and renderMoonPBR delegates. Therefore potential legacy no-timeout/cache-after-exception weaknesses do not establish active generated-app defects. The source block is catalogued because it retains state and can execute if source is opened standalone; it is not the current renderer owner.

**Security / privacy:** Embedded data PNGs are artwork, not secrets or executable remote input. No reproduced credential exposure.

**Performance / scale:** Two embedded decodes and legacy canvases are bounded. Generator still includes compatibility bytes; startup/byte-cost optimization belongs to delivery qualification, not an assumed visual-safe deletion.

**Architecture / debt:** Keep native compatibility and generated modern owner separate. Counting both renderers as active machines would inflate the catalogue and misattribute recovery behavior.

**Direction / design:** No repair recommendation for the dormant path without a supported standalone-entry contract. Never use fallback to bypass modern terrain readiness.

**Relevant existing tests**

- tests/moon-fixture-anchors.test.cjs
- tests/real-sky/moon_build_guard_test.py
- tests/real-sky/native-lunar-component.test.mjs

**Tests / validation scope:** Relevant tests are pointers to existing coverage, not assertions that each file passed. Parent owns broad regression adjudication. Locally executed join probes are identified explicitly.

**Verification gap / remaining risk:** Standalone fallback pixels and failure recovery were not exercised. Modern runtime correctness belongs to rendering lane; no active defect assigned.

### N12 — Native lunar geometry production and actual-consumption receipts

**Nature / runtime:** partly-explicit; active

**Source**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:1951–2025` — moonGeometryIdentity; moonGeometryObservation; nativeLunarSnapshot; renderMoon
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3126–3137` — _lastMoonPaint; applyTheme
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3925–3941` — SalahMoonHost capture/publish/fallback

**Retained state**

- moonSky geometry plus produced epoch/local-minute/location/tz stamp; lastMoonMin; _moonStaleWarned; _lastMoonPaint status/observation; moon and mask transforms; host captured generation/scene/phase/visibility/ratio/rate

**States**

- no fresh geometry
- requested geometry
- finite production stamped
- stale geometry detected
- theme attempt started
- theme completed/failed
- current modern surface published

**Events / transitions / guards / effects**

- renderMoon computes finite lunar snapshot from one date/location/zone and explicit overrides; writes matching moon/mask transforms and then stamps successful production
- consumer asks moonGeometryObservation against current epoch/local minute/location/tz; stale produces a warning once and request for fresh geometry rather than backfilling receipt
- applyTheme captures actual observation into last-attempt receipt; completion/failure updates that captured record
- SalahMoonHost.capture returns current snapshot and visibility/rate/warrant; publish writes canvas image href then re-evaluates native surface readiness

**Invariants**

- Produced identity and requested identity are separate. A fresh stamp is evidence of completed production, not of an attempted call. Moon body and star cutout geometry are identical. Last-consumed diagnostics never silently become a recomputed successful frame.

**Cancellation / expiry / error / recovery / termination**

- Config/day/clock changes reset relevant minute/scene markers. Failed finite production does not advance successful marker. Modern surface recovery is delegated to renderer; native fallback callback only re-evaluates readiness. Page lifetime owns diagnostic receipt.

**Dependencies**

- N02 sole epoch
- N01 target generation
- N13 scene/surface warrant
- N17 optical publication
- modern moon runtime/terrain receiver
- N19 rate/visibility

**Disposition:** inspected-protection; renderer-side acceptance remains other lane

**Correctness / concrete inspection:** Native scale bounds1.11–1.13 and paired transforms are explicit host contracts. Consumption receipt is sealed at attempt time, including failure, which prevents QA from hiding stale consumption through a later recomputation. Host.publish assumes its renderer caller has already admitted identity; this native callback alone does not recheck the renderer work-item ID.

**Security / privacy:** Host API is an in-page capability, not an external message channel. canvas.toDataURL carries generated image bytes; rendering lane must maintain source ownership/currentness before calling publish.

**Performance / scale:** Moon production is minute-cadenced unless identity is stale, with explicit scene invalidation. Last receipt is bounded. Native publish synchronously encodes a canvas; renderer owns scheduling/cost.

**Architecture / debt:** This is a contract boundary with two owners: native time/geometry versus modern terrain work. Keep source/receipt identity fields together in an extracted model.

**Direction / design:** Preserve opaque ashen calendar presence for near-new/below-horizon Moon, physical light eligibility, paired mask geometry and honest surface readiness.

**Relevant existing tests**

- tests/r0022-lunar-consumers.cjs
- tests/r000b-sky-withdrawal.test.mjs
- tests/real-sky/native-lunar-boundaries.test.mjs
- tests/real-sky/native-lunar-display.test.mjs

**Tests / validation scope:** Relevant tests are pointers to existing coverage, not assertions that each file passed. Parent owns broad regression adjudication. Locally executed join probes are identified explicitly.

**Verification gap / remaining risk:** Native image readiness, opacity, mask alignment and calendar-disc pixels unverified. Any caller-before-admission race must be established in renderer lane; not inferred solely from callback simplicity.

### N13 — Sky scene identity, first-document warrant and renderer-surface commit

**Nature / runtime:** partly-explicit; active

**Source**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:167–188` — sky-pending/sky-initializing/moon-ready and mask CSS
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:2142–2179` — skySceneIdentity; beginSkyScene; finishInitialSkyDocument; updateSkySurface; commitSkyScene
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:2819–2842` — paintCelestialWithoutTimetable
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3546–3616` — boot consumes first-document warrant
- `/workspace/scratch/8ab1bbbe9699/salah_widget/tools/build_native.py:64–76` — generated invalidation/notify additions

**Retained state**

- _skySceneKey/_skyCommitted/_skyMoonPresence/_skyInitialDocument; CSS classes sky-pending,sky-initializing,moon-ready,mask-on; photo href; _starProjectionKey; renderer current surface; native/preview invalidation hooks

**States**

- initial document warrant available
- scene invalidated/pending
- current bodies/preview available without prayer
- surface pending/current
- complete atmosphere staged
- scene committed
- initial warrant consumed permanently

**Events / transitions / guards / effects**

- boot or config/explicit clock change → invalidate modern moon and generated preview/real-sky → reset native scene/star/cloud state and withdraw ready classes
- current scene key is coordinates/zone plus wall-or-explicit anchor; it intentionally excludes ordinary ticking civil day
- surface-ready class requires current runtime.surface, href and scene key; mask additionally requires lunar presence
- commit requires fresh moon observation and matching star projection → paint clouds/particle gates → force one style/layout resolution → remove transition suppression and mark committed
- no-timetable helper can publish real bodies/current catalogue and remove sky-pending; it retains initial transition suppression until full palette paint
- finishInitialSkyDocument permanently consumes first-document warrant before async providers/yield; later invalidations cannot reacquire it

**Invariants**

- No neutral/default or stale celestial target becomes visible as accepted. Initial receiver authority is single-document and one-use. Texture decode is not readiness. First complete scene resolves transforms/colors synchronously before restoring transitions.

**Cancellation / expiry / error / recovery / termination**

- Scene invalidation clears cloud coverage/density and moon ready/mask state. Absent runtime surface remains unavailable. Independent body publication permits prayer outage without whole-card loading. Complete commit waits until both geometry/catalogue identity are current.

**Dependencies**

- N01 boot/apply
- N12 geometry/modern moon host
- N14 generated star stub
- N15 coverage reset
- N17 full atmosphere
- N19 visibility
- renderer preview/currentness owner

**Disposition:** inspected-protection; exact boundary explains NF02 reachability

**Correctness / concrete inspection:** NF02 reachable schedule: same-location normal wall clock → valid cloudy scene → local midnight without usable successor prayer record → no-timetable rendering for >current-weather TTL. skySceneIdentity is unchanged by civil day (2142–2144), so the no-prayer helper’s identity-change reset at2822 does not clear clouds. Its independent-body path never calls applyCloudState. This is a source-proven route beyond the controlled model-null boundary probe.

**Security / privacy:** Surface readiness is a capability query into the trusted same-page renderer. No remote text can assert moon-ready or initial-document authority.

**Performance / scale:** Scene commit intentionally performs bounded style/layout reads once. No-prayer helper projects/current-body work may recur each render second; renderer cache owns affordability.

**Architecture / debt:** Multiple CSS classes encode parallel readiness/transition/mask regions. Their semantics are distinct; compressing them into a single ready boolean would lose single-document and opacity guards.

**Direction / design:** Preserve early truthful celestial display, mask persistence during1.2s lunar fade and no pre-gate current-state publication. Cloud expiry should not require destroying/recreating the scene.

**Relevant existing tests**

- tests/r0021-reveal.cjs
- tests/real-sky/native-celestial-startup.test.mjs
- tests/real-sky/native-first-paint.test.mjs
- tests/real-sky/native-startup-handoff.test.cjs

**Tests / validation scope:** Relevant tests are pointers to existing coverage, not assertions that each file passed. Parent owns broad regression adjudication. Locally executed join probes are identified explicitly.

**Verification gap / remaining risk:** No native first-paint/transition or star-through-moon pixel evidence. Generated hooks were inspected; renderer lane must verify their scheduling and surface identity. NF02 is code-state evidence only.

### N14 — Star projection/catalogue contract and held appearance

**Nature / runtime:** implicit; generated-contract-active; native-source-implementation-replaced

**Source**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:2027–2140` — native synthetic catalogue; projectStars; refreshStarAppearance; buildStars
- `/workspace/scratch/8ab1bbbe9699/salah_widget/tools/build_native.py:48–65` — generated real-catalogue replacement stub

**Retained state**

- Source-only _starCat/element arrays/base extinction/bright and glint index arrays/light key; shared _starsProjected/_starProjectionKey; generated stub retains only projection readiness/key and clears placeholder DOM

**States**

- source catalogue unbuilt
- source catalogue built
- projected current anchor
- invalid projection hidden
- held live positions with changing scintillation
- advancing preview reprojection
- generated real-catalogue handoff

**Events / transitions / guards / effects**

- source buildStars deterministically seeds catalogue and glints once; project invalid input hides all elements, valid input maps to local sky and stamps scene key
- ordinary live star positions are held by render policy; explicit ADVANCING or scene/date invalidation reprojects; appearance wash can change without positions
- generated build replaces entire synthetic block: buildStars clears native stars/glints/Milky placeholders; projectStars only records valid native input identity and invalidates real sky on bad input; refreshStarAppearance is no-op because real-sky owns physical lunar wash

**Invariants**

- The generated app has one real star catalogue owner, not two competing synthetic/physical renderers. Projection validity follows accepted native target/clock. Held positions in ordinary live view are intentional; motion proof depends on native visual scintillation, not repeated coordinate writes.

**Cancellation / expiry / error / recovery / termination**

- Invalid source projection hides finite pool; generated invalid projection calls renderer invalidate. Configuration/clock invalidation resets projected flags. Catalogue arrays/DOM live for page, not per refresh.

**Dependencies**

- N01 one-time scene build
- N02 simulation clock
- N13 scene commit marker
- N17 source-only local light wash
- real-sky native-host/preview (renderer lane)
- tools/build_native.py substitution

**Disposition:** generated substitution reconciled; no active synthetic-star defect

**Correctness / concrete inspection:** The exact generator replaces src/native’s synthetic implementation and keeps only a native readiness stub. Source catalogue behavior is catalogued as conditional compatibility; generated physical renderer ownership is handed to rendering lane. Allegation that ordinary held star positions alone prove frozen motion is rejected as by design; native scintillation/real-sky evidence is required.

**Security / privacy:** Source catalogue is deterministic internal data; generated catalogue assets have independent renderer admission. No external instruction execution.

**Performance / scale:** Fixed source420-star pool and small glint pool are bounded. Generated clear/build occurs once; real catalogue asset cost belongs to renderer lane. Avoid testing legacy synthetic pixel paths as current performance evidence.

**Architecture / debt:** This entry describes the native-to-renderer handoff, not a duplicate of the renderer’s projection/cache machines. _starProjectionKey is a readiness acknowledgement, not proof of presented physical pixels.

**Direction / design:** Preserve intentional live motion under accessibility rules and independent lunar wash ownership; do not reintroduce a second dimmer or synthetic fallback.

**Relevant existing tests**

- tests/real-sky/native-star-preview.test.mjs
- tests/real-sky/native-host-streams.test.mjs
- tests/real-sky/cp9-scintillation.test.mjs
- tests/real-sky/native-bootstrap.test.mjs

**Tests / validation scope:** Relevant tests are pointers to existing coverage, not assertions that each file passed. Parent owns broad regression adjudication. Locally executed join probes are identified explicitly.

**Verification gap / remaining risk:** Actual native star visibility/scintillation needs clips/pixels; this lane establishes only substitution/contract. Source-only star projection was not freshly executed.

### N15 — Cloud population, motion integration, coverage and paint cache

**Nature / runtime:** partly-explicit; active

**Source**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:2538–2680` — cloudState; _cloudMotion; cloudSceneIdentity; advanceCloudMotion; paintClouds
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3024–3042` — applyCloudState
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3645–3649` — reduced/full-motion paint cadence

**Retained state**

- stable _cloudFieldSeed and seeded population; _cloudReady; cloudState coverage/wind/tint/sun/moon; _cloudMotion identity/population/lastRt/phase/life/wander/paused/reduced; canvas/context/ImageData caches; _cloudDirty; _colDens column profile

**States**

- population not built
- new explicit scene population
- held reduced/hidden axes
- integrating visible motion
- initial healthy coverage snapped
- healthy coverage easing
- unavailable coverage withdrawn
- dirty raster
- current raster and density

**Events / transitions / guards / effects**

- identity change creates deterministic population and resets motion origin; ordinary weather and civil-day changes retain population
- advance integrates old velocity to receipt time before replacing wind; elapsed time is bounded and periodic axes wrap
- visibility or motion-preference transition rebases time, preventing a hidden-tab catch-up jump
- first available cloud deck snaps; subsequent live decks ease at0.08; advancing preview snaps; unavailable live modelCode zeroes coverage and readiness
- paint clears output/density and rasterizes bounded seeded puffs/copies; invalid identity or negligible coverage yields empty output; render-loop cadence clears dirty work

**Invariants**

- Weather refresh changes coverage/light, not cloud population. Motion uses the captured explicit clock rate and bounded real elapsed time. Reduced motion holds axes while allowing changed truthful state to repaint. Raster and particle density describe the same admitted cloud copies.

**Cancellation / expiry / error / recovery / termination**

- Configuration/explicit clock reset invalidates scene; hide/reduce rebases without losing seed; unavailable decision has a synchronous coverage withdrawal path. Canvas creation failure is not separately recovered in this owner. The page owns caches and population. NF02 identifies a caller path that never invokes withdrawal.

**Dependencies**

- N09 weatherDecision and expiry
- N13 scene identity
- N16 particle gating
- N17 atmosphere palette
- N19 visible/reduced cadence
- native-sky cloud transfer renderer contract

**Disposition:** reproduced cross-machine defect NF02; bounded motion protections inspected

**Correctness / concrete inspection:** The expiry branch itself zeros coverage correctly in the control probe. The prayer-unavailable render branch bypasses it, retaining coverage and density. Ordinary same-location midnight leaves cloud scene identity unchanged. Periodic offscreen copies are counted only when intersecting the field, so density gating follows visible cloud material rather than origin positions alone.

**Security / privacy:** Procedural population and colors are internal numeric state. No remote HTML or execution enters the cloud renderer. Provider quantities are admitted before this owner.

**Performance / scale:** A small fixed raster, reused ImageData and bounded periodic copies cap memory/work. Normal motion paints about13Hz while native UI paints by second; reduced motion paints only dirty state. No measured native frame-budget claim.

**Architecture / debt:** Scene identity, motion integration and weather eligibility are parallel state regions with distinct reset causes. NF02 should be repaired at eligibility-to-coverage publication, preserving the population/motion regions.

**Direction / design:** Preserve full-width roofline, evolving natural clouds and live full-motion behavior. Expiry must not fabricate a clear-weather claim or reconstruct the entire scene.

**Relevant existing tests**

- tests/r0024-cloud-expiry.test.cjs
- tests/r0025-continuity.cjs
- tests/r0025-lifecycle.cjs
- tests/r0017-cloud-visibility.cjs
- tests/r0024-particle-origin.test.cjs

**Tests / validation scope:** Relevant tests are pointers to existing coverage, not assertions that each file passed. Parent owns broad regression adjudication. Locally executed join probes are identified explicitly.

**Verification gap / remaining risk:** Probe establishes retained numeric coverage and raster-density calls, not native pixels. Real motion, wrap/lifetime continuity and coverage appearance still require the AGENTS native clip/visual contract.

### N16 — Precipitation population, cloud-origin gating and lightning strike bucket

**Nature / runtime:** implicit; active

**Source**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:154–168` — reduced-motion and paused CSS
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:2182–2195` — buildWeather
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:2683–2695` — _rainTiedFx; tieRainToClouds
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3222–3246` — genLightning; _lastBolt
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3294–3299` — lightning bucket publication

**Retained state**

- one-time fog/drop/flake DOM population; _rainTiedFx and per-particle inline display; CSS animation phases and paused/fast/motion classes; data-fx/data-precip/data-lightning; _lastBolt and SVG bolt paths

**States**

- population built
- effects unavailable/dry
- precipitation eligible
- density profile absent → ungated
- density profile present → visible-column gated
- lightning prohibited
- permitted bucket unchanged
- new permitted strike bucket
- hidden/reduced animation held

**Events / transitions / guards / effects**

- one-time builder creates5 fog bands,32 drops and40 flakes and orders bolt/flash above precipitation
- effect publication chooses admitted precipitation state; tieRainToClouds considers both drops and flakes, clears old inline gating on exit, and gates columns above0.16 relative density only when a real profile exists
- permitted lightning and new floor(simNow/2600) bucket → deterministic branching paths; unchanged bucket retains paths
- reduced-motion CSS removes lightning/flash and restricts animation unless explicit motion full; offscreen/hidden paused class pauses CSS animations

**Invariants**

- Forecast/model thunder and radar pixels cannot authorize live lightning. Precipitation is bounded to eligible evidence and available cloud profile; no density profile is not mistaken for proof of a clear column. One scene does not duplicate the particle pool on config apply.

**Cancellation / expiry / error / recovery / termination**

- Leaving precipitation clears retained per-particle overrides. Expiry publishes unavailable/off through the truth owner. New lightning bucket replaces bounded paths. Page teardown is terminal for CSS/DOM animation. Native CSS timing/focus does not have a JS completion callback.

**Dependencies**

- N09 evidence permissions
- N15 density profile
- N17 data-attribute publication
- N19 visibility/motion preference
- N01 build-once

**Disposition:** inspected-protection; historical selector failure rejected as fixture drift

**Correctness / concrete inspection:** The selector is .wfx .drop,.wfx .flake. Parent adjudicated the old R0025 fixture that only recognized .drop as fixture drift; newer particle-origin coverage passed. genLightning is a pure generator inside this retained bucket machine, not an independent machine. Frozen explicit simulation can retain a strike shape while CSS phase runs subject to motion policy; this alone is not a demonstrated bug.

**Security / privacy:** No live remote script or HTML enters particle paths. Direct observation permissions and preview declaration remain the only paths to lightning permission.

**Performance / scale:** Fixed particle counts and bounded recursive path generation avoid per-frame population growth. Path generation occurs once per admitted time bucket, while CSS owns interpolation.

**Architecture / debt:** CSS animation phase and element inline display are retained state even though no JS enum represents them. Keep particle gating and effect authority separate from lightning geometry.

**Direction / design:** Preserve living full-motion rain/snow/flash design under explicit accessibility controls; model-code convenience must not weaken truthfulness.

**Relevant existing tests**

- tests/r0012-effects.cjs
- tests/r0024-particle-origin.test.cjs
- tests/r0025-lifecycle.cjs
- tests/r0024-weather.test.cjs

**Tests / validation scope:** Relevant tests are pointers to existing coverage, not assertions that each file passed. Parent owns broad regression adjudication. Locally executed join probes are identified explicitly.

**Verification gap / remaining risk:** No native precipitation/flash clip or media-query visual proof. The existing selector drift is not a product defect. NF02 stale cloud density can influence this consumer only when precipitation is itself eligible; expired precipitation is correctly off in the probe.

### N17 — Atmosphere publication, optical fade state and last-consumed diagnostics

**Nature / runtime:** implicit with derived regions; active

**Source**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:2409–2523` — derived sky/weather/optical classification
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:2711–2818` — nativeSolarPresentation; lunarPresentation; paintLunarOptic
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:2843–3020` — atmosphere
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3043–3137` — paint; applyTheme; _lastMoonPaint
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3308–3391` — qaState and diagnostic publication

**Retained state**

- published CSS palette/light/opacity variables and data-fx/precip/lightning; per-optic inline visibility overrides during opacity fades; _lastMoonPaint attempt/observation/status; _wxDowngrade diagnostics; DOM diagnostic text; distinct N06 _lastRender receipt

**States**

- derived atmosphere pending
- current theme computed
- theme attempt started
- theme fully painted
- theme failed
- optic present
- optic fading to zero
- optic zero/visibility override removed
- diagnostic recomputation versus last actual consumption

**Events / transitions / guards / effects**

- one captured weather decision plus current clock/geometry → atmosphere derived values; pure code classifiers do not create additional independent machines
- applyTheme snapshots lunar production observation into the actual-consumption receipt before paint; success/failure updates that attempt rather than synthesizing a later successful observation
- paint writes a coordinated palette/effect/cloud/header/optical presentation; optional generated hooks notify physical sky after publication
- paintLunarOptic sets visibility when nonzero, and retains visible override until computed opacity reacheszero during a fade; then removes it
- qaState exposes recomputed current facts separately from last-render/last-consumed receipt; debug flags use explicitly declared fragment paths

**Invariants**

- Physical eligibility is independent of aesthetic opacity. The same lunar observation must justify every lunar consumer. A later diagnostic recomputation cannot rewrite what was consumed by an earlier failed paint. Unknown weather is not synthesized into direct observation.

**Cancellation / expiry / error / recovery / termination**

- Scene reset clears relevant availability; fresh geometry replaces stale production after warning. Paint failure is recorded then rethrown, so render-loop recovery is a separate unverified concern. CSS transition completion is observed on subsequent paint, not assumed at assignment. Diagnostics are bounded but not wholly side-effect-free because storageAvailable performs a storage probe in the config module.

**Dependencies**

- N02 epoch
- N09 truth decisions
- N12 lunar geometry/receipts
- N13 surface readiness
- N15 cloud consumer
- N16 effects
- N19 scheduling
- renderer physical solar/lunar snapshots and notify hooks
- N22 storage status probe

**Disposition:** inspected-protection; no additional independent classifier machines

**Correctness / concrete inspection:** Derived classifiers were included in this publication machine rather than inflated into an enum census. Optical fade visibility is genuine DOM-retained state. Native solar presentation prefers a current physical snapshot when available, with timetable-based fallback scoped to its contract. Debug dawn forcing is deprecated/no-op, and lunar debug opacity does not override physical eligibility.

**Security / privacy:** Diagnostic strings and provider descriptions are textContent. Same-page hooks are trusted capabilities, not postMessage input. No secret/token content was found in inspected native state; this report does not reproduce private diagnostics.

**Performance / scale:** Per-second palette writes and a few computed-opacity/layout reads are bounded; the expensive cloud/moon ownership is separately cadenced. QA recomputation should not be mistaken for a cheap immutable snapshot in measurement.

**Architecture / debt:** This joins pure derived values with imperative multi-surface publication. A future explicit model should retain started/completed/failed receipt and distinct physical/light/visibility regions, rather than one generic scene-ready bit.

**Direction / design:** Preserve below-horizon/near-new calendar-disc legibility, independent lunar light gates, physical solar state and transparent truth diagnostics. No refactor may create a second physical light dimmer.

**Relevant existing tests**

- tests/r0022-lunar-consumers.cjs
- tests/r000b-sky-withdrawal.test.mjs
- tests/real-sky/native-solar-publication.test.mjs
- tests/real-sky/native-lunar-display.test.mjs

**Tests / validation scope:** Relevant tests are pointers to existing coverage, not assertions that each file passed. Parent owns broad regression adjudication. Locally executed join probes are identified explicitly.

**Verification gap / remaining risk:** Computed CSS fade behavior, actual consumer pixels and native presentation ordering remain unverified here. A generic thrown paint exception is a possible loop-recovery gap, not a reproduced ordinary execution failure.

### N18 — Countdown font readiness, rail sampling and geometry-fit cache

**Nature / runtime:** implicit; active

**Source**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3144–3216` — _cnFit; _cnFontLoads; cnFontSignature; cnFontsChanged; fitCn

**Retained state**

- _cnFit identity; WeakMap of actual FontFace to its tracked loaded promise; font event listeners; fitCn._x measurement context; fitCn._arcSamples last path and201 local samples; DOM fitted countdown font size/placement

**States**

- fallback font registered/unregistered
- relevant font loading
- font loaded/failed
- fit invalidated/dirty
- rail measured
- fit cached
- fit dependency not available

**Events / transitions / guards / effects**

- FontFaceSet loading/change events inspect actual Fraunces/Inter faces; per-face promise success or failure clears fit key and marks render dirty, even for a frozen preview
- fit builds key from current prayer, rounded sunrise/sunset and actual face signature; unchanged key returns cached geometry
- new key measures text and arc geometry, samples/caches the current path by exact d, transforms samples into current coordinates and chooses a bounded fit
- missing required DOM returns without inventing a successful fit

**Invariants**

- An absent font family cannot be treated as loaded solely because FontFaceSet.check returnedtrue. Settling one relevant face can wake fitting without waiting for every unrelated face. Arc-sampling cache corresponds to exact path text.

**Cancellation / expiry / error / recovery / termination**

- Relevant face load success/failure invalidates cache and schedules a redraw; failures retain usable fallback font. WeakMap does not keep detached FontFace objects alive. Cached canvas/path are single-instance/page-lifetime. No explicit ResizeObserver is needed for the fixed native card contract; arbitrary embedding transforms are a verification gap.

**Dependencies**

- N06 current prayer/countdown
- arc path and native fixed325×530 geometry
- FontFaceSet/FontFace loaded promises
- N19 dirty render wakeup

**Disposition:** inspected-protection; incomplete fit-key dependency is an unverified visual hypothesis

**Correctness / concrete inspection:** The face-specific promise path addresses late stylesheet registration and stalled unrelated faces. _cnFit omits exact rail d and location/Dhuhr geometry; if a config/day transition produces identical current-key and rounded sunrise/sunset but a different rail, early return can preserve a previous fit. No actual native text collision or size error was reproduced, so this is a dependency-coverage hypothesis, not a confirmed product finding.

**Security / privacy:** Font identity is inspected locally. No font completion callback gains configuration or network publication authority; it only invalidates layout.

**Performance / scale:** One last-path201-sample cache and reused measurement context bound work. Actual FontFace promises are tracked once per observed promise. Invalidations can do bounded synchronous layout/measurement on the UI thread.

**Architecture / debt:** Readiness and geometric dependency identity are distinct regions. If a layout defect is demonstrated, use a complete semantic fit key or explicit relevant invalidation rather than clearing every cache on every tick.

**Direction / design:** Preserve the approved native type hierarchy and countdown fit. A VM measurement stub cannot approve typographic changes.

**Relevant existing tests**

- tests/r0022-paint-cost.test.mjs
- tests/real-sky/native-startup-critical-path.test.mjs

**Tests / validation scope:** Relevant tests are pointers to existing coverage, not assertions that each file passed. Parent owns broad regression adjudication. Locally executed join probes are identified explicitly.

**Verification gap / remaining risk:** Real FontFace arrival/failure, exact text/rail geometry and possible equal-key/different-path collision need native metrics/pixels. No speculative fix is authorized.

### N19 — Singleton render loop, visibility, provider cadence and motion lifecycle

**Nature / runtime:** implicit; active

**Source**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3415–3415` — _loopStarted
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3622–3663` — startRenderLoop; loop; start; stop; setVis

**Retained state**

- _loopStarted; closure _raf/_onScreen/_lastSec/_lastWx/_lastCloud; visibility/intersection listeners; CSS paused/fast; motion telemetry counters and bounded history; accepted last-render second used at handoff

**States**

- not started
- single loop active
- waiting for valid simulation
- dirty/second UI render due
- provider poll due
- cloud paint due
- hidden/offscreen suspended
- visible resumed
- reduced-motion held axes

**Events / transitions / guards / effects**

- first eligible start captures already-painted second and wires lifetime listeners; subsequent starts return
- each frame checks simulation readiness, maintains prayer day, polls weather/radar at30s real-time opportunities outside advancing preview, renders only changed second ordirty, paints clouds by motion policy, presents optional sky, then schedules next frame
- document visibility or intersection change → rebase cloud motion and toggle paused; visible start only if no owned RAF, hidden stop cancels and clears it
- runtime motion preference is checked perframe; reduced mode paints dirty state at held axes

**Invariants**

- Only one native RAF/listener set exists across repeated apply. Hidden elapsed time does not accumulate into cloud jumps. Provider retry/expiry clocks are independent from simulated rate. Optional sky handoff follows native work and uses freshly accepted UTC.

**Cancellation / expiry / error / recovery / termination**

- Invalid simulation keeps scheduling cheap readiness checks and can recover after clock/config change. Hide/show cancels/restarts RAF. There is no general catch/finally around render/paint/preview.present; if a reachable exception escapes before tail scheduling, stored _raf remains non-null until a visibility stop/start. This remains an unverified recovery hypothesis without a concrete ordinary exception. Page teardown owns observers/listeners.

**Dependencies**

- N02 simulation/preview rate
- N05 prayer recovery
- N08/N10 provider cooldowns
- N13 initial handoff
- N15 motion/raster
- N16 CSS effects
- N18 dirty font wakeup
- renderer preview.present

**Disposition:** inspected-protection; exception recovery gap unverified

**Correctness / concrete inspection:** The handoff seeds _lastSec from an actual completed render receipt, preventing gratuitous same-second restart work. The native loop owns cadence only after boot currentness checks. Root adjudicated one concurrent VM300ms timeout by unchanged isolated16/16pass; it does not establish a loop defect. Listener lifetime is the whole document, so missing route-level teardown is not a remount leak under the current single-widget contract.

**Security / privacy:** No external messages drive loop ownership. Visibility/intersection events can change scheduling but cannot admit stale data.

**Performance / scale:** UI about1Hz, cloud about13Hz, fixed provider opportunities and bounded diagnostic history. Early simulation-unready RAF continues while visible; no measured native cost claim. Avoid a large state-machine framework solely for these small cadence closures.

**Architecture / debt:** Scheduler is independent from eligibility owners. Consider an explicit terminal/restart transition only if an actual uncaught path is established; do not add broad exception swallowing that hides truth-publication failure.

**Direction / design:** Preserve real-time living visuals and live reduced-motion changes. Performance qualification requires a native full-motion clip/cadence evidence, not DOM counters alone.

**Relevant existing tests**

- tests/r001d-lifecycle.cjs
- tests/r0020-clock.cjs
- tests/r0025-lifecycle.cjs
- tests/real-sky/native-lifecycle.test.mjs

**Tests / validation scope:** Relevant tests are pointers to existing coverage, not assertions that each file passed. Parent owns broad regression adjudication. Locally executed join probes are identified explicitly.

**Verification gap / remaining risk:** No real-browser RAF suspension, media-query transition, frame-budget or renderer-present exception recovery proof. Hypothetical thrown callbacks are not listed as reproduced product defects.

### N20 — Settings disclosure, focus ownership, dirty form and close-save

**Nature / runtime:** implicit; active

**Source**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3673–3679` — settings closure state
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3766–3786` — settings affordance
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3788–3862` — populate/wire/read/commit settings
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3903–3923` — _openSettings; _closeSettings; _toggleSettings

**Retained state**

- _setWired/_setOpen/_setSession; _setLastFocus/_setFocusTimer; _setDirty; form values; settings-open class; buckle interactive/tabindex/aria attributes; disclosure session and pending async owners

**States**

- unavailable in configured mode
- closed/wired
- open/current session
- delayed focus pending
- dirty valid form
- dirty invalid form
- unchanged normalized form
- closing/committing
- focus restored

**Events / transitions / guards / effects**

- permitted local/preferLocal mode enables idempotent pointer/keyboard affordance; wire registers form/keyboard handlers once
- open increments session, invalidates location lookups, repopulates state, captures prior focus, removes covered buckle from tab order, sets class, and schedules30ms first-field focus guarded by current open session
- input marks dirty and location/pref edits update their own ownership versions; Tab traps modal boundaries
- close/Escape increments session, invalidates lookup/timer, commits only changed normalized valid values, removes class and restores interactive buckle or prior focus

**Invariants**

- A closed/superseded panel cannot receive its old delayed focus or lookup result. One form edit has one normalized commit. Close is intentionally auto-save, including Escape; this is not a cancel affordance.

**Cancellation / expiry / error / recovery / termination**

- Invalid/incomplete form is not saved; reopening repopulates applied configuration. No-op normalized edits avoid reset. Apply errors/persistence are separate status owners. Timers are cleared on close/reopen; DOM listeners live once per page. Real keyboard/focus behavior still needs native proof.

**Dependencies**

- N01 applyConfig
- N21 location lookup/reset owners
- N22 storage outcome
- config.js normalization
- native DOM focus/keyboard support

**Disposition:** inspected-protection; close-save behavior accepted as explicit design

**Correctness / concrete inspection:** Session guard prevents focus-timer ABA after rapid open-close-open. The form is a disclosure with intentionally documented AUTO-SAVE on close. An incomplete invalid edit is discarded on close without a second persisted state; discoverability may merit UX review but is not independently classified as a correctness defect absent a stronger contract.

**Security / privacy:** User labels/form errors are assigned as text/value. Precise geolocation is requested only from the explicit GPS action. The panel does not execute provider text.

**Performance / scale:** Idempotent wiring, one focus timer and normalized equality check prevent redundant listeners and no-op applies. Valid display-only edits may still trigger broad reset under N01/rootF01.

**Architecture / debt:** DOM class, boolean open state and session generation are overlapping but intentionally checked at different boundaries. Explicit state extraction should preserve asynchronous intent authority, not only modal visibility.

**Direction / design:** Preserve accessible keyboard entry/trap/return, local-mode availability and existing close-save semantics unless a separate UX decision changes them.

**Relevant existing tests**

- tests/r000f-intent.cjs
- tests/r0010-preferences.cjs
- tests/r0011-storage.cjs
- tests/r000f-reset.cjs

**Tests / validation scope:** Relevant tests are pointers to existing coverage, not assertions that each file passed. Parent owns broad regression adjudication. Locally executed join probes are identified explicitly.

**Verification gap / remaining risk:** No native tab-order, screen-reader announcement, zoom, delayed focus or incomplete-form usability proof. Native screenshots cannot be inferred from DOM mocks.

### N21 — Settings place search, GPS, candidate cycling and reset intent ownership

**Nature / runtime:** partly-explicit; active

**Source**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3708–3760` — location edit/session/sequence owners and preference versions
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3822–3851` — search and candidate handlers
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3863–3901` — _useGPS; _resetLocal

**Retained state**

- _setSearchSeq/_setEdit/_setSession; _setCands/_setCandIdx/_setCandOwner/_setHomeCC; per-preference _setPrefSeq/_setPrefVersions; location evidence/origin/saved state; _locSource; _geoPermission/_geoLastError; captured reset owner and preference versions

**States**

- manual location
- place query pending
- candidate set owned
- cycling current candidates
- typed-label intent
- GPS request pending
- permission receipt pending
- precise evidence acquired
- reset clear failed
- reset coarse detection pending
- reset applying with newer preference merge
- stale result discarded

**Events / transitions / guards / effects**

- location edit invalidates pending search/candidates; coordinate edits revoke prior location evidence while label-only edits preserve coordinate provenance
- Enter valid query captures session+edit+sequence; successful result is usable only for exact owner; repeat Enter cycles owned candidates, Shift+Enter declares typed-label intent
- explicit GPS action captures owner → await geolocation → recheck → await permissionState → recheck → publish original acquisition evidence or owned failure
- reset clears persistence first; failure stops. Successful clear captures preference versions, awaits coarse detection, merges later user preferences before apply, rechecks after await, repopulates and restores still-newer preference edits

**Invariants**

- Last explicit location intent wins across out-of-order/ABA results and open-close cycles. Reset location authority does not overwrite preferences edited after dispatch or during apply. Saving/reusing GPS coordinates must not renew acquisition time or accuracy.

**Cancellation / expiry / error / recovery / termination**

- Lookup failures produce owned text status and preserve prior selected input. Logical invalidation discards network/GPS completion; config.js owns physical request cancellation/timeout. Candidate state is cleared on edit/close/reset. Reset clear failure does not silently replace persisted settings with a new location.

**Dependencies**

- N20 session/form
- N22 clear/save result
- N01 asynchronous apply generation
- config.js geocode/geolocate/coarseDetect/permission/evidence normalization
- provider candidate ranking other lane

**Disposition:** inspected-protection

**Correctness / concrete inspection:** Exact owner checks after both GPS await boundaries and after reset apply protect a stale permission or coarse-detection continuation. Per-field preference versions address concurrent location reset without denying later preference edits. Parent reports unchanged intent/reset tests pass; source evidence independently supports the intended traces.

**Security / privacy:** GPS is explicit, not a boot permission request. Persisted evidence retains original receipt/accuracy. Provider candidate text is written via value/text; no candidate can inject handlers. No private coordinates are emitted in this report.

**Performance / scale:** Only current candidate array is retained; async work is logically superseded rather than accumulated as visible promises. Abort/candidate caps are delegated to config lane; native does not busy-poll.

**Architecture / debt:** Location intent generation and per-field preference versions are justified distinct ownership domains. Merging these into one last-action flag would lose edits during awaited reset.

**Direction / design:** Retain manual correction, explicit permission, provenance precision and later-edit priority. A future explicit state model must make stale-result no-ops observable without treating them as user errors.

**Relevant existing tests**

- tests/r000f-intent.cjs
- tests/r000f-reset.cjs
- tests/r0010-preferences.cjs
- tests/r0003-ownership.test.cjs

**Tests / validation scope:** Relevant tests are pointers to existing coverage, not assertions that each file passed. Parent owns broad regression adjudication. Locally executed join probes are identified explicitly.

**Verification gap / remaining risk:** Browser permission prompts, geolocation denial timing, real geocoder results and native focus during reset unverified. Physical cancellation and evidence normalization are cross-lane dependencies.

### N22 — Persistence outcome and persistent warning publication

**Nature / runtime:** partly-explicit; active

**Source**

- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3676–3707` — _persistOutcome; _storageErr; _setHint; _publishPersistence; status/affordance
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3505–3518` — applyConfig save outcome
- `/workspace/scratch/8ab1bbbe9699/salah_widget/src/native/index.html:3880–3887` — reset clear outcome

**Retained state**

- _persistOutcome operation/status/error; _storageErr; _setHint; status and aria-live text; buckle persist-warning/gear/aria-label/title; applied configuration versus remembered storage selection

**States**

- no outcome
- saved
- cleared
- session-only after failed save
- reset-failed with saved settings retained
- panel hint with persistence warning still visible

**Events / transitions / guards / effects**

- save or reset result → sanitize bounded display error and assign semantic outcome; live region, form status and closed-panel affordance publish together
- failed save keeps runtime changes usable for session while exposing persistence failure; failed clear stops reset coarse-detection continuation
- subsequent successful outcome clears warning; ordinary hint updates compose with persistence message rather than erase it; closing panel preserves warning affordance

**Invariants**

- Runtime configuration success and persistence success are different facts. A failed save may not claim settings will survive reload. Failed reset must not claim saved settings cleared. Async place hints must not overwrite a persistent storage failure.

**Cancellation / expiry / error / recovery / termination**

- User can retry save/reset; new outcome supersedes old warning. Missing storage becomes an explicit unavailable result. Sanitized UI error is bounded40characters while raw error code remains diagnostic. Cross-tab storage updates are not live-subscribed; reload resolution belongs to config lane.

**Dependencies**

- config.js saveLocal/clearLocal/storageAvailable
- N01 runtime configuration
- N20 panel and buckle
- N21 reset ownership
- N17 qaState availability probe

**Disposition:** inspected-protection

**Correctness / concrete inspection:** Status construction explicitly distinguishes saved/cleared/session-only/reset-failed and preserves warning after close. qaState calls storageAvailable in the config module, which probes storage; diagnostic reads are therefore not strictly pure, but no credential disclosure or product defect was demonstrated. Storage-version/schema migration ownership belongs to the config lane.

**Security / privacy:** Persistence display error strips non-alphanumeric punctuation except underscore/dot/hyphen and caps length. User location storage is authorized by the remember flow; source evidence timestamps are not renewed by saving. No storage contents or secrets are reproduced here.

**Performance / scale:** Bounded single outcome/hint avoids alert queues. Availability probe cost depends on storage/browser; no per-frame storage poll is introduced by this native owner.

**Architecture / debt:** A small explicit outcome enum already models the most important failure distinction. Keep it separate from form dirty/apply state when consolidating diagnostics.

**Direction / design:** Preserve honest session-only warnings and accessible status after the panel closes. A successful runtime apply cannot substitute for a storage receipt.

**Relevant existing tests**

- tests/r0011-storage.cjs
- tests/r000f-reset.cjs
- tests/native-appearance-currentness.test.cjs

**Tests / validation scope:** Relevant tests are pointers to existing coverage, not assertions that each file passed. Parent owns broad regression adjudication. Locally executed join probes are identified explicitly.

**Verification gap / remaining risk:** Actual blocked/quota storage and closed-panel accessibility rendering were not exercised in a native browser. Config module persistence implementation is separately audited.

## Hypotheses and rejected allegations

### NH01 — unverified

Countdown fit key may reuse a fit across equal prayer/sunrise/sunset/font key with changed rail geometry.

Key lacks exact path/location geometry; no actual native text/rail collision demonstrated.

Construct an equal-key/different-path case and measure native text and rail geometry before filing a defect.

### NH02 — unverified

Uncaught render/paint/preview callback exception could strand RAF ownership until visibility reset.

Source has no finally rescheduling, but no reachable ordinary input/platform failure reproduced. Arbitrary fault injection alone does not establish user impact.

Locate a concrete reachable throw, then test its actual recovery contract.

### NR01 — rejected-as-active-owner-claim

Legacy native moon/synthetic stars are competing deployed renderer owners.

Generator replacement and modern-runtime guards make these source-only compatibility paths dormant/replaced in generated app.

### NR02 — rejected-as-product-defect

Historical R0025 particle lifecycle and R0005 concurrent timeout establish native runtime defects.

Parent adjudicated particle fixture selector drift; unchanged isolated R0005 passed16/16 after concurrent300ms VM timeout.

### NR03 — by-design; visual-proof-required

Held ordinary-live star positions alone prove the sky is frozen.

Live coordinate holding is explicit; actual generated scintillation/motion must be assessed through the renderer/native visual contract, not source coordinate changes.

## Cross-machine conflicts and GDOPL inputs

These are evidence/projection inputs for the parent, not a mandate to rewrite the application or a new implementation plan.

### Prayer availability must not own weather expiry

**Machines / evidence:** N06, N09, N13, N15, N17; NF02

Separate provider eligibility withdrawal from the prayer-model success branch. Keep scene identity and cloud population stable while withdrawing unsupported coverage.

**Hard constraints:** truthfulness, independent celestial preview, full-motion continuity, reduced motion

### Chronology must survive admission-to-model joins

**Machines / evidence:** N02, N04, N05, N06, N07; NF01

Express date-aware accepted prayer events and their tie policy as the shared model contract. Preserve absent tomorrow and separate calendar-source validity.

**Hard constraints:** prayer-time correctness, exact timezone inverse, calendar provenance

### Configuration equality needs input-specific invalidation

**Machines / evidence:** N01, N03, N08, N13, N15, N19, N20; root-F01

Project provider identity, presentation preference and scene/motion identity separately before narrowing reset scope. Retain generation checks and provider-adopted timezone.

**Hard constraints:** no stale publication, settings later-intent wins, motion continuity

### Current weather, forecast and radar are distinct authorities

**Machines / evidence:** N08, N09, N10, N16, N17; Existing protections inspected

Keep per-capability evidence records and expiry, rather than one generic weather-ready flag. Radar remains diagnostic; model thunder cannot permit live lightning.

**Hard constraints:** source honesty, spatial/temporal applicability

### Native and renderer custody is a two-owner contract

**Machines / evidence:** N12, N13, N14, N17, N19; Generator substitutions and host capture/publish

Preserve generation/scene/epoch/surface receipts across native and renderer lanes. Native publish simplicity is not permission to omit caller admission.

**Hard constraints:** one physical star/moon owner, first-document warrant, mask/light eligibility, actual-consumption diagnostics

### Motion is retained state across hidden and reduced modes

**Machines / evidence:** N15, N16, N19; Existing bounded integration and CSS pause protections

Retain deterministic population, phase and last-time rebasing. Scheduler changes should not substitute a fake epoch or reconstruct populations.

**Hard constraints:** accessibility, living full-motion visuals, native clip qualification

### Settings intent and storage success are separate domains

**Machines / evidence:** N20, N21, N22; Existing session/edit/per-field versions and persistence outcome enum

Preserve later-edit authority through reset awaits and preserve session-only/failed-reset messaging. Avoid one status enum that conflates applied with saved.

**Hard constraints:** explicit GPS permission, original evidence timestamps, accessible persistence warning

## Verification receipts

Parent raw native TAP cohort:538 total,533pass,1 concurrent VM300ms timeout,4TODO. Parent unchanged isolated R0005 retry16/16pass. Historical named-script extraction failures and omitted input failures are not product defects without independent reproduction; R0025 particle selector mismatch adjudicated fixture drift.

Root reports successful independent unchanged rerun of join-probes.cjs and verification of all four source regions plus stable live scene identity.

Per-machine relevant test files describe test relationships, not blanket pass claims. Source/VM evidence is not native visual or performance proof.

The local probe used the actual native admission/model/render/withdrawal/cloud owners. Bounded adaptations corrected existing test-harness extraction selectors to the current source layout; no production owner was patched. Two initial harness selector failures were corrected before the successful probe and are not product failure evidence. NF02 uses controlled no-model state plus actual weather-expiry and cloud-paint owners; the ordinary same-location midnight path is separately established by source inspection.

**Local artifacts**

- evidence/probes/native/join-probes.cjs
- evidence/probes/native/join-results.json
- evidence/probes/native/generated-joins.json
- evidence/probes/native/write-catalogue.py

## Read confirmation

- `salah_widget/AGENTS.md`: Full instructions, including visual/native proof requirements and source/generator ownership.
- `plans/AUDIT_SCOPE.md`: Full lane authorization, exact object pins and read-only write boundary.
- `methodology/audit-playbook.md`: Correctness / Bugs; Security / Privacy; Performance / Scale; Tests / Validation; Architecture / Tech Debt; Direction / Design; Finding Row Contract; Vetting.
- `implementaudit SKILL.md and references/continuity.md`: Execution Spine, read-only handoff and authority ceiling; known installed package only.
- `salah_widget/src/native/index.html`: All behavioral JavaScript regions through boot/host tail, plus relevant DOM/CSS classes/animations. Embedded image payload bytes were not decoded as a separate asset audit.
- `salah_widget/tools/build_native.py`: Native source substitutions, real-star stub, elevation/currentness notification and scene/paint hooks.
- `salah_widget/tools/build_moon.py`: Modern runtime integration/worker install and placement; legacy native guards inspected at source owner.
- `salah_widget/index.html`: Exact-match readback of all four targeted defect owner regions; generated file was parent-acquired and Git-object validated.
- `evidence/tests/native/results.json`: Parent regression receipts and parent-supplied unchanged retry/fixture-drift adjudications; no independent rerun of broad cohort.
- `evidence/probes/native/join-probes.cjs`: Locally authored bounded read-only probes using actual source functions and existing VM fixture; executed successfully and independently rerun by parent.

## Handoff and remaining risk

Two reproduced defects remain unimplemented by scope. Two explicitly bounded hypotheses require decision-changing native/reachable-path evidence. Other inspected protections are evidence-bounded, not exhaustive proof against all runtime/platform failures. Root performs independent omissions discovery and final GDOPL projection.

All native entries have an inspection disposition; none of the two defects is marked repaired. Renderer-internal machines and config/builder machines are intentionally cross-referenced to their owners, so the parent can merge and independently sweep the complete catalogue without duplicate ownership.
