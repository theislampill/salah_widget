# Test abnormalities — preserve before focused follow-up

Initial native glob: 538 TAP tests, 533 pass, 1 VM-timeout failure, 4 TODO (not passes). Timeout in R0005 adoption test at unchanged 300ms VM guard while two source-test cohorts ran. Retain original; any isolated rerun must keep code and timeout unchanged.

Initial renderer cohort: 255 TAP tests, 250 pass, 5 fail. Four suite-load failures need missing pinned scientific data; classify environment/input, not product. cp9-ownership-age requires separate cause inspection.

Inherited named native runner remains FAIL. Several VM extraction fixtures reject added current bootstrap scripts, some lack _skyInitialDocument, and others require omitted historical Git/doc inputs. These are not silently skipped or treated as product failures. Focused adjudication follows.

Runner duration field is unreliable for JSON-shaped output: tools/cp9/run_native_regressions.py reuses local variable start for a text offset in its JSON parser and later subtracts that from time.monotonic(). These reported multi-hour numbers are not elapsed performance evidence. Exit codes and logs retained separately.

No evaluator assertions, source files or timeouts changed to obtain green. No release/visual qualification claim.

## Focused resolution

All five initial renderer file failures were missing bright-stars.json; exact Git-pinned catalogue, runtime manifest and V-nside128.json were restored. The five unchanged suites then passed 25/25 cases. Initial 250 passing renderer cases were not repeated.

The unchanged R0005 adoption suite passed 16/16 in isolation with its original 300ms VM timeout. The initial concurrent-run timeout remains recorded; no assertion or timeout was changed.

R0025 rain-column test fixture returns particles only for selector .wfx .drop, but current source correctly queries .wfx .drop,.wfx .flake. The newer R0024 particle-origin tests exercise both and passed in the native glob. The stale fixture failure is validation drift, not evidence of a rain regression.
