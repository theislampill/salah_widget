salah_widget state-machine audit — evidence package
Date: 6 November 2026

START HERE

1. deliverables/salah_widget_state_machine_audit.html is the complete readable report. Open it in a browser; each machine/finding record expands. Its content is self-contained and needs no external assets.
2. deliverables/salah_widget_state_machine_catalogue.json is the reconciled machine-readable result: 83 protocols, 18 established observations, 3 unverified hypotheses, source anchors, contracts, scope and acceptance records.
3. plans/AUDIT_SCOPE.md and plans/AUDIT_CLOSURE.md bind the read-only work and its terminal limits.

SOURCE IDENTITIES

Application: theislampill/salah_widget
Commit: f71fef6ccf7e4efcb57b5a26688d2360461a3253
Tree: 79aedcac840d624b5ea423922314f0832dc3f750
Methodology: theislampill/IMPLEMENTAUDIT.md
Commit: e78f7cb21af4197d490f10bc95917a4c75f748aa

Both main branches still matched these pins at the closing read. This package contains audit artifacts, probes and logs, not an application checkout or generated deployment payload.

WHICH RECORD IS AUTHORITATIVE

Use the reconciled report/JSON for final conclusions. Raw specialist packets and the frozen82 catalogue are deliberately unchanged; some wording in those inputs is superseded by root acceptance and normalization records. In particular: S01 merges into R37; R26 cannot promise arbitrary same-instance recovery after native allocation refusal; unsupported scientific-owner naming is removed; RF04 remains a hypothesis; repair classes are normalized; XF02 is the later accepted clock-discontinuity finding.

evidence/GDOPL_PROJECTION.md is the immutable reviewed draft. evidence/GDOPL_FINAL.md contains accepted revisions. review_acceptance.json and second_pass_acceptance.json explain the changes. The raw independent reviews remain visible.

COVERAGE AND TESTS

evidence/final_source_readback.json and final_verification.json are the final byte-identity authority: 419 verified blobs out of 640 selected manifest entries. source_hashes.json contains 485 records, but only419 are verified; 66 failed-transfer placeholder records do not establish source coverage. support_downloads.json and unavailable_transfers.json are historical acquisition records, not final coverage counts.

evidence/tests preserves original failures. The native aggregate remains FAIL. The unchanged isolated native suite and restored-input renderer rerun qualify only their named cases. Do not use affected native runner durations: its JSON-offset variable overwrites its timing origin. TEST_ABNORMALITIES.md and tests/adjudication.json classify those limits.

PROBES AND REPRODUCTION

Probes execute pinned source functions or controlled instrumentation of retained cache sizes. They do not establish native pixels, real-provider incidence, Windows installation, deployment or performance. The clock-discontinuity probe stops at beginRequest; no request is dispatched. Renderer spectral map instrumentation adds introspection only and does not modify the app snapshot.

Some original probes retain the session-specific repository root /workspace/scratch/8ab1bbbe9699/salah_widget. To repeat them elsewhere, obtain an independent checkout of the exact application pin and use a separate copy with only the repository-root constant adjusted. Record that harness-path difference and a new digest; do not overwrite the preserved original evidence or imply it was executed unchanged. Relative-root probes expect a salah_widget directory beside evidence/. Runtime/test inputs omitted from this package must come from the pinned repository, not substitute fixtures. No automatic rerun of all tests is required to read the audit.

Build scripts under evidence/ assemble audit deliverables only and never write into the application. HTML generation expects the provided runtime's marked package. check_report.mjs is an attempted layout check whose browser could not launch in this environment; final_artifact_verification.json is the successful structural check. No report-layout or app-native visual PASS is claimed.

MANIFEST

MANIFEST.sha256.json records every included payload file's size and SHA256. It does not include itself. The ZIP was read back and its payload digests verified after creation. No helper credentials, application source tree, external project data or large binary assets are included.
