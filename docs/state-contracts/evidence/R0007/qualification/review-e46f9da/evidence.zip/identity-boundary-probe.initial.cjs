'use strict';
// Independent complete-input identity/provenance controls. No browser, server,
// provider, owner writes or product execution; only local Git reads and parsing.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {execFileSync}=require('node:child_process');
const test=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const root=path.join(__dirname,'candidate');
const current=require(path.join(root,'tests/native-script-contract.js'));
const prior=require(path.join(__dirname,'prior-inputs/tests/native-script-contract.js'));
const base='5e946fe18a31750cf528bd58210ce79182dcf1e1';
const hash=text=>crypto.createHash('sha256').update(text).digest('hex');
const gitSource=(commit,file)=>execFileSync('git',['-C',root,'show',commit+':'+file],{encoding:'utf8'});
const authored=gitSource(base,'src/native/index.html'),delivered=gitSource(base,'index.html');
const authoredHash='e8603192a095cd8682c35416f3ecca00938d772f5152324b37f9928077eac037';
const parentHash='983f8b609eba48821e8d8c539cca7d0b9e40caf3f35a924514a4e93eb24766e9';
const legacyHash='c60eef46e0feeb4fcbc2daa34ec7069af470326648d8cf53943ee42a21865308';
const flag='<script>if(location.protocol==="file:")window.__SALAH_MOON_OFFLINE__=true;</script>';
const host='<script src="moon/moon-host.js"></script>';
const transform='Remove both complete Moon initial/refinement tags once; append the exact legacy file flag and moon-host tag before </body>; all other bytes unchanged.';
function replaceOnce(text,before,after){assert.equal(text.split(before).length-1,1);return text.replace(before,after);}
function reconstruct(text){
  const tags=[...text.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)];
  let result=text;
  for(const id of ['moon-initial-code','moon-refinement-code']){
    const matches=tags.filter(m=>m[1].trim()==='id="'+id+'"');
    assert.equal(matches.length,1,id+' unique complete tag');
    result=replaceOnce(result,matches[0][0],'');
  }
  assert.equal(text.includes(host),false,'source is split, without a legacy host');
  return replaceOnce(result,'</body>',flag+host+'</body>');
}
const legacy=reconstruct(delivered);
function admit(contract,source){
  const scripts=contract.parseScripts(source),digests=scripts.map(s=>hash(s.body));
  return contract.admitScripts(source,scripts,digests,hash(source));
}
function constants(file){
  const text=fs.readFileSync(file,'utf8'),anchor="return Object.freeze({schema:'salah-native-script-adapter/1'";
  assert.equal(text.split(anchor).length-1,1);
  const exposed=text.replace(anchor,"return Object.freeze({RETAINED_INPUTS,SPLIT_PINS,schema:'salah-native-script-adapter/1'");
  // Inspection-only exposure of otherwise private constants. Admission below
  // always uses the unmodified actual modules required above.
  const context={module:{exports:{}}};vm.runInNewContext(exposed,context);
  return JSON.parse(JSON.stringify(context.module.exports));
}
const oldConstants=constants(path.join(__dirname,'prior-inputs/tests/native-script-contract.js'));
const newConstants=constants(path.join(root,'tests/native-script-contract.js'));
const transport=JSON.parse(fs.readFileSync(path.join(__dirname,'candidate-transport.log'),'utf8'));

test('literal authored and parent identities equal accepted Git objects and current bytes',()=>{
  assert.equal(hash(authored),authoredHash);assert.equal(hash(delivered),parentHash);
  assert.equal(fs.readFileSync(path.join(root,'src/native/index.html'),'utf8'),authored);
  assert.equal(fs.readFileSync(path.join(root,'index.html'),'utf8'),delivered);
});

test('independent exact legacy transformation yields its literal complete-input pin',()=>{
  assert.equal(hash(legacy),legacyHash);
  const originalNative=admit(current,delivered).native.body;
  assert.equal(admit(current,legacy).native.body,originalNative,'structural transform preserves every native byte');
  assert.equal(transport.sourceProfiles.legacyMoon.sourceSha256,legacyHash);
  assert.equal(transport.sourceProfiles.legacyMoon.parentCommit,base);
  assert.equal(transport.sourceProfiles.legacyMoon.parentSha256,parentHash);
  assert.equal(transport.sourceProfiles.legacyMoon.transform,transform);
  assert.equal(transport.sourceProfiles.legacyMoon.runtimeQualified,false);
});

test('exact new complete inputs are admitted with truthful provenance and no runtime qualification',()=>{
  for(const [source,profile,kind,file] of [[authored,'current-authored-native','current-authored-source','src/native/index.html'],[legacy,'retained-legacy-moon-structural-control','structural-control','index.html']]){
    const result=admit(current,source);
    assert.equal(result.profile,profile);assert.equal(result.runtimeQualified,false);
    assert.equal(result.provenance.kind,kind);assert.equal(result.provenance.commit,base);assert.equal(result.provenance.path,file);
    if(kind==='structural-control'){
      assert.equal(result.provenance.parentSha256,parentHash);assert.equal(result.provenance.transform,transform);
    }
    assert.throws(()=>admit(prior,source),error=>error.code==='SETUP_INCOMPLETE');
  }
});

test('all six prior retained identities and all prerequisite pins are preserved exactly',()=>{
  assert.equal(Object.keys(oldConstants.RETAINED_INPUTS).length,6);
  assert.equal(Object.keys(newConstants.RETAINED_INPUTS).length,8);
  for(const [key,value] of Object.entries(oldConstants.RETAINED_INPUTS))assert.deepEqual(newConstants.RETAINED_INPUTS[key],value);
  assert.deepEqual(Object.keys(newConstants.RETAINED_INPUTS).filter(k=>!oldConstants.RETAINED_INPUTS[k]).sort(),[authoredHash,legacyHash].sort());
  assert.deepEqual(newConstants.SPLIT_PINS,oldConstants.SPLIT_PINS);
});

test('actual parser, admission guards, error behavior and flag constant are unchanged',()=>{
  for(const name of ['SetupError','requireSetup','parseScripts','admitScripts'])assert.equal(current[name].toString(),prior[name].toString(),name);
  assert.equal(current.MOON_FILE_BOOTSTRAP,prior.MOON_FILE_BOOTSTRAP);
  assert.equal(current.MOON_FILE_BOOTSTRAP,'if(location.protocol==="file:")window.__SALAH_MOON_OFFLINE__=true;');
});

test('one-byte complete-input drift cannot inherit either newly retained identity',()=>{
  for(const source of [authored,legacy]){
    for(const changed of [source+'\n',replaceOnce(source,'<title>Prayer Times</title>','<title>Prayer Times!</title>')]){
      assert.notEqual(hash(changed),hash(source));
      assert.throws(()=>admit(current,changed),error=>error.code==='SETUP_INCOMPLETE');
    }
  }
});

test('legacy flag and host mutations remain rejected',()=>{
  for(const changed of [replaceOnce(legacy,flag,flag.replace('true;','false;')),replaceOnce(legacy,host,host.replace('moon-host.js','unreviewed.js'))])
    assert.throws(()=>admit(current,changed),error=>error.code==='SETUP_INCOMPLETE');
});

test('generated semantic mutants remain admissible without relaxing real owner checks',()=>{
  const mutant=replaceOnce(delivered,'let _skyInitialDocument=true;','let _skyInitialDocument=false;');
  for(const contract of [prior,current]){
    assert.equal(admit(contract,mutant).profile,'split-moon');
    const native=admit(contract,delivered).native;
    const bad=replaceOnce(delivered,'<script'+native.attributes+'>'+native.body+'</script>','<script>function boot(){}\nboot();</script>');
    assert.throws(()=>admit(contract,bad),error=>error.code==='SETUP_INCOMPLETE');
  }
});

fs.writeFileSync(path.join(__dirname,'identity-probe-bindings.json'),JSON.stringify({
  sourceCommit:base,authoredSha256:hash(authored),parentSha256:hash(delivered),legacySha256:hash(legacy),
  transform,oldRetainedIdentityCount:Object.keys(oldConstants.RETAINED_INPUTS).length,
  candidateRetainedIdentityCount:Object.keys(newConstants.RETAINED_INPUTS).length,
  currentContractSha256:hash(fs.readFileSync(path.join(root,'tests/native-script-contract.js'))),
  priorContractSha256:hash(fs.readFileSync(path.join(__dirname,'prior-inputs/tests/native-script-contract.js'))),
  runtimeQualified:false,nativeExecuted:false
},null,2)+'\n');
