"""Direct exact-candidate native binding only; never calls main/producer."""
import hashlib
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT / "candidate"
HEAD = "e46f9dae61b2990a2b5dd5007feaa8342bd0b748"
TREE = "6934f644f150dd2d41edb872b528b99fcd51f29b"
PRIOR = "9d24fb4b34f5979aac9961f34794ffbf4490e049"
ACCEPTED = "226c5e8fb1badc7244ca3fa4e0ce8d5f726972e5"
BASE = "5e946fe18a31750cf528bd58210ce79182dcf1e1"


def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT), *args])


def load(name, relative):
    spec = importlib.util.spec_from_file_location(name, ROOT / relative)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n")


native = load("rebound_native", "tools/qualification/r0007_native.py")
driver = load("rebound_driver", "tools/cp9/r0007_browser.py")
identity = native.clean_identity(ROOT)
assert identity == {"commit": HEAD, "tree": TREE}
recipe = ROOT / native.DEFAULT_RECIPE
packet = json.loads(recipe.read_text())
old_bound = json.loads((OUT.parent / "qualification-review-226c5e8/actual-bound-packet.json").read_text())
e = packet["execution"]
requested = e["defaultCaseIds"] + e["conditionalPreservationCaseIds"] + e["mutationCaseIds"]
selected = native.select_cases(packet, requested)
assert len(selected) == len(requested) == len(set(requested)) == 31
assert selected == old_bound["cases"]
healthy = [c for c in selected if not c.get("expectedFailure")]
mutants = [c for c in selected if c.get("expectedFailure")]
assert len(healthy) == 22 and len(mutants) == 9 and selected == healthy + mutants
bound = native.bind_packet(ROOT, recipe, identity, selected)
validated = driver.validate_cases(bound, ROOT)
assert validated["status"] == "PREPARED_NOT_EXECUTED" and validated["caseCount"] == 31
assert len(bound["sourceFiles"]) == 147
assert bound["sourceFiles"] == old_bound["sourceFiles"]
shared = ["tests/native-script-contract.js", "tests/r0017-transport.cjs"]
membership = [{"path": p, "inAccepted226Binding": p in old_bound["sourceFiles"],
               "inCandidateBinding": p in bound["sourceFiles"],
               "actualCandidateSha256": hashlib.sha256((ROOT / p).read_bytes()).hexdigest()} for p in shared]
assert all(not row["inAccepted226Binding"] and not row["inCandidateBinding"] for row in membership)
save("actual-bound-packet.json", bound)

protected = ["src", "index.html", "offline.html", "config.js", "builder.html", "tools/build_native.py",
             "real-sky", "moon", "vendor", "v1", "tests/rlgwo/prayer-browser-fixture.cjs",
             "tools/cp9/browser_runtime.py", "tools/cp9/runtime_identity.py"]
native_helpers = ["tools/cp9/r0007_browser.py", "tools/cp9/r0007_font_observer.js",
                  "tools/qualification/r0007_native.py", ".github/workflows/r0007-native.yml",
                  "tests/test_r0007_native_qualification.py", "tests/real-sky/cp9_browser_runtime_test.py",
                  "tests/r0007-recovery-precondition.test.cjs", native.DEFAULT_RECIPE]
objects = []
for relative in protected + native_helpers:
    actual = git("rev-parse", HEAD + ":" + relative).decode().strip()
    accepted = git("rev-parse", ACCEPTED + ":" + relative).decode().strip()
    prior = git("rev-parse", PRIOR + ":" + relative).decode().strip()
    assert actual == accepted == prior, relative
    row = {"path": relative, "candidateObject": actual, "priorObject": prior, "accepted226Object": accepted}
    if relative in protected:
        base_object = git("rev-parse", BASE + ":" + relative).decode().strip()
        assert actual == base_object, relative
        row["accepted5eObject"] = base_object
    objects.append(row)
save("protected-identities.json", objects)

# Test/fixture owners supporting the new adapter controls are otherwise exact.
unchanged_test_owners = ["tests/r0017-adapters.test.cjs", "tests/hotfix-prayer-weather.test.cjs",
                         "tests/native-inline-runtime.cjs", "tests/r000f-fixture.cjs",
                         "tests/r0011-fixture.cjs", "tests/r001d-harness.cjs", "tests/widget-fixture.html"]
for relative in unchanged_test_owners:
    assert git("show", HEAD + ":" + relative) == git("show", PRIOR + ":" + relative), relative
scope = ["tests", "tools", ".github", "src", "index.html", "offline.html", "config.js", "builder.html",
         "real-sky", "moon", "vendor", "v1", "AGENTS.md"]
changed = git("diff", "--name-only", PRIOR, HEAD, "--", *scope).decode().splitlines()
assert set(changed) == set(shared), changed
manifest = json.loads((OUT / "input-manifest.json").read_text())
for item in manifest["files"]:
    data = (ROOT / item["path"]).read_bytes()
    assert hashlib.sha256(data).hexdigest() == item["sha256"]
    assert data == git("show", HEAD + ":" + item["path"])
assert native.clean_identity(ROOT) == identity
result = {"identity": identity, "status": validated["status"], "caseCount": 31, "healthy": 22, "mutants": 9,
          "sourceFiles": 147, "allCaseValuesEqualAccepted226": True, "all147SourceHashesEqualAccepted226": True,
          "sharedFileMembership": membership, "nativeHelpersAndProtectedObjects": len(objects),
          "protectedObjectsEqualAccepted5e": len(protected), "unchangedAdapterOwnerCount": len(unchanged_test_owners),
          "onlyExecutableScopeChanges": changed, "inputsReverified": len(manifest["files"]),
          "candidateClean": True, "mainInvoked": False, "nativeInvoked": False}
save("native-reanchor-verification.json", result)
print(json.dumps(result, indent=2))
