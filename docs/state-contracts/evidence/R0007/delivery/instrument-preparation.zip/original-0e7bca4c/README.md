# R0007 affected public-consumer delivery preparation

Prepared only under `analysis-r0007/delivery-preparation/`. No public request, browser, provider call, workflow launch, active-candidate edit, GitHub write or issue action was executed. The request remains deliberately UNBOUND and cannot authorize or execute acquisition.

## Prepared implementation and intended placement

| Prepared file | Intended reviewed repository path if root chooses inclusion |
| --- | --- |
| `r0007_public_consumer.py` | `tools/qualification/r0007_public_consumer.py` |
| `r0007_public_cases.json` | `tools/qualification/r0007_public_cases.json` |
| `r0007-public-delivery.yml` | `.github/workflows/r0007-public-delivery.yml` |
| `delivery-request.template.json` | Post-merge only: `docs/state-contracts/evidence/R0007/delivery/request.json` |

Include/review the executable, case data and workflow before exact merge approval if using this route. Keep the real request absent until actual owner approval, actual merge and exact-commit Pages readback have occurred. The workflow trigger is only a request-file push to the commissioned branch; it does not run on source changes or normal merge. The job's first gate rejects an unbound or premature request before dependency installation or browsers. The schema/status strings preserve gate evidence; they do not manufacture authority or independently prove the owner approved.

The standalone tool imports Playwright and opens HTTP only in acquisition mode after all gates and local immutable Git identities pass. `--validate-only --template` is pure preparation and returns PREPARED_TEMPLATE_NOT_EXECUTABLE. A bound request compares its probe/case hashes with the actual files and their copies in the merged Git tree. It requires the qualified approved tree to equal the actual merged tree. A changed tree requires explicit reconciliation before this route can accept it.

## Bounded public cases and non-claims

Default acquisition is four independent contexts per engine, sequential Chromium and Firefox:

| Case | Controlled input and actual consumer predicate |
| --- | --- |
| `public-reordered24` | UTC 7 September 2026, 23:00; current Isha00:30, next-day Isha00:31. Actual completed receipt and DOM must agree on Isha,00:31,next date08-09-2026,UTC,epoch1788827460000,91minutes, selected row/arc marker and compatible wall interval. |
| `public-ordinary24` | Same UTC epoch with ordinary19:30 Isha. Actual receipt/DOM must select next-day Fajr05:00,epoch1788843600000,360minutes, with ordinary wall progress/arc semantics retained. |
| `public-missing24` | Current record admitted, actual next-day HTTP response intentionally held before headers. Countdown must remain unavailable with no fabricated target/highlight; current timetable/date/arc stay present. This is absence of an admitted next record while ingress is pending, not a claim that a real provider failed. |
| `public-recovery24` | Same unavailable state, then fulfill that actual pending native request. Original fetch/JSON/adoption/dirty-frame path must paint the coherent Isha91 endpoint at the identical frozen epoch after native scheduling. |

`public-reordered-offline` is an optional representative offline HTML consumer, explicitly selected with `--case-id`; it is not part of the default denominator. The offline file's delivered bytes are always checked regardless of this optional behavior case.

Inputs/oracles were copied from the already-authored independent R0007 recipes, not generated from observed product results. The case manifest retains its source-recipe SHA. The only pre-boot clock change is a fixed Date ingress; performance, rAF, timers, renderer, boot, state adoption, and stored product data are not replaced or invoked by the probe. Every case uses a new private browser context with explicit coordinates and no granted permissions. It reads actual public HTML unchanged and never calls render/model or seeds a product record/cache. Browser-owned storage is ephemeral, separate from the user's profile.

Provider HTTP responses are controlled before provider contact, using strict expected host/path/date/coordinates/method/school matching and native JSON consumption. Weather/radar requests fail through controlled ingress. Missing/recovery hold a response before headers; this narrower boundary is explicit and does not claim the historical body-stall timing subproof. Actual site assets and the real source font CSS/font hosts remain native; unknown external requests/WebSockets are blocked and recorded as nonpassing evidence.

Readiness samples and prayer-DOM MutationObserver callbacks read `window.qaState().render`, the actual last completed render receipt, plus actual DOM. `qaState()` also computes other diagnostics and may touch a pending Moon getter; before/after material classes/href are retained, and diagnostic surface changes receive no scene-preservation credit. The probe never treats the diagnostic recomputation as a painted frame. Its250ms recovery observation is native elapsed scheduling, not a first-frame oracle. Screenshot receipt association and original video remain separate. No earliest/all-first-presented-frame claim, full-scene motion/Moon acceptance, or live-provider incidence is made.

## Pre-approval readiness and exact approval request

1. Reconcile the whole-owner ledger against latest accepted main after R0017's approved integration/delivery/closure, preserving the authorized R0017→R0007→R000B merge order. Current source, all still-applicable original duties, ES07, source/generated parity and relevant native Linux/Windows qualifications must be accounted for. Keep owner-assigned exceptions exact.
2. Finish executable engineering, fix independently reviewed findings, and bind the separately attributed review to exact PR head/base/tree. Inspect whole diff/generated files and artifact/source hashes. Add these helper files to the candidate only through root's normal reviewed source process, then freeze their hashes and prepare a certificate with delivery fields explicitly pending.
3. Read current PR via `github_get_pr_info` and checks via `github_get_commit_combined_status`; verify exact head/base/tree, completed review and all required readiness. Request the single owner's merge decision with those exact identities. State AWAITING_OWNER_MERGE_APPROVAL. A reviewed PR is not whole-owner completion.

## Post-approval same-thread merge and delivery sequence

1. Bind the actual owner approval receipt to the exact candidate. Re-read PR head/base/mergeability/checks and current main; do not promote approval across a changed candidate/base without reconciliation. Use `github_merge_pull_request(repository_full_name=theislampill/salah_widget, pr_number=<actual>, expected_head_sha=<approved head>, merge_method=<approved/repository method>)`. The tool has a head guard but no base guard, so current-base readback immediately before merge remains necessary. Inspect a rejection or uncertain result before replaying the effect.
2. Read back merged PR and merge commit with `github_get_pr_info` / `github_fetch_commit`; bind actual main SHA/tree and source/generated hashes. Verify the issue remains open rather than assuming the non-closing Implements#7 PR closed it. Record the satisfied merge one-shot before proceeding.
3. Inspect the normal Pages deployment associated with the exact merged main SHA. The specialized commit-workflow tool filters PR runs and is insufficient for all Pages runs. Use the existing allowed connector GET `https://api.github.com/repos/theislampill/salah_widget/actions/runs?head_sha=<merged SHA>` and inspect actual workflow/job conclusions through `github_fetch_workflow_run_jobs`; reconcile deployment/source identity outside this probe. No rerun, replacement deployment or broad polling is built in. If Pages is still pending or bytes stale, retain the exact state and wait for a real change signal.
4. Fill the request with actual approval/head/base/tree receipt, verified merge/main SHA/tree, successful exact-source Pages run id/receipt, expected file byte lengths/SHA256 from that immutable merged Git tree, and the reviewed probe/case digests. Only then set `status=READY_AFTER_APPROVAL_MERGE_AND_PAGES_READBACK`, approval statusAPPROVED_EXACT_CANDIDATE, merge statusMERGED_VERIFIED, and Pages statusSUCCESS_VERIFIED_EXTERNALLY. These fields record already obtained evidence, not new grants. Preserve exact owner authority separately.
5. Publish this request only on the commissioned branch. The prepared Windows job fetches current main, requires it to equal the requested merged SHA, and uses the merged Git objects to verify every expected file and helper identity. The job is Contents-read only, private Windows2022, headed Chromium/Firefox, one owned concurrency group, and pinned checkout/upload. No R0017 workflow/runner or shared local preview is used. A request commit on the feature branch does not alter deployed main or start another Pages deployment.
6. Download/read back the exact delivery artifact and inspect raw served hashes, actual root/config navigation identities, controlled-ingress ledgers, actual completed receipt/DOM, screenshots, original videos, browser binary/version/OS and actual producer exit. Re-read current main and the Pages binding after acquisition to detect a moved external frontier before certificate acceptance. Source assertions return only PARTIAL_INDEPENDENT_PIXELS_REQUIRED. A separately attributed actual-pixel review must close the affected visible predicates and source association. A zero process exit or the request's Pages string is not whole-owner acceptance.
7. Complete and publish the whole-owner certificate only after every original/ES07/delivery residual is terminal under the actual owner/policy. Bind actual merge, delivered source, Pages run, public cases, independent review, original evidence/approved exceptions and remaining non-claims. Use `github_add_comment_to_issue` with the actual issue number7 (this connector names its parameter `pr_number`) and immediately read back the issue comments to verify the certificate bytes/location.
8. When actually eligible under the approved commission, deliberately close issue7 with `github_update_issue(repository_full_name=theislampill/salah_widget, issue_number=7, state=closed, state_reason=completed)`, then `github_fetch_issue` readback of the completed state. Do not let certificate publication or mere PR merge stand in for issue closure. Finish formal audit closure from the actual evidence and continuity records; do not emit completion while a dependent gate remains pending. R000B remains its separate owner/thread.

## Exact commands

Pure validation now, with no Git/network/browser:

```bash
python3 r0007_public_consumer.py --request delivery-request.template.json --cases r0007_public_cases.json --validate-only --template
```

After approved merge, normal Pages success/readback and a fully bound request, from a repo holding the exact merged Git objects:

```bash
python3 tools/qualification/r0007_public_consumer.py \
  --request docs/state-contracts/evidence/R0007/delivery/request.json \
  --cases tools/qualification/r0007_public_cases.json \
  --repository-root /absolute/readback-checkout \
  --output /absolute/fresh-private-delivery-evidence \
  --engine chromium --engine firefox --headed
```

For local Linux, omit `--headed` only where headless is the available explicitly recorded route; Linux evidence is not Windows evidence. A private explicit executable requires a single `--engine`. Managed-engine executable paths are made explicit and hashed; no sandbox fallback is present. The workflow records the actual script producer exit, full logs, setup exits, native traces, PNGs and videos even on failure.

## Served identity and historical protocol reference

Before browser acquisition, streamed HTTP readback compares root,offline,config,Moon BUILD/asset/initial manifests and the Real-Sky checkpoint against merged Git bytes. Actual browser root/offline navigation bytes are independently hashed; root's actual config response is also hashed. Root/config are rechecked after acquisition to expose source drift. Other actual asset requests remain native and logged; this is not a claim to have hashed every conditional science asset. There is no local substitute server and no source HTML rewrite.

Historical reference inspected read-only: commit `ea1ec15c6973e4b30b7bb21be4720aea2f7783b2`, `docs/rlgwo-execution/20261014/R0007/delivery/public-consumer/case-input.json` (Git blob05ae702066f4f5c062e725f8e90aeaa30fab39fa) and `readback.json` (blobefc16b891a36558e8db58d912d6f1fbb37ccaac7). Those used fresh actual public root/V1 consumers, controlled provider ingress, preboot fixed time, actual HTML hashes and original pixels; Firefox was headed. Their historic PASS is not fresh delivery credit for this extension.

Current validation is structural/pure only. No browser or network route in this new tool has been executed; runtime integration, served bytes, screenshots/video, actual Windows presentation and final owner acceptance remain unverified until their authorized stage.
