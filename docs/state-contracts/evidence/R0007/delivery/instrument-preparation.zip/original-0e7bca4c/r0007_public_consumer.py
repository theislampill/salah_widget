#!/usr/bin/env python3
"""Observe original delivered R0007 HTML after explicit approval/merge/Pages gates.

Validation mode opens no network/browser. Acquisition uses fresh contexts,
controlled provider HTTP ingress and fixed pre-boot Date only. It never calls
product render/model or seeds product state. Pixels remain independently reviewed.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import platform
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request
from urllib.parse import parse_qs, unquote, urljoin, urlsplit

SITE = "https://theislampill.github.io/salah_widget/"
REQUIRED_FILES = {"index.html", "offline.html", "config.js", "moon/BUILD.json", "moon/asset-manifest.json",
                  "moon/initial-manifest.json", "moon/initial-compact-manifest.json", "moon/initial-source-association.json",
                  "real-sky/checkpoint.json"}
PROBE_PATH = "tools/qualification/r0007_public_consumer.py"
CASES_PATH = "tools/qualification/r0007_public_cases.json"


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def safe_path(path):
    return isinstance(path, str) and path and ":" not in path and "\\" not in path and not any(ord(c) < 32 for c in path) and not PurePosixPath(path).is_absolute() and all(p not in {"", ".", ".."} for p in path.split("/"))


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise urllib.error.HTTPError(req.full_url, code, "unexpected served-file redirect refused", headers, fp)


def validate(request, cases, template=False):
    if request.get("schema") != "r0007-public-delivery-request/v1" or request.get("site") != SITE or request.get("issue") != 7:
        raise ValueError("request scope/site mismatch")
    if cases.get("schema") != "r0007-public-consumer-cases/v1":
        raise ValueError("public case schema mismatch")
    ids = [c["caseId"] for c in cases["cases"]]
    if len(ids) != len(set(ids)) or not set(cases["requiredCaseIds"]).issubset(ids):
        raise ValueError("case population invalid")
    for c in cases["cases"]:
        if not re.fullmatch(r"[A-Za-z0-9_-]+", c["caseId"]) or c["entry"] not in {"index.html", "offline.html"} or c["mode"] not in {"ready", "missing", "recovery"}:
            raise ValueError("case path/mode invalid")
        if "timeScale" in c["hash"] or "simTime=23%3A00" not in c["hash"] or c["epoch"] != "2026-09-07T23:00:00Z":
            raise ValueError("case must retain its declared frozen native-clock input")
    if not REQUIRED_FILES.issubset(request.get("expectedFiles", {})):
        raise ValueError("required served file population incomplete")
    for path, record in request["expectedFiles"].items():
        if not safe_path(path):
            raise ValueError("unsafe served path")
        if not template and (not re.fullmatch(r"[0-9a-f]{64}", record.get("sha256", "")) or not isinstance(record.get("bytes"), int) or record["bytes"] <= 0):
            raise ValueError("served file identity is unbound: " + path)
    if template:
        return {"status": "PREPARED_TEMPLATE_NOT_EXECUTABLE", "requiredCaseCount": len(cases["requiredCaseIds"]), "network": False}
    if request.get("status") != "READY_AFTER_APPROVAL_MERGE_AND_PAGES_READBACK":
        raise ValueError("explicit post-approval/merge/Pages request is absent")
    approval, merge, pages = request["ownerApproval"], request["merge"], request["pages"]
    for value in [approval["headSha"], approval["baseSha"], approval["treeSha"], merge["mainSha"], merge["treeSha"], pages["sourceSha"]]:
        if not re.fullmatch(r"[0-9a-f]{40}", value):
            raise ValueError("approval/merge/Pages identity is unbound")
    if approval.get("status") != "APPROVED_EXACT_CANDIDATE" or merge.get("status") != "MERGED_VERIFIED" or pages.get("status") != "SUCCESS_VERIFIED_EXTERNALLY":
        raise ValueError("approval/merge/Pages status is not ready")
    if approval["treeSha"] != merge["treeSha"] or pages["sourceSha"] != merge["mainSha"]:
        raise ValueError("qualified tree or Pages source differs from the approved merged candidate")
    if not all(isinstance(x, str) and x and x != "UNBOUND" for x in [approval.get("receipt"), merge.get("receipt"), pages.get("receipt")]):
        raise ValueError("externally verified gate receipts are missing")
    if not isinstance(pages.get("runId"), int) or pages["runId"] <= 0:
        raise ValueError("Pages run identity missing")
    return {"status": "REQUEST_STRUCTURALLY_BOUND_EXTERNAL_AUTHORITY_NOT_RECREATED", "requiredCaseCount": len(cases["requiredCaseIds"]), "network": False}


def git_bytes(root, revision, path):
    return subprocess.check_output(["git", "-C", str(root), "cat-file", "blob", revision + ":" + path])


def verify_git(request, root, require_fetch_head):
    merged = request["merge"]["mainSha"]
    tree = subprocess.check_output(["git", "-C", str(root), "rev-parse", merged + "^{tree}"], text=True).strip()
    if tree != request["merge"]["treeSha"]:
        raise ValueError("merged commit/tree differs from request")
    if require_fetch_head and subprocess.check_output(["git", "-C", str(root), "rev-parse", "FETCH_HEAD"], text=True).strip() != merged:
        raise ValueError("freshly fetched main moved from requested merge; reconcile before delivery acceptance")
    for path, expected in request["expectedFiles"].items():
        content = git_bytes(root, merged, path)
        if len(content) != expected["bytes"] or sha(content) != expected["sha256"]:
            raise ValueError("expected served identity differs from merged Git bytes: " + path)
    if sha(git_bytes(root, merged, PROBE_PATH)) != request["probeSha256"] or sha(git_bytes(root, merged, CASES_PATH)) != request["casesSha256"]:
        raise ValueError("delivery probe/cases are not the reviewed merged versions")


def served_readback(request, output):
    receipts = []
    for path, expected in request["expectedFiles"].items():
        url = SITE if path == "index.html" else urljoin(SITE, path)
        row = {"path": path, "url": url, "startedUtc": now(), "expected": expected}
        dump(output / "served-readback.json", {"status": "IN_PROGRESS", "files": receipts, "active": row})
        req = urllib.request.Request(url, headers={"Cache-Control": "no-cache", "Accept-Encoding": "identity", "User-Agent": "R0007-delivered-consumer-readback"})
        with urllib.request.build_opener(NoRedirect()).open(req, timeout=45) as response:
            if response.geturl() != url or response.status != 200:
                raise ValueError("unexpected redirect/status for served file: " + path)
            digest, length = hashlib.sha256(), 0
            while chunk := response.read(1024 * 1024):
                digest.update(chunk)
                length += len(chunk)
                if length > expected["bytes"]:
                    raise ValueError("served file exceeds qualified byte length: " + path)
            row.update(status=response.status, finalUrl=response.geturl(), headers=dict(response.headers), bytes=length, sha256=digest.hexdigest())
        row["matchesQualifiedTree"] = row["bytes"] == expected["bytes"] and row["sha256"] == expected["sha256"]
        row["finishedUtc"] = now()
        receipts.append(row)
        dump(output / "served-readback.json", {"status": "HASHES_RECORDED", "files": receipts})
        if not row["matchesQualifiedTree"]:
            raise ValueError("served bytes differ from qualified merged tree: " + path)
    return receipts


INIT = r"""(() => {
 const NativeDate=Date, epoch=__EPOCH__;
 window.Date=class extends NativeDate {constructor(...args){super(...(args.length?args:[epoch]));}static now(){return epoch;}};
 const P=window.__r0007PublicDelivery={snapshots:[],events:[],started:performance.now()};
 const copy=x=>JSON.parse(JSON.stringify(x,(_,v)=>typeof v==='number'&&!Number.isFinite(v)?{finite:false,value:null}:v));
 const dom=selector=>{const e=document.querySelector(selector);if(!e)return {unavailable:true};const r=e.getBoundingClientRect();return {text:e.textContent,html:e.innerHTML,tagName:e.tagName.toLowerCase(),geometry:{x:r.x,y:r.y,width:r.width,height:r.height}};};
 P.sample=stage=>{
  if(typeof window.qaState!=='function')return null;
  const before={href:document.querySelector('.mphoto')?.getAttribute('href'),classes:document.querySelector('.c')?.className};
  try{
   const q=window.qaState(),s={stage,observedAt:performance.now(),wallUtcMs:Date.now(),render:copy(q.render),cache:copy(q.cache),currentDay:q.cache?.prayerDate,timezone:q.render?.zone,
    dom:Object.fromEntries(['.c','.nt','.left','.times','.arc','#ce','#ah','.buckle','.d'].map(x=>[x,dom(x)])),
    rows:[...document.querySelectorAll('.times .p')].map(e=>({key:e.dataset.prayerKey,on:e.classList.contains('on'),clock:e.querySelector('.tm')?.textContent,classes:e.className})),
    fonts:{status:document.fonts.status,faces:[...document.fonts].map(f=>({family:f.family,status:f.status}))},
    diagnosticSurface:{before,after:{href:document.querySelector('.mphoto')?.getAttribute('href'),classes:document.querySelector('.c')?.className}}};
   P.snapshots.push(s);return s;
  }catch(e){P.events.push({type:'observation-error',message:String(e),at:performance.now()});return null;}
 };
 const watch=()=>{P.sample('dom-ready');const observer=new MutationObserver(()=>P.sample('actual-prayer-dom-mutation'));for(const s of ['.nt','.left','.times']){const e=document.querySelector(s);if(e)observer.observe(e,{childList:true,subtree:true,characterData:true});}};
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',watch,{once:true});else watch();
})();"""


def assert_expected(snapshot, expected):
    if snapshot is None:
        raise AssertionError("no actual completed-render observation")
    for key, wanted in expected.get("equals", {}).items():
        actual = snapshot
        for part in key.split("/"):
            actual = actual[part]
        if actual != wanted:
            raise AssertionError(key + ": expected " + repr(wanted) + ", observed " + repr(actual))
    for field, mapping in [("contains", lambda a, b: b in a), ("regex", lambda a, b: re.fullmatch(b, a) is not None)]:
        for key, wanted in expected.get(field, {}).items():
            actual = snapshot
            for part in key.split("/"):
                actual = actual[part]
            if not mapping(actual, wanted):
                raise AssertionError(field + " actual consumer mismatch: " + key)
    for key, bounds in expected.get("numberRange", {}).items():
        actual = snapshot
        for part in key.split("/"):
            actual = actual[part]
        if isinstance(actual, bool) or not isinstance(actual, (float, int)) or not math.isfinite(actual) or not bounds[0] <= actual <= bounds[1]:
            raise AssertionError("actual consumer outside range: " + key)
    if len(snapshot["rows"]) != 6 or len({r["key"] for r in snapshot["rows"]}) != 6:
        raise AssertionError("actual timetable is not six distinct admitted event rows")
    if any(x in snapshot["dom"][s]["text"] for s in [".nt", ".left", ".times"] for x in ["NaN", "Infinity", "undefined"]):
        raise AssertionError("invalid visible prayer text")


def acquire_case(playwright, engine, case, request, output, headed):
    output.mkdir(parents=True, exist_ok=False)
    dump(output / "case-input.json", case)
    trace = {"caseId": case["caseId"], "engine": engine, "status": "STARTED", "startedUtc": now(), "network": [], "blocked": [],
             "pageErrors": [], "checkpoints": [], "firstPresentationClaim": "NOT_MADE", "liveProviderIncidenceClaim": "NOT_MADE"}
    browser = context = page = None
    pending = []
    responses = []
    try:
        family = getattr(playwright, engine)
        executable = os.environ.get("SALAH_BROWSER_EXECUTABLE") or family.executable_path
        options = {"headless": not headed, "executable_path": executable}
        if engine == "chromium":
            options.update(chromium_sandbox=True, args=["--disable-dev-shm-usage"])
        browser = family.launch(**options)
        dump(output / "browser-identity.json", {"engine": engine, "version": browser.version, "headless": not headed,
             "executable": executable, "executableSha256": sha(Path(executable).read_bytes()), "os": platform.system(), "release": platform.release()})
        context = browser.new_context(viewport={"width": 370, "height": 570}, device_scale_factor=1, timezone_id="UTC",
                                      permissions=[], accept_downloads=False, record_video_dir=str(output / "video"), record_video_size={"width": 370, "height": 570})
        epoch = int(datetime.fromisoformat(case["epoch"].replace("Z", "+00:00")).timestamp() * 1000)
        context.add_init_script(INIT.replace("__EPOCH__", str(epoch)))

        def route_request(route):
            req = route.request
            url = urlsplit(req.url)
            row = {"url": req.url, "method": req.method, "resourceType": req.resource_type, "atMonotonic": time.monotonic()}
            trace["network"].append(row)
            if req.method not in {"GET", "HEAD"}:
                row["policy"] = "BLOCKED_METHOD"; trace["blocked"].append(row); route.abort(); return
            if url.scheme == "https" and url.hostname == "api.aladhan.com" and re.fullmatch(r"/v1/timings/(07|08)-09-2026", url.path):
                query = parse_qs(url.query)
                if any(query.get(k) != [v] for k, v in {"latitude": "40.71", "longitude": "-74.01", "method": "2", "school": "0"}.items()):
                    row["policy"] = "BLOCKED_UNEXPECTED_PROVIDER_INPUT"; trace["blocked"].append(row); route.abort(); return
                tomorrow = url.path.endswith("08-09-2026")
                if tomorrow and case["mode"] in {"missing", "recovery"}:
                    row["policy"] = "CONTROLLED_NEXT_RESPONSE_HELD_BEFORE_HEADERS"; pending.append((route, row)); return
                row["policy"] = "CONTROLLED_PROVIDER_HTTP_RESPONSE_NO_PROVIDER_CONTACT"
                route.fulfill(status=200, content_type="application/json", headers={"Access-Control-Allow-Origin": "*"}, body=json.dumps(case["tomorrowPayload"] if tomorrow else case["todayPayload"]))
                return
            if url.scheme == "https" and ((url.hostname == "api.open-meteo.com" and url.path == "/v1/forecast") or (url.hostname == "api.rainviewer.com" and url.path == "/public/weather-maps.json")):
                row["policy"] = "CONTROLLED_WEATHER_RADAR_OFFLINE_NO_PROVIDER_CONTACT"; route.abort("internetdisconnected"); return
            site = urlsplit(SITE)
            if url.scheme == "https" and url.netloc == site.netloc and url.path.startswith(site.path) and ".." not in unquote(url.path).split("/"):
                row["policy"] = "ACTUAL_PUBLIC_SITE_BYTES_UNMODIFIED"; route.continue_(); return
            if url.scheme == "https" and ((url.hostname == "fonts.googleapis.com" and url.path == "/css2" and req.resource_type == "stylesheet") or (url.hostname == "fonts.gstatic.com" and url.path.startswith("/s/") and req.resource_type == "font")):
                row["policy"] = "ACTUAL_NATIVE_FONT_FETCH"; route.continue_(); return
            if url.scheme == "https" and url.netloc == site.netloc and url.path == "/favicon.ico":
                row["policy"] = "STANDARD_FAVICON_NOT_A_RUNTIME_DELIVERY_CLAIM"; route.continue_(); return
            row["policy"] = "BLOCKED_UNRECOGNIZED_EXTERNAL_REQUEST"; trace["blocked"].append(row); route.abort()

        context.route("**/*", route_request)
        def refuse_socket(socket):
            trace["blocked"].append({"url": socket.url, "policy": "BLOCKED_UNRECOGNIZED_WEBSOCKET"})
            socket.close(code=1008, reason="No websocket admitted by controlled R0007 delivery probe")
        context.route_web_socket("**/*", refuse_socket)
        page = context.new_page()
        page.set_default_timeout(15000)
        page.on("pageerror", lambda error: trace["pageErrors"].append(str(error)))
        page.on("response", lambda response: responses.append(response))
        url = (SITE if case["entry"] == "index.html" else urljoin(SITE, case["entry"])) + case["hash"]
        response = page.goto(url, wait_until="domcontentloaded", timeout=90000)
        if response is None or response.status != 200 or sha(response.body()) != request["expectedFiles"][case["entry"]]["sha256"]:
            raise AssertionError("actual public navigation source bytes differ from qualified tree")
        page.wait_for_function("() => {const p=window.__r0007PublicDelivery,s=p?.sample('current-readiness');return !!(s?.cache?.prayerLoaded&&s.render&&s.rows.length===6)}", polling=100)

        def capture(name, expected):
            snapshot = page.evaluate("name=>window.__r0007PublicDelivery.sample(name)", name)
            assert_expected(snapshot, expected)
            trace["checkpoints"].append({"name": name, "snapshot": snapshot})
            before = page.evaluate("JSON.stringify(window.qaState().render)")
            page.screenshot(path=str(output / (name + ".png")))
            after = page.evaluate("JSON.stringify(window.qaState().render)")
            dump(output / (name + "-presentation.json"), {"renderReceiptStableAcrossScreenshot": before == after,
                 "beforeReceipt": json.loads(before), "afterReceipt": json.loads(after), "claim": "Actual checkpoint pixels; no earliest-frame assertion"})

        if case["mode"] in {"missing", "recovery"}:
            deadline = time.monotonic() + 10
            while not pending and time.monotonic() < deadline:
                page.wait_for_timeout(25)
            if not pending:
                raise AssertionError("expected next-day ingress request was not observed")
            capture("unavailable", case["expectedUnavailable"])
        if case["mode"] == "recovery":
            for route, row in list(pending):
                row["releasedAtMonotonic"] = time.monotonic()
                route.fulfill(status=200, content_type="application/json", headers={"Access-Control-Allow-Origin": "*"}, body=json.dumps(case["tomorrowPayload"]))
            pending.clear()
        if case["mode"] != "missing":
            page.wait_for_function("() => !!window.__r0007PublicDelivery.sample('tomorrow-admission-readiness')?.cache?.tomorrowLoaded", polling=100)
            # Observe native scheduling; never render, advance time, or assign data.
            page.wait_for_timeout(250)
            capture("actual-completed-consumer", case["expectedFinal"])
        for r in responses:
            if urlsplit(r.url).path == urlsplit(SITE).path + "config.js":
                content = r.body()
                trace["actualConfigResponse"] = {"url": r.url, "bytes": len(content), "sha256": sha(content)}
        if case["entry"] == "index.html" and trace.get("actualConfigResponse", {}).get("sha256") != request["expectedFiles"]["config.js"]["sha256"]:
            raise AssertionError("actual consumed public config bytes differ from qualified tree")
        if trace["blocked"] or trace["pageErrors"]:
            raise AssertionError("blocked unknown request or page error; inspect original trace")
        page.wait_for_timeout(1000)
        trace["nativePresentationTailMs"] = 1000
        trace["status"] = "ASSERTIONS_MET_INDEPENDENT_PIXELS_PENDING"
    except Exception as error:
        trace.update(status="FAILED_OR_UNVERIFIED", failure=repr(error))
    finally:
        if page:
            try:
                trace["observations"] = page.evaluate("() => {const p=window.__r0007PublicDelivery;return {snapshots:p.snapshots,events:p.events,started:p.started}}")
                trace["diagnosticSurfaceChanges"] = sum(s["diagnosticSurface"]["before"] != s["diagnosticSurface"]["after"] for s in trace["observations"]["snapshots"])
                if trace["status"] != "ASSERTIONS_MET_INDEPENDENT_PIXELS_PENDING":
                    page.screenshot(path=str(output / "failure.png"))
            except Exception as error:
                trace["exportFailure"] = repr(error)
        for route, row in pending:
            try:
                row["cleanup"] = "HELD_INGRESS_ABORTED_ON_CONTEXT_DISPOSAL"; route.abort()
            except Exception:
                pass
        cleanup_errors = []
        for label, owned in [("context", context), ("browser", browser)]:
            try:
                if owned: owned.close()
            except Exception as error:
                cleanup_errors.append({"owner": label, "error": repr(error)})
        trace["ownedCleanupReturned"] = not cleanup_errors
        trace["cleanupEvidence"] = "Owned SDK close calls; no independent OS process census claimed"
        if cleanup_errors:
            trace.update(cleanupFailures=cleanup_errors, status="FAILED_OR_UNVERIFIED")
        if trace["blocked"] or trace["pageErrors"]:
            trace["status"] = "FAILED_OR_UNVERIFIED"
        trace["finishedUtc"] = now()
        dump(output / "trace.json", trace)
    return trace


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--request", type=Path, required=True)
    p.add_argument("--cases", type=Path, required=True)
    p.add_argument("--repository-root", type=Path)
    p.add_argument("--output", type=Path)
    p.add_argument("--engine", choices=["chromium", "firefox"], action="append")
    p.add_argument("--case-id", action="append")
    p.add_argument("--headed", action="store_true")
    p.add_argument("--require-fetch-head", action="store_true")
    p.add_argument("--validate-only", action="store_true")
    p.add_argument("--template", action="store_true", help="Structural preparation only; never permits acquisition")
    args = p.parse_args(argv)
    request = json.loads(args.request.read_text(encoding="utf-8"))
    cases = json.loads(args.cases.read_text(encoding="utf-8"))
    validation = validate(request, cases, args.template)
    if sha(Path(__file__).read_bytes()) != request["probeSha256"] or sha(args.cases.read_bytes()) != request["casesSha256"]:
        raise ValueError("probe/case bytes differ from explicit request")
    if args.validate_only:
        print(json.dumps(validation)); return 0
    if args.template or args.repository_root is None or args.output is None:
        p.error("acquisition requires bound request, repository-root and output")
    root, output = args.repository_root.resolve(), args.output.resolve()
    if output.is_relative_to(root) or output.exists():
        p.error("output must be a fresh directory outside repository-root")
    engines = args.engine or ["chromium", "firefox"]
    if len(engines) != len(set(engines)) or len(engines) > 1 and os.environ.get("SALAH_BROWSER_EXECUTABLE"):
        p.error("engines must be unique; an explicit executable requires a single engine")
    ids = args.case_id or cases["requiredCaseIds"]
    selected = [c for c in cases["cases"] if c["caseId"] in ids]
    if set(ids) != {c["caseId"] for c in selected}:
        p.error("unknown/empty public case selection")
    output.mkdir(parents=True)
    summary = {"schema": "r0007-public-delivery-acquisition/v1", "status": "PARTIAL", "startedUtc": now(), "results": [],
               "request": request, "probeSha256": request["probeSha256"], "casesSha256": request["casesSha256"],
               "claim": "Affected public consumer assertions only; pixels, Pages binding and whole-owner certificate remain separate"}
    exit_code = 1
    try:
        verify_git(request, root, args.require_fetch_head)
        summary["servedFiles"] = served_readback(request, output)
        from playwright.sync_api import sync_playwright
        stopped = False
        with sync_playwright() as playwright:
            for engine in engines:
                for case in selected:
                    if stopped:
                        summary["results"].append({"engine": engine, "caseId": case["caseId"], "status": "UNATTEMPTED_OWNED_CLEANUP_UNVERIFIED"}); continue
                    result = acquire_case(playwright, engine, case, request, output / engine / case["caseId"], args.headed)
                    summary["results"].append({"engine": engine, "caseId": case["caseId"], "status": result["status"]})
                    stopped = not result.get("ownedCleanupReturned")
                    dump(output / "summary.json", summary)
        # Recheck the affected source/config after acquisition; the original file
        # population's full readback remains retained without repeated large copies.
        final_request = {**request, "expectedFiles": {k: v for k, v in request["expectedFiles"].items() if k in {"index.html", "config.js"}}}
        after = output / "after"; after.mkdir()
        summary["servedFilesAfter"] = served_readback(final_request, after)
        summary["requiredPopulationObserved"] = set(engines) == {"chromium", "firefox"} and set(cases["requiredCaseIds"]).issubset(ids)
        exit_code = 0 if all(r["status"] == "ASSERTIONS_MET_INDEPENDENT_PIXELS_PENDING" for r in summary["results"]) else 1
    except Exception as error:
        summary["failure"] = repr(error)
    summary.update(exitCode=exit_code, finishedUtc=now())
    dump(output / "summary.json", summary)
    print("R0007_PUBLIC_RESULT " + json.dumps({"status": "PARTIAL_INDEPENDENT_PIXELS_REQUIRED", "exitCode": exit_code,
          "mergedMainSha": request["merge"]["mainSha"], "results": summary["results"], "certificateOrIssueClosure": "NOT_PERFORMED"}))
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
