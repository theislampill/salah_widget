# Prepared delivery verifier repair — author report

Status: **SUCCESSOR PREPARED FOR INDEPENDENT REVIEW; NO DELIVERY ACCEPTANCE**.

All changes are confined to `analysis-r0007/delivery-preparation/`. No active checkout, public endpoint, browser, provider, workflow, GitHub object/ref/issue or deployment was changed or executed. Original preparation inputs were saved byte-for-byte before repair in `original-0e7bca4c/`; `input-digests.json` binds the original six reviewed files plus their two original invocation logs. The original separately attributed GAP-REVISE report remains unchanged under `delivery-review/`.

## Changes and meaningful controls

| Original finding | Successor change | Preserved controls |
| --- | --- | --- |
| DELREV-01, visible duration | Literal independent `1h 31m left until Isha` / `6h 0m left until Fajr` equals predicates in every final-case oracle, alongside the existing target/epoch/minute/DOM predicates. | Every healthy literal passes; correct receipt with `999h 59m` fails all four applicable final cases. |
| DELREV-02, incomplete export/artifacts | Assertion-success is assigned only after actual export, returned closure, complete required checkpoint membership, PNG CRC/scanline validity, exact presentation-to-snapshot/receipt/geometry/image hashes, browser identity, SDK video path after closure and bounded structural WebM checks. Export JSON is separately retained and checked against the trace. | Healthy acquisition double stays pixels-pending; export failure, missing video, invalid PNG, receipt mismatch, deleted required screenshot, altered export/presentation and truncated WebM fail. This is structural evidence integrity, not decoded-frame/pixel meaning. |
| DELREV-03, no-handle custody | Persist launch entry before calling SDK; record handle-return stages and individual entered/returned close calls. A launch error without returned handle has unknown custody and stops the real population loop. SDK close is not an independent OS census. | No-handle error cannot claim cleanup; context-close failure still attempts browser-close and fails custody; the production population loop performs exactly one launch and marks all seven remaining cells unattempted. |
| DELREV-04, recovery setup | Before held-next release, require actual authored LINK trusted load/error receipt; loaded CSS must be applied/enabled with `media=all` and a sheet. Read geometry, await actual `document.fonts.ready`, require loaded status, and observe unchanged actual receipt/geometry/font signatures over three native rAF callbacks. Repeat before final capture. Time-bounded observers do not invoke product render/model or assign product flags. | CSS-pending/fonts-loading doubles cannot release recovery; healthy recovery observes font promise and stable callbacks before fulfillment. Pure observer-program controls distinguish untrusted events, trusted-but-unapplied CSS, pending real font promise and actual terminal fallback. Native outcomes remain untested. |
| DELREV-05, real approved objects | Real base/head/merged commit types and trees; base ancestry of head; agreed method `merge` only; exact parents `[approved base, approved head]`; head tree equals merged tree; fresh-main and all original file/helper checks retained. Workflow fetches complete main ancestry before probing. | Real isolated Git objects: justified merge passes; wrong actual approved head tree, wrong base tree, reversed parents and unsupported rebase fail. |
| DELREV-06, redirect containment | No `route.continue_`; allowlisted assets use ordinary `route.fetch(max_redirects=0)` with original API response fulfillment. Every 3xx is refused, transport/disposal errors recorded, service workers blocked. No broader allowlist. | Healthy 200/404 retains the identical API response object; 302/307 abort without fulfillment; transport exception is retained; source contains no continue escape. These test helper semantics, not an executed SDK/network boundary. |

## Verification and limits

`validation.json` records exact command arguments, raw-log hashes and exit status. The original expanded pure suite is RED, exit1; successor suite is GREEN, **21 tests**, exit0. The preserved original observer program fails the new event/promise control, exit1; the successor observer control passes, exit0. Observer JS parsing, both Python compilations and workflow YAML parsing pass. Structural template invocation returns0; the same unbound request without `--template` returns1. Every pure-run folder and failed attempt remains retained. The earlier original15-test RED is separately preserved as `repair-red.log`/`repair-red.json`.

The private product dirty flag and loop-started state are not exposed through public diagnostics; the tool explicitly reports `not-exposed`. Three stable native observations after typography settlement do not prove exclusive accepted-next wakeup causality. Root expressly authorized the public recovery scope as **eventual only**, with no first-presented-frame/all-frame or exclusive-wakeup claim. Existing independent native qualification must carry any stronger dirty-wakeup discrimination. Font/geometry doubles do not establish real native timing.

The no-redirect transport preserves original HTTP response payload bytes but buffers responses and changes ingress timing. It is not a fully uninstrumented public networking experiment. Screenshot/video files require independent actual playback/pixel/source-association review; structural parsing is insufficient for visual acceptance. The request remains UNBOUND and no external approval is invented. Actual approval, exact merge/current-main reconciliation, successful Pages source/run binding, public bytes, both-engine Windows acquisition, final certificate and deliberate issue7 closure remain pending their authorized stage.

## Exact successor

Probe SHA-256: `22e83395b1d7ec961ba880cc50729d7658e58860c9feb1c843d34df5b1271dc9`.

Cases SHA-256: `b834e2435b7cdd735dadd2902c74e2994df7e454ed7397d1b2f8b81938646bf3`.

`successor-scope.json` binds the six core files, two pure test programs and this report. After its creation the author stops edits while the separately attributed successor review proceeds. No completion or readiness authority is asserted by this report.
