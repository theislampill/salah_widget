#!/usr/bin/env python3
"""Real local Git witnesses for inherited trace environment and config paths.

Synthetic credentials have no authority. All Git endpoints are disposable file://
repositories. Trace files and RED evidence are retained, never scrubbed or deleted.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import types
import unittest
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]
HELPER = ROOT / 'templates/materialize.py'
REF = 'refs/heads/pro/r0007-explicit-next-event-state-20261106'


class TraceBoundary(unittest.TestCase):
    def exercise(self, channel):
        raw = HELPER.read_bytes()
        subject = types.ModuleType('pack_trace_subject')
        subject.__file__ = str(HELPER)
        exec(compile(raw, str(HELPER), 'exec'), subject.__dict__)
        fixtures = ROOT / 'test-runs-trace'
        fixtures.mkdir(exist_ok=True)
        root = Path(tempfile.mkdtemp(prefix=channel + '-', dir=fixtures))
        work, bare, evidence = root / 'work', root / 'remote.git', root / 'evidence'
        evidence.mkdir()
        environment = {'PATH': os.environ.get('PATH', '/usr/bin:/bin'),
                       'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': os.devnull,
                       'GIT_TERMINAL_PROMPT': '0', 'LC_ALL': 'C',
                       'PYTHONDONTWRITEBYTECODE': '1'}

        def git(cwd, *arguments):
            result = subprocess.run(['git', '-C', str(cwd), *arguments], env=environment,
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
            return result.stdout.decode().strip()

        git(root, 'init', '--quiet', '--initial-branch=fixture', str(work))
        git(root, 'init', '--quiet', '--bare', str(bare))
        git(work, 'config', 'user.name', 'Local trace-boundary fixture')
        git(work, 'config', 'user.email', 'fixture@example.invalid')

        def commit(label):
            (work / 'payload.txt').write_text(label + '\n')
            git(work, 'add', 'payload.txt')
            git(work, 'commit', '--quiet', '-m', label)
            return git(work, 'rev-parse', 'HEAD')

        seed = commit('synthetic seed')
        intermediate = commit('synthetic intermediate')
        remote = bare.as_uri()
        git(work, 'push', '--quiet', remote, seed + ':' + REF)
        trace = evidence / 'git-trace-output'
        token = 'R0007_SUCCESSOR_SYNTHETIC_CREDENTIAL_NO_AUTHORITY'
        ambient = dict(environment)
        config = None
        if channel == 'environment':
            ambient.update(GIT_TRACE2_EVENT=str(trace), GIT_TRACE2_ENV_VARS='R0007_PUSH_TOKEN')
        else:
            config = root / 'global.gitconfig'
            git(work, 'config', '--file', str(config), 'trace2.envVars', 'R0007_PUSH_TOKEN')
            git(work, 'config', '--file', str(config), 'trace2.' + channel, str(trace))
            ambient['GIT_CONFIG_GLOBAL'] = str(config)
        config_before = config.read_bytes() if config else None
        repository_config_before = (work / '.git/config').read_bytes()
        with patch.dict(os.environ, ambient, clear=True), patch.object(subject, 'REMOTE', remote):
            result = subject.publish_intermediate(work, intermediate, seed, evidence, token)
        observed = git(bare, 'rev-parse', REF)
        leaked = [str(file.relative_to(root)) for file in root.rglob('*')
                  if file.is_file() and token.encode() in file.read_bytes()]
        config_unchanged = config is None or config.read_bytes() == config_before
        repository_config_unchanged = (work / '.git/config').read_bytes() == repository_config_before
        record = {'schema': 'r0007-successor-trace-boundary/v1', 'channel': channel,
                  'localFixtureOnly': True, 'productionRemoteContacted': False,
                  'helperSha256': hashlib.sha256(raw).hexdigest(),
                  'publicationStatus': result['status'], 'refUpdated': result['refUpdated'],
                  'pushAttempts': result.get('pushAttempts'),
                  'expectedSeed': seed, 'expectedIntermediate': intermediate,
                  'observedRemote': observed, 'traceFilePresent': trace.exists(),
                  'syntheticCredentialPersisted': bool(leaked), 'credentialFilePaths': leaked,
                  'configurationUnchanged': config_unchanged and repository_config_unchanged,
                  'structuredReceiptContainsCredential': token in json.dumps(result),
                  'gitVersion': git(root, '--version')}
        (root / 'witness.json').write_text(json.dumps(record, indent=2) + '\n')
        print(json.dumps(record, sort_keys=True), flush=True)
        self.assertFalse(leaked, 'Git tracing persisted the synthetic push credential')
        self.assertTrue(config_unchanged and repository_config_unchanged,
                        'existing configuration was changed')
        self.assertNotIn(token, json.dumps(result))
        if channel == 'environment':
            self.assertEqual(result['status'], 'REMOTE_REF_VERIFIED_INTERMEDIATE')
            self.assertIs(result['refUpdated'], True)
            self.assertEqual(observed, intermediate)
            self.assertFalse(trace.exists(), 'inherited trace environment reached controlled Git children')
        else:
            self.assertEqual(result['status'], 'REFUSED_BEFORE_PUSH')
            self.assertIs(result['refUpdated'], False)
            self.assertEqual(result['pushAttempts'], 0)
            self.assertEqual(observed, seed)

    def test_inherited_trace_environment_cannot_persist_push_credential(self):
        self.exercise('environment')

    def test_global_trace2_normal_target_refuses_before_push(self):
        self.exercise('normalTarget')

    def test_global_trace2_event_target_refuses_before_push(self):
        self.exercise('eventTarget')

    def test_global_trace2_perf_target_refuses_before_push(self):
        self.exercise('perfTarget')


if __name__ == '__main__':
    unittest.main(verbosity=2)
