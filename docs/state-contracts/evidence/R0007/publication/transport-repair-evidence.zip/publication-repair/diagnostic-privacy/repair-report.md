# R0007 HTTP diagnostic privacy repair — author handoff

Date: 2026-11-10 UTC. Status: local repair frozen for a fresh independent successor review. This is an author report, not an independent review, publication approval, acceptance determination, or lifecycle closure.

## Finding consumed and reproduced

The commissioned successor review was read in full from `publication-review-successor/review.md`, whose SHA256 is `59f4195c6ad10e267bd98c2ebf588e3bc3bb9b473021e5d9db621cc0abf9241f`. It is FINAL with disposition GAP-REVISE and finding F-S1. No unrelated reviewer report was read. All prior independent review files remain byte-identical; final validation checks their recorded hashes.

F-S1 is confirmed. The former `http_error_details` copied free-form message, URL and selected error strings into receipts after replacing only exact token/full-small-source values. A source fragment remained visible when it was a substring of a small source or a fragment of a source over 65,536 bytes. The first repair's claim of source-free error diagnostics was therefore too broad. Its previous report remains historical and unchanged; this report supersedes that diagnostic claim for the newly frozen helper hash.

Before editing, the three helper files and author control file were copied byte-for-byte under `original/`. `original/hashes.json` binds those copies and the consumed independent evidence. The unchanged held-out witness script was run against the prior helper and reproduced two failures out of four tests. See `held-out-red.log` and `held-out-red.json`; original reviewer failures also remain untouched.

## Bounded repair

Only `publication-bootstrap/templates/materialize.py::http_error_details` changed in executable helper code. The preparer and workflow bytes are unchanged. AST comparison confirms that every top-level item outside that one function is unchanged, including upload serialization, byte/SHA checks, fixed endpoint, token handling, no-retry behavior, parent/seed guards and the complete main function.

The function no longer reads or retains arbitrary response `message`, `documentation_url`, `resource`, `field` or `value` strings. It does not copy an arbitrary `code` string. It no longer attempts token/source substring scrubbing and does not inspect the token or source arguments at all.

The retained information is deterministic and typed:

- A fixed `statusClass` selected from the numeric HTTP status, including VALIDATION_FAILED for 422, REQUEST_TOO_LARGE for 413, and fixed authentication/permission/conflict/rate/server/redirect categories.
- A fixed body-read outcome. Failure records only FAILED, without exception names or messages.
- At most 65,537 bytes read; the actual count, a truncation flag and SHA256 of the first at most 65,536 bytes are retained. Raw bytes are never retained.
- A fixed body-format classification: TRUNCATED, UNPARSEABLE, JSON_NON_OBJECT or JSON_OBJECT. Truncated bodies are not parsed. Invalid JSON, invalid Unicode and excessive JSON nesting receive the fixed UNPARSEABLE label.
- For a JSON object's `errors` list, at most twenty entries are examined. Exact matches to a fixed set of known-shaped code strings select fixed output enums such as API_CODE_TOO_LARGE. All other entries select UNRECOGNIZED_ERROR_CODE. The output contains only the deduplicated fixed classifications, examined count and truncation flag; no input string is copied through.

The classification API_CODE_TOO_LARGE means that an exact structured code was reported. It does not establish which transport/content limit caused a refusal. A message that cannot be represented by these classifications is deliberately omitted; diagnosis can consequently remain incomplete. The original hosted HTTP 422 cause remains UNKNOWN.

The source-echo defect is removed by excluding free-form strings from the receipt, rather than assuming a substring redactor can recognize every source fragment. Digest/count metadata are retained as explicitly authorized evidence. No request/response headers or source/request bodies are recorded by this diagnostic function.

## Test sequence and retained evidence

1. `held-out-red.log`: unchanged reviewer script against prior helper; four tests, two expected privacy failures. The whole-source/token positive control and eleven-case ancestry guard matrix were already successful.
2. `author-controls-red.log`: expanded author transport controls reproduced missing fixed classifications and retained arbitrary error text. This initial run also exposed a synthetic HTTP body missing a `close()` method; the original output is preserved.
3. `author-controls-red-2.log`: that test double received `close()` while helper bytes were unchanged; twelve test methods produced fourteen expected assertion failures including the table-driven status cases. No destructor warning remained.
4. `held-out-green.log`: the original reviewer script was rerun unmodified against the repair; four tests completed with exit 0, including both formerly failing held-out witnesses and its eleven-case guard matrix.
5. `author-suite-green.log`: the full author suite completed all eighteen tests with exit 0. This includes the prior six real disposable-Git ancestry tests and prior transport boundaries. The former free-form-message expectation was changed to the newly authorized fixed status/code classification contract, and three diagnostic controls were added.

The new controls cover arbitrary echoes in every formerly retained response-string field, small/large held-out source fragments, an exact synthetic token, unknown or malformed code values, response prefix hash/count integrity, fixed classification of eleven HTTP statuses, and body-read exceptions without arbitrary exception text. Existing checks continue to cover UTF-8/BOM/Unicode/line-ending byte preservation, binary base64, local and returned Git identities, bounded errors, terminal refusal/timeout, no alternate request/redirect, token stripping and depth-three forward seed reconstruction with wrong-parent/extra-path rejection.

Every HTTP interaction in these controls is synthetic. The Git commits are confined to disposable test directories. This repair used no network, browser, repository API, actual upload, credential export, active root-source edit, branch change or other remote effect. The earlier actual large-blob measurement was not rerun because no upload serialization or identity code changed; its historical fake-transport nature remains explicit.

## Frozen identities

| File | Bytes | SHA256 | This repair |
|---|---:|---|---|
| `prepare_payload.py` | 7,019 | `fc85ff2ce1f65b677e2d955ecf0a4c1489cd84f0b94dfd73dd026f9594952b81` | unchanged |
| `templates/materialize.py` | 17,670 | `c9557db24d9bd8256be02ae1d1153b81a15a5363579940e044910179cb4f3411` | changed |
| `templates/r0007-materialize.yml` | 2,270 | `77a56129d289e98083c2ea4b0fca42de10efc64ecae1d3bdd955456c332b3730` | unchanged |

The author control file SHA256 is `f9d87b81da8ed2280d0734c0e1853ddd2e5a880cd738daee7fddff4b07ee7569`. `final-validation.json` is the machine-readable validation and identity record. `helper-repair.diff` contains the single-function implementation change; `transport-controls.diff` contains the exact control revision. The previous helper SHA256 was `5c40102037ab6adc3a73ca27a80974eb71e3223a450ef04ffaea129dc9ffd55a` and remains available under `original/helpers/templates/materialize.py`.

## Handoff boundary

All executable changes and evidence writes are stopped at this handoff. Root owns fresh independent review of materializer SHA256 `c9557db24d9bd8256be02ae1d1153b81a15a5363579940e044910179cb4f3411`, reconciliation of F-S1, any new manifest binding and any authorized hosted attempt. The materializer's hash change requires a freshly prepared manifest/workflow binding before hosted use. No independent review, publication readiness, native qualification, merge approval or closure claim is made here.
