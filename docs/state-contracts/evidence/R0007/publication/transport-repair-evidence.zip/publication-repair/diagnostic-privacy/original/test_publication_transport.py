#!/usr/bin/env python3
"""Local-only boundary tests: no network, credentials, or active-repository edits."""
import base64
import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import urllib.error

HERE = Path(__file__).resolve().parent
HELPERS = Path(os.environ.get('R0007_HELPER_DIR', str(HERE.parent / 'publication-bootstrap')))
SPEC = importlib.util.spec_from_file_location('materialize_under_test', HELPERS / 'templates/materialize.py')
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)
RUNS = HERE / 'test-runs'
RUNS.mkdir(exist_ok=True)
BRANCH = 'pro/r0007-explicit-next-event-state-20261106'
SEEDS = {'.github/workflows/r0007-materialize.yml', '.github/r0007-bootstrap/materialize.py',
         '.github/r0007-bootstrap/manifest.json', '.github/r0007-bootstrap/source.patch'}
FAKE_TOKEN = 'TEST_ONLY_NOT_A_CREDENTIAL_591256'


def execute(argv, cwd=None, check=True, env=None, input=None):
    if env is None:
        env = os.environ.copy()
        env.pop('R0007_UPLOAD_TOKEN', None)
        env['PYTHONDONTWRITEBYTECODE'] = '1'
    return subprocess.run(argv, cwd=cwd, input=input, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          check=check, env=env)


def git(root, *args):
    return execute(['git', '-C', str(root), *args]).stdout.decode().strip()


def identity(raw, path='fixture.txt'):
    blob = execute(['git', 'hash-object', '--stdin'], input=raw).stdout.decode().strip()
    return {'path': path, 'blobSha': blob, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


class Response:
    def __init__(self, sha, status=201):
        self.status = status
        self.data = json.dumps({'sha': sha, 'url': 'https://api.github.com/repos/theislampill/salah_widget/git/blobs/' + sha}).encode()

    def read(self):
        return self.data

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass


class TransportTests(unittest.TestCase):
    def setUp(self):
        self.evidence = Path(tempfile.mkdtemp(prefix='transport-', dir=RUNS))
        self.calls = []

    def run_upload(self, raw, response=None, error=None, expected=None):
        expected = expected or identity(raw)
        response = response or Response(expected['blobSha'])

        def open_request(request, timeout):
            self.calls.append(request)
            self.assertEqual(request.full_url, 'https://api.github.com/repos/theislampill/salah_widget/git/blobs')
            self.assertEqual(request.get_method(), 'POST')
            self.assertEqual(timeout, 180)
            if error:
                raise error
            return response

        class Opener:
            open = staticmethod(open_request)

        def build_opener(*handlers):
            self.assertEqual(len(handlers), 1)
            self.assertIsInstance(handlers[0], M.NoRedirect)
            return Opener()

        with patch.object(M.urllib.request, 'build_opener', side_effect=build_opener):
            return M.upload_blob(raw, FAKE_TOKEN, expected, self.evidence, 1)

    def receipt(self):
        return json.loads((self.evidence / 'upload-001.json').read_bytes())

    def test_utf8_request_preserves_unicode_line_endings_controls_and_git_identity(self):
        # Catches base64 inflation and accidental BOM/newline/Unicode normalization.
        raw = '\ufeff<html>العربية 😀 "quote" \\ path\r\nline\r\t\x00</html>\n'.encode('utf-8')
        result = self.run_upload(raw)
        request = self.calls[0]
        payload = json.loads(request.data)
        self.assertEqual(payload['encoding'], 'utf-8')
        self.assertEqual(payload['content'].encode('utf-8'), raw)
        self.assertIn('العربية'.encode(), request.data)
        self.assertEqual(result.get('encoding'), 'utf-8')
        self.assertEqual(result.get('requestBytes'), len(request.data))
        self.assertEqual(result.get('requestSha256'), hashlib.sha256(request.data).hexdigest())
        self.assertEqual(result.get('localBlobSha'), identity(raw)['blobSha'])
        self.assertEqual(result['observedBlobSha'], identity(raw)['blobSha'])
        self.assertEqual(result['status'], 'VERIFIED_BLOB_STORED_NO_REF_UPDATE')
        self.assertFalse(result['refUpdated'])
        self.assertEqual(len(self.calls), 1)
        serialized = (self.evidence / 'upload-001.json').read_text()
        self.assertNotIn(FAKE_TOKEN, serialized)
        self.assertNotIn('العربية', serialized)
        self.assertNotIn('Authorization', serialized)

    def test_non_utf8_binary_uses_lossless_base64(self):
        raw = b'\xff\xfe\x00\x80binary\r\n'
        result = self.run_upload(raw)
        payload = json.loads(self.calls[0].data)
        self.assertEqual(payload['encoding'], 'base64')
        self.assertEqual(base64.b64decode(payload['content'], validate=True), raw)
        self.assertEqual(result.get('encoding'), 'base64')
        self.assertEqual(result.get('localBlobSha'), identity(raw)['blobSha'])

    def test_input_identity_mismatch_stops_before_transport(self):
        expected = identity(b'expected bytes')
        with self.assertRaises(ValueError):
            self.run_upload(b'different bytes', expected=expected)
        self.assertEqual(self.calls, [])
        self.assertEqual(self.receipt()['status'], 'UPLOAD_UNVERIFIED_STOPPED')

    def test_http_refusal_retains_bounded_safe_diagnostics_without_retry(self):
        raw = b'SOURCE_BODY_MUST_NOT_BE_RETAINED'
        payload = {'message': 'Validation failed ' + FAKE_TOKEN,
                   'documentation_url': 'https://docs.github.com/rest/git/blobs#create-a-blob',
                   'errors': [{'resource': 'Blob', 'field': 'content', 'code': 'too_large', 'value': raw.decode()}],
                   'content': raw.decode(), 'headers': {'Authorization': FAKE_TOKEN}}
        error = urllib.error.HTTPError('https://api.github.com/unused', 422, 'refused',
                                       {'Secret-Header': FAKE_TOKEN}, io.BytesIO(json.dumps(payload).encode()))
        with self.assertRaisesRegex(RuntimeError, 'HTTP 422'):
            self.run_upload(raw, error=error)
        result = self.receipt()
        self.assertEqual(result['status'], 'HTTP_ERROR_STOPPED')
        self.assertEqual(result['httpStatus'], 422)
        self.assertIn('Validation failed', result.get('httpError', {}).get('message', ''))
        self.assertEqual(result.get('httpError', {}).get('errors'), [{'resource': 'Blob', 'field': 'content', 'code': 'too_large'}])
        self.assertFalse(result.get('httpError', {}).get('bodyTruncated', True))
        self.assertEqual(len(self.calls), 1)
        saved = (self.evidence / 'upload-001.json').read_text()
        for prohibited in (FAKE_TOKEN, raw.decode(), 'Authorization', 'Secret-Header'):
            self.assertNotIn(prohibited, saved)

    def test_oversized_non_json_error_is_bounded_and_not_logged_as_body(self):
        body = b'PRIVATE_RESPONSE_BODY' * 10000
        stream = io.BytesIO(body)
        error = urllib.error.HTTPError('https://api.github.com/unused', 422, 'refused', {}, stream)
        with self.assertRaises(RuntimeError):
            self.run_upload(b'hello', error=error)
        result = self.receipt()
        self.assertTrue(result.get('httpError', {}).get('bodyTruncated'))
        self.assertLessEqual(stream.tell(), 65537)
        self.assertNotIn('PRIVATE_RESPONSE_BODY', (self.evidence / 'upload-001.json').read_text())
        self.assertEqual(len(self.calls), 1)

    def test_server_echo_of_small_source_in_message_is_redacted(self):
        raw = b'SOURCE_BODY_MUST_NOT_BE_RETAINED'
        body = json.dumps({'message': 'Invalid content: ' + raw.decode()}).encode()
        error = urllib.error.HTTPError('https://api.github.com/unused', 422, 'refused', {}, io.BytesIO(body))
        with self.assertRaises(RuntimeError):
            self.run_upload(raw, error=error)
        self.assertNotIn(raw.decode(), (self.evidence / 'upload-001.json').read_text())

    def test_wrong_returned_git_sha_stops_without_retry(self):
        with self.assertRaises(ValueError):
            self.run_upload(b'hello', response=Response('0' * 40))
        self.assertEqual(self.receipt()['status'], 'UPLOAD_UNVERIFIED_STOPPED')
        self.assertEqual(len(self.calls), 1)

    def test_timeout_stops_without_alternate_request(self):
        with self.assertRaises(TimeoutError):
            self.run_upload(b'hello', error=TimeoutError('synthetic timeout'))
        self.assertEqual(self.receipt()['status'], 'UPLOAD_UNVERIFIED_STOPPED')
        self.assertEqual(len(self.calls), 1)

    def test_redirect_is_refused_and_child_environment_omits_token(self):
        with self.assertRaises(urllib.error.HTTPError):
            request = M.urllib.request.Request('https://api.github.com/repos/theislampill/salah_widget/git/blobs')
            M.NoRedirect().redirect_request(request, None, 302, 'redirect', {}, 'https://example.invalid/')
        with patch.dict(os.environ, {'R0007_UPLOAD_TOKEN': FAKE_TOKEN}):
            self.assertNotIn('R0007_UPLOAD_TOKEN', M.child_env())


class SeedTests(unittest.TestCase):
    def setUp(self):
        self.directory = Path(tempfile.mkdtemp(prefix='seed-', dir=RUNS))
        self.root = self.directory / 'source'
        self.root.mkdir()
        git(self.root, 'init', '-b', BRANCH)
        git(self.root, 'config', 'user.name', 'Local publication fixture')
        git(self.root, 'config', 'user.email', 'fixture@example.invalid')
        (self.root / 'src/native').mkdir(parents=True)
        (self.root / 'tools').mkdir()
        self.builder = ("from pathlib import Path\nimport hashlib,json\n"
                        "p=Path('src/native/index.html').read_bytes()\n"
                        "Path('index.html').write_bytes(b'INDEX '+p)\n"
                        "Path('offline.html').write_bytes(b'OFFLINE '+p)\n"
                        "Path('moon').mkdir(exist_ok=True)\n"
                        "Path('moon/BUILD.json').write_text(json.dumps({'sha256':hashlib.sha256(p).hexdigest()})+'\\n')\n")
        (self.root / 'tools/build_native.py').write_text(self.builder)
        (self.root / 'src/native/index.html').write_bytes(b'<html>base</html>\r\n')
        execute([sys.executable, 'tools/build_native.py'], cwd=self.root)
        self.base = self.commit('fixture base')
        (self.root / 'src/native/index.html').write_bytes('<html>target العربية</html>\r\n'.encode())
        execute([sys.executable, 'tools/build_native.py'], cwd=self.root)
        self.target = self.commit('fixture target')
        self.target_tree = git(self.root, 'rev-parse', self.target + '^{tree}')
        self.count = 0

    def commit(self, message):
        git(self.root, 'add', '-A')
        git(self.root, 'commit', '-m', message)
        return git(self.root, 'rev-parse', 'HEAD')

    def prepare(self, parent=None, check=True):
        self.count += 1
        out = self.directory / ('payload-' + str(self.count))
        argv = [sys.executable, str(HELPERS / 'prepare_payload.py'), '--source-root', str(self.root),
                '--base', self.base, '--target', self.target, '--output', str(out)]
        if parent is not None:
            argv += ['--seed-parent', parent]
        result = execute(argv, check=False)
        (self.directory / ('prepare-' + str(self.count) + '.stdout')).write_bytes(result.stdout)
        (self.directory / ('prepare-' + str(self.count) + '.stderr')).write_bytes(result.stderr)
        if check:
            self.assertEqual(result.returncode, 0, result.stderr.decode())
        return out, result

    def seed(self, parent, payload, extra=False):
        git(self.root, 'checkout', '--detach', parent)
        for relative in SEEDS:
            p = self.root / relative
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes((payload / relative).read_bytes())
        if extra:
            (self.root / 'unplanned-runtime.txt').write_text('must be rejected\n')
        return self.commit('fixture bootstrap seed')

    def continuation(self):
        first_payload, _ = self.prepare()
        first = self.seed(self.base, first_payload)
        git(self.root, 'checkout', BRANCH)
        second_payload, _ = self.prepare(first)
        return first, second_payload

    def materialize(self, source):
        evidence = self.directory / ('evidence-' + str(len(list(self.directory.glob('evidence-*')))))
        result = execute([sys.executable, str(source / '.github/r0007-bootstrap/materialize.py'),
                          '--source-root', str(source), '--manifest', str(source / '.github/r0007-bootstrap/manifest.json'),
                          '--evidence-root', str(evidence), '--dry-run'], check=False)
        (evidence / 'launcher.stdout').write_bytes(result.stdout)
        (evidence / 'launcher.stderr').write_bytes(result.stderr)
        summary = json.loads(next(evidence.glob('attempt-*/summary.json')).read_bytes())
        return result, summary, evidence

    def test_default_preparation_explicitly_binds_base_parent(self):
        payload, _ = self.prepare()
        manifest = json.loads((payload / '.github/r0007-bootstrap/manifest.json').read_bytes())
        self.assertEqual(manifest.get('expectedSeedParent'), self.base)

    def test_forward_seed_depth3_reconstructs_exact_candidate_tree(self):
        # Catches conflating immutable reconstruction base with immediate seed parent.
        first, payload = self.continuation()
        second = self.seed(first, payload)
        git(self.root, 'checkout', '-b', 'fixture-continuation', second)
        shallow = self.directory / 'depth3'
        execute(['git', 'clone', '--depth', '3', '--branch', 'fixture-continuation', self.root.as_uri(), str(shallow)])
        self.assertEqual(git(shallow, 'rev-list', '--count', 'HEAD'), '3')
        self.assertEqual(git(shallow, 'show', '-s', '--format=%P', 'HEAD'), first)
        result, summary, _ = self.materialize(shallow)
        self.assertEqual(result.returncode, 0, summary)
        self.assertEqual(summary['observedTargetTree'], self.target_tree)
        self.assertEqual(summary.get('expectedSeedParent'), first)
        self.assertEqual(summary['uploads'], [])
        self.assertFalse(summary['refUpdated'])
        self.assertEqual(git(self.root, 'diff', '--name-only', self.base, second).splitlines(), sorted(SEEDS))

    def test_wrong_immediate_parent_is_rejected_before_builder(self):
        first, payload = self.continuation()
        self.seed(self.base, payload)
        result, summary, evidence = self.materialize(self.root)
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(summary['status'], 'STOPPED_NO_REF_UPDATE')
        self.assertFalse(list(evidence.glob('attempt-*/04-real-native-builder.json')))

    def test_extra_cumulative_runtime_path_is_rejected_before_builder(self):
        first, payload = self.continuation()
        self.seed(first, payload, extra=True)
        result, summary, evidence = self.materialize(self.root)
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(summary['status'], 'STOPPED_NO_REF_UPDATE')
        self.assertFalse(list(evidence.glob('attempt-*/04-real-native-builder.json')))

    def test_preparer_rejects_runtime_candidate_as_seed_parent(self):
        out, result = self.prepare(self.target, check=False)
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(out.exists())

    def test_preparer_rejects_missing_seed_parent_object(self):
        out, result = self.prepare('1' * 40, check=False)
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(out.exists())


if __name__ == '__main__':
    unittest.main(verbosity=2)
