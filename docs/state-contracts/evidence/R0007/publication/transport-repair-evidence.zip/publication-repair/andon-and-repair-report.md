# R0007 publication transport: bounded Andon return and local repair

Date: 2026-11-10 UTC. Caller: `/root`. Scope: the failed hosted blob upload and a forward-only continuation of the existing bootstrap seed. This report does not qualify the native candidate, grant audit lifecycle status, or authorize publication, ref movement, merge, deployment, or release.

## Conclusion

The original HTTP 422 cause remains **UNKNOWN**. The hosted artifact proves that the materializer reconstructed the bound candidate tree and then received HTTP 422 for its first blob request. The implementation discarded GitHub's response body, so the retained evidence cannot distinguish a request-size refusal from another validation failure.

Two local mechanisms are established: the uploader always expands content to base64, and its exception handler loses diagnostic detail. A separate deterministic ancestry limitation rejects a legitimate successor bootstrap commit because it requires the current seed's immediate parent to be the original reconstruction base.

The bounded countermeasure is now implemented locally in the three files authorized by root. It chooses the documented UTF-8 representation when strict round-trip preserves the bytes, uses base64 for non-UTF-8 bytes, retains bounded sanitized failure diagnostics, and explicitly binds the immediate seed parent while keeping the original base and exact four-file cumulative bootstrap delta. The endpoint, repository, API version, permissions, no-retry rule, no-redirect rule, workflow exclusion, and prohibition on job ref/commit writes remain in place.

## Entry envelope and effect ceiling

This work entered `audit-andon` through root's explicit cord-pull around an actual observed hosted failure. The skill was read from `/home/agent/.codex/skills/remote-skills/skill-6a85962852508191a70c4b0eedbd1928/SKILL.md`. The bounded diagnosis was returned to root before repair. Root then explicitly authorized local edits to these files only:

- `analysis-r0007/publication-bootstrap/prepare_payload.py`
- `analysis-r0007/publication-bootstrap/templates/materialize.py`
- `analysis-r0007/publication-bootstrap/templates/r0007-materialize.yml`

The original bytes were copied into `publication-repair/original/` before any edit; `original/hashes.json` records their identities. Test fixtures, reports, receipts and this report are confined to `publication-repair/`. Local immutable Git objects from the candidate repository were read for measurement. No active repository file, index, branch, or ref was edited by this work. Fixture commits are restricted to newly created disposable repositories under `publication-repair/test-runs/`.

Root authorized read-only official GitHub documentation retrieval for diagnosis. No repository API, hosted-run mutation, credential acquisition/export, real upload, browser action, or publication was performed. No child audit package was routed.

## Evidence and bounded causal account

The hosted artifact ZIP has SHA256 `73d251c1058e843f794e15c4138f48527d1f25e1c0ff03afa6d44e3930e2db0e`, independently recomputed here. Its extracted attempt is `publication-bootstrap/hosted-run-42754815319/attempt-3luhvrw2/`.

The retained `summary.json`, `upload-001.json`, launcher receipt and launcher log establish:

| Fact | Retained value |
|---|---|
| Hosted run / job | `42754815319` / `129626629674` (job identifier supplied by root) |
| Seed commit | `19004279805604ef5e41292ffd4e9f442e1321f2` |
| Original base commit | `eebba178172f96b3ffe5ab3845bc0fffd57c6e1b` |
| Bound local candidate | `b20e3aa64f4cec47a8b025be1b77a9b9c0bb955b` |
| Expected and observed target tree | `1666a919dc9d197e9ff95d28eb013470ba822d5c` |
| Manifest SHA256 | `2b806bfbc43340e9d240fb6e23f67a64dadf71d99abafc9dc3daff2daf61b3a6` |
| First attempted blob | `offline.html`, 81,702,660 bytes |
| Expected blob SHA | `7da1308517d143c38708ac9a0afbd0790e137e33` |
| Result | HTTP 422; exit 1; zero verified upload receipts |
| Job ref effects | No ref operation exists in the reviewed helper; retained result reports `refUpdated: false` |

Zero verified uploads is not proof about the existence of an unreferenced object inside GitHub. No returned blob SHA was retained for the failed request. The branch/head facts in the commission were not refreshed by this subtask and are not newly minted currentness evidence.

The causal inquiry stops at the missing response body: the downstream upload failure is established, the API's precise reason is not. The unconditional serialization and insufficient failure evidence are local helper mechanisms. There is no evidence here of a native builder mismatch, a product-source defect causing the transport failure, an authorization bypass, or a need for broader token permissions.

## Primary GitHub documentation

[GitHub REST API: Git blobs](https://docs.github.com/en/rest/git/blobs?apiVersion=2022-11-28) was retrieved on 2026-11-10. Its create-blob section documents `POST /repos/{owner}/{repo}/git/blobs`, accepts `utf-8` and `base64`, lists Contents-write permission, and describes HTTP 422 as validation failure. The same page's 100-megabyte note belongs to **Get a blob**, not to a documented create-request JSON-body ceiling.

[GitHub: About large files](https://docs.github.com/en/repositories/working-with-files/managing-large-files/about-large-files-on-github) states the repository file-size block above 100 MiB. The original 81,702,660-byte content is below that size. These sources support the alternate documented encoding and delimit what can be concluded about size; neither proves the old 422 was caused by the 108.9 MB JSON body. The existing API-version header was preserved.

## Actual byte measurements

The independent pre-repair measurement and the repaired uploader's fake-transport exercise agree:

| Content | Original content bytes | Legacy base64 JSON bytes | Repaired UTF-8 JSON bytes |
|---|---:|---:|---:|
| `offline.html` | 81,702,660 | 108,936,917 | 82,904,481 |
| `index.html` | 1,590,626 | 2,120,873 | 1,608,148 |

The repaired `offline.html` request is 26,032,436 bytes smaller. Its request-body SHA256 is `283325576fc9ad673ffce0b3751d881b538dfbd482f552d25c93709124770e35`; its content SHA256 remains `697ed290d2f71a777b9c1a44c3d7b12350cd51dfc66648e8c8907ff897e9be57` and its Git blob SHA remains `7da1308517d143c38708ac9a0afbd0790e137e33`.

All 106 changed non-workflow blobs from the immutable b20e3aa manifest were exercised through the repaired uploader. The fake transport decoded the actual outgoing JSON, checked its byte length and SHA256 against the independently prepared manifest, and ran `git hash-object --stdin` on the decoded bytes. All matched. Of the 106 blobs, 105 used UTF-8; only `r0007-source-history.bundle` required base64.

The full machine-readable record is `transport-measurement-b20e3aa.json`; individual upload-function receipts are in `byte-validation-b20e3aa/`. **Those HTTP 201 receipts came from a fake transport. They establish local request construction and verification behavior only, not real GitHub object storage or hosted transport success.**

## Implemented controls

### Blob request and failure evidence

Before creating a request, the uploader independently verifies content length, SHA256 and Git blob SHA against the manifest. Strict UTF-8 decoding is followed by strict re-encoding and byte equality. Valid UTF-8 is serialized with `ensure_ascii=False` and compact JSON separators; invalid UTF-8 uses base64. Selection happens before the sole request. A refusal or uncertain result never triggers a different encoding, retry, alternate endpoint or credential.

Each receipt now records selected encoding, exact request byte length, request SHA256 and local Git blob SHA. Returned blob SHA comparison remains mandatory. Request headers and source content are never dumped into receipts.

HTTP failures read at most 65,537 bytes. The receipt retains prefix hash, byte count and truncation metadata, and only allowlisted JSON diagnostic fields: bounded message, a GitHub documentation URL, and bounded `resource`/`field`/`code` error items. Unknown fields, echoed `value`/`content`, all headers and raw response bodies are omitted. Token values and full small-source echoes are redacted from retained text. Oversized or non-JSON error bodies retain structural metadata only. A failure while reading the diagnostic body records its exception class, not arbitrary exception text.

### Explicit forward seed binding

The preparer accepts `--seed-parent <full SHA>` with explicit default to the supplied base. The manifest and preparation receipt include `expectedSeedParent`. The preparer requires that object to exist locally as a commit. A non-base parent must have the original base as its sole parent and have exactly the four bootstrap paths as its cumulative delta from that base.

The materializer independently validates that declared parent, checks the current seed's sole parent against the declaration, and still requires exactly the four bootstrap paths in the current seed's cumulative delta from the original base. It still pins the base tree and reconstructs from the original base. Existing target-tree, manifest/materializer/patch, path, dirty-state and unplanned-builder-change checks remain in force. An absent or invalid `expectedSeedParent` is rejected; the helper does not infer a parent from branch state.

The workflow checkout depth changes from two to three. This supplies successor → current seed → original base for the specifically authorized one-step continuation. It does not silently admit arbitrary chains or use an opportunistic remote fetch. The existing fixed repository/ref/event restrictions, Contents-write-only permission, disabled checkout credential persistence, token stripping from child processes and excluded workflow blobs remain unchanged.

For the actual next preparation, the intended explicit parent is `19004279805604ef5e41292ffd4e9f442e1321f2`; the original base remains `eebba178172f96b3ffe5ab3845bc0fffd57c6e1b`. At handoff, root reported that the actual seed object has been fetched locally without branch movement, making it available for the preparer's read-only validation.

## Validation and exact repaired identities

The local test suite was written and run before helper edits. It ran 15 tests and produced nine expected failures for the missing UTF-8/evidence/parent behavior. After the repair, all 15 tests completed with exit 0. Raw producer records are `red-tests.json` and `green-tests-1.json`; their complete outputs are the matching `.log` files. `test_publication_transport.py` is the runnable suite.

The suite covers Unicode/BOM/line-ending/control-byte preservation; invalid UTF-8 base64; wrong input and returned Git identities; fake success and HTTP refusal; bounded non-JSON errors; token/source/header omission; timeout and no-retry behavior; redirect refusal; child token stripping; explicit default parent binding; a real depth-three forward seed fixture rebuilding its exact target tree; wrong immediate parent; extra runtime paths; and absent/incoherent seed-parent objects. The negative ancestry cases stop before invoking the builder.

AST parsing succeeded for both Python files. YAML parsing confirmed depth three, only Contents-write permission and disabled persisted checkout credentials. These checks and file digests are recorded in `repair-hashes-and-static-validation.json`.

| Repaired helper | Bytes | SHA256 |
|---|---:|---|
| `prepare_payload.py` | 7,019 | `fc85ff2ce1f65b677e2d955ecf0a4c1489cd84f0b94dfd73dd026f9594952b81` |
| `templates/materialize.py` | 17,511 | `5c40102037ab6adc3a73ca27a80974eb71e3223a450ef04ffaea129dc9ffd55a` |
| `templates/r0007-materialize.yml` | 2,270 | `77a56129d289e98083c2ea4b0fca42de10efc64ecae1d3bdd955456c332b3730` |

The authoritative machine-readable hashes are in `repair-hashes-and-static-validation.json`. The human report and a unified original-to-repaired diff are provided for the separate reviewer.

## Escalation recommendation and follow-up obligation

The repair is ready for root's separately commissioned independent helper review. It is not a hosted transport success claim. No larger permission, job token export, job ref writer, force push or content-changing workaround is recommended.

After review, root should bind a fresh payload to the final corrected clean candidate, not treat this b20e3aa measurement as qualification of the candidate root is repairing. That payload needs an actual disposable dry reconstruction, a manifest bound to the explicit existing seed parent, and fresh review of the exact four bootstrap bytes. Root can then create a forward successor whose only cumulative application-base delta remains those four bootstrap files and whose sole parent is the verified current seed. Root retains connector publication and ref authority.

One separately authorized hosted run can test the materially smaller request. Its artifact must retain either all expected matching blob receipts or the first bounded diagnostic refusal. A new failure returns for diagnosis; it does not authorize retries, broader credentials, relaxed ancestry, or alternate endpoints. Any subsequent connector finalization must reconcile the fresh artifact, exact candidate tree, current expected branch head and separately handled workflow blobs. Native acceptance, audit closure, merge order and merge approval remain outside this work.
