#!/usr/bin/env python3
"""Independent pure review checks; all HTTP is mocked and no Git state is written."""
import ast
import io
import json
from pathlib import Path
from types import SimpleNamespace
import unittest
import urllib.error


HELPERS = Path('/workspace/scratch/8726e3e6def5/analysis-r0007/publication-bootstrap')
SOURCE = HELPERS / 'templates/materialize.py'
TEXT = SOURCE.read_text()
M = {'__name__': 'independent_review_subject', '__file__': str(SOURCE)}
exec(compile(TEXT, str(SOURCE), 'exec'), M)
MARKER = 'SYNTHETIC_PRIVATE_SOURCE_FRAGMENT_739'
TOKEN = 'TEST_ONLY_FAKE_TOKEN_481'
BASE = 'a' * 40
FIRST = 'b' * 40
NEXT = 'c' * 40
OTHER = 'd' * 40
SEEDS = M['SEED_FILES']


def diagnostic(content, message):
    raw = json.dumps({'message': message}).encode()
    error = urllib.error.HTTPError('https://api.github.com/unused', 422,
                                   'synthetic fixture', {}, io.BytesIO(raw))
    return M['http_error_details'](error, TOKEN, content)


def guard_code():
    tree = ast.parse(TEXT)
    main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
    body = next(n.body for n in main.body if isinstance(n, ast.Try))

    def assigns(node, name):
        return isinstance(node, ast.Assign) and any(
            isinstance(t, ast.Name) and t.id == name for t in node.targets)

    start = next(i for i, n in enumerate(body) if assigns(n, 'expected_parent'))
    end = next(i for i, n in enumerate(body) if assigns(n, 'dirty'))
    builder = next(n.lineno for n in ast.walk(main)
                   if isinstance(n, ast.Constant) and n.value == '04-real-native-builder')
    assert max(n.end_lineno for n in body[start:end]) < builder
    return compile(ast.Module(body=body[start:end], type_ignores=[]), str(SOURCE), 'exec')


GUARD = guard_code()


def run_guard(parent=FIRST, head=NEXT, previous_parents=None,
              previous_delta=None, current_parents=None, current_delta=None,
              parent_type='commit', upload=True):
    previous_parents = [BASE] if previous_parents is None else previous_parents
    previous_delta = SEEDS if previous_delta is None else previous_delta
    current_parents = [parent] if current_parents is None else current_parents
    current_delta = SEEDS if current_delta is None else current_delta

    def git(root, *args):
        if args == ('cat-file', '-t', parent):
            return parent_type + '\n'
        if args == ('show', '-s', '--format=%P', parent):
            return ' '.join(previous_parents) + '\n'
        if args == ('show', '-s', '--format=%P', 'HEAD'):
            return ' '.join(current_parents) + '\n'
        if args[:4] == ('diff', '--no-renames', '--name-only', '-z'):
            if args[4:] == (BASE, parent):
                return ''.join(p + '\0' for p in sorted(previous_delta))
            if args[4:] == (BASE, 'HEAD'):
                return ''.join(p + '\0' for p in sorted(current_delta))
        raise AssertionError('unexpected Git operation in guard: ' + repr(args))

    context = {'manifest': {'baseCommit': BASE, 'expectedSeedParent': parent},
               'root': object(), 'head': head, 'git': git, 'SEED_FILES': SEEDS,
               'args': SimpleNamespace(upload_blobs=upload)}
    exec(GUARD, context)


class IndependentChecks(unittest.TestCase):
    def test_large_source_echo_is_not_retained(self):
        """Expected privacy contract; this exposes the frozen successor's gap."""
        content = (MARKER + 'x' * 65537).encode()
        result = diagnostic(content, 'Invalid content: ' + MARKER)
        self.assertNotIn(MARKER, json.dumps(result))

    def test_partial_small_source_echo_is_not_retained(self):
        """Whole-source substitution cannot sanitize a partial server echo."""
        content = ('begin ' + MARKER + ' end').encode()
        result = diagnostic(content, 'Invalid content: ' + MARKER)
        self.assertNotIn(MARKER, json.dumps(result))

    def test_full_small_source_and_token_are_redacted(self):
        content = MARKER.encode()
        result = diagnostic(content, 'Invalid content: ' + MARKER + ' ' + TOKEN)
        self.assertNotIn(MARKER, json.dumps(result))
        self.assertNotIn(TOKEN, json.dumps(result))

    def test_seed_guard_positive_and_negative_matrix(self):
        cases = [
            ('initial seed', {'parent': BASE, 'head': FIRST}, True),
            ('one forward successor', {}, True),
            ('wrong immediate parent', {'current_parents': [BASE]}, False),
            ('unrelated declared parent', {'previous_parents': [OTHER]}, False),
            ('merge declared parent', {'previous_parents': [BASE, OTHER]}, False),
            ('non-bootstrap declared parent', {'previous_delta': SEEDS | {'runtime.js'}}, False),
            ('extra cumulative runtime path', {'current_delta': SEEDS | {'runtime.js'}}, False),
            ('missing cumulative seed path', {'current_delta': SEEDS - {'.github/r0007-bootstrap/source.patch'}}, False),
            ('non-commit declared parent', {'parent_type': 'blob'}, False),
            ('base cannot upload', {'parent': BASE, 'head': BASE}, False),
            ('base dry reconstruction', {'parent': BASE, 'head': BASE, 'upload': False}, True),
        ]
        for label, arguments, accepted in cases:
            with self.subTest(case=label):
                if accepted:
                    run_guard(**arguments)
                else:
                    with self.assertRaises(ValueError):
                        run_guard(**arguments)


if __name__ == '__main__':
    unittest.main(verbosity=2)
