#!/usr/bin/env python3
"""Pure independent boundary checks for fixed diagnostic metadata."""
import hashlib
import io
import json
from pathlib import Path
import unittest
import urllib.error

SOURCE = Path('/workspace/scratch/8726e3e6def5/analysis-r0007/publication-bootstrap/templates/materialize.py')
M = {'__name__': 'privacy_boundary_subject', '__file__': str(SOURCE)}
exec(compile(SOURCE.read_text(), str(SOURCE), 'exec'), M)


def inspect_body(raw):
    stream = io.BytesIO(raw)
    error = urllib.error.HTTPError('https://api.github.com/unused', 422,
                                   'SYNTHETIC_REASON_OMIT', {}, stream)
    details = M['http_error_details'](error, 'TEST_ONLY_FAKE_TOKEN', b'fixture source')
    return details, stream.tell()


class BoundaryChecks(unittest.TestCase):
    def test_exact_body_limit_and_one_byte_over_are_bounded(self):
        prefix, suffix = b'{"message":"', b'"}'
        raw = prefix + b'x' * (65536 - len(prefix) - len(suffix)) + suffix
        details, read = inspect_body(raw)
        self.assertEqual(read, 65536)
        self.assertEqual(details['bodyFormat'], 'JSON_OBJECT')
        self.assertFalse(details['bodyTruncated'])
        self.assertEqual(details['bodyPrefixSha256'], hashlib.sha256(raw).hexdigest())
        self.assertNotIn('message', details)
        details, read = inspect_body(raw + b' ')
        self.assertEqual(read, 65537)
        self.assertEqual(details['bodyFormat'], 'TRUNCATED')
        self.assertTrue(details['bodyTruncated'])
        self.assertEqual(details['bodyPrefixSha256'], hashlib.sha256(raw).hexdigest())

    def test_error_classes_are_fixed_and_at_most_twenty_items_are_examined(self):
        marker = 'SYNTHETIC_ARBITRARY_RESPONSE_STRING_691'
        errors = [{'code': 'missing'}, {'code': 'too_large'}]
        errors += [{'code': marker, 'resource': marker, 'field': marker, 'value': marker}] * 19
        raw = json.dumps({'message': marker, 'documentation_url': marker, 'errors': errors}).encode()
        details, read = inspect_body(raw)
        self.assertEqual(read, len(raw))
        self.assertEqual(details['errorsExamined'], 20)
        self.assertTrue(details['errorsTruncated'])
        self.assertEqual(details['errorClasses'], ['API_CODE_MISSING', 'API_CODE_TOO_LARGE',
                                                   'UNRECOGNIZED_ERROR_CODE'])
        self.assertNotIn(marker, json.dumps(details))
        self.assertEqual(set(details), {'statusClass', 'bodyReadStatus', 'bodyBytesRead',
                                      'bodyTruncated', 'bodyPrefixSha256', 'bodyFormat',
                                      'errorClasses', 'errorsExamined', 'errorsTruncated'})

    def test_malformed_and_non_object_bodies_retain_only_fixed_shape(self):
        for raw, format_name in [(b'\xffinvalid', 'UNPARSEABLE'),
                                 (b'["SYNTHETIC_RESPONSE_FRAGMENT"]', 'JSON_NON_OBJECT')]:
            with self.subTest(format=format_name):
                details, read = inspect_body(raw)
                self.assertEqual(read, len(raw))
                self.assertEqual(details['bodyFormat'], format_name)
                self.assertEqual(set(details), {'statusClass', 'bodyReadStatus', 'bodyBytesRead',
                                               'bodyTruncated', 'bodyPrefixSha256', 'bodyFormat'})
                self.assertNotIn('SYNTHETIC_RESPONSE_FRAGMENT', json.dumps(details))


if __name__ == '__main__':
    unittest.main(verbosity=2)
