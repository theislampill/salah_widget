#!/usr/bin/env python3
"""Bounded Git-version diagnostic probe; nonsecret marker, no repository or network."""
from pathlib import Path
import hashlib
import json
import subprocess

BASE = Path(__file__).resolve().parent / "config-probe"
BASE.mkdir(exist_ok=True)
GIT = Path("/usr/bin/git")
MARKER_NAME = "R0007_ANDON_NONSECRET_MARKER"
MARKER_VALUE = "public-diagnostic-marker"
results = []
for name in ("global_config_only", "explicit_target_disable", "isolated_global_config"):
    case = BASE / name
    case.mkdir(exist_ok=True)
    home = case / "home"
    home.mkdir(exist_ok=True)
    targets = {"normalTarget": case / "normal.trace", "eventTarget": case / "event.jsonl", "perfTarget": case / "perf.trace"}
    config = case / "global.config"
    config.write_text("[trace2]\n" + "".join("\t" + key + " = " + str(path) + "\n" for key, path in targets.items()) + "\tenvVars = " + MARKER_NAME + "\n")
    env = {"PATH": "/usr/bin:/bin", "HOME": str(home), "LC_ALL": "C", "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": str(config), MARKER_NAME: MARKER_VALUE}
    if name == "explicit_target_disable":
        env.update(GIT_TRACE2="0", GIT_TRACE2_EVENT="0", GIT_TRACE2_PERF="0")
    elif name == "isolated_global_config":
        env["GIT_CONFIG_GLOBAL"] = "/dev/null"
    process = subprocess.run([str(GIT), "version"], cwd=case, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    result = {"case": name, "argv": [str(GIT), "version"], "exitCode": process.returncode, "gitVersion": process.stdout.decode().strip(), "stderrBytes": len(process.stderr), "config": str(config), "configSha256": hashlib.sha256(config.read_bytes()).hexdigest(), "targets": []}
    for kind, target in targets.items():
        entry = {"kind": kind, "path": str(target), "exists": target.exists()}
        if target.exists():
            raw = target.read_bytes()
            entry.update(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(), nonsecretMarkerPresent=MARKER_VALUE.encode() in raw)
        result["targets"].append(entry)
    results.append(result)
record = {"scope": "git version only; no repository/ref operations; no network; explicit nonsecret marker only", "scriptSha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "gitExecutable": str(GIT.resolve()), "gitExecutableSha256": hashlib.sha256(GIT.read_bytes()).hexdigest(), "cases": results}
output = Path(__file__).resolve().parent / "git-trace2-config-probe-result.json"
output.write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
