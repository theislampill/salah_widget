#!/usr/bin/env python3
"""Held-out local Git credential-file boundary; never contacts a network endpoint."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import types
import unittest
from unittest.mock import patch


REVIEW = Path(__file__).resolve().parent
HELPER = REVIEW.parent / 'publication-pack/templates/materialize.py'
REF = 'refs/heads/pro/r0007-explicit-next-event-state-20261106'


class TraceBoundary(unittest.TestCase):
    def test_trace_configuration_cannot_persist_push_credential(self):
        raw = HELPER.read_bytes()
        self.assertEqual(hashlib.sha256(raw).hexdigest(),
                         'd17689992e2d392e8489018a58cc402676627d076515f99cd311eaee56b8e8d7')
        subject = types.ModuleType('pack_review_subject')
        subject.__file__ = str(HELPER)
        exec(compile(raw, str(HELPER), 'exec'), subject.__dict__)
        fixtures = REVIEW / 'fixtures'
        fixtures.mkdir(exist_ok=True)
        root = Path(tempfile.mkdtemp(prefix='trace-boundary-', dir=fixtures))
        work, bare, evidence = root / 'work', root / 'remote.git', root / 'evidence'
        evidence.mkdir()
        environment = {'PATH': os.environ.get('PATH', '/usr/bin:/bin'),
                       'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': os.devnull,
                       'GIT_TERMINAL_PROMPT': '0', 'LC_ALL': 'C',
                       'PYTHONDONTWRITEBYTECODE': '1'}

        def git(cwd, *arguments):
            result = subprocess.run(['git', '-C', str(cwd), *arguments], env=environment,
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
            return result.stdout.decode().strip()

        git(root, 'init', '--quiet', '--initial-branch=fixture', str(work))
        git(root, 'init', '--quiet', '--bare', str(bare))
        git(work, 'config', 'user.name', 'Independent local review')
        git(work, 'config', 'user.email', 'review@example.invalid')

        def commit(label):
            (work / 'payload.txt').write_text(label + '\n')
            git(work, 'add', 'payload.txt')
            git(work, 'commit', '--quiet', '-m', label)
            return git(work, 'rev-parse', 'HEAD')

        seed = commit('synthetic seed')
        intermediate = commit('synthetic intermediate')
        remote = bare.as_uri()
        git(work, 'push', '--quiet', remote, seed + ':' + REF)
        trace = evidence / 'git-trace2.jsonl'
        token = 'R0007_INDEPENDENT_SYNTHETIC_CREDENTIAL_NO_AUTHORITY'
        ambient = {**environment, 'GIT_TRACE2_EVENT': str(trace),
                   'GIT_TRACE2_ENV_VARS': 'R0007_PUSH_TOKEN'}
        with patch.dict(os.environ, ambient, clear=True), patch.object(subject, 'REMOTE', remote):
            result = subject.publish_intermediate(work, intermediate, seed, evidence, token)
        observed = git(bare, 'rev-parse', REF)
        leaked = trace.exists() and token.encode() in trace.read_bytes()
        record = {'schema': 'independent-pack-trace-boundary/v1',
                  'localFixtureOnly': True, 'productionRemoteContacted': False,
                  'fixture': str(root), 'helperSha256': hashlib.sha256(raw).hexdigest(),
                  'publicationStatus': result['status'], 'refUpdated': result['refUpdated'],
                  'expectedIntermediate': intermediate, 'observedRemote': observed,
                  'traceFile': str(trace), 'syntheticCredentialPersisted': leaked,
                  'structuredReceiptContainsCredential': token in json.dumps(result),
                  'gitConfigContainsCredential': token in (work / '.git/config').read_text(),
                  'gitVersion': git(root, '--version')}
        (root / 'witness.json').write_text(json.dumps(record, indent=2) + '\n')
        print(json.dumps(record, indent=2), flush=True)
        self.assertFalse(leaked, 'inherited Git Trace2 configuration persisted the synthetic push credential')


if __name__ == '__main__':
    unittest.main(verbosity=2)
