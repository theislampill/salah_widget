"""Synthetic credential prompts only; Git credential fill makes no network call."""
import importlib.util
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class AuthBoundaryTests(unittest.TestCase):
    def setUp(self):
        spec = importlib.util.spec_from_file_location('pack_auth', ROOT / 'templates/materialize.py')
        self.M = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.M)
        self.assertTrue(callable(getattr(self.M, 'askpass_script', None)), 'missing credential boundary')
        runs = ROOT / 'test-runs-auth'
        runs.mkdir(exist_ok=True)
        self.root = Path(tempfile.mkdtemp(prefix='auth-', dir=runs))
        self.script = self.root / 'askpass'
        self.script.write_text(self.M.askpass_script())
        self.script.chmod(0o700)
        self.token = 'SYNTHETIC_ASKPASS_TOKEN_NO_AUTHORITY_2637'
        self.env = {'PATH': os.environ.get('PATH', '/usr/bin:/bin'), 'HOME': str(self.root),
                    'GIT_CONFIG_NOSYSTEM': '1', 'GIT_TERMINAL_PROMPT': '0', 'LC_ALL': 'C',
                    'GIT_ASKPASS': str(self.script), 'R0007_PUSH_TOKEN': self.token}

    def test_real_git_credential_fill_uses_exact_repository_prompts(self):
        result = subprocess.run(['git', '-c', 'credential.helper=', '-c', 'credential.useHttpPath=true', 'credential', 'fill'],
                                input=b'protocol=https\nhost=github.com\npath=theislampill/salah_widget.git\n\n',
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=self.env)
        self.assertEqual(result.returncode, 0)
        self.assertIn(b'username=x-access-token\n', result.stdout)
        self.assertIn(('password=' + self.token + '\n').encode(), result.stdout)
        self.assertNotIn(self.token.encode(), self.script.read_bytes())
        self.assertEqual(result.stderr, b'')

    def test_other_hosts_paths_and_arbitrary_prompts_receive_no_credential(self):
        prompts = ["Password for 'https://x-access-token@example.invalid/theislampill/salah_widget.git': ",
                   "Password for 'https://x-access-token@github.com/other/repository.git': ",
                   "Password for 'http://x-access-token@github.com/theislampill/salah_widget.git': ",
                   'SYNTHETIC_UNKNOWN_PROMPT']
        for prompt in prompts:
            with self.subTest(prompt_type=prompts.index(prompt)):
                result = subprocess.run([str(self.script), prompt], stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=self.env)
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(result.stdout, b'')
                self.assertNotIn(self.token.encode(), result.stderr)


if __name__ == '__main__':
    unittest.main(verbosity=2)
