"""Local, disposable-Git controls for the R0007 publication boundary.

Run with PYTHONDONTWRITEBYTECODE=1.  Every Git endpoint used by these tests is
a fresh file:// bare repository.  The fixed production remote is patched only
in the imported module; this does not introduce a production remote override.
The tests retain their fixtures below test-runs-push for producer inspection.
"""

from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest
from unittest import mock


PACK = Path(__file__).resolve().parents[1]
MODULE = PACK / "templates" / "materialize.py"
RUNS = PACK / "test-runs-push"
REMOTE = "https://github.com/theislampill/salah_widget.git"
REF = "refs/heads/pro/r0007-explicit-next-event-state-20261106"
SUCCESS = "REMOTE_REF_VERIFIED_INTERMEDIATE"
REAL_RUN = subprocess.run
REAL_POPEN = subprocess.Popen


def is_git(argv, command):
    return (
        isinstance(argv, (tuple, list))
        and bool(argv)
        and Path(str(argv[0])).name == "git"
        and command in [str(part) for part in argv[1:]]
    )


def scalar_values(value):
    if isinstance(value, dict):
        for nested in value.values():
            yield from scalar_values(nested)
    elif isinstance(value, (list, tuple)):
        for nested in value:
            yield from scalar_values(nested)
    else:
        yield value


class GitFixture:
    """All mutations, including adversarial ref movement, stay in this root."""

    def __init__(self, root):
        self.root = root
        self.work = root / "checkout"
        self.bare = root / "remote.git"
        self.evidence = root / "evidence"
        self.home = root / "home"
        self.evidence.mkdir()
        self.home.mkdir()
        self.env = {
            "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
            "HOME": str(self.home),
            "XDG_CONFIG_HOME": str(self.home / "config"),
            "GIT_CONFIG_NOSYSTEM": "1",
            "GIT_TERMINAL_PROMPT": "0",
            "LC_ALL": "C",
            "GIT_AUTHOR_DATE": "2026-01-01T00:00:00Z",
            "GIT_COMMITTER_DATE": "2026-01-01T00:00:00Z",
        }
        self.git("init", "--quiet", "--initial-branch=fixture-work", str(self.work), cwd=root)
        self.git("init", "--quiet", "--bare", str(self.bare), cwd=root)
        self.git("config", "user.name", "R0007 Disposable Fixture")
        self.git("config", "user.email", "r0007-fixture@example.invalid")
        self.base = self.commit("base", "base\n")
        self.seed = self.commit("seed", "seed\n")
        self.intermediate = self.commit("intermediate", "intermediate\n")
        self.advanced = self.commit("remote advanced", "remote advanced\n")
        self.remote = self.bare.as_uri()
        self.git("push", "--quiet", self.remote, f"{self.advanced}:{REF}")
        self.set_remote(self.seed)
        self.git("update-ref", "refs/heads/main", self.base, cwd=self.bare)
        self.git("update-ref", "refs/heads/untouched-sibling", self.base, cwd=self.bare)
        self.git("update-ref", "refs/tags/untouched-tag", self.base, cwd=self.bare)
        self.git("reset", "--quiet", "--hard", self.intermediate)
        self.git("branch", "unpublished-local-branch", self.intermediate)
        self.git("tag", "unpublished-local-tag", self.intermediate)

    def git(self, *args, cwd=None):
        completed = REAL_RUN(
            ["git", "-C", str(cwd or self.work), *map(str, args)],
            env=self.env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=True,
        )
        return completed.stdout.strip()

    def commit(self, message, contents):
        (self.work / "payload.txt").write_text(contents, encoding="utf-8")
        self.git("add", "payload.txt")
        self.git("commit", "--quiet", "-m", message)
        return self.git("rev-parse", "HEAD")

    def set_remote(self, commit):
        self.git("update-ref", REF, commit, cwd=self.bare)

    def refs(self):
        return {
            ref: sha
            for sha, ref in (line.split() for line in self.git("show-ref", cwd=self.bare).splitlines())
        }


class ChildLaunches:
    """Observe real process launches; never replace ordinary Git behavior."""

    def __init__(self, module, before_push=None):
        self.module = module
        self.before_push = before_push
        self.calls = []
        self._moved = False

    def _popen(self, argv, *args, **kwargs):
        environment = kwargs.get("env")
        self.calls.append(
            {
                "argv": list(argv) if isinstance(argv, (list, tuple)) else argv,
                "env": dict(os.environ if environment is None else environment),
                "shell": kwargs.get("shell", False),
            }
        )
        if is_git(argv, "push") and self.before_push is not None and not self._moved:
            self._moved = True
            self.before_push()
        return REAL_POPEN(argv, *args, **kwargs)

    def __enter__(self):
        self.patch = mock.patch.object(self.module.subprocess, "Popen", self._popen)
        self.patch.start()
        return self

    def __exit__(self, *exception):
        self.patch.stop()

    @property
    def pushes(self):
        return [call for call in self.calls if is_git(call["argv"], "push")]


class GitPushControls(unittest.TestCase):
    def setUp(self):
        self.assertTrue(MODULE.is_file(), "publication materialize.py has not been implemented")
        spec = importlib.util.spec_from_file_location("r0007_push_controls_materialize", MODULE)
        self.assertIsNotNone(spec)
        self.assertIsNotNone(spec.loader)
        self.M = importlib.util.module_from_spec(spec)
        # Import the materializer without writing outside this test's assigned scope.
        previous = sys.dont_write_bytecode
        sys.dont_write_bytecode = True
        try:
            spec.loader.exec_module(self.M)
        finally:
            sys.dont_write_bytecode = previous
        self.assertTrue(callable(getattr(self.M, "publish_intermediate", None)),
                        "publish_intermediate has not been implemented")
        self.assertTrue(callable(getattr(self.M, "guard_script", None)),
                        "guard_script has not been implemented")
        RUNS.mkdir(exist_ok=True)
        self.run_root = Path(tempfile.mkdtemp(prefix=self._testMethodName + "-", dir=RUNS))
        self.fixture = GitFixture(self.run_root)
        self.environment = mock.patch.dict(os.environ, self.fixture.env, clear=True)
        self.environment.start()
        self.addCleanup(self.environment.stop)

    def publish(self, token="fixture-token-with-no-authority", evidence=None):
        with mock.patch.object(self.M, "REMOTE", self.fixture.remote):
            result = self.M.publish_intermediate(
                self.fixture.work,
                self.fixture.intermediate,
                self.fixture.seed,
                evidence or self.fixture.evidence,
                token,
            )
        self.assertIsInstance(result, dict)
        return result

    def assert_refusal(self, result, launches):
        self.assertNotEqual(result.get("status"), SUCCESS)
        self.assertIn("refUpdated", result)
        if launches.pushes:
            self.assertEqual(result.get("status"), "PUSH_UNCERTAIN")
            self.assertIsNone(result["refUpdated"])
        else:
            self.assertEqual(result.get("status"), "REFUSED_BEFORE_PUSH")
            self.assertIs(result["refUpdated"], False)

    def assert_token_absent_from_files(self, token):
        needle = token.encode("utf-8")
        for path in self.run_root.rglob("*"):
            if path.is_file() and not path.is_symlink():
                self.assertNotIn(needle, path.read_bytes(), f"token persisted in {path}")

    def run_guard(self, stdin, *, remote_name=REMOTE, remote_location=REMOTE, label="guard"):
        directory = self.run_root / label
        directory.mkdir()
        intent = directory / "intent.json"
        receipt = directory / "receipt.json"
        hook = directory / "pre-push"
        intent.write_text(
            json.dumps({
                "remote": REMOTE,
                "ref": REF,
                "expectedRemote": self.fixture.seed,
                "newCommit": self.fixture.intermediate,
            }),
            encoding="utf-8",
        )
        hook.write_text(self.M.guard_script(intent, receipt), encoding="utf-8")
        hook.chmod(0o700)
        completed = REAL_RUN(
            [str(hook), remote_name, remote_location],
            input=stdin,
            env=self.fixture.env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        self.assertTrue(receipt.is_file(), "guard did not retain a structured receipt")
        record = json.loads(receipt.read_text(encoding="utf-8"))
        self.assertEqual(record.get("schema"), "r0007-pack-guard/v1")
        self.assertIn(record.get("status"), {"ACCEPTED", "REFUSED"})
        self.assertIsInstance(record.get("reason"), str)
        self.assertTrue(record["reason"], "guard receipt needs a fixed reason classification")
        return completed, record

    def advertised_line(self, *, old=None, new=None, ref=REF):
        commit = new or self.fixture.intermediate
        return f"{commit} {commit} {ref} {old or self.fixture.seed}\n"

    def test_single_ref_push_updates_exact_intermediate_and_verifies_readback(self):
        # Catches a wrong refspec, an omitted push, extra refs, or unverified success.
        expected = self.fixture.refs()
        expected[REF] = self.fixture.intermediate
        with ChildLaunches(self.M) as launches:
            result = self.publish()
        self.assertEqual(result.get("status"), SUCCESS)
        self.assertIs(result.get("refUpdated"), True)
        self.assertEqual(self.fixture.refs(), expected)
        self.assertEqual(len(launches.pushes), 1)
        argv = [str(value) for value in launches.pushes[0]["argv"]]
        self.assertIn(f"{self.fixture.intermediate}:{REF}", argv)
        self.assertFalse(any(value.startswith("+") for value in argv))
        self.assertFalse(any(re.match(r"--(?:force|mirror|all|tags|delete|follow-tags)", value)
                             for value in argv))
        push_index = launches.calls.index(launches.pushes[0])
        self.assertTrue(any(is_git(call["argv"], "ls-remote")
                            for call in launches.calls[push_index + 1:]),
                        "success requires an independent post-push remote readback")
        self.assertIn(self.fixture.intermediate, list(scalar_values(result)))

    def test_advanced_remote_is_refused_and_all_refs_remain_unchanged(self):
        # Catches publication against an advertised remote newer than the bound seed.
        self.fixture.set_remote(self.fixture.advanced)
        before = self.fixture.refs()
        with ChildLaunches(self.M) as launches:
            result = self.publish()
        self.assert_refusal(result, launches)
        self.assertEqual(self.fixture.refs(), before)
        self.assertLessEqual(len(launches.pushes), 1)

    def test_rewound_remote_is_refused_even_when_normal_push_would_fast_forward(self):
        # Omitting exact old-ID validation would wrongly accept this fast-forward.
        self.fixture.set_remote(self.fixture.base)
        before = self.fixture.refs()
        with ChildLaunches(self.M) as launches:
            result = self.publish()
        self.assert_refusal(result, launches)
        self.assertEqual(self.fixture.refs(), before)
        self.assertLessEqual(len(launches.pushes), 1)

    def test_guard_refuses_remote_rewind_between_preflight_and_real_push(self):
        # A preflight-only implementation misses this race and changes the remote.
        expected = self.fixture.refs()
        expected[REF] = self.fixture.base
        with ChildLaunches(self.M, before_push=lambda: self.fixture.set_remote(self.fixture.base)) as launches:
            result = self.publish()
        self.assertEqual(len(launches.pushes), 1, "the race must reach the actual push boundary")
        self.assertEqual(result.get("status"), "PUSH_UNCERTAIN")
        self.assertIsNone(result.get("refUpdated"))
        self.assertEqual(self.fixture.refs(), expected)
        receipts = []
        for path in self.run_root.rglob("*.json"):
            try:
                record = json.loads(path.read_text(encoding="utf-8"))
            except (UnicodeError, json.JSONDecodeError):
                continue
            if isinstance(record, dict) and record.get("schema") == "r0007-pack-guard/v1":
                receipts.append(record)
        self.assertTrue(any(record.get("status") == "REFUSED" for record in receipts),
                        "the actual advertisement guard must refuse the rewound old commit")

    def test_guard_accepts_one_exact_advertised_update(self):
        # An always-refusing guard cannot satisfy the valid protocol case.
        completed, record = self.run_guard(self.advertised_line())
        self.assertEqual(completed.returncode, 0)
        self.assertEqual(record["status"], "ACCEPTED")

    def test_guard_refuses_wrong_ref_without_retaining_advertised_text(self):
        # Catches a missing destination comparison and raw-input receipt logging.
        marker = "UNTRUSTED_REF_INPUT_DO_NOT_RETAIN"
        completed, record = self.run_guard(self.advertised_line(ref="refs/heads/" + marker))
        self.assertNotEqual(completed.returncode, 0)
        self.assertEqual(record["status"], "REFUSED")
        self.assertNotIn(marker, json.dumps(record))

    def test_guard_refuses_multiple_updates_without_retaining_advertised_text(self):
        # Catches first-line-only validation that would permit a second ref update.
        marker = "UNTRUSTED_SECOND_UPDATE_DO_NOT_RETAIN"
        lines = self.advertised_line() + self.advertised_line(ref="refs/heads/" + marker)
        completed, record = self.run_guard(lines)
        self.assertNotEqual(completed.returncode, 0)
        self.assertEqual(record["status"], "REFUSED")
        self.assertNotIn(marker, json.dumps(record))

    def test_guard_refuses_advanced_and_rewound_advertised_old_commits(self):
        # Exercises the hook's exact old-ID check independently of preflight.
        for label, old in (("advanced", self.fixture.advanced), ("rewound", self.fixture.base)):
            with self.subTest(advertisement=label):
                completed, record = self.run_guard(self.advertised_line(old=old), label=label)
                self.assertNotEqual(completed.returncode, 0)
                self.assertEqual(record["status"], "REFUSED")

    def test_guard_refuses_wrong_new_commit(self):
        # Catches publication of an unbound local object even at the correct ref.
        completed, record = self.run_guard(self.advertised_line(new=self.fixture.advanced))
        self.assertNotEqual(completed.returncode, 0)
        self.assertEqual(record["status"], "REFUSED")

    def test_guard_refuses_wrong_remote_name_or_location(self):
        # Both hook argv fields must be checked; checking the stdin ref is insufficient.
        for label, name, location in (
            ("name", "UNTRUSTED_REMOTE_NAME", REMOTE),
            ("location", REMOTE, "https://example.invalid/UNTRUSTED_REMOTE_LOCATION.git"),
        ):
            with self.subTest(argument=label):
                completed, record = self.run_guard(self.advertised_line(), remote_name=name,
                                                   remote_location=location, label=label)
                self.assertNotEqual(completed.returncode, 0)
                self.assertEqual(record["status"], "REFUSED")
                self.assertNotIn("UNTRUSTED_REMOTE", json.dumps(record))

    def test_existing_executable_pre_push_hook_is_refused_without_overwrite(self):
        # Catches bypassing, invoking, or replacing an existing security gate.
        hook = self.fixture.work / ".git" / "hooks" / "pre-push"
        original = b"#!/bin/sh\n# Existing fixture security gate.\nexit 77\n"
        hook.write_bytes(original)
        hook.chmod(0o751)
        before = self.fixture.refs()
        with ChildLaunches(self.M) as launches:
            result = self.publish()
        self.assert_refusal(result, launches)
        self.assertEqual(len(launches.pushes), 0)
        self.assertEqual(hook.read_bytes(), original)
        self.assertEqual(hook.stat().st_mode & 0o777, 0o751)
        self.assertEqual(self.fixture.refs(), before)

    def test_core_hooks_path_is_refused_without_changing_configuration(self):
        # Catches installing a private hook while silently disabling configured hooks.
        hooks = self.run_root / "configured-hooks"
        hooks.mkdir()
        hook = hooks / "pre-push"
        original = b"#!/bin/sh\nexit 78\n"
        hook.write_bytes(original)
        hook.chmod(0o700)
        self.fixture.git("config", "core.hooksPath", str(hooks))
        config = self.fixture.work / ".git" / "config"
        config_before = config.read_bytes()
        refs_before = self.fixture.refs()
        with ChildLaunches(self.M) as launches:
            result = self.publish()
        self.assert_refusal(result, launches)
        self.assertEqual(len(launches.pushes), 0)
        self.assertEqual(config.read_bytes(), config_before)
        self.assertEqual(hook.read_bytes(), original)
        self.assertEqual(self.fixture.refs(), refs_before)

    def test_existing_url_rewrite_or_credential_config_is_refused_without_overwrite(self):
        # Catches redirecting the push or allowing a second credential provider.
        settings = (
            ("url.file:///disposable-untrusted-redirect/.insteadOf", self.fixture.remote),
            ("credential.helper", "!false"),
            ("http.extraHeader", "X-R0007-Fixture: configured"),
        )
        config = self.fixture.work / ".git" / "config"
        for index, (key, value) in enumerate(settings):
            with self.subTest(setting=key):
                self.fixture.git("config", key, value)
                try:
                    before = config.read_bytes()
                    refs_before = self.fixture.refs()
                    evidence = self.run_root / f"configuration-evidence-{index}"
                    evidence.mkdir()
                    with ChildLaunches(self.M) as launches:
                        result = self.publish(evidence=evidence)
                    self.assert_refusal(result, launches)
                    self.assertEqual(len(launches.pushes), 0)
                    self.assertEqual(config.read_bytes(), before)
                    self.assertEqual(self.fixture.refs(), refs_before)
                finally:
                    self.fixture.git("config", "--unset-all", key)

    def test_token_is_scoped_to_push_environment_and_absent_from_persistent_state(self):
        # Catches inherited-token propagation, token argv/config/logging, and auth readback.
        token = "R0007_SYNTHETIC_SECRET_7f4bd3e60b9c_NO_AUTHORITY"
        with mock.patch.dict(os.environ, {"R0007_UPLOAD_TOKEN": token, "R0007_PUSH_TOKEN": token}):
            with ChildLaunches(self.M) as launches:
                result = self.publish(token=token)
        self.assertEqual(result.get("status"), SUCCESS)
        self.assertEqual(len(launches.pushes), 1)
        self.assertGreater(len(launches.calls), 1)
        for call in launches.calls:
            self.assertIsInstance(call["argv"], list)
            self.assertFalse(call["shell"])
            self.assertNotIn(token, json.dumps(call["argv"]))
            if is_git(call["argv"], "push"):
                self.assertEqual(call["env"].get("R0007_PUSH_TOKEN"), token)
                self.assertNotIn("R0007_UPLOAD_TOKEN", call["env"])
                for key, value in call["env"].items():
                    if key != "R0007_PUSH_TOKEN":
                        self.assertNotIn(token, str(value), f"duplicate token environment key {key}")
            else:
                self.assertNotIn("R0007_PUSH_TOKEN", call["env"])
                self.assertNotIn("R0007_UPLOAD_TOKEN", call["env"])
                self.assertNotIn(token, json.dumps(call["env"]))
        self.assertNotIn(token, self.fixture.git("config", "--local", "--list"))
        self.assertNotIn(token, json.dumps(result))
        self.assert_token_absent_from_files(token)

    def test_timeout_after_completed_write_stays_uncertain_and_never_replays_push(self):
        # The server has accepted the write, but the client sees a timeout and no readback.
        # A false refUpdated value, raw exception retention, or retry is therefore unsafe.
        token = "R0007_SYNTHETIC_TIMEOUT_SECRET_6501e972_NO_AUTHORITY"
        state = {"push_attempts": 0, "completed_write": False}

        def uncertain_run(argv, *args, **kwargs):
            if is_git(argv, "push"):
                state["push_attempts"] += 1
                if not state["completed_write"]:
                    completed = REAL_RUN(argv, *args, **kwargs)
                    self.assertEqual(completed.returncode, 0, "fixture push must complete before timeout")
                    state["completed_write"] = True
                raise subprocess.TimeoutExpired(argv, 1, output=token.encode(), stderr=token.encode())
            if state["completed_write"] and is_git(argv, "ls-remote"):
                raise subprocess.TimeoutExpired(argv, 1, output=token.encode(), stderr=token.encode())
            return REAL_RUN(argv, *args, **kwargs)

        with ChildLaunches(self.M) as launches:
            with mock.patch.object(self.M.subprocess, "run", uncertain_run):
                result = self.publish(token=token)
        self.assertTrue(state["completed_write"], "the test must exercise uncertain completed publication")
        self.assertEqual(state["push_attempts"], 1)
        self.assertEqual(len(launches.pushes), 1)
        self.assertEqual(self.fixture.refs()[REF], self.fixture.intermediate)
        self.assertEqual(result.get("status"), "PUSH_UNCERTAIN")
        self.assertIn("refUpdated", result)
        self.assertIsNone(result["refUpdated"])
        self.assertNotIn(token, json.dumps(result))
        self.assert_token_absent_from_files(token)


if __name__ == "__main__":
    unittest.main(verbosity=2)
