#!/usr/bin/env python3
"""Real local Git fixtures for the bounded pack intermediate and explicit seed chain."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
RUNS = ROOT / 'test-runs-tree'
RUNS.mkdir(exist_ok=True)
SPEC = importlib.util.spec_from_file_location('pack_materializer', ROOT / 'templates/materialize.py')
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)
BRANCH = 'pro/r0007-explicit-next-event-state-20261106'
SEEDS = {'.github/workflows/r0007-materialize.yml', '.github/r0007-bootstrap/materialize.py',
         '.github/r0007-bootstrap/manifest.json', '.github/r0007-bootstrap/source.patch'}
TARGET_WORKFLOWS = {'.github/workflows/r0007-native.yml', '.github/workflows/r0007-public-delivery.yml'}


def run(argv, cwd=None, check=True):
    env = os.environ.copy()
    env.pop('R0007_UPLOAD_TOKEN', None)
    env.pop('R0007_PUSH_TOKEN', None)
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    return subprocess.run(argv, cwd=cwd, env=env, check=check, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


def git(root, *args):
    return run(['git', '-C', str(root), *args]).stdout.decode().strip()


def entries(root, tree):
    rows = run(['git', '-C', str(root), 'ls-tree', '-rz', tree]).stdout.split(b'\0')
    return {row.split(b'\t', 1)[1].decode(): row.split(b'\t', 1)[0].decode() for row in rows if row}


class TreeBindingTests(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp(prefix='binding-', dir=RUNS))
        self.repo = self.dir / 'source'
        self.repo.mkdir()
        git(self.repo, 'init', '-b', BRANCH)
        git(self.repo, 'config', 'user.name', 'Local pack fixture')
        git(self.repo, 'config', 'user.email', 'fixture@example.invalid')
        (self.repo / 'src/native').mkdir(parents=True)
        (self.repo / 'tools').mkdir()
        (self.repo / '.github/workflows').mkdir(parents=True)
        (self.repo / '.github/workflows/baseline.yml').write_text('name: unchanged baseline\n')
        (self.repo / 'tools/build_native.py').write_text(
            "from pathlib import Path\nimport hashlib,json\n"
            "s=Path('src/native/index.html').read_bytes()\n"
            "Path('index.html').write_bytes(b'INDEX '+s)\n"
            "Path('offline.html').write_bytes(b'OFFLINE '+s)\n"
            "Path('moon').mkdir(exist_ok=True)\n"
            "Path('moon/BUILD.json').write_text(json.dumps({'sha256':hashlib.sha256(s).hexdigest()})+'\\n')\n")
        (self.repo / 'src/native/index.html').write_bytes(b'<html>base</html>\r\n')
        run([sys.executable, 'tools/build_native.py'], cwd=self.repo)
        self.base = self.commit('base')
        (self.repo / 'src/native/index.html').write_bytes('<html>target العربية 😀</html>\r\n'.encode())
        run([sys.executable, 'tools/build_native.py'], cwd=self.repo)
        for name in TARGET_WORKFLOWS:
            (self.repo / name).write_text('name: final target workflow\n')
        self.target = self.commit('target')
        self.target_tree = git(self.repo, 'rev-parse', self.target + '^{tree}')
        git(self.repo, 'checkout', '--detach', self.base)
        self.first = self.seed('first')
        self.second = self.seed('second')
        self.executing = self.seed('executing')
        self.manifest = {'baseCommit': self.base, 'baseTree': git(self.repo, 'rev-parse', self.base + '^{tree}'),
                         'expectedSeedParent': self.second, 'seedAncestors': [self.second, self.first, self.base]}

    def commit(self, message):
        git(self.repo, 'add', '-A')
        git(self.repo, 'commit', '-m', message)
        return git(self.repo, 'rev-parse', 'HEAD')

    def seed(self, label):
        for name in SEEDS:
            path = self.repo / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text('fixture ' + label + '\n')
        return self.commit(label)

    def require(self, name):
        function = getattr(M, name, None)
        self.assertTrue(callable(function), 'missing bounded helper: ' + name)
        return function

    def test_exact_three_ancestor_chain_is_admitted(self):
        self.require('validate_seed_chain')(self.repo, self.executing, self.manifest, True)

    def test_wrong_immediate_parent_and_wrong_known_edge_are_refused(self):
        validate = self.require('validate_seed_chain')
        with self.assertRaises(ValueError):
            validate(self.repo, self.second, self.manifest, True)
        wrong = {**self.manifest, 'seedAncestors': [self.second, self.base, self.first]}
        with self.assertRaises(ValueError):
            validate(self.repo, self.executing, wrong, True)

    def test_extra_runtime_path_in_executing_seed_is_refused(self):
        validate = self.require('validate_seed_chain')
        git(self.repo, 'checkout', '--detach', self.second)
        for name in SEEDS:
            (self.repo / name).write_text('fixture executing\n')
        (self.repo / 'rogue-runtime.txt').write_text('unplanned\n')
        bad = self.commit('extra runtime path')
        with self.assertRaises(ValueError):
            validate(self.repo, bad, self.manifest, True)

    def test_intermediate_preserves_all_target_product_and_seed_workflows(self):
        build = self.require('build_intermediate')
        evidence = self.dir / 'intermediate-evidence'
        evidence.mkdir()
        result = build(self.repo, self.target_tree, self.executing, evidence)
        intermediate = result['intermediateTree']
        target, seed, observed = [entries(self.repo, t) for t in [self.target_tree, self.executing, intermediate]]
        expected = {p: value for p, value in target.items() if not p.startswith('.github/workflows/') and p not in SEEDS}
        expected.update({p: value for p, value in seed.items() if p.startswith('.github/workflows/') or p in SEEDS})
        self.assertEqual(observed, expected)
        final_paths = set(git(self.repo, 'diff', '--name-only', self.target_tree, intermediate).splitlines())
        self.assertEqual(final_paths, SEEDS | TARGET_WORKFLOWS)
        self.assertEqual(set(result['finalizationPaths']), SEEDS | TARGET_WORKFLOWS)
        self.assertEqual(git(self.repo, 'rev-parse', intermediate + ':.github/workflows'),
                         git(self.repo, 'rev-parse', self.executing + ':.github/workflows'))

    def test_unplanned_target_workflow_refuses_intermediate(self):
        build = self.require('build_intermediate')
        git(self.repo, 'checkout', '--detach', self.target)
        (self.repo / '.github/workflows/extra.yml').write_text('name: unplanned\n')
        altered = self.commit('unplanned workflow')
        evidence = self.dir / 'intermediate-evidence'
        evidence.mkdir()
        with self.assertRaises(ValueError):
            build(self.repo, git(self.repo, 'rev-parse', altered + '^{tree}'), self.executing, evidence)

    def test_preparer_and_depth4_dry_reconstruction_bind_chain_and_finalization(self):
        git(self.repo, 'checkout', BRANCH)
        payload = self.dir / 'payload'
        args = [sys.executable, str(ROOT / 'prepare_payload.py'), '--source-root', str(self.repo),
                '--base', self.base, '--target', self.target, '--output', str(payload)]
        for ancestor in [self.second, self.first, self.base]:
            args += ['--seed-ancestor', ancestor]
        prepared = run(args, check=False)
        (self.dir / 'preparation.stdout').write_bytes(prepared.stdout)
        (self.dir / 'preparation.stderr').write_bytes(prepared.stderr)
        self.assertEqual(prepared.returncode, 0, prepared.stderr.decode())
        manifest = json.loads((payload / '.github/r0007-bootstrap/manifest.json').read_bytes())
        self.assertEqual(manifest['seedAncestors'], [self.second, self.first, self.base])
        self.assertEqual(set(manifest['finalizationPaths']), SEEDS | TARGET_WORKFLOWS)
        git(self.repo, 'checkout', '--detach', self.second)
        for name in SEEDS:
            (self.repo / name).write_bytes((payload / name).read_bytes())
        executing = self.commit('prepared executing seed')
        git(self.repo, 'checkout', '-b', 'fixture-executing', executing)
        shallow = self.dir / 'depth4'
        run(['git', 'clone', '--depth', '4', '--branch', 'fixture-executing', self.repo.as_uri(), str(shallow)])
        self.assertEqual(git(shallow, 'rev-list', '--count', 'HEAD'), '4')
        evidence = self.dir / 'dry-evidence'
        result = run([sys.executable, str(shallow / '.github/r0007-bootstrap/materialize.py'),
                      '--source-root', str(shallow), '--manifest', str(shallow / '.github/r0007-bootstrap/manifest.json'),
                      '--evidence-root', str(evidence), '--dry-run'], check=False)
        (evidence / 'launcher.stdout').write_bytes(result.stdout)
        (evidence / 'launcher.stderr').write_bytes(result.stderr)
        summary = json.loads(next(evidence.glob('attempt-*/summary.json')).read_bytes())
        self.assertEqual(result.returncode, 0, summary)
        self.assertEqual(summary['observedTargetTree'], self.target_tree)
        self.assertEqual({row['path'] for row in summary['workflowBlobsForConnector']}, TARGET_WORKFLOWS)
        self.assertEqual(set(summary['finalizationPaths']), SEEDS | TARGET_WORKFLOWS)
        self.assertEqual(summary['refUpdated'], False)
        self.assertTrue(summary['dryRun'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
