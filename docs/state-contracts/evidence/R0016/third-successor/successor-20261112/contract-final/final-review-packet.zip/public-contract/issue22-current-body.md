<!-- salah-widget-audit-20260907:SW-022 -->
# R0016: Give both installer dry-run switches an explicit no-effect boundary

**Repository-local identity:** `R0016` in `theislampill/salah_widget`; existing tracker [#22](https://github.com/theislampill/salah_widget/issues/22). The SW identifier is historical draft provenance.


Campaign draft alias: SW-022. Product defect; proposed priority P1. Define `DRY_RUN=1` and `-DryRun` as offline previews: read local discovery state and print the intended actions, but make zero filesystem, clipboard, browser, profile, extension or network effects. A preview must neither produce an installable artifact nor tell the next function that a merely proposed path is an existing file.

VAL-008 is a source-confirmed inventory. No full installer or full dry-run was executed in the audit. The tests below are executable future recipes and acceptance specifications, not an invented historical no-effect PASS.

## Source identity and the actual reachability problem

Evidence baseline: main `fd2972ba64225fe9d6848e92497e6d0ed20ea624`; candidate `9d9c43649748555afbe09e3ca49bc47db2d7e7bb`. Before authorized repair:

```text
git --no-optional-locks rev-parse --show-toplevel
git --no-optional-locks remote get-url origin
git --no-optional-locks status --short --branch
git --no-optional-locks rev-parse HEAD
git --no-optional-locks diff fd2972ba64225fe9d6848e92497e6d0ed20ea624 HEAD -- install.sh install.ps1 README.md builder.html
```

Bind the intended `theislampill/salah_widget` target, closer guidance and unrelated dirty work. Inspect changed launch, cache and staging contracts before using fixed baseline ranges. Stop on incompatible drift; an old source inventory is not proof of a defect at arbitrary future HEAD. Neither candidate adoption nor installation is authorized by this issue.

| Existing path | Historical source finding and why a late guard is insufficient |
|---|---|
| [Bash initialization](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/install.sh#L18-L37) | `DRY_RUN` is set, then `mkdir -p` runs unconditionally before any wizard decision. |
| [Bash clipboard/open](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/install.sh#L71-L109) | `open_url` has a guard, `copy_text` does not. NO_OPEN suppresses opening only; it is not a dry-run substitute. |
| [Bash release/download/extraction](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/install.sh#L248-L320) | Python release lookup performs network before the download guard; mkdir precedes the cache test; extraction removes/recreates a directory and unzips without a guard. |
| [Bash preset/manual callers](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/install.sh#L323-L427) | A dry preset returns a proposed pathname. Cache/existing-file observations and manual instructions must not convert it into a copied/opened actual artifact. |
| [PowerShell initialization and clipboard](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/install.ps1#L24-L88) | `New-Item` runs eagerly; `Copy-Text` calls `Set-Clipboard` without DryRun. |
| [PowerShell metadata, cache and extraction](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/install.ps1#L296-L415) | Metadata has a dry guard, but existing in-process metadata can return earlier; Download-Asset creates a directory and returns cached paths before its guard. Expand-ChromiumAsset deletes/creates/extracts unconditionally. |
| [PowerShell install/store/fallback callers](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/install.ps1#L443-L503) | Cached selection reaches expansion; store and error fallback retain confirmations. A caught selector error is not successful preview of a downloadable asset. |

The actual cached extraction path depends on fixing the separate launch/selector/path failures. An earlier bug masking a later effect is not a protection contract. Conversely, the source inventory does not prove that every listed effect occurred during a real dry-run. Keep that distinction in the eventual evidence comment.

## Public bounded RED: effects become output, never real operations

Use the pinned files. Save the following Node fixture outside the repo as `red-dry-bash.cjs`; run `node red-dry-bash.cjs /absolute/pinned/install.sh`. It executes only extracted helper/initialization excerpts, substitutes mutation/network tools, and writes evidence to stdout/stderr. It does not launch the full installer.

```js
const fs=require('fs'),cp=require('child_process');
const lines=fs.readFileSync(process.argv[2],'utf8').split(/\r?\n/);
const x=(a,b)=>lines.slice(a-1,b).join('\n');
const stubs=`set -Eeuo pipefail
DRY_RUN=1
TMPDIR=/fixture
PLATFORM=mac
mkdir(){ printf 'EFFECT mkdir\\n' >&2; }
rm(){ printf 'EFFECT rm\\n' >&2; }
unzip(){ printf 'EFFECT unzip\\n' >&2; }
curl(){ printf 'EFFECT network\\n' >&2; return 99; }
pbcopy(){ cat >/dev/null; printf 'EFFECT clipboard\\n' >&2; }
need_cmd(){ :; }
find(){ printf '/fixture/v1/tabliss-chromium-unpacked/manifest.json\\n'; }
select_asset(){ printf 'v1\\ttabliss-chromium.zip\\thttps://example.invalid/file\\n'; }
[(){ if test "$1" = -f; then return 0; else builtin [ "$@"; fi; }
`;
const code=stubs+'\n'+x(34,40)+'\n'+x(95,114)+'\n'+x(282,321)+`
copy_text fixture
path="$(download_tablissng_asset chromium)"
expand_chromium_asset "$path"
`;
const r=cp.spawnSync(process.env.BASH_EXE||'bash',['--noprofile','--norc','-c',code],{encoding:'utf8'});
console.log({exit:r.status,stdout:r.stdout,stderr:r.stderr});
```

The pinned source calls the mkdir, clipboard, rm and unzip spies despite `DRY_RUN=1`. The asset-selection function is deliberately stubbed here, so this fixture does not prove Python-network reachability; that is visible in the exact source above. The polluted cached stdout is [R0013](https://github.com/theislampill/salah_widget/issues/19)’s separate witness and must not be “fixed” inside this test merely to make a whole-entry claim.

The PowerShell companion below runs on 5.1 or 7 and extracts only `Copy-Text` and `Expand-ChromiumAsset` from explicit UTF-8 text. It illustrates a safe minimum RED independent of the file-decoding owner:

```powershell
param([Parameter(Mandatory=$true)][string]$SourceFile)
$ErrorActionPreference='Stop'; $DryRun=$true
$script:effects=@()
function Set-Clipboard { param($Value) $script:effects += 'clipboard' }
function Test-Path { param($LiteralPath) return $true }
function Remove-Item { param($LiteralPath,[switch]$Recurse,[switch]$Force) $script:effects += 'remove' }
function New-Item { param($ItemType,$Path,[switch]$Force) $script:effects += 'mkdir' }
function Expand-Archive { param($LiteralPath,$DestinationPath,[switch]$Force) $script:effects += 'extract' }
function Get-ChildItem {
  param($LiteralPath,[switch]$Recurse,$Filter,$ErrorAction)
  [pscustomobject]@{FullName='C:\fixture\asset-unpacked\manifest.json'}
}
$tokens=$null; $errors=$null
$ast=[System.Management.Automation.Language.Parser]::ParseInput(
  [IO.File]::ReadAllText($SourceFile,[Text.Encoding]::UTF8),[ref]$tokens,[ref]$errors)
if (@($errors).Count) { throw 'Source syntax drift' }
foreach($name in 'Copy-Text','Expand-ChromiumAsset') {
  $defs=@($ast.FindAll({param($n)
    $n -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $name
  },$true))
  if($defs.Count -ne 1){ throw 'Function identity mismatch' }
  . ([scriptblock]::Create($defs[0].Extent.Text))
}
$null=Copy-Text 'fixture'
$null=Expand-ChromiumAsset 'C:\fixture\asset.zip'
$script:effects | ConvertTo-Json
```

Run `powershell.exe -NoProfile -File .\red-dry-ps.ps1 -SourceFile C:\fixture\install.ps1` and the analogous `pwsh.exe` command. The proposed RED output is the sequence `clipboard, remove, mkdir, extract`. This particular recipe has not been executed in the audit. Inspect actual output and preserve it when future execution is authorized; never report it as historical native evidence. Final whole-file parsing is separately required by [R0014](https://github.com/theislampill/salah_widget/issues/20).

## Repair order and preview data flow

**1. Fix the entry boundary first.** Parse/validate options and platform before creating any directory. For preview, perform read-only local target discovery, mark legacy profiles as refused, print intended per-target actions and terminate without entering the installation loop. Do not require a person to pretend they installed an extension by pressing Enter. A no-terminal preview can enumerate all detected eligible targets; an `ask` source prints both available routes as unresolved alternatives. No target/no eligible target remains an explicit non-success planning result. Keep this branch small and local to each existing main entry point; it is not a generic plan/execution engine.

Choose offline behavior for the existing switch: no metadata requests, no provider requests, no download and no implicit DNS/network availability test. If the owner later wants an online read-only preview, that requires a separately explicit product option and contract; do not silently allow it here. Say “release/version/path unresolved until execution” rather than fabricate a current tag, a cache hit or a completed download. The preview can show a proposed directory template but may not create one to learn its random suffix.

**2. Guard each effect site as defense against alternate callers.** The early branch is the main consumer boundary; helpers remain independently guarded so cached/fallback paths or a future caller cannot bypass it. Check DryRun before mkdir, copy, remove, unzip/Expand-Archive, permission changes, file writes, clipboard, open/process launch and cleanup. `copy_text`/`Copy-Text` must return a result that does not trigger “Copied” output when suppressed. Choose false/no-copy with a preview diagnostic; a dry-run success boolean would lie to existing callers. Guard `select_asset`/`Get-LatestRelease` before even an existing metadata cache is interpreted as authority for effects.

**3. Stop passing imagined artifacts down real paths.** `download_tablissng_asset`, `Download-Asset` and preset helpers must not return a pretend success path under preview. The entry preview prints the plan itself, bypassing actual artifact-returning helpers. If a guarded helper is invoked during dry-run, return no usable path and a documented suppressed result/diagnostic; callers must stop that operation rather than expand, copy or fall back to opening a store. Normal helper success retains the existing path contract. This avoids introducing a new persisted result schema solely for dry-run.

**4. Join private staging before the final gate.** [R0015](https://github.com/theislampill/salah_widget/issues/21) creates separate scratch and retained roots. Dry-run must not call its initializer, create a retained bundle, chmod a parent, adopt an old cache, or run cleanup. Cleanup is an effect too; a guard that stops writes but runs a trap deleting cached/manual assets is a failure. Integrate shared `bash/staging`, `bash/preset-write`, `bash/unpacked-lifetime` and `bash/download-return` hunks serially with the installer owner. [R0013](https://github.com/theislampill/salah_widget/issues/19)’s actual-input repair applies to normal installation; agree explicitly that preview does not wait for terminal confirmations.

**5. Make completion wording reflect the mode.** End preview with “Preview only; no changes made” only after the no-effect controls pass. List planned opens/copies/imports with “would”, retain the legacy-profile refusal and dashboard replacement warning, and state which remote facts remain unresolved. Normal execution still distinguishes staged files from manual browser installation/import. A swallowed selector failure or an empty selected set cannot become successful install text.

## Whole-entry acceptance: branch and effect matrix

Build isolated fixtures with actual source entry points, fake profile discovery and effect spies. Snapshot the fixture filesystem before/after, including preexisting cached ZIP/XPI, unpacked marker and preset sentinels; hash contents and record names/modes. Place spy logs outside the snapshot target and distinguish harness-created fixture files from installer effects. Deny network at the test transport boundary. Avoid the owner’s browser storage/profiles and real clipboard. A missing spy hit alone is insufficient if a direct .NET write escaped interception; the snapshot and network denial are the independent post-state controls.

| Branch/control | Required observation under dry-run |
|---|---|
| Fresh GitHub Chromium/Firefox | No metadata/download/extraction/clipboard/open; unresolved tag explicitly shown. |
| Cached asset + cached metadata; preexisting unpacked directory | Same zero effects; cached files and directory sentinels byte-identical; no cached shortcut to expansion. |
| Store route; source `ask`; GitHub metadata error/fallback | Plan only, no browser process, no “after installed” confirmation, no network; unresolved choice stays unresolved. |
| Already-installed TablissNG; missing preset URL; existing configured preset | No preset download/rewrite/copy; manual import/replacement warning remains understandable. |
| Legacy-only, mixed eligible/legacy, zero profiles, malformed options | Refusal/error is explicit and no-effect; eligible plans exclude legacy; no staged-completion claim. |
| NO_OPEN/NoOpen alone, dry-run off | Only opening is suppressed. The fixture still logs expected download/staging/copy, proving the tests distinguish switches. |
| Non-dry positive, effects stubbed | Expected normal branches reach the spies with exact arguments and configuration; the repair has not disabled installation globally. |
| Mutants: remove eager-init guard, return cached path early, copy during preview, cleanup on EXIT | Each targeted case detects a specific call or changed sentinel; a fresh-only fixture cannot pass the cache mutant. |

Run Bash on the claimed Apple Bash 3.2 and modern Linux host, and PowerShell exact-file entry on actual 5.1 and supported 7, after their launch owners’ controls pass. Parser-only, helper-only, source inventory and whole-entry/native results must be labeled separately. A native host unavailable to the executor remains a qualification gap. Do not “test dry-run” by running the uncorrected full script against a live home directory.

## Alternatives, dependencies and closure

Keeping network allowed would make previews depend on rate limits, auth and current release content while still resolving no installed effect; the existing contract can be deterministic without it. Guarding only download misses eager mkdir, cache extraction and clipboard. An early return alone is fragile under later helper reuse, whereas a small entry plan plus local effect guards closes the current branches without a new command framework. Renaming the switch “mostly preview” evades the requested no-effect boundary. Disabling all operations unconditionally produces a false GREEN unless the normal positive control still reaches intended effects.

Preserve the accepted dependencies: [R0013](https://github.com/theislampill/salah_widget/issues/19) and [R0014](https://github.com/theislampill/salah_widget/issues/20) are qualification prerequisites for claimed native whole-entry results; [R0015](https://github.com/theislampill/salah_widget/issues/21) is the staging/lifetime interface. Analysis and bounded fixtures may proceed before those issues close. Keep one shared installer writer; no additional whole-issue serialization, issue merge or platform framework is proposed.

IMPLEMENTAUDIT R001D requires both usage surfaces and README/builder text where preview is exposed to state the same offline/no-effect policy. Keep preset bytes, config encoding, 325×530 embed, geolocation permission and manual installation boundary. Rollback guards only together with withdrawal of their no-effect claim; never delete cached/manual assets to reset a failed test. Stop on any observed effect, incompatible staging interface, missing native entry qualification or inability to isolate the fixture.

DONE requires final-tree RED→GREEN, complete branch/effect and normal-positive controls, exact native host evidence claimed, independent exact-tree review of the integrated effects, and an evidence comment before manual closure. Distribution claims additionally require authorized raw-script/usage readback on both platforms. Use non-closing `Implements #22` PR wording. Work-order publication and local helper results are not product, native-installation or deployed completion.

Methodology references (separate repository, not Salah work owners): [R001D in IMPLEMENTAUDIT](https://github.com/theislampill/IMPLEMENTAUDIT.md/issues/155).

Identity provenance: first repository-local allocation batch; existing GitHub object order was used to assign distinct monotonic hex-4 IDs. Closed/held IDs are not reused. Issue number is not implementation priority.
