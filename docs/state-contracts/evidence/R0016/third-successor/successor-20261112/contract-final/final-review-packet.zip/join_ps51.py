#!/usr/bin/env python3
"""Bounded data-only join of new PS5.1 receipt; not a receiver/campaign rerun."""
import collections
import datetime
import hashlib
import io
import json
import pathlib
import subprocess
import tarfile
import zipfile

ROOT = pathlib.Path('/workspace/scratch/0dd4b9b6a244')
OUT = ROOT / 'reviews/final_contract_review'
INPUT = OUT / 'additional-inputs'
REPO = ROOT / 'salah_widget'
SOURCE = 'a89bbb3ddac639cc787ba08d030e8b2539057387'
INITIAL_TREE = 'b154fcce037278223d8c2559f36fbf51339cf2a0'
checks = []
sources = []

def h(b): return hashlib.sha256(b).hexdigest()
def ck(name, ok, detail=None):
    row = {'name':name,'pass':bool(ok)}
    if detail is not None: row['detail'] = detail
    checks.append(row)
def read(name): return json.loads((INPUT/name).read_bytes())
def git(path): return subprocess.check_output(['git','show',SOURCE+':'+path],cwd=REPO)

report = (INPUT/'ps51-attempt2-report.md').read_bytes()
manifest_bytes = (INPUT/'ps51-attempt2-manifest.json').read_bytes()
admission_bytes = (INPUT/'root-receipt-admission-advanced.json').read_bytes()
ck('exact supplied PS5.1 report',h(report)=='ed0c59da3d8eee098a45de2fb85f658ef98e32d7c0fa8d9a486fdefe9af8417d')
ck('exact supplied PS5.1 manifest',h(manifest_bytes)=='482d1b85bd1c32954c15404fc9974aa1a7c663d9b7e7a3e6dd48457075c7ccad')
ck('exact supplied advanced root admission',h(admission_bytes)=='9f5de7a39f2e004b8aa76409545a409f13d64f0cb85b3e3fd572884249932696' and len(admission_bytes)==8113)
for rec in json.loads(manifest_bytes):
    data=pathlib.Path(rec['path']).read_bytes()
    ck('receiver manifest '+pathlib.Path(rec['path']).name,len(data)==rec['bytes'] and h(data)==rec['sha256'])

d=read('ps51-attempt2-checks.json')
outer=read('ps51-attempt2-outer-received.json')
admission=json.loads(admission_bytes)
ck('receipt exact source and acquisition identity',d['status']=='FINAL' and d['head']==SOURCE and d['tree']=='efa716f4c8f1fe61c1a5a85b48bd97e813305d16' and d['run']==43220592915 and d['attempt']==2 and d['job']==131197436545 and d['artifact']==13947627028)

archive=ROOT/'recovery/full20-a89/ps51-attempt2/ps51-full20-43220592915-attempt2.zip'
zb=archive.read_bytes()
ck('actual original ZIP digest and size',len(zb)==3067872 and h(zb)=='4247cb1eee4043d59c950936b84ac1b9ce09dbf4041edaad323d2857357c37b1')
with zipfile.ZipFile(io.BytesIO(zb)) as z:
    ck('original ZIP CRC and sole payload',z.testzip() is None and len(z.namelist())==1)
    tb=z.read(z.namelist()[0])
ck('actual original TAR digest and size',len(tb)==3219546 and h(tb)=='6e633fd69f2b94b8680b5a88c8d92b8889947a6df76a54f36abdfb0ff02bf9cb')
with tarfile.open(fileobj=io.BytesIO(tb),mode='r:gz') as t:
    members=t.getmembers()
    ck('original TAR membership shape',len(members)==2769 and sum(m.isfile() for m in members)==1648 and len({m.name for m in members})==2769 and all(m.isdir() or m.isfile() for m in members))
    control=[m for m in members if m.isfile() and m.name.startswith('installer-evidence/control/')]
    ck('fourteen original source role copies',len(control)==14)
    for m in control:
        path=m.name.removeprefix('installer-evidence/control/')
        data=t.extractfile(m).read()
        ck('original native input equals exact a89 '+path,data==git(path))
        sources.append({'path':path,'bytes':len(data),'sha256':h(data),'source':SOURCE})
    route=json.loads(t.extractfile('installer-evidence/route-result.json').read())
ck('original outer association equals independent received association',route['association']==outer)
ck('original native host and controller outcome',route['sourceCommit']==SOURCE and route['nativeHost']['version']=='5.1.20348.5773' and route['nativeHost']['edition']=='Desktop' and route['nativeHost']['platform']=='Win32NT' and route['phases']['fullEntry']['exit']==0 and route['phases']['fullEntry']['timedOut'] is False and route['phases']['fullEntry']['timeoutSeconds']==6550 and route['phases']['fullEntry']['error'] is None)
ck('original hard-containment and transport limits retained',route['independentHardContainment']=='NOT_ACQUIRED' and route['independentGlobalTransportTelemetry'] is None)
ck('940 custody facts and18 producer relations retained',d['outerCustodyFacts']==940 and d['producerReceiptsCompared']==18 and outer['caseCount']==20)

cases=d['cases'];ps7=json.loads((OUT/'source/docs/state-contracts/evidence/R0016/third-successor/successor-20261112/full20-ps7-attempt1/case-received.json').read_text())
ck('same original20 ordered case identities as received PS7',[c['scenario'] for c in cases]==[c['case'] for c in ps7] and len({c['scenario'] for c in cases})==20)
normal=[c for c in cases if c['scenario'] in ['positive','no-open']]
preview=[c for c in cases if c['scenario'] not in ['positive','no-open']]
ck('eighteen preview andtwo normal',len(preview)==18 and len(normal)==2)
ck('all direct outcomes match original required cases',all(a['directExit']==b['entryExit'] for a,b in zip(cases,ps7)))
ck('only two early refusals lack direct discovery',{c['scenario'] for c in cases if not c['directDiscoveryObserved']}=={'bad-option','invalid-env-source'})
ck('all18 held source equalities and exits',all(c['fullHeldBeforeEqualsAfter'] is True and c['heldWrapperExit']==0 and c['heldSemanticExit']==c['directExit'] and c['effects']=={} for c in preview))
ck('held startup input differences preserved',all(c['heldPreparedEqualsBefore'] is False for c in preview))
ck('PS5.1 legacy full-profile flags kept distinct from PS7',all(c['legacyLifecycleChecks']['fullProfileUnchanged'] is True for c in preview) and all(c['legacyLifecycleChecks']['fullProfileUnchanged'] is False for c in normal))
ck('source-free carrier is not installer case credit',all(c.get('sourceCompletion') in ['exit-code-observed','terminating-exception'] for c in preview))
ck('native guard coverage exactly33 helpers295points',len(d['guardCoverage']['effectHelpers'])==33 and len(d['guardCoverage']['methodInventory'])==295 and d['guardCoverage']['nativeAstInventoryReexecuted'] is False)
ck('original native journals retained',len(d['nativeJournals'])==56)

normal_summary=[]
for c in normal:
    name=c['scenario'];p=c['normalPreparation'];post=c['normalPostcondition'];cache=p['cacheCaptures']
    expected={'prompt':3,'metadata':1,'download':3,'clipboard':4}
    if name=='positive': expected['open']=4
    ck('actual useful normal effects '+name,c['effects']==expected)
    ck('strict normal postcondition '+name,post['complete'] is True and len(post['added'])==8 and post['removed']==[] and len(post['changed'])==2 and all(set(x['fields'])=={'mtimeNs'} for x in post['changed']))
    ck('normal source-free warm-json20 scope '+name,p['mode']=='warm-json' and p['holdSeconds']==20 and c['warmTerminalSeconds']>=20 and p['warmJsonContext']['context']['normal']=='0' and p['warmJsonContext']['context']['command']=='ConvertFrom-Json')
    ck('warmAfter complete inventory equals product baseline '+name,p['phaseFacts']['warmAfter']['sha256']==p['phaseFacts']['productBefore']['sha256'])
    ck('cache absent before preparation '+name,cache['warmBefore']['inventoryRow']['kind']=='absent' and cache['warmBefore']['capture'] is None)
    rows=[cache[k]['inventoryRow'] for k in ['warmAfter','productBefore','productAfter']]
    ck('actual732-byte cache completely unchanged '+name,rows[0]==rows[1]==rows[2] and rows[0]['bytes']==732 and all(cache[k]['capture']['bytes']==732 and cache[k]['capture']['sha256']==rows[0]['sha256'] for k in ['warmAfter','productBefore','productAfter']))
    normal_summary.append({'scenario':name,'cacheBytes':rows[0]['bytes'],'cacheSha256':rows[0]['sha256'],'warmTerminalSeconds':c['warmTerminalSeconds'],'effects':c['effects'],'strictPostcondition':post})

for gate in ['T01','T02','T03','T04']:
    ck('root expressly admits '+gate,admission['technicalGateDispositions'][gate].startswith('ADMITTED'))
ck('root native admission distinct from packet/acceptance',admission['allNativeTechnicalGatesAdmitted'] is True and admission['completePacketRootAdmission'] is False and all(admission[k] is False for k in ['wholeContractSatisfied','mergeApprovalGranted','finalPublicDeliverySatisfied','certificateIssued','issueClosureAuthorizedAtThisStage']))
ck('prior adverse attempt retained explicitly','attempt1' in admission['technicalGateDispositions']['T01'].replace(' ','') and 'unresolved cause' in admission['technicalGateDispositions']['T01'])

result={'schema':'r0016-bounded-ps51-contract-join.v1','recordedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'initialTree':INITIAL_TREE,'sourceCommit':SOURCE,'finalTree':None,'finalVerdict':'PENDING_EXACT_FINAL_TREE','authority':'Technical receipt-to-contract join only; no acceptance, lifecycle, publication or external delivery authority.','method':'Own data comparisons and selective immutable original archive source/JSON reads. No repeat of prior292 checks, published native receiver replay, native campaign, or archived executable execution.','checks':checks,'passed':sum(c['pass'] for c in checks),'failed':[c for c in checks if not c['pass']],'originalSources':sources,'normalSummary':normal_summary,'caseSummary':[{'scenario':c['scenario'],'directExit':c['directExit'],'directDiscoveryObserved':c['directDiscoveryObserved'],'legacyLifecycleChecks':c['legacyLifecycleChecks'],'heldSourceEquality':c.get('fullHeldBeforeEqualsAfter'),'heldPreparedEqualsBefore':c.get('heldPreparedEqualsBefore')} for c in cases]}
(OUT/'ps51-join-checks.json').write_text(json.dumps(result,indent=2)+'\n')
old=json.loads((OUT/'initial-row-dispositions.json').read_text());rows=[]
for r in old['rows']:
    external=r['id'] in ['22-14','R0016-A06']
    rows.append({'id':r['id'],'category':r['category'],'originalObligation':r['originalObligation'],'historicalPointer':r['historicalPointer'],'initialCutoffBasis':r['independentBasis'],'currentTechnicalDisposition':'EXTERNAL_DELIVERY_AND_CERTIFICATE_REQUIRED' if external else 'TECHNICAL_EVIDENCE_SUPPORTED_FINAL_TREE_JOIN_PENDING','newPS51ReceiptApplicable':'T01' in r['publishedRemainingGateIds'],'newPS51Receipt':{'sha256':h(report),'run':43220592915,'attempt':2,'job':131197436545,'artifact':13947627028} if 'T01' in r['publishedRemainingGateIds'] else None,'rootAdmission':'T01_T02_T03_T04_ADMITTED_WITH_RECORDED_LIMITS','remaining':'Final immutable documentation/evidence tree join/T05 plus applicable existing external handoff/delivery gates. No further native execution identified.' if not external else 'Authorized exact final public delivery/readback and certificate/closure requirements remain.','acceptance':None})
(OUT/'ps51-row-join-provisional.json').write_text(json.dumps({'schema':'r0016-provisional-original46-ps51-join.v1','sourceCommit':SOURCE,'initialTree':INITIAL_TREE,'finalTree':None,'denominator':old['denominator'],'authority':'Per-row technical recommendations only; final tree and root acceptance not supplied.','rows':rows},indent=2)+'\n')
print(json.dumps({'checks':len(checks),'passed':result['passed'],'failed':result['failed'],'rowCount':len(rows),'technicalDispositionCounts':dict(collections.Counter(r['currentTechnicalDisposition'] for r in rows))},indent=2))
raise SystemExit(bool(result['failed']))
