# Bounded PS5.1 receipt join — final tree pending

The new independent PS5.1 attempt2 receipt resolves the actual native receiving gap identified in the initial review. **64/64 focused data/custody/source/contract-join checks pass.** This addendum joins additional digest-bound evidence to source a89 and the original46 contract; it does not provide a final documentation-tree verdict or acceptance.

## Exact added inputs

| Input | Exact SHA-256 |
| --- | --- |
| Independent PS5.1 report, 15,846 bytes | `ed0c59da3d8eee098a45de2fb85f658ef98e32d7c0fa8d9a486fdefe9af8417d` |
| Independent receipt manifest | `482d1b85bd1c32954c15404fc9974aa1a7c663d9b7e7a3e6dd48457075c7ccad` |
| Advanced root admission, 8,113 bytes | `9f5de7a39f2e004b8aa76409545a409f13d64f0cb85b3e3fd572884249932696` |
| Original attempt2 ZIP, 3,067,872 bytes | `4247cb1eee4043d59c950936b84ac1b9ce09dbf4041edaad323d2857357c37b1` |
| Original TAR, 3,219,546 bytes | `6e633fd69f2b94b8680b5a88c8d92b8889947a6df76a54f36abdfb0ff02bf9cb` |

Acquisition is run43220592915, attempt2, job131197436545, artifact13947627028, exact source `a89bbb3ddac639cc787ba08d030e8b2539057387`. The archived native host identifies Windows PowerShell5.1.20348.5773/Desktop/Win32NT/64-bit. The independent report and all nine manifest entries were hash-verified before use. The original ZIP passed CRC; original TAR membership has 2,769 unique regular-file/directory members, including1,648 regular files. All fourteen original copied source roles independently equal immutable a89 Git bytes. The original route-result association equals the independently received outer association.

## Contract join

The same twenty ordered scenarios required by the already received PS7 receipt are present. All direct outcomes agree with their required case behavior. Eighteen preview cases have empty effect ledgers and separate held before/after equality; their held semantic exit matches the direct exit. Exactly bad-option and invalid-env-source lack direct discovery and are received as attributable early refusals. They do not gain direct readiness or at-ready inventory credit.

The two normal cases retain actual useful consumer effects: positive has15 events and NoOpen11, differing by the four expected opens. Both strict postconditions add one exact eight-entry manual bundle, remove no inputs and retain only the original profile-root/TEMP-parent mtime allowances. Source-free warm-json preparation lasts20 seconds with normal flag zero; its full warmAfter inventory equals productBefore. Both caches are **732 bytes**, with the entire cache row unchanged from warmAfter through productAfter. Prior diagnostic738-byte values are not copied into this result.

PS5.1 and PS7 measurement schemas/results remain distinct. PS5.1's legacy fullProfileUnchanged flag is true for all18 previews, while its complete prepared-input lifecycle relations still retain the subject/temp mtime difference and clone identity differences. Its two normal full-profile flags are false because the admitted bundle is added. PS7's original direct full-profile comparisons are false for all20. All18 PS5.1 held prepared/pre-invocation relations are unequal, while the actual source invocation windows are equal. No complete lifecycle is silently promoted to a source-window equality.

The original33 helper/295 source-coordinate guard inventory,52 source-read contexts,56 native file journals,940 outer custody facts, and18 reproduced producer relations retain their original scope. The new receipt's3,066,481 low-level checks are not additional experiments. Source-read probes establish fixed source-bound input associations; native file/AST facts remain original Windows observations, with no local native remeasurement. Independent OS containment remains NOT_ACQUIRED and global transport telemetry remains null.

Attempt1's unchanged60-second preinstaller ACL setup/capture timeout remains adverse evidence with zero product cases and an unknown cause. Attempt2 success supplies no transient-cause explanation, no universal20-second guarantee and no uniquely necessary/sufficient native-JSON repair claim.

## Updated technical frontier

The advanced root record expressly admits T01–T04 within the recorded scope limits. Native receiving is no longer missing. Whole-contract acceptance, complete-packet root admission, owner merge approval, public delivery, certificate and closure remain false or pending in that same record.

`ps51-row-join-provisional.json` preserves all original46 IDs/order/wording. Forty-four rows have scoped technical support pending the exact final tree/T05;22-14 and R0016-A06 still require actual external delivery and certificate work. The existing Fable handoff remains applicable. These are per-row technical recommendations, not an accepted-row count.

This review executed only `join_ps51.py`, using its own Python data comparisons and selective original-archive source/JSON reads. It did not rerun the initial292 checks, execute a native receiver/campaign or archived executable, read another current final reviewer’s findings, or mutate shared source/audit state. Final verdict remains pending the exact immutable final documentation/evidence tree.
