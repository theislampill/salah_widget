#!/usr/bin/env python3
"""Inert, bounded final-tree join; never executes received archive contents."""
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import json
import subprocess
import zipfile

ROOT = Path('/workspace/scratch/0dd4b9b6a244')
REPO = ROOT / 'salah_widget'
OUT = ROOT / 'reviews/final_contract_review'
TREE = '0505633b8966aa7b7a892adb512b99bb8d5b650d'
BASE = 'd61f1b84fcea1c129c3c2b549d2cdda6b3536d33'
INITIAL_TREE = 'b154fcce037278223d8c2559f36fbf51339cf2a0'
SOURCE = 'a89bbb3ddac639cc787ba08d030e8b2539057387'
EVIDENCE = 'docs/state-contracts/evidence/R0016/'
SUCCESSOR = EVIDENCE + 'third-successor/successor-20261112/'
NEW = SUCCESSOR + 'full20-ps51-attempt2/'
MATRIX = EVIDENCE + 'current-acceptance-matrix.json'
DOC = 'docs/state-contracts/R0016.md'
checks = []
reads = {}

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])

def blob(rev, path):
    key = (rev, path)
    if key not in reads:
        data = git('show', f'{rev}:{path}')
        reads[key] = {'revision': rev, 'path': path, 'bytes': len(data),
                      'sha256': sha256(data).hexdigest(), 'data': data}
    return reads[key]['data']

def check(name, condition, detail=None):
    checks.append({'name': name, 'passed': bool(condition), 'detail': detail})

def identity(data, entry):
    return len(data) == entry['bytes'] and sha256(data).hexdigest() == entry['sha256']

def parse(data):
    return json.loads(data)

supplied = parse((OUT / 'final-tree-inputs/MANIFEST.json').read_bytes())
expected = {e['path']: e for e in supplied['files']}
delta = [line.split('\t') for line in git('diff-tree', '--no-commit-id', '--name-status', '-r', BASE, TREE).decode().splitlines()]
check('Exact final object is a Git tree', git('cat-file', '-t', TREE).strip() == b'tree')
check('Published predecessor resolves to initial reviewed tree', git('rev-parse', BASE + '^{tree}').decode().strip() == INITIAL_TREE)
check('Exactly ten supplied documentation/evidence paths changed', len(delta) == 10 and {p for _, p in delta} == set(expected) and all(s in {'A', 'M'} for s, _ in delta), delta)
whole_delta = git('diff-tree', '--no-commit-id', '--name-only', '-r', SOURCE, TREE).decode().splitlines()
check('All changes since qualified product/instrument source are documentation/evidence only', all(p.startswith('docs/state-contracts/') for p in whole_delta), {'changedPaths': len(whole_delta)})
for path, entry in expected.items():
    data = blob(TREE, path)
    check('Exact staged blob ' + path, identity(data, entry) and data == (OUT / 'final-tree-inputs' / path).read_bytes(), entry)
check('Explicit final Markdown identity', identity(blob(TREE, DOC), {'bytes': 33063, 'sha256': '604f735dd8c2ae5ac54846c42873c452740c128f818b0559411aee85e84c25d6'}))
check('Explicit final matrix identity', identity(blob(TREE, MATRIX), {'bytes': 302981, 'sha256': '969e73921d52fb8b4befbe5fab59ebddefbbf2c691a3f98ca5579cb9c4a95ca5'}))
old = parse(blob(BASE, MATRIX))
new = parse(blob(TREE, MATRIX))
old_doc = blob(BASE, DOC)
initial_rows = parse((OUT / 'initial-row-dispositions.json').read_bytes())['rows']
provisional = parse((OUT / 'ps51-row-join-provisional.json').read_bytes())

immutable_row_fields = ['id', 'category', 'obligation', 'historicalStatus', 'historicalPointer', 'priorEvidenceProjection', 'historicalCurrentEvidenceAt9c51']
check('All original 46 row identities, wording, histories and ordering unchanged', len(new['rows']) == 46 and [[r.get(k) for k in immutable_row_fields] for r in new['rows']] == [[r.get(k) for k in immutable_row_fields] for r in old['rows']])
check('Exact original category counts', dict(Counter(r['category'] for r in new['rows'])) == {'requirements': 14, 'residual_acceptance': 6, 'branch_matrix': 15, 'effects': 11})
check('Own sealed original46 dispositions match final matrix identities', [(r['id'], r['category'], r['originalObligation'], r['historicalPointer']) for r in initial_rows] == [(r['id'], r['category'], r['obligation'], r['historicalPointer']) for r in new['rows']])
history = blob(TREE, EVIDENCE + 'historical-matrix.json')
check('Historical matrix remains exact original digest', sha256(history).hexdigest() == '828638072d532c8e2e2167248c89d3ad19e707addac7db65e4742e4112e61dac')
historical_keys = [k for k in old if k.startswith(('historical', 'previous', 'prior'))] + ['contract', 'common', 'denominator', 'historySha256', 'dependencyAdvance', 'dependencyAdvanceHistory', 'successorRecovery', 'nativeMacOSAttempts', 'nativeLogRetentionCandidate4', 'windowsNormalPreparationHistory']
check('All predecessor historical objects remain unchanged', all(old[k] == new[k] for k in historical_keys), historical_keys)
check('Prior publication references exact immutable d61 bytes', new['previousPublishedProjectionAtD61']['commit'] == BASE and new['previousPublishedProjectionAtD61']['tree'] == INITIAL_TREE and identity(blob(BASE, MATRIX), new['previousPublishedProjectionAtD61']['matrix']) and identity(old_doc, new['previousPublishedProjectionAtD61']['markdown']))
check('Source binding map unchanged from already verified initial tree', new['currentReconciliation']['sourceBindings'] == old['currentReconciliation']['sourceBindings'])
check('Dependency source/accepted base remain bound', new['dependency']['head'] == SOURCE and new['dependency']['tree'] == 'efa716f4c8f1fe61c1a5a85b48bd97e813305d16' and new['dependency']['acceptedMain'] == '3b0e614114ef066de40db117d0e85c0031cf3e30')
check('No fictional future publication identity', new['documentationEvidenceBaseline']['commit'] == BASE and new['documentationEvidenceBaseline']['futurePublicationCommit'] is None and new['currentReconciliation']['candidateQualificationUpdate']['nextCommit'] is None)

for name in ['api-association-received.json', 'checks.json', 'manifest.json', 'report.md']:
    check('New published native receipt equals separately joined original ' + name, blob(TREE, NEW + name) == (OUT / 'additional-inputs' / ('ps51-attempt2-' + name)).read_bytes())
root_data = blob(TREE, SUCCESSOR + 'root-receipt-admission.json')
prior_root = blob(TREE, SUCCESSOR + 'root-receipt-admission-G0028.json')
root = parse(root_data)
check('Current root admission exact supplied advanced input', root_data == (OUT / 'additional-inputs/root-receipt-admission-advanced.json').read_bytes() and sha256(root_data).hexdigest() == '9f5de7a39f2e004b8aa76409545a409f13d64f0cb85b3e3fd572884249932696')
check('Prior root admission preserved exactly', prior_root == (OUT / 'additional-inputs/root-receipt-admission.json').read_bytes() and sha256(prior_root).hexdigest() == '58686a771b0db518c9553bed4e5dc7e58c7c3eeb12ece2c41325694156b3a92d')
packet = parse(blob(TREE, NEW + 'packet.json'))
zip_data = blob(TREE, NEW + 'receiving-packet.zip')
check('Published complete receiving ZIP matches packet digest', len(zip_data) == packet['packetBytes'] and sha256(zip_data).hexdigest() == packet['packetSha256'])
check('Packet binds exact genuine native source/run/job/artifact', (packet['sourceHead'], packet['runId'], packet['attempt'], packet['jobId'], packet['artifactId']) == (SOURCE, 43220592915, 2, 131197436545, 13947627028) and packet['originalZipSha256'] == '4247cb1eee4043d59c950936b84ac1b9ce09dbf4041edaad323d2857357c37b1' and packet['originalZipBytes'] == 3067872)
with zipfile.ZipFile(BytesIO(zip_data)) as archive:
    names = archive.namelist()
    entries = packet['completeReceiverDirectoryFiles']
    check('Receiving packet CRC, unique flat member set and ten-file completeness', archive.testzip() is None and len(names) == len(set(names)) == 10 and set(names) == {e['path'] for e in entries} and all('/' not in n and '\\' not in n for n in names))
    for entry in entries:
        data = archive.read(entry['path'])
        check('Receiving packet exact member ' + entry['path'], identity(data, entry), {'bytes': len(data), 'sha256': sha256(data).hexdigest(), 'executed': False})
    native_manifest = parse(archive.read('manifest.json'))
    check('Native manifest nine inputs match complete packet members', len(native_manifest) == 9 and all(identity(archive.read(Path(e['path']).name), e) for e in native_manifest))
    check('Published receipt JSON/text bytes equal the complete packet', all(archive.read(name) == blob(TREE, NEW + name) for name in ['api-association-received.json', 'checks.json', 'manifest.json', 'report.md']))

admission_ref = {'path': 'third-successor/successor-20261112/root-receipt-admission.json', 'bytes': 8113, 'sha256': '9f5de7a39f2e004b8aa76409545a409f13d64f0cb85b3e3fd572884249932696'}
check('All root admission projections match exact current decisions and limits', new['rootBoundedAdmission']['technicalGateDispositions'] == root['technicalGateDispositions'] and new['rootBoundedAdmission']['retainedLimits'] == root['retainedLimits'] and new['rootBoundedAdmission']['receipt'] == admission_ref and new['currentReconciliation']['rootAdmissionReceipt'] == admission_ref)
check('T01-T04 admitted; T05 explicitly remains open pending independent verdict', all(new['technicalFrontier'][g]['state'].startswith('ADMITTED') and new['technicalFrontier'][g]['rootDecision'] == root['technicalGateDispositions'][g] for g in ['T01', 'T02', 'T03', 'T04']) and new['technicalFrontier']['T05']['state'] == 'OPEN')
check('No automatic acceptance numerator or contract/delivery satisfaction', new['acceptanceNumerator'] is None and all(new[k] is False for k in ['wholeContractSatisfied', 'nativeAppleSatisfied', 'nativeWindowsSatisfied', 'finalPublicDeliverySatisfied']))
check('Root decision retains complete-packet, approval, delivery, certificate and closure limits', root['allNativeTechnicalGatesAdmitted'] is True and root['completePacketRootAdmission'] is False and all(root[k] is False for k in ['wholeContractSatisfied', 'mergeApprovalGranted', 'finalPublicDeliverySatisfied', 'certificateIssued', 'issueClosureAuthorizedAtThisStage']) and new['currentReconciliation']['rootAdmission'] is False and new['rootBoundedAdmission']['completeFinalPacketAdmitted'] is False)
expected_remaining = {r['id']: ['T05'] + (['X01'] if r['id'] == '22-10' else ['X02', 'X03', 'X04'] if r['id'] in ['22-14', 'R0016-A06'] else []) for r in new['rows']}
check('Each row retains T05 and only its preexisting applicable external gates', all(r['currentRemainingGateIds'] == expected_remaining[r['id']] for r in new['rows']), expected_remaining)
check('Each row admits exactly its former applicable T01-T04 gates without inventing new gates', all(r['currentAdmittedTechnicalGateIds'] == [g for g in o['currentRemainingGateIds'] if g in ['T01', 'T02', 'T03', 'T04']] and r['currentRootAdmissionReceipt'] == admission_ref for r, o in zip(new['rows'], old['rows'])))
check('Each row retains its exact prior receipt join set', all(r['currentReceiptJoins'] == o['currentReceiptJoins'] for r, o in zip(new['rows'], old['rows'])))
check('External handoff, owner approval, actual delivery and manual closure stay open', {k: v['state'] for k, v in new['externalGates'].items()} == {'X01': 'INPUT_ALREADY_INTEGRATED_HANDOFF_PENDING', 'X02': 'NOT_ESTABLISHED_BY_THIS_LANE', 'X03': 'OPEN_EXTERNAL_EFFECT_AND_RECEIVING', 'X04': 'OPEN_OWNER_DECISION'})

join = new['currentEvidenceReceiptJoins']['J_WFULL20']
check('Current genuine full20 projection includes exactly original two attempts', join['full20Passed'] is True and join['candidateQualificationHead'] == SOURCE and [a['attempt'] for a in join['attempts']] == [1, 2] and all(a['sourceCommit'] == SOURCE for a in join['attempts']))
a1, a2 = join['attempts']
ps51 = a2['ps51']
check('PS5.1 attempt1 preserved as unresolved zero-product-case bootstrap failure', a1['hosts']['ps51']['completedInstallerCases'] == 0 and a1['hosts']['ps51']['reportedFullEntryAccepted'] is False and a1['hosts']['ps51']['jobConclusion'] == 'failure' and a1['hosts']['ps51']['archive'] == old['currentEvidenceReceiptJoins']['J_WFULL20']['attempts'][0]['hosts']['ps51']['archive'] and 'No cause or repair' in a1['hosts']['ps51']['limits'])
check('PS7 current credit remains original attempt1; attempt2 listing is not execution', a1['hosts']['ps766']['completedInstallerCases'] == 20 and a1['hosts']['ps766']['job'] == '131190813338' and a1['hosts']['ps766']['artifact'] == '13944574998' and a2['ps766']['newNativeExecution'] is False and a2['ps766']['originalAttempt'] == 1 and a2['ps766']['originalJob'] == '131190813338')
check('PS5.1 current credit binds received actual20 and correct original artifact', ps51['completedInstallerCases'] == ps51['qualifiedCases'] == 20 and ps51['producerReportedPreviewCases'] == 18 and ps51['producerReportedNormalCases'] == 2 and ps51['job'] == '131197436545' and ps51['artifact'] == '13947627028' and ps51['sourceCommit'] == SOURCE and identity(root_data, ps51['rootAdmissionReceipt']))
for field in ['receivingReceipt', 'receivingManifest', 'receivingChecks', 'completeReceivingPacket']:
    entry = ps51[field]
    check('PS5.1 current projection references exact ' + field, identity(blob(TREE, EVIDENCE + entry['path']), entry))
physical = ps51['physicalScope']
check('PS5.1 host-specific lifecycle scope remains explicit', physical == {'previewCases': 18, 'earlyRefusalsWithinPreview': 2, 'previewFullProfileUnchanged': True, 'earlyRefusalStartupQuiescent': False, 'completeDirectInputLifecycleEqualCases': 0, 'heldInvocationEqualCases': 18, 'heldAfterPostexitEqualCases': 18, 'heldPreparedEqualsPrelaunchCases': 18, 'heldPreparationEqualsBeforeInvocationCases': 0, 'normalFullProfileUnchanged': False, 'noDirectDiscoveryProofForEarlyRefusals': True})
prior_join = parse((OUT / 'ps51-join-checks.json').read_bytes())
normal = ps51['strictNormal']
check('Actual normal732 cache identity joins own independently checked summaries', normal['passed'] is True and normal['cases'] == 2 and normal['cacheBytes'] == 732 and normal['cacheSha256'] == {r['scenario']: r['cacheSha256'] for r in prior_join['normalSummary']} and all(r['cacheBytes'] == 732 for r in prior_join['normalSummary']))
check('Normal cache and preparation equalities retain full fields and original postconditions', normal['cacheAbsentAtWarmBefore'] is True and normal['completeCacheRowsEqualAcross'] == ['warmAfter', 'productBefore', 'productAfter'] and normal['completeWarmAfterEqualsProductBefore'] is True and 'exact eight-entry' in normal['scope'] and 'no cache exclusion' in normal['scope'])
check('Preview/direct/held case counts retain distinct scopes', join['caseBreakdown'] == old['currentEvidenceReceiptJoins']['J_WFULL20']['caseBreakdown'] and join['caseBreakdown']['total'] == 20 and join['caseBreakdown']['preview'] == join['caseBreakdown']['heldRelationships'] == 18 and join['caseBreakdown']['normal'] == join['caseBreakdown']['earlyOptionRefusalsWithinPreview'] == 2)
check('Windows instrument denominators and absent independent hard containment preserved', all(new['scopedCurrentPowerShell'][k] == old['scopedCurrentPowerShell'][k] for k in ['coreRowsPerHost', 'normalRowsPerHost', 'actualCallerRoutesPerHost', 'original18BehaviorRowsForReusePerHost', 'original18ParserRowsHistoricalOnlyPerHost', 'independentHardContainment']) and new['scopedCurrentPowerShell']['independentHardContainment'] == 'NOT_ACQUIRED')
check('Historical Linux aggregate failure and entry-subgroup scope unchanged', new['scopedCurrentLinux']['entrySubgroup'] == old['scopedCurrentLinux']['entrySubgroup'] and new['scopedCurrentLinux']['entrySubgroup']['aggregateStatus'] == 'FAIL')
check('Mac catalog exception and adverse scope unchanged', new['scopedCurrentMacOS']['cataloguedButUnexecutedChangedInput'] == old['scopedCurrentMacOS']['cataloguedButUnexecutedChangedInput'] and new['scopedCurrentMacOS']['scope'] == old['scopedCurrentMacOS']['scope'])
check('Original18 decoded-stream and absent custody limits in current fallback row', all(t in next(r for r in new['rows'] if r['id'] == 'N03')['currentEvidence'][-1] for t in ['decoded UTF-8', 'rather than original OS stream buffers', 'no Job/descendant', 'full-profile']))

provenance = parse((OUT / 'provenance-update.json').read_bytes())
check('All six conclusions sealed before incidental summary visibility are unchanged', len(provenance['sealedPriorConclusions']) == 6 and all(identity((OUT / e['path']).read_bytes(), e) for e in provenance['sealedPriorConclusions']))
check('Prior native join remains successful without rerun', prior_join['passed'] == 64 and prior_join['failed'] == [] and provisional['finalTree'] is None)
check('Prior initial review remains successful without rerun', parse((OUT / 'initial-checks.json').read_bytes())['passed'] == 292 and parse((OUT / 'initial-checks.json').read_bytes())['failed'] == [])

result = {
    'schema': 'r0016-final-contract-tree-delta-checks.v1',
    'recordedUtc': datetime.now(timezone.utc).isoformat(),
    'reviewedTree': TREE, 'baselineCommit': BASE, 'sourceCommit': SOURCE,
    'method': 'Bounded exact Git-object, new receipt/packet, unchanged-history, per-row mapping and admission-boundary comparisons. Earlier292 and64 checks not rerun; no native or archive code execution.',
    'authority': 'Ordinary technical review only. Root admission, integration, external delivery, certification and lifecycle decisions remain separate.',
    'checks': checks, 'passed': sum(c['passed'] for c in checks),
    'failed': [c for c in checks if not c['passed']],
    'nonblockingEditorialFinding': {
        'id': 'C-FINAL-01', 'rows': ['22-05', '22-10'],
        'finding': 'Two currentEvidence sentences retain prospective must-still-supply / complete-Windows-full20 phrasing although current states and gate arrays correctly record admission.',
        'disposition': 'Root acknowledged bounded wording correction in later final status/publication delta; no missing native proof.'
    },
    'provenance': provenance,
    'readManifest': [{k: v for k, v in r.items() if k != 'data'} for r in reads.values()],
}
(OUT / 'final-delta-checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'passed': result['passed'], 'total': len(checks), 'failed': result['failed'], 'immutableObjectsRead': len(reads)}, indent=2))
raise SystemExit(1 if result['failed'] else 0)
