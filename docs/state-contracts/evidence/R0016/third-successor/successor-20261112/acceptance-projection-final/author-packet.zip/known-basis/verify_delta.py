#!/usr/bin/env python3
"""Bounded data/preservation/source/link checks; no native or archived execution."""
from collections import Counter
import hashlib,json,posixpath,re,subprocess,tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
WORK=ROOT.parent.parent
REPO=WORK/'salah_widget'
PRIOR=ROOT.parent/'acceptance_projection_a89'
BASELINE='d61f1b84fcea1c129c3c2b549d2cdda6b3536d33'
TREE='b154fcce037278223d8c2559f36fbf51339cf2a0'
SOURCE='a89bbb3ddac639cc787ba08d030e8b2539057387'
SOURCE_TREE='efa716f4c8f1fe61c1a5a85b48bd97e813305d16'
MD='docs/state-contracts/R0016.md'
MATRIX='docs/state-contracts/evidence/R0016/current-acceptance-matrix.json'
HISTORY='docs/state-contracts/evidence/R0016/historical-matrix.json'
EVIDENCE='docs/state-contracts/evidence/R0016/'
PUB='third-successor/successor-20261112/'
ADMISSION=EVIDENCE+PUB+'root-receipt-admission.json'
CHECKS=[]
def check(name,value,detail=None):CHECKS.append(dict(name=name,passed=bool(value),**({'detail':detail} if detail is not None else {})))
def sha(data):return hashlib.sha256(data).hexdigest()
def git(path,commit=BASELINE):return subprocess.check_output(['git','-C',str(REPO),'show',commit+':'+path])
def load(name):return json.loads((ROOT/name).read_text())

inputs=load('input-bindings.json');bindings=load('candidate-bindings.json')
base={p:(ROOT/'baseline'/p).read_bytes() for p in (MD,MATRIX,HISTORY)}
candidate={p:(ROOT/'candidate'/p).read_bytes() for p in (MD,MATRIX)}
old=json.loads(base[MATRIX]);new=json.loads(candidate[MATRIX]);history=json.loads(base[HISTORY])
mapping=json.loads(git(EVIDENCE+PUB+'mapping/current-mapping-reconciled.json'))
admission_bytes=(ROOT/'inputs/root-receipt-admission.known.json').read_bytes()
admission=json.loads(admission_bytes)
for p,b in base.items():
    check('baseline immutable '+p,b==git(p))
    check('shared target still unmodified '+p,b==(REPO/p).read_bytes())
check('baseline tree exact',subprocess.check_output(['git','-C',str(REPO),'show','-s','--format=%T',BASELINE],text=True).strip()==TREE)
check('source tree exact',subprocess.check_output(['git','-C',str(REPO),'show','-s','--format=%T',SOURCE],text=True).strip()==SOURCE_TREE)
check('published baseline equals prior delivered Markdown',sha(base[MD])=='6ea5a9c8a0f4e5f6873ae587c208730609ac0b2a55b676b55b317c62ac0f115f')
check('published baseline equals prior delivered matrix',sha(base[MATRIX])=='cbde41e50f14c05a7402d1d53a72dc9ed81b5ab4b880814eadc92256ec182e4a')
check('prior output manifest immutable',sha((PRIOR/'MANIFEST.json').read_bytes())=='d882629e150d3adcd619b6273bff87ff0e13738ca7b12a29342734072e1012e5')
for item in inputs['priorOutputFiles']:
    b=(PRIOR/item['path']).read_bytes()
    check('prior output immutable '+item['path'],len(b)==item['bytes'] and sha(b)==item['sha256'])
check('root admission exact known authority',sha(admission_bytes)=='58686a771b0db518c9553bed4e5dc7e58c7c3eeb12ece2c41325694156b3a92d')
check('root admission source/baseline bound',admission['reviewedProjectionHead']==BASELINE and admission['reviewedProjectionTree']==TREE and admission['nativeFull20SourceHead']==SOURCE)
check('root record retains no closure/merge/delivery authority',all(admission[k] is False for k in ('wholeContractSatisfied','mergeApprovalGranted','finalPublicDeliverySatisfied','certificateIssued','issueClosureAuthorizedAtThisStage')))
for receipt in admission['receipts']:
    b=git(receipt['path'])
    check('root admitted receipt exact '+receipt['id'],len(b)==receipt['bytes'] and sha(b)==receipt['sha256'])

check('historical matrix unchanged exact hash',sha(base[HISTORY])=='828638072d532c8e2e2167248c89d3ad19e707addac7db65e4742e4112e61dac' and not (ROOT/'candidate'/HISTORY).exists())
check('same schema/contract/common/history hash',all(new[k]==old[k] for k in ('schema','contract','common','historySha256')))
check('denominator exact original46',new['denominator']==old['denominator']==dict(requirements=14,residual_acceptance=6,branch_matrix=15,effects=11,total=46))
check('same original IDs and order',[r['id'] for r in new['rows']]==[r['id'] for r in old['rows']]==[r['id'] for r in mapping['rows']] and len(new['rows'])==46)
check('exact category counts',Counter(r['category'] for r in new['rows'])==dict(requirements=14,residual_acceptance=6,branch_matrix=15,effects=11))
mutable={'currentStatus','currentEvidence','remaining','currentRemainingGateIds','currentGapDetail'}
for before,after,mapped in zip(old['rows'],new['rows'],mapping['rows']):
    rid=before['id']
    for k in ('id','category','obligation','historicalStatus','historicalPointer'):
        check(rid+': original '+k,before[k]==after[k]==mapped[k])
    check(rid+': all original historical/noncurrent row fields preserved',all(after[k]==v for k,v in before.items() if k not in mutable))
    node=history
    for part in after['historicalPointer'].split('#',1)[1].strip('/').split('/'):
        part=part.replace('~1','/').replace('~0','~');node=node[int(part)] if isinstance(node,list) else node[part]
    check(rid+': original history pointer resolves',isinstance(node,dict) and node.get('id',rid)==rid)
    admitted=[g for g in mapped['remainingTechnicalGates'] if g in ('T02','T03','T04')]
    remaining=[g for g in mapped['remainingTechnicalGates'] if g not in admitted]
    check(rid+': no added gates or unadmitted removal',after['currentAdmittedTechnicalGateIds']==admitted and after['currentRemainingGateIds']==remaining+['T05']+mapped['externalGates'])
    check(rid+': original receipt aliases unchanged',after['currentReceiptJoins']==before['currentReceiptJoins'])
    check(rid+': no stale remaining T02/T03/T04 admission',not any(s.startswith(('T02:','T03:','T04:')) for s in after['remaining']))
    check(rid+': no acceptance','NO_ACCEPTANCE' in after['currentStatus'] and any(s.startswith('T05:') for s in after['remaining']))
for key in old:
    if key.startswith(('historical','previous','prior')) or key in ('successorRecovery','dependencyAdvance','dependencyAdvanceHistory','nativeMacOSAttempts','nativeLogRetentionCandidate4'):
        check('historical object retained '+key,new[key]==old[key])
check('only existing technical/external gates',list(new['technicalFrontier'])==list(old['technicalFrontier'])==['T01','T02','T03','T04','T05'] and list(new['externalGates'])==list(old['externalGates'])==['X01','X02','X03','X04'])
for gate in ('T02','T03','T04'):
    check('root-authorized current gate '+gate,new['technicalFrontier'][gate]['state']==admission['technicalGateDispositions'][gate].split(':',1)[0] and new['technicalFrontier'][gate]['rootDecision']==admission['technicalGateDispositions'][gate])
check('T01 and T05 remain open',new['technicalFrontier']['T01']['state']=='OPEN' and new['technicalFrontier']['T05']['state']=='OPEN')
check('whole-contract/native/delivery flags unclaimed',all(new[k] is False for k in ('wholeContractSatisfied','nativeAppleSatisfied','nativeWindowsSatisfied','finalPublicDeliverySatisfied')) and new['acceptanceNumerator'] is None)
check('complete packet and final review unclaimed',new['currentReconciliation']['rootAdmission'] is False and new['currentReconciliation']['finalIndependentExact46Review'] is False and new['rootBoundedAdmission']['completeFinalPacketAdmitted'] is False)
check('root bounded authority copied exactly',new['rootBoundedAdmission']['authority']==admission['authority'] and new['rootBoundedAdmission']['retainedLimits']==admission['retainedLimits'])

changed=subprocess.check_output(['git','-C',str(REPO),'diff','--name-only',SOURCE,BASELINE],text=True).splitlines()
check('d61 changes are documentation/evidence only',all(p.startswith('docs/state-contracts/') for p in changed),changed)
for path,item in new['currentReconciliation']['sourceBindings'].items():
    b=git(path,SOURCE)
    check('exact source identity unchanged through d61 '+path,b==git(path,BASELINE) and len(b)==item['bytes'] and sha(b)==item['sha256'] and item['commit']==SOURCE)
check('product source/d61 document identities separated',new['documentationEvidenceBaseline']['commit']==BASELINE and new['documentationEvidenceBaseline']['tree']==TREE and new['documentationEvidenceBaseline']['productAndInstrumentSource']==SOURCE and new['documentationEvidenceBaseline']['futurePublicationCommit'] is None)
check('source-security bounded phase retained',new['sourceSecurityReview']['state']=='BOUNDED_FIRST_PHASE_PASS_FINAL_TREE_JOIN_PENDING' and new['sourceSecurityReview']['finalImmutableTreeJoin'] is None and new['sourceSecurityReview']['sourceHead']==SOURCE)
full=new['currentEvidenceReceiptJoins']['J_WFULL20']
check('no two-host pass inferred',full['full20Passed'] is False and new['scopedCurrentPowerShell']['fullEntryPassed'] is False)
check('original failed attempt retains0 cases',full['attempts'][0]['hosts']['ps51']['completedInstallerCases']==0 and full['attempts'][0]['hosts']['ps51']['reportedFullEntryAccepted'] is False)
check('PS7 original20 root-admitted',full['attempts'][0]['hosts']['ps766']['completedInstallerCases']==20 and full['attempts'][0]['hosts']['ps766']['rootAdmission'] is True)
second=full['attempts'][1]['ps51']
check('PS51 producer success distinct from receiving',second['state']=='COMPLETED_SUCCESS' and second['producerReportedCases']==20 and second['independentReceiving']=='PENDING' and second['qualifiedCases'] is None)
check('actual732 distinct from diagnostic738',second['observedNormalCacheBytes']==732 and new['windowsNormalPreparationHistory']['laterWarm20AndWarmJson']['stableCacheBytes']==738)
check('PS7 reused job remains no new execution',full['attempts'][1]['ps766']['newNativeExecution'] is False)
check('full20 correct denominator',full['caseBreakdown']['total']==20 and full['caseBreakdown']['preview']==18 and full['caseBreakdown']['normal']==2 and full['caseBreakdown']['earlyOptionRefusalsWithinPreview']==2)
original=(WORK/inputs['ps51Attempt2Archive']['path']).read_bytes()
check('PS51 attempt2 exact original ZIP custody',len(original)==3067872 and sha(original)=='4247cb1eee4043d59c950936b84ac1b9ce09dbf4041edaad323d2857357c37b1')
check('original18 decoded capture and confinement limits',all(s in new['currentEvidenceReceiptJoins']['J_WFALLBACK15']['limits'] for s in ('decoded UTF-8','not original OS stream buffers','No Job/descendant','complete-profile containment')))
check('current status no PRIVATE claim','PRIVATE' not in new['currentReconciliation']['status'])
check('publication wording binds actual d61','d61' in new['currentReconciliation']['publication'] and 'private' not in new['currentReconciliation']['publication'].lower())
check('owner merge approval retained','owner merge approval before integration into main' in new['externalGates']['X02']['minimum'])

md=candidate[MD].decode()
for name,needle in [('decoded capture','decoded UTF-8 text'),('no original buffers','not original OS stream buffers'),('normal actual cache','actual732-byte normal caches'),('original old diagnostic','738-byte diagnostic caches'),('independent receiving pending','Independent original receiving and root technical disposition remain pending'),('source security pending','final immutable documentation/evidence-tree and native-evidence joins remain open'),('old Linux failure','FAIL37/45'),('old Mac targeted gap','ACQUISITION_GAP'),('Mac cache delta','adds41 Python-cache entries'),('Windows lack containment','independentHardContainment=NOT_ACQUIRED'),('docs clipped PNG','horizontally clipped'),('blank-widget limit','blank widget')]:
    check('current prose retains '+name,needle.lower() in md.lower())
for target in sorted(set(re.findall(r'\]\(([^)]+)\)',md))):
    if re.match(r'^[a-z]+://',target):continue
    path=posixpath.normpath(posixpath.join(posixpath.dirname(MD),target.split('#',1)[0]))
    exists=(path==ADMISSION and sha(admission_bytes)==inputs['rootAdmission']['sha256']) or subprocess.run(['git','-C',str(REPO),'cat-file','-e',BASELINE+':'+path],capture_output=True).returncode==0
    check('exact relative evidence target '+target,exists)
check('no private machine paths in candidates',all('/workspace/' not in b.decode() and '/home/agent/' not in b.decode() for b in candidate.values()))

patch=(ROOT/'candidate.patch').read_bytes()
check('exact two-file delta',re.findall(r'^diff --git a/(\S+) b/(\S+)$',patch.decode(),re.M)==[(MD,MD),(MATRIX,MATRIX)])
with tempfile.TemporaryDirectory(prefix='private-apply-',dir=ROOT) as temp:
    t=Path(temp)
    for p,b in base.items():q=t/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
    r=subprocess.run(['git','apply','--check',str(ROOT/'candidate.patch')],cwd=t,capture_output=True,text=True)
    check('patch check on exact d61 baseline',r.returncode==0,r.stderr)
    r=subprocess.run(['git','apply',str(ROOT/'candidate.patch')],cwd=t,capture_output=True,text=True)
    check('actual private apply',r.returncode==0,r.stderr)
    for p,b in candidate.items():check('private apply exact bytes '+p,(t/p).read_bytes()==b)
    check('historical matrix remains untouched after apply',(t/HISTORY).read_bytes()==base[HISTORY])
for item in bindings['files']:
    b=candidate[item['path']];check('candidate exact hash '+item['path'],len(b)==item['bytes'] and sha(b)==item['sha256'])
check('patch exact hash',len(patch)==bindings['patch']['bytes'] and sha(patch)==bindings['patch']['sha256'])
failures=[c for c in CHECKS if not c['passed']]
result=dict(status='PASS_KNOWN_BASIS_PS51_RECEIVING_PENDING' if not failures else 'GAP',
    source=SOURCE,documentationEvidenceBaseline=BASELINE,authority='Author-side bounded preservation/source/link/diff checks; root decision is the sole admission input.',
    checksPassed=len(CHECKS)-len(failures),checksTotal=len(CHECKS),failures=failures,checks=CHECKS,
    incompleteReceiverOutputsRead=False,independentPS51ReceivingClaimed=False,
    acceptanceNumerator=None,wholeContractSatisfied=False)
(ROOT/'checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('status','checksPassed','checksTotal','failures')},indent=2))
raise SystemExit(0 if not failures else 1)
