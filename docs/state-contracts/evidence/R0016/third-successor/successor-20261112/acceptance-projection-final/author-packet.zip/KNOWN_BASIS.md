# R0016 known-basis delta

The two-file candidate applies to published d61f1b84fcea1c129c3c2b549d2cdda6b3536d33. Product/instrument source remains a89bbb3ddac639cc787ba08d030e8b2539057387. The root-created admission file is bound at SHA-256 58686a771b0db518c9553bed4e5dc7e58c7c3eeb12ece2c41325694156b3a92d.

T02, T03 and T04, existing scoped receipts, and PS7 all20 are marked root-admitted only within that decision. The stale PRIVATE/publication wording is corrected; original18 behavior15 retains decoded-UTF8, no-original-OS-buffer and no-Job/full-profile-containment limits.

PS5.1 attempt2 producer reports20 after a successful job; independent receiving remains pending. Actual732-byte caches remain distinct from738-byte diagnostic caches. No incomplete receiver outputs were read. Complete-packet root admission, native satisfaction, T05, merge approval, delivery, certificate and closure remain unclaimed/open.

All46 IDs/order/categories/obligation text/history are preserved. Bounded verification returned exit0 with652/652 checks, including exact d61 patch application and unchanged prior output. No native/test campaign or shared repository write occurred.

The root will provide the completed PS5.1 receipt and updated technical decision before the final delta advances T01 or native dispositions.
