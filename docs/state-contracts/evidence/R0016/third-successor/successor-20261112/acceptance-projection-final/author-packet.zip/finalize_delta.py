#!/usr/bin/env python3
"""Finalize the delegated two-file projection from frozen inputs; private writes only."""
import copy, datetime as dt, difflib, hashlib, json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
WORK=ROOT.parent.parent
REPO=WORK/'salah_widget'
KNOWN=ROOT/'known-basis'
BASELINE='d61f1b84fcea1c129c3c2b549d2cdda6b3536d33'
SOURCE='a89bbb3ddac639cc787ba08d030e8b2539057387'
MD='docs/state-contracts/R0016.md'
MATRIX='docs/state-contracts/evidence/R0016/current-acceptance-matrix.json'
EVIDENCE='docs/state-contracts/evidence/R0016/'
PUB='third-successor/successor-20261112/'
FINAL_SHA='9f5de7a39f2e004b8aa76409545a409f13d64f0cb85b3e3fd572884249932696'
def sha(b): return hashlib.sha256(b).hexdigest()
def fact(b,path): return dict(path=path,bytes=len(b),sha256=sha(b))
def load(p): return json.loads(p.read_text())
def save(p,b):
    q=ROOT/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
def jsave(p,v): save(p,(json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode())

admission_bytes=(ROOT/'inputs/root-receipt-admission.final.json').read_bytes()
assert len(admission_bytes)==8113 and sha(admission_bytes)==FINAL_SHA
assert admission_bytes==(REPO/EVIDENCE/PUB/'root-receipt-admission.json').read_bytes()
admission=json.loads(admission_bytes)
af=fact(admission_bytes,PUB+'root-receipt-admission.json')
prior_bytes=(ROOT/'inputs/root-receipt-admission.known.json').read_bytes()
prior_af=fact(prior_bytes,PUB+'root-receipt-admission-G0028.json')
assert prior_bytes==(REPO/EVIDENCE/PUB/'root-receipt-admission-G0028.json').read_bytes()
new=load(KNOWN/'candidate'/MATRIX)
old_af=copy.deepcopy(new['rootBoundedAdmission']['receipt'])
def replace_admission(value):
    if isinstance(value,dict):
        if value==old_af:return copy.deepcopy(af)
        return {k:replace_admission(v) for k,v in value.items()}
    if isinstance(value,list):return [replace_admission(v) for v in value]
    return value
new=replace_admission(new)
new['recordedUtc']=dt.datetime.now(dt.timezone.utc).isoformat()
new['scope']='Original46 obligation identity/history preserved. Published documentation/evidence baseline d61 and unchanged a89 product/instrument source are reconciled to root-recorded bounded admission of T01/T02/T03/T04, including both independently received native full20 originals. T05 final immutable-tree review and existing external gates remain open. No whole-contract acceptance, numerator, certificate, merge approval, delivery or closure is supplied.'
new['priorRootBoundedAdmission']=dict(receipt=prior_af,interpretation='Earlier G0028 cutoff is preserved exactly. Current G0029 extends its technical dispositions after FINAL PS5.1 attempt2 receiving; it does not erase adverse observations or supply final packet acceptance.')
new['rootBoundedAdmission'].update(receipt=af,authority=admission['authority'],continuityReceipt=admission['continuityReceipt'],technicalGateDispositions=copy.deepcopy(admission['technicalGateDispositions']),retainedLimits=copy.deepcopy(admission['retainedLimits']),allNativeTechnicalGatesAdmitted=admission['allNativeTechnicalGatesAdmitted'],completeFinalPacketAdmitted=admission['completePacketRootAdmission'])
new['allNativeTechnicalGatesAdmitted']=admission['allNativeTechnicalGatesAdmitted']
new['dependency']['qualificationReservation']='The a89 product/instrument bytes are unchanged at published documentation/evidence baseline d61. Root admits both native full20 originals and T02/T03/T04 within the exact recorded limits. T05 final immutable source/document/evidence-tree reconciliation remains open; no obligation acceptance or whole-contract satisfaction is inferred.'

receiver_dir=WORK/'reviews/full20_ps51_attempt2'
expected_receiving={
    'report.md':(15846,'ed0c59da3d8eee098a45de2fb85f658ef98e32d7c0fa8d9a486fdefe9af8417d'),
    'manifest.json':(1846,'482d1b85bd1c32954c15404fc9974aa1a7c663d9b7e7a3e6dd48457075c7ccad'),
    'checks.json':(144428,'0d3423bc434052ea42ae16f784af240db6eeabb6be8bf57205845d03d7fa63b4'),
}
rf={}
for name,(n,h) in expected_receiving.items():
    b=(receiver_dir/name).read_bytes();assert len(b)==n and sha(b)==h
    assert b==(REPO/EVIDENCE/PUB/'full20-ps51-attempt2'/name).read_bytes()
    rf[name]=fact(b,PUB+'full20-ps51-attempt2/'+name)
packet=(REPO/EVIDENCE/PUB/'full20-ps51-attempt2/receiving-packet.zip').read_bytes()
assert len(packet)==132327 and sha(packet)=='f83d32210daf280ee63882b8bcc93fa4bd0abe4cbb8b0535745b16bfee1f77ab'
rf['receiving-packet.zip']=fact(packet,PUB+'full20-ps51-attempt2/receiving-packet.zip')

full=new['currentEvidenceReceiptJoins']['J_WFULL20']
full.update(state='BOTH_NATIVE_FULL20_ORIGINALS_RECEIVED_ROOT_ADMITTED_WITH_LIMITS',full20Passed=True,rootAdmission=True)
full['limits']='Root admits PS7 attempt1 and PS5.1 attempt2 actual20 within their recorded case, source-window and lifecycle scopes. Each20 comprises18 previews including2 early refusals plus2 normal; the18 held relationships are separate. Preserve the PS5.1 attempt1 zero-installer-case bootstrap failure, all host-specific direct/held inequalities, and normal preparation history. No hard containment, global telemetry, whole-contract acceptance or causal repair claim follows.'
second=full['attempts'][1]
second.update(state='PS51_FINAL_RECEIVED_ROOT_ADMITTED_WITH_LIMITS',statusSource='FINAL independent original receipt and exact G0029 root bounded admission record.')
second['ps51'].update(independentReceiving='FINAL_PASS_ALL20_ROOT_ADMITTED_WITH_LIMITS',qualifiedCases=20,completedInstallerCases=20,rootAdmission=True,rootAdmissionReceipt=af,receivingReceipt=rf['report.md'],receivingManifest=rf['manifest.json'],receivingChecks=rf['checks.json'],completeReceivingPacket=rf['receiving-packet.zip'],nativeVersion='5.1.20348.5773',sourceCommit=SOURCE,sourceAndInputsUnchanged=True,outerCustodyFacts=940,nativeFileJournals=56,nativeFileComparisons=472,nonceCount=58,aclReadbackJournals=38)
second['ps51']['observationLimit']='FINAL receiving verifies actual732-byte normal caches, distinct from738-byte diagnostic caches. All18 previews retain fullProfileUnchanged=true; startupQuiescent=false applies to the2 early refusals. All18 complete direct input lifecycles differ in subject/temp mtime, and the2 normal complete lifecycles differ under their original bundle/parent-mtime rules. All18 complete held invocation windows and held after/postexit windows are equal; held preparation/pre-invocation differs in subject/temp mtime. These are host/schema-specific facts, not whole-lifecycle equality or global effect telemetry.'
second['ps51']['physicalScope']=dict(previewCases=18,earlyRefusalsWithinPreview=2,previewFullProfileUnchanged=True,earlyRefusalStartupQuiescent=False,completeDirectInputLifecycleEqualCases=0,heldInvocationEqualCases=18,heldAfterPostexitEqualCases=18,heldPreparedEqualsPrelaunchCases=18,heldPreparationEqualsBeforeInvocationCases=0,normalFullProfileUnchanged=False,noDirectDiscoveryProofForEarlyRefusals=True)
second['ps51']['strictNormal']=dict(cases=2,passed=True,cacheBytes=732,cacheAbsentAtWarmBefore=True,completeCacheRowsEqualAcross=['warmAfter','productBefore','productAfter'],completeWarmAfterEqualsProductBefore=True,cacheSha256={'positive':'589682361bc92da795eb5ab1fe1830d28292a71a85d96fb8eb33cd7d6cf9525f','no-open':'36695d0a520bdb6c7395da697ffb8a296ab6539331bf88b4540a19b78befe6db'},scope='Original strict postconditions remain unchanged: exact eight-entry manual bundle and declared profile-root/subject-TEMP-parent mtime changes only; no cache exclusion. Native JSON plus20-second hold is source-free normal preparation, not a universal guarantee or established unique/sufficient fix.')
second['limits']='The actual PS5.1-only same-source rerun completed and its original20 case contracts are independently received and root-admitted within recorded limits. PS7 listing reuses its original execution. No deadline/source change, transient-cause claim or rewrite of attempt1 follows.'
new['scopedCurrentPowerShell']['fullEntryPassed']=True
new['scopedCurrentPowerShell']['fullEntryAdmission']='Both native originals are independently received and root-admitted for their original20 case contracts. This scoped technical result is separate from T05 final exact-tree review and whole-contract satisfaction.'
for gate in ('T01','T02','T03','T04'):
    f=new['technicalFrontier'][gate]
    f.update(state=admission['technicalGateDispositions'][gate].split(':',1)[0],rootDecision=admission['technicalGateDispositions'][gate],rootAdmissionReceipt=af)
new['technicalFrontier']['T01']['minimum']='Root admission is recorded for actual a89 full20 on PS7 attempt1 and PS5.1 attempt2, each independently received with18 previews including2 early refusals plus2 strict normal cases. Preserve original case predicates, host-specific lifecycle comparisons, the attempt1 zero-installer-case failure and actual732-byte versus diagnostic738-byte caches. Final immutable-tree reconciliation remains T05; no repeated native acquisition is required.'
new['technicalFrontier']['T05'].update(state='OPEN',rootDecision=admission['technicalGateDispositions']['T05'],rootAdmissionReceipt=af,minimum='Bind the final immutable source/document/evidence tree and independently reconcile every original46 row, the admitted T01/T02/T03/T04 receipts and bounded reuse, source/security first-phase finding, failed attempts and limits. Both native full20 receipts are available; no final exact-tree review result is supplied by this projection.')
new['sourceSecurityReview']['scope']='Independent source/security first-phase PASS with86 inert checks. Both current full20 originals are received and root-admitted; the final immutable documentation/evidence-tree join and independent exact46 review remain open.'
new['deltaFrontier']['D02']='Root admits both current native full20 originals including readable/unreadable reasons: PS7 attempt1 and PS5.1 attempt2. PS5.1 attempt1 remains admitted adverse evidence only with0 installer cases; its cause remains unresolved.'
new['deltaFrontier']['D05']='Current full20 is20 direct cases per native host:18 preview including2 early-option refusals plus2 normal, with18 separate held relationships. Both originals are independently received and root-admitted. Reviewed normal-only preparation preserves complete input/security/content/timestamp and profile comparators. Prior PS5.1 warm20/warm-json diagnostic passes, earlier warm20 failures and unresolved cause remain. Final immutable-tree review remains T05.'
new['deltaFrontier']['D07']='Accepted R0013/R0015 protection/source ancestry remains exact. Root admits scoped Windows core75/normal18/routes and both native current full20 originals; final immutable-tree/exact46 reconciliation remains T05.'
new['deltaFrontier']['D11']='Root admits both Windows core75/normal18 scopes and both current full20 originals. Retain152 unequal full lifecycles per core host. PS7 all20 direct full-profile/complete-input lifecycles differ. PS5.1 all18 preview fullProfileUnchanged flags are true, both early startupQuiescent flags are false, and all20 complete direct input lifecycles differ. Each host has18 equal held preview source windows; PS5.1 held after/postexit also equals while its preparation/pre-invocation TEMP mtime differs. Attempt1 remains0 installer cases. Hard containment remains unacquired and global telemetry null.'

mapping=load(REPO/EVIDENCE/PUB/'mapping/current-mapping-reconciled.json')
gap_rows=[]
for row,mapped in zip(new['rows'],mapping['rows']):
    assert row['id']==mapped['id']
    admitted=mapped['remainingTechnicalGates']
    assert all(g in ('T01','T02','T03','T04') for g in admitted)
    row['currentAdmittedTechnicalGateIds']=admitted
    row['currentRemainingGateIds']=['T05']+mapped['externalGates']
    row['currentRootAdmissionReceipt']=af
    row['currentEvidence'][0]='Immutable a89 product/instrument source and published d61 documentation/evidence baseline are bound. The exact G0029 root decision admits T01/T02/T03/T04 within their recorded scopes, including independently received PS7 attempt1 and PS5.1 attempt2 full20. Final immutable-tree/exact46 review and applicable existing external gates remain open.'
    for i,s in enumerate(row['currentEvidence']):
        s=s.replace('full20 remains open.','both current native full20 originals are independently received and root-admitted; final exact-tree review remains open.')
        s=s.replace('PS5.1 attempt1 adverse receipt has0 installer cases and attempt2 producer reports20; independent receiving is pending.','PS5.1 attempt1 adverse receipt has0 installer cases; attempt2 actual20, including strict normal2, is independently received and root-admitted.')
        s=s.replace('actual Windows readable/unreadable pair and full-entry source controls remain required.','actual Windows readable/unreadable pairs and full-entry source controls are independently received and root-admitted on both hosts within their exact scopes.')
        row['currentEvidence'][i]=s
    row['remaining']=['T05: final immutable source/document/evidence-tree join and independent exact46 review remain open; no obligation acceptance is supplied.']+[g+': '+new['externalGates'][g]['minimum'] for g in mapped['externalGates']]
    row['currentStatus']='APPLICABLE_TECHNICAL_GATES_ROOT_ADMITTED; FINAL_REVIEW_AND_APPLICABLE_EXTERNAL_GATES_OPEN; NO_ACCEPTANCE'
    row['currentGapDetail']='Applicable T01/T02/T03/T04 evidence and bounded reuse are root-admitted. Complete T05 final immutable-tree/exact46 reconciliation and applicable existing external gates. No further native or rendering acquisition gap is introduced.'
    gap_rows.append(dict(id=row['id'],category=row['category'],obligation=row['obligation'],admittedTechnicalGates=admitted,remainingTechnicalGates=[],finalIndependentGate='T05',externalGates=mapped['externalGates'],proposedAcceptance=None))
jsave('per-obligation-gaps.json',dict(head=SOURCE,documentationEvidenceBaseline=BASELINE,rootAdmission=af,rows=gap_rows))
recon=new['currentReconciliation']
recon.update(status='ENGINEERING_PROJECTION_T01_T04_ROOT_ADMITTED_FINAL_TREE_REVIEW_PENDING',rootAdmissionReceipt=af,rootAdmissionScope='Root has admitted T01/T02/T03/T04 and all native technical evidence within the exact recorded scopes. The existing rootAdmission Boolean denotes complete final packet admission and remains false because T05 final immutable-tree review is pending.',allNativeTechnicalGatesAdmitted=True,rootAdmission=False,finalIndependentExact46Review=False)
recon['candidateQualificationUpdate'].update(state='BOTH_NATIVE_FULL20_RECEIVED_ROOT_ADMITTED_FINAL_TREE_REVIEW_PENDING',full20Passed=True,note='PS7 attempt1 and PS5.1 attempt2 actual20 are independently received and root-admitted within recorded limits. PS5.1 attempt1 remains adverse preinstaller evidence with0 installer cases. The PS7 attempt2 listing reuses its original execution; T05 final exact-tree review remains open.')
recon['receivingReports'].append(rf['report.md'])
recon['satisfactionFlags']='allNativeTechnicalGatesAdmitted=true mirrors the explicit G0029 root decision. Legacy nativeAppleSatisfied/nativeWindowsSatisfied and wholeContractSatisfied remain false as unclaimed final-candidate satisfaction flags pending T05; they introduce no new native acquisition gate. Complete packet admission, acceptance numerator and final public delivery remain unclaimed.'
recon['publication']='The predecessor R0016 documentation/matrix and named earlier receipt files were published at immutable d61. This update joins the separately digest-bound current G0029 root decision and FINAL PS5.1 attempt2 receipt to that baseline and unchanged a89 product/instrument bytes. The final publication head/tree will be joined after it exists, without a future self-hash.'
jsave('candidate/'+MATRIX,new)

md=(KNOWN/'candidate'/MD).read_text()
def replace(a,b):
    global md
    assert a in md,a
    md=md.replace(a,b)
def paragraph(prefix,replacement):
    global md
    parts=md.split('\n\n');at=[i for i,p in enumerate(parts) if p.startswith(prefix)];assert len(at)==1,(prefix,at)
    parts[at[0]]=replacement;md='\n\n'.join(parts)
replace('bounded technical admission of T02/T03/T04 and PS7 full20','bounded technical admission of T01/T02/T03/T04, including both current native full20 originals')
replace('Root has admitted the recorded scoped evidence and PS7 full20. PS5.1 attempt2 producer success awaits independent receiving/root decision; no two-host or whole-contract acceptance is inferred.','Root has admitted the recorded scoped evidence and both independently received native full20 originals. T05 final immutable-tree review remains open; no whole-contract acceptance is inferred.')
replace('| Windows full20 | Run43220592915 at a89: PS7 all20 independently received and root-admitted; PS5.1 attempt1 adverse receipt retains0 installer cases. Actual PS5.1 attempt2 job succeeds and producer reports20; independent receiving is pending. | Two-host gate remains OPEN. Required20 =18 preview including2 early-option refusals plus2 normal. All18 preview cases have separate held source windows; normal2 uses strict postconditions. |','| Windows full20 | Run43220592915 at a89: PS7 attempt1 and PS5.1 attempt2 each have all20 original contracts independently received and root-admitted. PS5.1 attempt1 remains adverse evidence with0 installer cases. | T01 is admitted with recorded limits. Each20 =18 preview including2 early-option refusals plus2 normal. All18 preview cases have separate held source windows; normal2 uses strict postconditions. T05 final immutable-tree review remains open. |')
replace('The current two-owner Windows full20 composition requires its own acquisition and receiving.','The current two-owner Windows full20 composition has its own independently received original acquisition on both hosts, recorded below.')
replace('Current two-host full20 receiving remains OPEN.','Both current native full20 originals are independently received and root-admitted within these exact scopes; T05 final immutable-tree review remains open.')
replace('Both hosts still require independently received current full20 evidence; source-free diagnostics and core75/normal18 receipts cannot substitute for that composition.','Both hosts now have independently received current full20 evidence for these predicates. The source-free diagnostics and core75/normal18 receipts remain separate instruments.')
replace('supplies the retained empty/unsuitable/metadata fallback scope for root admission','supplies the root-admitted retained empty/unsuitable/metadata fallback scope')
paragraph('Actual PS5.1 attempt2',
    'Actual PS5.1 attempt2 job131197436545 at unchanged a89 ran2026-11-12T12:56:36Z to13:13:18Z. The [FINAL PS5.1 original receiver](evidence/R0016/third-successor/successor-20261112/full20-ps51-attempt2/report.md) independently receives all20 original contracts:18 genuine preview entries including2 early refusals, plus2 genuine normal entries, with18 separate held preview invocations. Original artifact13947627028 is3,067,872 bytes, SHA256 `4247cb1eee4043d59c950936b84ac1b9ce09dbf4041edaad323d2857357c37b1`. Exact14 copied roles,12 launched roles,940 outer custody facts,56 native file journals with472 comparisons,58 nonces and38 ACL readback journals join. These are receipt counts, not additional experiments or contract obligations. The root admits this exact bounded T01 evidence through the current decision.\n\n'
    'PS5.1 all18 preview `fullProfileUnchanged` flags remain true, while `startupQuiescent=false` remains for the2 early refusals with no direct discovery boundary. Every complete direct input prelaunch/postexit comparison still differs through existing `subject/temp` mtime; the2 normal full-profile comparisons differ through the validated bundle. All18 held prepared/prelaunch inventories are equal, all18 held preparation/pre-invocation inventories differ in the existing TEMP-parent mtime, and all18 complete held invocation and held after/postexit windows are equal. These PS5.1 flags and phase relations remain distinct from the PS7 all20 full-profile inequalities. No full-lifecycle equality, hard containment or global telemetry is inferred.\n\n'
    'Both PS5.1 strict normal postconditions pass unchanged. The actual732-byte normal caches are absent at warmBefore and their complete rows equal at warmAfter, productBefore and productAfter; the full warmAfter inventory equals productBefore. Positive and NoOpen retain cache hashes `589682361bc92da795eb5ab1fe1830d28292a71a85d96fb8eb33cd7d6cf9525f` and `36695d0a520bdb6c7395da697ffb8a296ab6539331bf88b4540a19b78befe6db`. These actual values are distinct from the738-byte diagnostic caches. The original exact eight-entry bundle and declared profile-root/TEMP-parent mtime rules remain; no cache or physical field is excluded.\n\n'
    'Attempt2 PS7 listing131197440277 reuses the original12:43:59 to12:46:23 execution and receipt. No new PS7 native execution, transient cause, source/deadline repair or rewrite of the first PS5.1 failure follows from the later success.')
replace('actual current full20 still requires qualification.','actual current full20 is now independently received and root-admitted through its separate original receipts.')
replace('The final immutable documentation/evidence-tree and native-evidence joins remain open; this source finding supplies no native result, merge approval, public-delivery qualification or closure.','Both native full20 originals are now received and root-admitted. The final immutable documentation/evidence-tree join and independent exact46 review remain open; this first-phase source finding supplies no final-tree acceptance, merge approval, public-delivery qualification or closure.')
paragraph('The [root admission decision](evidence/R0016/third-successor/successor-20261112/root-receipt-admission.json) admits',
    'The [current root admission decision](evidence/R0016/third-successor/successor-20261112/root-receipt-admission.json), SHA256 `'+FINAL_SHA+'`, admits T01 both native full20 originals, T02 native caller/fallback associations, T03 local docs71 and T04 scoped POSIX/Windows native receipts, with all preserved adverse/calibration evidence and recorded limits. The [earlier G0028 cutoff](evidence/R0016/third-successor/successor-20261112/root-receipt-admission-G0028.json) remains intact. Original18 behavior15 reuse stays limited to decoded UTF-8 captures; no original OS-buffer, Job/descendant or complete-profile containment claim follows. This is the root\'s bounded technical decision. `allNativeTechnicalGatesAdmitted=true` records that decision; complete final packet admission remains false pending T05. Legacy native-satisfaction fields remain unclaimed final-candidate fields and create no additional acquisition requirement.')
paragraph('The [exact46 reconciliation]',
    'The [exact46 reconciliation](evidence/R0016/third-successor/successor-20261112/mapping/current-mapping-reconciled.json) preserves the original obligations and existing gates. T01/T02/T03/T04 are now root-admitted within the [recorded scopes](evidence/R0016/third-successor/successor-20261112/root-receipt-admission.json), including both native full20 originals, original18 behavior15, named Linux/Mac entry25, local docs71 and scoped native receipts. T05 remains the independent final immutable-tree/exact-candidate46-row reconciliation. No scoped count is an acceptance numerator.')
save('candidate/'+MD,md.encode())
patch=[]
for p in (MD,MATRIX):
    before=(ROOT/'baseline'/p).read_text();after=(ROOT/'candidate'/p).read_text()
    patch.append('diff --git a/'+p+' b/'+p+'\n')
    patch.extend(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/'+p,tofile='b/'+p))
save('candidate.patch',''.join(patch).encode())
bindings=load(KNOWN/'candidate-bindings.json')
bindings['files']=[fact((ROOT/'candidate'/p).read_bytes(),p) for p in (MD,MATRIX)]
bindings['patch']=fact((ROOT/'candidate.patch').read_bytes(),'candidate.patch')
jsave('candidate-bindings.json',bindings)
inputs=load(KNOWN/'input-bindings.json')
inputs.update(rootAdmission=af,priorRootAdmission=prior_af,ps51Attempt2Receiving=rf,knownBasisManifest=fact((KNOWN/'MANIFEST.json').read_bytes(),'known-basis/MANIFEST.json'),receivingBoundary='Only FINAL independent PS5.1 attempt2 receipt/checks/manifest and root-prepared exact packet bytes are used. No receiver or acquisition code is executed; authority comes from the exact root decision.')
jsave('input-bindings.json',inputs)
print(json.dumps(dict(state='FINAL_DELTA_PREPARED',obligations=len(new['rows']),admittedTechnicalGates=['T01','T02','T03','T04'],remainingTechnicalGate='T05',bindings=bindings),indent=2))
