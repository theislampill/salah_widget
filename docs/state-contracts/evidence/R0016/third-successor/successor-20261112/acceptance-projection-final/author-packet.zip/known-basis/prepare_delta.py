#!/usr/bin/env python3
"""Bounded documentation delta; source/evidence reads only, private writes only."""
import copy
import datetime as dt
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parent
WORK=ROOT.parent.parent
REPO=WORK/'salah_widget'
PRIOR=ROOT.parent/'acceptance_projection_a89'
BASELINE='d61f1b84fcea1c129c3c2b549d2cdda6b3536d33'
BASELINE_TREE='b154fcce037278223d8c2559f36fbf51339cf2a0'
SOURCE='a89bbb3ddac639cc787ba08d030e8b2539057387'
SOURCE_TREE='efa716f4c8f1fe61c1a5a85b48bd97e813305d16'
ACCEPTED='3b0e614114ef066de40db117d0e85c0031cf3e30'
MD='docs/state-contracts/R0016.md'
MATRIX='docs/state-contracts/evidence/R0016/current-acceptance-matrix.json'
HISTORY='docs/state-contracts/evidence/R0016/historical-matrix.json'
EVIDENCE='docs/state-contracts/evidence/R0016/'
PUB='third-successor/successor-20261112/'
ADMISSION=EVIDENCE+PUB+'root-receipt-admission.json'
ADMISSION_SHA='58686a771b0db518c9553bed4e5dc7e58c7c3eeb12ece2c41325694156b3a92d'

def sha(data): return hashlib.sha256(data).hexdigest()
def git(path,commit=BASELINE): return subprocess.check_output(['git','-C',str(REPO),'show',commit+':'+path])
def save(name,data):
    p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
def jsave(name,value): save(name,(json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode())
def fact(data,path): return dict(path=path,bytes=len(data),sha256=sha(data))
def receipt(relative): return fact(git(EVIDENCE+relative),relative)

baseline={p:git(p) for p in (MD,MATRIX,HISTORY)}
for p,b in baseline.items():save('baseline/'+p,b)
admission_path=ROOT/'inputs/root-receipt-admission.known.json'
if not admission_path.exists():
    data=(REPO/ADMISSION).read_bytes()
    assert sha(data)==ADMISSION_SHA
    save('inputs/root-receipt-admission.known.json',data)
admission_bytes=admission_path.read_bytes();assert sha(admission_bytes)==ADMISSION_SHA
admission=json.loads(admission_bytes)
admission_fact=fact(admission_bytes,PUB+'root-receipt-admission.json')
old=json.loads(baseline[MATRIX]);new=copy.deepcopy(old)
mapping=json.loads(git(EVIDENCE+PUB+'mapping/current-mapping-reconciled.json'))
new['recordedUtc']=dt.datetime.now(dt.timezone.utc).isoformat()
new['scope']='Original46 obligation identity/history preserved. Published engineering baseline d61 is reconciled to root-recorded bounded admission of T02/T03/T04 and PS7 full20. PS5.1 attempt2 producer success awaits independent receiving. No whole-contract acceptance, numerator, certificate, merge approval, delivery or closure is supplied.'
new['previousPublishedProjectionAtD61']=dict(commit=BASELINE,tree=BASELINE_TREE,
    markdown=fact(baseline[MD],MD),matrix=fact(baseline[MATRIX],MATRIX),
    interpretation='Immutable published predecessor retains its original current-state fields. Original historical objects and46 identities remain unchanged in this update.')
new['documentationEvidenceBaseline']=dict(commit=BASELINE,tree=BASELINE_TREE,
    productAndInstrumentSource=SOURCE,sourceTree=SOURCE_TREE,
    futurePublicationCommit=None,note='The product/instrument binding is immutablea89; documentation/evidence baseline is immutabled61. No future self-commit hash is invented.')
new['rootBoundedAdmission']=dict(receipt=admission_fact,
    authority=admission['authority'],continuityReceipt=admission['continuityReceipt'],
    technicalGateDispositions=copy.deepcopy(admission['technicalGateDispositions']),
    retainedLimits=copy.deepcopy(admission['retainedLimits']),
    completeFinalPacketAdmitted=False)
new['dependency']['documentationEvidenceBaseline']=copy.deepcopy(new['documentationEvidenceBaseline'])
new['dependency']['qualificationReservation']='a89 product/instrument bytes are unchanged at published documentation/evidence baselined61. Root admits PS7 all20 and existing T02/T03/T04 within the recorded limits. PS5.1 attempt2 job succeeds with a producer all20 report, pending independent original receiving and root decision. No two-host full20 or native-satisfaction decision is inferred.'

for name in ('scopedCurrentPowerShell','scopedCurrentLinux','scopedCurrentMacOS'):
    item=new[name]
    item['status']='ROOT_ADMITTED_WITH_RECORDED_SCOPE_LIMITS'
    item['sourceReuseState']='ROOT_ADMITTED_UNCHANGED_EXECUTED_SCOPE'
    item['rootAdmissionReceipt']=admission_fact
    item['sourceReuseLimit']='Original acquisition/review source and actual environment remain recorded. Root has admitted bounded executed-scope reuse; final exact-candidate reconciliation remains open.'

joins=new['currentEvidenceReceiptJoins']
for key,item in joins.items():
    if key=='J_WFULL20':continue
    item['state']='ROOT_ADMITTED_LOCAL_DOCUMENTATION_ONLY' if key=='J_DOCS' else 'ROOT_ADMITTED_WITH_RECORDED_SCOPE_LIMITS'
    item['rootAdmission']=True
    item['rootAdmissionReceipt']=admission_fact
    item['sourceReuseAtA89']['state']='ROOT_ADMITTED_UNCHANGED_EXECUTED_SCOPE'
    item['sourceReuseAtA89']['limits']=item['sourceReuseAtA89']['limits'].replace('Root admission and final independent reconciliation remain pending.','Root bounded admission is recorded; final independent reconciliation remains pending.')
joins['J_WFALLBACK15']['limits']='Only15 reviewed behavioral rows per host transfer, including bounded empty/unsuitable/metadata fallback. The3 old whole-file parser/ASCII rows stay historical. Retained streams are decoded UTF-8 captures, not original OS stream buffers. No Job/descendant custody or complete-profile containment is inferred. Root admits this exact bounded reuse; no new original18 execution or whole-file transfer is claimed.'

full20=joins['J_WFULL20']
full20['state']='PS7_FULL20_ROOT_ADMITTED_PS51_ATTEMPT2_PRODUCER_SUCCESS_RECEIVING_PENDING'
full20['rootAdmissionReceipt']=admission_fact
first=full20['attempts'][0]['hosts']
for host in ('ps51','ps766'):
    first[host]['rootAdmission']=True
    first[host]['rootAdmissionReceipt']=admission_fact
first['ps766']['independentReceiving']='FINAL_PASS_ALL20_ROOT_ADMITTED_WITH_LIMITS'
first['ps51']['independentReceiving']='FINAL_ADVERSE_BOOTSTRAP_ROOT_ADMITTED_ZERO_INSTALLER_CASES'
summary_path=WORK/'recovery/full20-a89/ps51-attempt2/summary.json'
summary_bytes=summary_path.read_bytes();summary=json.loads(summary_bytes)
archive=summary_path.parent/summary['zip_file'];archive_bytes=archive.read_bytes()
assert len(archive_bytes)==3067872 and sha(archive_bytes)=='4247cb1eee4043d59c950936b84ac1b9ce09dbf4041edaad323d2857357c37b1'
save('inputs/ps51-attempt2-summary.json',summary_bytes)
second=full20['attempts'][1]
second['state']='PS51_COMPLETED_SUCCESS_RECEIVING_PENDING'
second['statusSource']='Root live checkpoint plus original artifact metadata; independent receiver is active and its incomplete outputs are not used.'
second['ps51'].update(state='COMPLETED_SUCCESS',finishedAt='2026-11-12T13:13:18Z',
    producerReportedCases=20,producerReportedPreviewCases=18,producerReportedNormalCases=2,
    independentReceiving='PENDING',qualifiedCases=None,
    artifact='13947627028',archive=dict(name=archive.name,bytes=len(archive_bytes),sha256=sha(archive_bytes)),
    artifactUrl=summary['artifact']['url'],artifactDownloadUrl=summary['artifact']['archive_download_url'],
    observedNormalCacheBytes=732,
    observationLimit='732-byte actual normal caches are parent-attributed original report observations, not the738-byte diagnostic caches. Original independent receiving and root admission remain pending.')
second['ps766']['rootAdmission']=True
second['ps766']['rootAdmissionReceipt']=admission_fact
second['limits']='Actual PS5.1-only same-source rerun completed successfully; independent original receiving is pending. PS7 listing reuses original execution. No deadline/source change, transient-cause claim or rewrite of attempt1 follows.'
full20['limits']='Root admits PS7 actual20 within its recorded source-window/lifecycle limits. PS5.1 attempt2 producer reports20 but is not yet independently received or root-admitted. Preserve attempt1 bootstrap failure and all original direct/held inequalities; no diagnostic or reused job substitutes for two-host qualification.'

for gate in ('T02','T03','T04'):
    f=new['technicalFrontier'][gate]
    f['state']=admission['technicalGateDispositions'][gate].split(':',1)[0]
    f['rootDecision']=admission['technicalGateDispositions'][gate]
    f['rootAdmissionReceipt']=admission_fact
new['technicalFrontier']['T02']['minimum']='Root admission is recorded for native routes8, original18 behavior15 and named Linux/Mac entry25 store/ask/fallback associations. Preserve parser3 as historical and decoded-UTF8/no-Job/no-full-profile limits. Final exact-candidate reconciliation remains T05; no replay is required.'
new['technicalFrontier']['T03']['minimum']='Root admission is recorded for docs71 and its original API/archive/source/PNG joins, with unchanged relevant inputs. This satisfies the scoped local-documentation join; actual public delivery and final review remain separate.'
new['technicalFrontier']['T04']['minimum']='Root admission is recorded for exact relevant POSIX/Windows scoped receipts and named entry25 associations, with the Mac broad-catalog exception and every adverse/measurement limit. The existing Fable handoff remains X01; final exact-candidate reconciliation remains T05.'
new['technicalFrontier']['T01']['minimum']='PS7 a89 actual20 is independently received and root-admitted. Independently receive the completed PS5.1 attempt2 original and obtain the root technical decision. Preserve its actual732-byte normal caches separately from738-byte diagnostic caches, the attempt1 zero-installer-case failure, all original case predicates and full lifecycle differences. Producer success alone is insufficient.'
new['technicalFrontier']['T01']['rootDecision']=admission['technicalGateDispositions']['T01']
new['technicalFrontier']['T01']['rootAdmissionReceipt']=admission_fact
new['technicalFrontier']['T05']['minimum']='After the outstanding PS5.1 receiving/root decision, bind the final immutable source/document/evidence tree and independently reconcile every original46 row, admitted scoped receipts/reuse, source/security first-phase finding, failed attempts and limits. No final review result is supplied by this projection.'
new['technicalFrontier']['T05']['scopeLimit']='Final independent exact-candidate evidence review remains open. Suite counts, source-only checks and root bounded receipt admission are not whole-contract acceptance or closure.'
new['technicalFrontier']['T05']['rootDecision']=admission['technicalGateDispositions']['T05']
new['sourceSecurityReview']=dict(state='BOUNDED_FIRST_PHASE_PASS_FINAL_TREE_JOIN_PENDING',sourceHead=SOURCE,sourceTree=SOURCE_TREE,
    receipt=receipt(PUB+'source-security-a89/report.md'),checks=receipt(PUB+'source-security-a89/checks.json'),
    scope='Independent source/security first-phase PASS with86 inert checks; final immutable documentation/evidence and native joins remain open.',
    rootAdmissionReceipt=admission_fact,finalImmutableTreeJoin=None)

new['deltaFrontier']['D02']='Root admits PS7 current full20 including native readable/unreadable reasons. PS5.1 attempt1 is admitted adverse evidence only with0 installer cases; completed same-source attempt2 producer reports20 and awaits independent receiving/root decision.'
new['deltaFrontier']['D03']='Root admits eight actual controlled store/ask routes per Windows host, original18 behavior15 bounded fallback reuse and named Linux/Mac entry25 source choices. Routes8 has zero fallback rows. Original18 decoded UTF-8 captures are not original OS buffers and imply no Job or full-profile containment.'
new['deltaFrontier']['D06']='Root admits local docs71 with original archive/API/source and PNG joins. Public delivery remains OPEN; clipped Windows PNG/full DOM and blank-widget limits remain.'
new['deltaFrontier']['D07']='Accepted R0013/R0015 protection/source ancestry remains exact. Root admits scoped Windows core75/normal18/routes and PS7 current full20; PS5.1 attempt2 independent receiving remains open.'
new['deltaFrontier']['D11']='Root admits both Windows core75/normal18 scopes and PS7 current full20. Retain152 unequal full lifecycles per core host and all20 unequal PS7 direct lifecycles versus18 equal preview source windows. PS5.1 attempt1 remains0 installer cases; attempt2 producer success awaits receiving. Hard containment remains unacquired and global telemetry null.'

replacements={
    'Root admission/T05':'T05',
    'Root admission of this source reuse is pending':'Root has admitted this bounded source reuse',
    'root admission and final review remain separate.':'root bounded admission is recorded; final review remains open.',
    'root admission and final review remain':'final review remains',
    'available for root admission':'root-admitted within recorded scope',
    'for root admission':'within root-admitted scope',
    'Root admission remains.':'Root bounded admission is recorded.',
    'root admission remains.':'root bounded admission is recorded.',
    'root admission and final independent reconciliation remain pending.':'root bounded admission is recorded; final independent reconciliation remains pending.',
    'attempt2 is pending':'attempt2 producer reports20; independent receiving is pending',
}
def reconcile_text(text):
    for a,b in replacements.items():text=text.replace(a,b)
    return text
gap_rows=[]
for row,mapped in zip(new['rows'],mapping['rows']):
    assert row['id']==mapped['id']
    original=mapped['remainingTechnicalGates']
    admitted=[g for g in original if g in ('T02','T03','T04')]
    remaining=[g for g in original if g not in admitted]
    row['currentAdmittedTechnicalGateIds']=admitted
    row['currentRemainingGateIds']=remaining+['T05']+mapped['externalGates']
    row['currentRootAdmissionReceipt']=admission_fact
    row['currentEvidence']=[reconcile_text(s) for s in row['currentEvidence']]
    row['currentEvidence'][0]='Immutable a89 product/instrument source and published d61 documentation/evidence baseline are bound. Root admits existing T02/T03/T04 and PS7 full20 through the exact root-receipt-admission record; final review and PS5.1 receiving remain open.'
    if row['id']=='N03':
        row['currentEvidence'].append('Original18 behavior15 retains decoded UTF-8 captures rather than original OS stream buffers; no Job/descendant or full-profile containment is inferred. This exact bounded fallback reuse is root-admitted.')
    new_remaining=[]
    if 'T01' in remaining:
        new_remaining.append('T01: independently receive completed PS5.1 attempt2 original and obtain root technical disposition. PS7 all20 is already root-admitted; preserve attempt1 failure and actual732-byte versus diagnostic738-byte cache distinction.')
    new_remaining.append('T05: final immutable source/document/evidence-tree join and independent exact46 review remain open; no obligation acceptance is supplied.')
    for g in mapped['externalGates']:new_remaining.append(g+': '+new['externalGates'][g]['minimum'])
    row['remaining']=new_remaining
    row['currentStatus']='SCOPED_ROOT_ADMISSION_RECORDED; PS51_FULL20_RECEIVING_OPEN; NO_ACCEPTANCE' if 'T01' in remaining else 'SCOPED_ROOT_ADMISSION_RECORDED; FINAL_REVIEW_AND_APPLICABLE_EXTERNAL_GATES_OPEN; NO_ACCEPTANCE'
    row['currentGapDetail']=('PS7 and applicable T02/T03/T04 scopes are root-admitted. Complete independent PS5.1 attempt2 receiving and root decision, retaining exact original case/effect boundaries; then T05 and applicable existing external gates.' if 'T01' in remaining else
        'Applicable scoped evidence/reuse is root-admitted. Complete the final immutable-tree/exact46 review and applicable existing external gates; no repeated native or rendering campaign follows.')
    gap_rows.append(dict(id=row['id'],category=row['category'],obligation=row['obligation'],admittedTechnicalGates=admitted,
        remainingTechnicalGates=remaining,finalIndependentGate='T05',externalGates=mapped['externalGates'],proposedAcceptance=None))
jsave('per-obligation-gaps.json',dict(head=SOURCE,documentationEvidenceBaseline=BASELINE,rows=gap_rows))

recon=new['currentReconciliation']
recon['status']='ENGINEERING_PROJECTION_ROOT_BOUNDED_ADMISSION_RECORDED'
recon['documentationEvidenceBaseline']=copy.deepcopy(new['documentationEvidenceBaseline'])
recon['rootAdmissionReceipt']=admission_fact
recon['rootAdmissionScope']='Root has admitted the recorded T02/T03/T04 receipts and PS7 full20; the existing rootAdmission Boolean denotes complete final technical packet admission and remains false pending the PS5.1 receiving/root decision.'
recon['rootAdmission']=False
recon['finalIndependentExact46Review']=False
recon['publication']='The predecessor R0016 documentation/matrix and the named attempt1/source-security receipt files were published at immutabled61. This update uses that exact documentation/evidence baseline and immutablea89 product/instrument bytes. The root admission decision is separately digest-bound; final publication head/tree will be joined after it exists, without a future self-hash.'
recon['authority']='Root-created bounded technical receipt admission is recorded through its exact decision file. This projection supplies no child admission authority, obligation acceptance, acceptance numerator, completion certificate, merge approval, public-delivery verdict, lifecycle transition or closure.'
recon['candidateQualificationUpdate'].update(state='PS7_ROOT_ADMITTED_PS51_ATTEMPT2_PRODUCER_SUCCESS_RECEIVING_PENDING',
    note='PS7 all20 and PS5.1 attempt1 adverse bootstrap are independently received and root-admitted. PS5.1 attempt2 producer reports20 after a successful job; its original independent receiving/root decision remain pending. PS7 attempt2 listing reuses original execution.')
recon['receivingReports'].append(receipt(PUB+'source-security-a89/report.md'))
recon['satisfactionFlags']='Whole-contract and public-delivery flags remain false. Native satisfaction and complete-packet root technical disposition remain unclaimed until an explicit root decision after PS5.1 receiving; T05 remains open.'
new['externalGates']['X02']['minimum']=new['externalGates']['X02']['minimum'].replace('This private projection neither requests nor supplies that approval.','This engineering projection neither requests nor supplies that approval.')
new['externalGates']['X04']['minimum']=new['externalGates']['X04']['minimum'].replace('This lane sends no messages or publications.','The bounded technical admission record supplies no certificate or closure authority.')
for row in new['rows']:
    row['remaining']=[s.replace('This private projection neither requests nor supplies that approval.','This engineering projection neither requests nor supplies that approval.').replace('This lane sends no messages or publications.','The bounded technical admission record supplies no certificate or closure authority.') for s in row['remaining']]
jsave('candidate/'+MATRIX,new)

md=baseline[MD].decode()
def paragraph(prefix,replacement):
    global md
    parts=md.split('\n\n');indices=[i for i,p in enumerate(parts) if p.startswith(prefix)];assert len(indices)==1,(prefix,indices)
    parts[indices[0]]=replacement.replace('@',chr(96));md='\n\n'.join(parts)
paragraph('This engineering candidate implements',
    'This engineering candidate implements [issue22](https://github.com/theislampill/salah_widget/issues/22), including its original contract and retained remaining-work specification. It is not a completion certificate or merge approval request. The [complete acceptance matrix](evidence/R0016/current-acceptance-matrix.json) retains all14 original rows,6 residual acceptances,15 branch rows and11 effect rows in their original order and wording. These46 rows are overlapping views of the contract. The [historical matrix](evidence/R0016/historical-matrix.json) remains unchanged. The [root admission decision](evidence/R0016/'+PUB+'root-receipt-admission.json) records bounded technical admission of T02/T03/T04 and PS7 full20; it does not accept the whole contract, approve merge or issue a certificate.')
source_para=next(p for p in md.split('\n\n') if p.startswith('This source projection is bound'))
source_para=source_para.replace('This source projection supplies no two-host full20 pass or obligation acceptance.',
    'The published documentation/evidence baseline is @'+BASELINE+'@, tree @'+BASELINE_TREE+'@; product and full20 instrument bytes remain those of a89. Root has admitted the recorded scoped evidence and PS7 full20. PS5.1 attempt2 producer success awaits independent receiving/root decision; no two-host or whole-contract acceptance is inferred.')
paragraph('This source projection is bound',source_para)
oldline=next(s for s in md.splitlines() if s.startswith('| Windows original18 / behavior15 reuse |'))
md=md.replace(oldline,'| Windows original18 / behavior15 reuse | Retained run43028305607, artifact13861137478:15 behavioral rows per host retain exact unchanged function/fixture associations and are root-admitted. | Parser3 stays historical; captures are decoded UTF-8 text, not original OS stream buffers. No Job/descendant or full-profile containment is inferred. This18 is distinct from normal18. |')
oldline=next(s for s in md.splitlines() if s.startswith('| Windows full20 |'))
md=md.replace(oldline,'| Windows full20 | Run43220592915 at a89: PS7 all20 independently received and root-admitted; PS5.1 attempt1 adverse receipt retains0 installer cases. Actual PS5.1 attempt2 job succeeds and producer reports20; independent receiving is pending. | Two-host gate remains OPEN. Required20 =18 preview including2 early-option refusals plus2 normal. All18 preview cases have separate held source windows; normal2 uses strict postconditions. |')
paragraph("The root's live checkpoint records",
    'Actual PS5.1 attempt2 job131197436545 at unchanged a89 ran2026-11-12T12:56:36Z to13:13:18Z and completed successfully. Original artifact13947627028 is3,067,872 bytes, SHA256 @4247cb1eee4043d59c950936b84ac1b9ce09dbf4041edaad323d2857357c37b1@. The producer reports all20 cases, with actual732-byte normal caches; those are distinct from the738-byte diagnostic caches. Independent original receiving and root technical disposition remain pending, so job success supplies no inferred acceptance. Attempt2 PS7 listing131197440277 reuses the original12:43:59 to12:46:23 execution and receipt. No transient cause, source/deadline repair or rewrite of the first PS5.1 failure follows from the later success.')
security='''## Source/security and root admission

The [independent source/security first phase](evidence/R0016/PUBsource-security-a89/report.md) records a bounded PASS at exact a89 with86 inert checks. Both complete installers and reviewed full20 acquisition changes were examined. The final immutable documentation/evidence-tree and native-evidence joins remain open; this source finding supplies no native result, merge approval, public-delivery qualification or closure.

The [root admission decision](evidence/R0016/PUBroot-receipt-admission.json) admits T02 native caller/fallback associations, T03 local docs71, T04 scoped POSIX/Windows native receipts, the PS7 all20 result, and preserved adverse/calibration evidence within their exact recorded limits. The original18 behavior15 reuse remains limited to decoded UTF-8 captures; no original OS-buffer, Job/descendant or complete-profile containment claim follows. This is the root's bounded evidence decision, not authority created by this documentation update. The complete final technical packet, PS5.1 original receiving and T05 final review remain open.

'''.replace('PUB',PUB)
md=md.replace('## Remaining acceptance gates\n',security+'## Remaining acceptance gates\n')
paragraph('The [exact46 reconciliation]',
    'The [exact46 reconciliation](evidence/R0016/'+PUB+'mapping/current-mapping-reconciled.json) preserves the original obligations and existing gates. T02/T03/T04 are now root-admitted within the [recorded scopes](evidence/R0016/'+PUB+'root-receipt-admission.json), including original18 behavior15, named Linux/Mac entry25, local docs71 and scoped native receipts. T01 remains OPEN for independent receiving of the completed PS5.1 attempt2 original and the root technical decision; PS7 all20 is already admitted. T05 remains the independent final immutable-tree/exact-candidate46-row reconciliation. No scoped count is an acceptance numerator.')
paragraph('Accepted dependency inputs remain integrated',
    'Accepted dependency inputs remain integrated in the recorded ancestry. The existing Fable handoff, final-head/then-current-main reconciliation, separate owner merge approval, authorized integration, actual merged/served byte and rendered-guidance readback, evidence certificate and deliberate issue closure remain open in their original scopes. The engineering projection and bounded root admission supply no merge approval or certificate. Final review must join the actual immutable documentation/evidence tree and completed native receipts before any acceptance decision. All46 obligations remain; no issue is closed by this projection or its PR wording.')
save('candidate/'+MD,(md.rstrip()+'\n').encode())

patch=[]
for path in (MD,MATRIX):
    patch.append('diff --git a/'+path+' b/'+path+'\n')
    patch.extend(difflib.unified_diff(baseline[path].decode().splitlines(keepends=True),(ROOT/'candidate'/path).read_text().splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path))
save('candidate.patch',''.join(patch).encode())
jsave('candidate-bindings.json',dict(baseline=BASELINE,baselineTree=BASELINE_TREE,source=SOURCE,sourceTree=SOURCE_TREE,
    files=[fact((ROOT/'candidate'/p).read_bytes(),p) for p in (MD,MATRIX)],patch=fact((ROOT/'candidate.patch').read_bytes(),'candidate.patch')))
jsave('input-bindings.json',dict(baseline=BASELINE,baselineTree=BASELINE_TREE,source=SOURCE,sourceTree=SOURCE_TREE,
    rootAdmission=admission_fact,rootAdmissionSource=ADMISSION,
    priorOutputManifest=fact((PRIOR/'MANIFEST.json').read_bytes(),'acceptance_projection_a89/MANIFEST.json'),
    priorOutputFiles=json.loads((PRIOR/'MANIFEST.json').read_text())['files'],
    ps51Attempt2Summary=fact(summary_bytes,'inputs/ps51-attempt2-summary.json'),
    ps51Attempt2Archive=fact(archive_bytes,str(archive.relative_to(WORK))),
    baselineFiles=[fact(b,p) for p,b in baseline.items()],
    receivingBoundary='No incomplete PS5.1 receiver output was read. Candidate records producer/metadata success only.'))
print(json.dumps(dict(state='KNOWN_BASIS_PREPARED_PS51_RECEIVING_PENDING',baseline=BASELINE,source=SOURCE,obligations=len(new['rows']),rootAdmittedGates=['T02','T03','T04'],full20Passed=full20['full20Passed']),indent=2))
