#!/usr/bin/env python3
"""Inert exact-source comparisons. Does not import or execute installer/harness code."""
import ast
import hashlib
import json
import pathlib
import re
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent
REPO = pathlib.Path('/workspace/scratch/0dd4b9b6a244/salah_widget')
CANDIDATE = 'a89bbb3ddac639cc787ba08d030e8b2539057387'
BASE = '3b0e614114ef066de40db117d0e85c0031cf3e30'
PRE_ACQUISITION = '8a360f5'
CHECKS = []


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def source(ref, path):
    return subprocess.check_output(['git', 'show', ref + ':' + path], cwd=REPO)


def record(name, passed, **evidence):
    CHECKS.append(dict(check=name, passed=bool(passed), **evidence))


def functions(raw):
    tree = ast.parse(raw)
    lines = raw.decode('utf-8').splitlines(keepends=True)
    return {node.name: ''.join(lines[node.lineno-1:node.end_lineno]).encode()
            for node in tree.body if isinstance(node, ast.FunctionDef)}


manifest = json.loads((ROOT / 'source-manifest.json').read_text())
tree = subprocess.check_output(['git', 'rev-parse', CANDIDATE + '^{tree}'], cwd=REPO, text=True).strip()
record('candidate-tree', tree == 'efa716f4c8f1fe61c1a5a85b48bd97e813305d16', commit=CANDIDATE, tree=tree)
for entry in manifest['files']:
    raw = (ROOT / 'source' / entry['path']).read_bytes()
    record('exact-copy:' + entry['path'], raw == source(CANDIDATE, entry['path']) and
           sha(raw) == entry['sha256'] and len(raw) == entry['bytes'], sha256=sha(raw), bytes=len(raw))
    if entry['path'].endswith('.py'):
        ast.parse(raw)
        record('python-parse:' + entry['path'], True)

for path in ('install.sh', 'install.ps1'):
    facts = {}
    for ref in ('9c05df0', '12904a8', CANDIDATE):
        raw = source(ref, path)
        facts[ref] = dict(sha256=sha(raw), bytes=len(raw))
    record('unchanged-installers-across-acquisition:' + path, len({value['sha256'] for value in facts.values()}) == 1,
           revisions=facts)

ps = source(CANDIDATE, 'install.ps1').decode()
base_ps = source(BASE, 'install.ps1').decode()
for name, begin, end in (
    ('R13-linear-lexer', 'function Test-StrictJson(', 'function Get-FirefoxExtensionStatus('),
    ('R15-native-staging-boundary', 'function Initialize-CompilerNative {', 'function Write-Section('),
):
    current = ps[ps.index(begin):ps.index(end)].encode()
    prior = base_ps[base_ps.index(begin):base_ps.index(end)].encode()
    record('accepted-main-byte-preservation:' + name, current == prior,
           candidateSha256=sha(current), acceptedMainSha256=sha(prior), bytes=len(current))

bash = source(CANDIDATE, 'install.sh')
syntax = subprocess.run(['/usr/bin/env', '-i', 'PATH=/usr/bin:/bin', 'bash', '--noprofile', '--norc', '-n',
                         str(ROOT / 'source/install.sh')], capture_output=True)
record('bash-parse-only', syntax.returncode == 0, command=syntax.args, exit=syntax.returncode,
       stdout=syntax.stdout.decode(), stderr=syntax.stderr.decode(), installerExecuted=False)
record('bash-no-here-document-or-here-string-token', b'<<' not in bash, tokenCount=bash.count(b'<<'))

path = 'tests/install-entry-native-composition.py'
original = functions(source(PRE_ACQUISITION, path))
current = functions(source(CANDIDATE, path))
for name, raw in original.items():
    if name == '_case_impl':
        continue
    record('original-function-byte-preservation:' + name, current.get(name) == raw,
           originalSha256=sha(raw), candidateSha256=sha(current.get(name, b'')))

old_case = ast.parse(original['_case_impl'])
new_case = ast.parse(current['_case_impl'])
def requirements(tree):
    return [ast.dump(node, include_attributes=False) for node in ast.walk(tree)
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'require']
old_checks = requirements(old_case)
new_checks = requirements(new_case)
record('all-original-case-require-predicates-retained', all(value in new_checks for value in old_checks),
       originalCount=len(old_checks), currentCount=len(new_checks), removed=[value for value in old_checks if value not in new_checks])

for path in ('tests/install-entry-composition-support.py', 'tests/install-entry-coverage-support.py',
             'tests/install-entry-product-support.py', 'tests/install-entry-driver-diagnostic.py',
             'tests/install-entry-held.ps1', 'tests/install-entry-input-probe.ps1',
             'tests/install-entry-diagnostic-shadow.psm1', 'tests/install-preview.ps1',
             'tests/install-preview-window.ps1', 'tools/qualification/installer_preview_host_probe.py',
             '.github/workflows/installer-preview-windows-full-entry.yml'):
    current_bytes = source(CANDIDATE, path)
    prior_bytes = source(PRE_ACQUISITION, path)
    record('pre-acquisition-full-file-preservation:' + path, current_bytes == prior_bytes,
           sha256=sha(current_bytes), bytes=len(current_bytes))

carrier = source(CANDIDATE, 'tools/qualification/installer_preview_windows_full_entry.py')
carrier_tree = ast.parse(carrier)
assigns = {node.targets[0].id: ast.literal_eval(node.value) for node in carrier_tree.body
           if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
           and node.targets[0].id in ('INPUTS', 'CASES', 'FAILURE_CASES', 'BUDGET')}
for path, expected in assigns['INPUTS'].items():
    raw = source(CANDIDATE, path)
    record('full20-exact-input-pin:' + path, (len(raw), sha(raw)) == expected, bytes=len(raw), sha256=sha(raw))
record('full20-denominator', len(assigns['CASES']) == 20 and len(set(assigns['CASES'])) == 20,
       cases=assigns['CASES'], failureCases=assigns['FAILURE_CASES'])
old_carrier_tree = ast.parse(source(PRE_ACQUISITION, 'tools/qualification/installer_preview_windows_full_entry.py'))
old_assigns = {node.targets[0].id: ast.literal_eval(node.value) for node in old_carrier_tree.body
              if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
              and node.targets[0].id in ('CASES', 'FAILURE_CASES', 'BUDGET')}
for name in ('CASES', 'FAILURE_CASES', 'BUDGET'):
    record('full20-existing-value-preserved:' + name, assigns[name] == old_assigns[name], value=assigns[name])

issue = json.loads((ROOT / 'issue22.json').read_text())['structuredContent']['issue']
result = dict(schema='r0016-independent-technical-source-checks.v1', candidate=CANDIDATE, tree=tree,
              acceptedMain=BASE, acquisitionBaseline=PRE_ACQUISITION,
              scope='Inert byte, AST and Bash parse checks; no installer/harness import or execution; no native result inferred.',
              issue=dict(url=issue['url'], title=issue['title'], updatedAt=issue['updated_at'],
                         receiptSha256=sha((ROOT / 'issue22.json').read_bytes())),
              passed=sum(row['passed'] for row in CHECKS), total=len(CHECKS), checks=CHECKS)
(ROOT / 'checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ('schema', 'candidate', 'passed', 'total')}))
raise SystemExit(0 if all(row['passed'] for row in CHECKS) else 1)
