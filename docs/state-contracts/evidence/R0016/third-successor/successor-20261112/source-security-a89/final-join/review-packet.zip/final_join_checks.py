#!/usr/bin/env python3
"""Inert final-tree, receipt-reference and documentation consistency checks.

This reads fixed Git objects and receiver packets. It never imports/runs project
code, launches installers, replays native acquisition, or writes the repository.
"""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path('/workspace/scratch/0dd4b9b6a244/reviews/final_source_security')
OUT = ROOT / 'final-join'
REPO = Path('/workspace/scratch/0dd4b9b6a244/salah_widget')
TREE = '0505633b8966aa7b7a892adb512b99bb8d5b650d'
PARENT = 'd61f1b84fcea1c129c3c2b549d2cdda6b3536d33'
SOURCE = 'a89bbb3ddac639cc787ba08d030e8b2539057387'
SOURCE_TREE = 'efa716f4c8f1fe61c1a5a85b48bd97e813305d16'
EVIDENCE = 'docs/state-contracts/evidence/R0016/'
SUCCESSOR = EVIDENCE + 'third-successor/successor-20261112/'
MATRIX_PATH = EVIDENCE + 'current-acceptance-matrix.json'
checks = []


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def data(path, revision=TREE):
    return git('show', revision + ':' + path)


def sha(value):
    return hashlib.sha256(value).hexdigest()


def read_json(path):
    return json.loads(path.read_bytes())


def check(name, ok, **detail):
    checks.append({'check': name, 'passed': bool(ok), **detail})


def binding(name, ref, prefix='', revision=TREE):
    path = prefix + ref['path']
    value = data(path, revision)
    check(name, len(value) == ref['bytes'] and sha(value) == ref['sha256'],
          path=path, bytes=len(value), sha256=sha(value), revision=revision)


matrix = json.loads(data(MATRIX_PATH))
before = json.loads(data(MATRIX_PATH, PARENT))
doc = data('docs/state-contracts/R0016.md').decode('utf-8')
admission = json.loads(data(SUCCESSOR + 'root-receipt-admission.json'))
currentness = read_json(OUT / 'source-currentness.json')
tree_manifest = read_json(OUT / 'review-tree-manifest.json')
prior = read_json(ROOT / 'source-manifest.json')
receipt_checks = read_json(OUT / 'native-receipt-joins.json')
scope_checks = read_json(OUT / 'native-scope-joins.json')

check('immutable-target-is-tree-object', git('cat-file', '-t', TREE).strip() == b'tree')
check('comparison-parent-tree', git('rev-parse', PARENT + '^{tree}').strip().decode() ==
      'b154fcce037278223d8c2559f36fbf51339cf2a0')
check('source-commit-tree', git('rev-parse', SOURCE + '^{tree}').strip().decode() == SOURCE_TREE)
changed = git('diff', '--name-only', PARENT, TREE).decode().splitlines()
check('exact-ten-document-evidence-delta', len(changed) == 10 and
      changed == [row['path'] for row in tree_manifest['files']] and
      all(path.startswith('docs/state-contracts/') for path in changed), paths=changed)
check('recorded-new-tree-byte-currentness', currentness['reviewTree'] == TREE and
      currentness['sourceHead'] == SOURCE and currentness['parent'] == PARENT and
      currentness['allPrior27InputsUnchanged'] is True and
      len(currentness['sourceRows']) == len(prior['files']) == 27 and
      currentness['nonDocsChangedSinceA89'] == [] and
      currentness['priorReviewManifestSha256'] == sha((ROOT/'source-manifest.json').read_bytes()),
      evidence='source-currentness.json', sourceInputCount=27)
for row in tree_manifest['files']:
    value = data(row['path'])
    check('tree-inventory:' + row['path'], len(value) == row['bytes'] and
          sha(value) == row['sha256'] and value == (OUT/'tree'/row['path']).read_bytes() and
          git('rev-parse', TREE + ':' + row['path']).strip().decode() == row['blob'], **row)
check('contract-document-expected-sha', sha(doc.encode()) ==
      '604f735dd8c2ae5ac54846c42873c452740c128f818b0559411aee85e84c25d6')
check('matrix-expected-sha', sha(data(MATRIX_PATH)) ==
      '969e73921d52fb8b4befbe5fab59ebddefbbf2c691a3f98ca5579cb9c4a95ca5')

for name, expected in {
    'report.md': 'b387b8d7d34864702c6c7b1f5a91e47abed6d5d8e6b84cefafb251c61bb85d4f',
    'source-manifest.json': '19fe45b8d19a99f33d0259633062c06c2fcf454c5968251cf5497c0b084ae85f',
    'hash-manifest.json': '5769aeed856699b1de98b7f8be6ec3289d7758424362beaa274c0be49b8f81f9',
}.items():
    check('initial-review-preserved:' + name, sha((ROOT/name).read_bytes()) == expected)
check('prior-packet-hash-joins-recorded', receipt_checks['passed'] == receipt_checks['total'] == 57
      and all(row['passed'] is True for row in receipt_checks['checks']))
check('prior-native-scope-joins-recorded', scope_checks['passed'] == scope_checks['total'] == 63
      and all(row['passed'] is True for row in scope_checks['checks']))
check('root-decision-copy-unchanged', data(SUCCESSOR+'root-receipt-admission.json') ==
      (OUT/'root-receipt-admission.json').read_bytes())
for row in admission['receipts']:
    binding('root-nine-receipt-reference:' + row['id'], row)
for i, row in enumerate(matrix['currentReconciliation']['receivingReports']):
    binding('matrix-receipt-reference:' + str(i), row, EVIDENCE)
for name, row in matrix['currentReconciliation']['sourceBindings'].items():
    value = data(row['path'])
    check('matrix-source-binding:' + name, sha(value) == row['sha256'] and
          len(value) == row['bytes'] and row['commit'] == SOURCE and
          git('rev-parse', TREE+':'+row['path']).strip().decode() == row['gitBlob'])
for label, ref in [
    ('source-first-phase-report', matrix['sourceSecurityReview']['receipt']),
    ('source-first-phase-checks', matrix['sourceSecurityReview']['checks']),
    ('root-current-decision', matrix['rootBoundedAdmission']['receipt']),
    ('root-prior-decision', matrix['priorRootBoundedAdmission']['receipt']),
]:
    binding(label, ref, EVIDENCE)

for host in ['full20-ps7-attempt1', 'full20-ps51-attempt1', 'full20-ps51-attempt2']:
    for name in ['report.md', 'checks.json', 'manifest.json', 'packet.json']:
        check('previously-received-copy:' + host + '/' + name,
              data(SUCCESSOR+host+'/'+name) == (OUT/'receipts'/host/name).read_bytes())
packet_path = SUCCESSOR+'full20-ps51-attempt2/'
packet = json.loads(data(packet_path+'packet.json'))
zip_bytes = data(packet_path+'receiving-packet.zip')
check('ps51-attempt2-packet-digest', len(zip_bytes) == packet['packetBytes'] == 132327 and
      sha(zip_bytes) == packet['packetSha256'] ==
      'f83d32210daf280ee63882b8bcc93fa4bd0abe4cbb8b0535745b16bfee1f77ab')
with zipfile.ZipFile(io.BytesIO(zip_bytes)) as z:
    for name in ['report.md', 'checks.json', 'manifest.json', 'api-association-received.json']:
        check('ps51-new-tree-sidecar-equals-received-member:' + name,
              data(packet_path+name) == z.read(name))

protected = ['id', 'category', 'obligation', 'historicalStatus', 'historicalPointer',
             'priorEvidenceProjection', 'historicalCurrentEvidenceAt9c51']
check('protected-original46-identity-order-wording-history', len(matrix['rows']) == 46 and
      [{k: row.get(k) for k in protected} for row in matrix['rows']] ==
      [{k: row.get(k) for k in protected} for row in before['rows']], fields=protected)
check('original-denominator-unchanged', matrix['denominator'] == before['denominator'] ==
      {'requirements':14, 'residual_acceptance':6, 'branch_matrix':15, 'effects':11, 'total':46})
history = data(EVIDENCE+'historical-matrix.json')
check('historical-matrix-byte-preserved', history == data(EVIDENCE+'historical-matrix.json', PARENT)
      and sha(history) == matrix['historySha256'] == before['historySha256'] ==
      '828638072d532c8e2e2167248c89d3ad19e707addac7db65e4742e4112e61dac')
check('prior-historical-row-projection-preserved',
      matrix['historicalPublishedRowProjectionBeforeA89Reconciliation'] ==
      before['historicalPublishedRowProjectionBeforeA89Reconciliation'])
for label in ['markdown', 'matrix']:
    binding('d61-predecessor-reference:' + label,
            matrix['previousPublishedProjectionAtD61'][label], revision=PARENT)
check('root-disposition-projection-exact',
      matrix['rootBoundedAdmission']['technicalGateDispositions'] == admission['technicalGateDispositions']
      and matrix['rootBoundedAdmission']['retainedLimits'] == admission['retainedLimits'])
check('native-admission-distinct-from-complete-packet',
      matrix['allNativeTechnicalGatesAdmitted'] is True and
      matrix['rootBoundedAdmission']['allNativeTechnicalGatesAdmitted'] is True and
      matrix['rootBoundedAdmission']['completeFinalPacketAdmitted'] is False and
      matrix['currentReconciliation']['rootAdmission'] is False and
      matrix['currentReconciliation']['finalIndependentExact46Review'] is False)
check('no-whole-contract-delivery-or-numerator-claim',
      all(matrix[k] is False for k in ['wholeContractSatisfied','nativeAppleSatisfied',
                                     'nativeWindowsSatisfied','finalPublicDeliverySatisfied'])
      and matrix['acceptanceNumerator'] is None)
check('all-original46-retain-final-review-and-no-acceptance',
      all('T05' in row['currentRemainingGateIds'] and 'NO_ACCEPTANCE' in row['currentStatus']
          for row in matrix['rows']))
check('T05-and-external-authority-remain-open', matrix['technicalFrontier']['T05']['state'] == 'OPEN'
      and matrix['sourceSecurityReview']['finalImmutableTreeJoin'] is None and
      set(matrix['externalGates']) == {'X01','X02','X03','X04'}
      and all(admission[k] is False for k in ['wholeContractSatisfied','mergeApprovalGranted',
          'finalPublicDeliverySatisfied','certificateIssued','issueClosureAuthorizedAtThisStage',
          'completePacketRootAdmission']))
check('document-source-and-baseline-differ-correctly',
      matrix['documentationEvidenceBaseline']['commit'] == PARENT and
      matrix['documentationEvidenceBaseline']['productAndInstrumentSource'] == SOURCE and
      matrix['documentationEvidenceBaseline']['sourceTree'] == SOURCE_TREE and
      matrix['documentationEvidenceBaseline']['futurePublicationCommit'] is None)

full = matrix['currentEvidenceReceiptJoins']['J_WFULL20']
ps7 = full['attempts'][0]['hosts']['ps766']
bad = full['attempts'][0]['hosts']['ps51']
ps51 = full['attempts'][1]['ps51']
check('full20-count-scope-preserved', full['run'] == '43220592915' and
      full['candidateQualificationHead'] == SOURCE and
      {k:full['caseBreakdown'][k] for k in ['total','preview','normal','earlyOptionRefusalsWithinPreview','heldRelationships']} ==
      {'total':20,'preview':18,'normal':2,'earlyOptionRefusalsWithinPreview':2,'heldRelationships':18})
check('native-job-artifact-source-identities',
      ps7['job'] == '131190813338' and ps7['artifact'] == '13944574998' and
      ps51['job'] == '131197436545' and ps51['artifact'] == '13947627028' and
      bad['job'] == '131190813869' and bad['artifact'] == '13945063071' and
      all(row['sourceCommit'] == SOURCE for row in [ps7,ps51,bad]))
check('native-20-plus20-failed-zero-not-superseded',
      ps7['completedInstallerCases'] == ps51['completedInstallerCases'] == 20 and
      bad['completedInstallerCases'] == 0 and bad['reportedFullEntryAccepted'] is False and
      bad['jobConclusion'] == 'failure' and 'cause' in bad['limits'])
check('ps7-attempt2-is-reused-listing', full['attempts'][1]['ps766']['newNativeExecution'] is False
      and full['attempts'][1]['ps766']['originalJob'] == ps7['job'])
check('ps51-host-phase-differences-not-erased', ps51['physicalScope'] == {
    'previewCases':18, 'earlyRefusalsWithinPreview':2,
    'previewFullProfileUnchanged':True, 'earlyRefusalStartupQuiescent':False,
    'completeDirectInputLifecycleEqualCases':0, 'heldInvocationEqualCases':18,
    'heldAfterPostexitEqualCases':18, 'heldPreparedEqualsPrelaunchCases':18,
    'heldPreparationEqualsBeforeInvocationCases':0, 'normalFullProfileUnchanged':False,
    'noDirectDiscoveryProofForEarlyRefusals':True})
normal = ps51['strictNormal']
check('strict-normal-cache-full-row-scope', normal['cases'] == 2 and normal['passed'] is True and
      normal['cacheBytes'] == 732 and normal['cacheAbsentAtWarmBefore'] is True and
      normal['completeCacheRowsEqualAcross'] == ['warmAfter','productBefore','productAfter'] and
      normal['completeWarmAfterEqualsProductBefore'] is True and
      normal['cacheSha256'] == {
          'positive':'589682361bc92da795eb5ab1fe1830d28292a71a85d96fb8eb33cd7d6cf9525f',
          'no-open':'36695d0a520bdb6c7395da697ffb8a296ab6539331bf88b4540a19b78befe6db'})
check('document-retains-measurement-limit-markers', all(part in doc for part in [
    'independentHardContainment=NOT_ACQUIRED', 'general transport counts remain null',
    'ACQUISITION_GAP', 'adds41 Python-cache entries', 'not original OS stream buffers',
    'All20 PS7 direct full-profile and complete-input before/after lifecycles remain unequal',
    'before any installer launch', 'product credit is0', 'actual732-byte normal caches',
    'distinct from the738-byte diagnostic caches', 'no cache or physical field is excluded',
    'T05 remains', 'separate owner merge approval']))

result = {
    'schema':'r0016-final-source-security-tree-join-checks.v1',
    'reviewTree':TREE, 'comparisonParent':PARENT, 'underlyingSource':SOURCE,
    'scope':'Inert exact-tree/document/reference joins; previous source and native receipt-level checks retained. Not installer execution, native receiving replay, or contract acceptance.',
    'checks':checks, 'passed':sum(c['passed'] for c in checks), 'total':len(checks),
    'failed':[c['check'] for c in checks if not c['passed']],
}
(OUT/'checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['reviewTree','passed','total','failed']},indent=2))
raise SystemExit(0 if result['passed'] == result['total'] else 1)
