#!/usr/bin/env python3
"""Read-only original receipt of adverse full20 PS5.1 attempt; never executes native code."""
import ast
import base64
import collections
import hashlib
import io
import json
import math
from pathlib import Path,PurePosixPath,PureWindowsPath
import re
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET
import zipfile

sys.dont_write_bytecode=True
sys.path.insert(0,'/workspace/scratch/0dd4b9b6a244/reviews/windows_receiving')
import receive as helper

BASE=Path(__file__).parent
RECOVERY=Path('/workspace/scratch/0dd4b9b6a244/recovery/full20-a89/ps51')
ROOT=RECOVERY/'extracted/installer-evidence'
PRIOR=Path('/workspace/scratch/0dd4b9b6a244/recovery/native-43216080799/extracted/installer-evidence')
REPO=Path('/workspace/scratch/0dd4b9b6a244/salah_widget')
HEAD='a89bbb3ddac639cc787ba08d030e8b2539057387'
TREE='efa716f4c8f1fe61c1a5a85b48bd97e813305d16'
MAIN='3b0e614114ef066de40db117d0e85c0031cf3e30'
COUNTS=collections.Counter();GROUP='setup'

def require(value,message,*args):
    COUNTS[GROUP]+=1
    if not value:raise AssertionError(message)

helper.require=require
read=helper.strict_json
sha=helper.sha
WPath=helper.WPath
fact=helper.fact
verify_fact=helper.verify_fact

def native_read(path,owner=None):
    return read(helper.checked_path(path,owner))

def git_bytes(commit,role):
    return subprocess.run(['git','show',commit+':'+role],cwd=REPO,check=True,stdout=subprocess.PIPE).stdout

def function_source(path,name):
    raw=path.read_text();node=next(n for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef) and n.name==name)
    return ast.get_source_segment(raw,node),node

def original_archive():
    path=RECOVERY/'ps51-full20-43220592915.zip';raw=path.read_bytes()
    require((len(raw),sha(raw))==(150750,'e6c4a2a5c8b505a5166acaf17321ddbc6b7c56b758256a55cd1a740e3d1a7fdc'), 'Original ZIP differs')
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        require(z.namelist()==['installer-full-entry-evidence.tar.gz'] and z.testzip() is None,'ZIP membership/CRC differs')
        packed=z.read(z.namelist()[0])
    require((len(packed),sha(packed))==(150704,'3a3f1de0474631b0fc8a7734b33656b3071c74ad20f1aa28301bf1db5b5e43c6'),'Original TAR differs')
    require(packed==(RECOVERY/'original.tar.gz').read_bytes(),'Retained TAR copy differs')
    inventory=[]
    with tarfile.open(fileobj=io.BytesIO(packed),mode='r:gz') as tar:
        members=tar.getmembers();names=[m.name for m in members]
        require(len(members)==76 and len(set(names))==76,'TAR member count/uniqueness differs')
        for m in members:
            name=PurePosixPath(m.name)
            require(not name.is_absolute() and '..' not in name.parts and name.parts[0]=='installer-evidence','TAR path escape')
            require(m.isfile() or m.isdir(),'TAR link/special member')
            p=ROOT.joinpath(*name.parts[1:]);require(not p.is_symlink(),'Extracted link')
            if m.isfile():
                content=tar.extractfile(m).read()
                require(len(content)==m.size and p.read_bytes()==content,'Extracted file differs from original')
                inventory.append(dict(path=m.name,bytes=len(content),sha256=sha(content)))
            else:require(p.is_dir(),'Missing extracted directory')
    require(len(inventory)==36,'Regular-file count differs')
    require({p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}==
        {str(PurePosixPath(r['path']).relative_to('installer-evidence')) for r in inventory},'Extra/missing extracted regular file')
    require(sorted(inventory,key=lambda r:r['path'])==sorted(read(RECOVERY/'inventory.json'),key=lambda r:r['path']),
        'Root supplied inventory differs')
    return dict(zip=dict(path=str(path),bytes=len(raw),sha256=sha(raw)),
        tar=dict(bytes=len(packed),sha256=sha(packed),members=76),files=36,inventory=inventory)

def process_observation(record,command,capture,budget,exit_code):
    require(record['command']==command and type(record['exit']) is int and record['exit']==exit_code,
        'Actual outer command or integer exit differs')
    require(record['timeoutSeconds']==budget and type(record['timeoutSeconds']) is int,
        'Outer budget differs')
    require(type(record['elapsedSeconds']) in (int,float) and math.isfinite(record['elapsedSeconds'])
        and 0<=record['elapsedSeconds']<budget,'Outer elapsed time is not finite within budget')
    require(record['timedOut'] is False and record['error'] is None,'Outer timeout/error differs')
    require(all(record[k] is True for k in ('exitObserved','jobAssignedBeforeResume','jobClosedKillOnClose')),
        'Outer lifecycle observation missing')
    require(all(type(record[k]) is int and record[k]>0 for k in ('processId','threadId')),
        'Outer identity missing')
    require(record['capture']=='direct files; no redirected pipe drain' and record['drain']=='not applicable',
        'Outer capture protocol differs')
    require(native_read(capture/'observer.process.json',capture)==record,'Original outer process receipt differs')
    launch=native_read(capture/'observer.launch.json',capture)
    for key in ('command','processId','threadId','timeoutSeconds','createdSuspendedUtc'):
        require(launch[key]==record[key],'Original outer launch association differs: '+key)
    require(launch['jobAssignedBeforeResume'] is True and launch['jobClosedKillOnClose'] is False
        and launch['exit'] is None and launch['timedOut'] is False and launch['error'] is None,
        'Original suspended Job launch facts differ')
    for stream in ('stdout','stderr'):verify_fact(record[stream],capture/('observer.'+stream+'.raw'),capture)

def prior_acl_comparison(harness,plan):
    previous_plan=read(PRIOR/'diagnostic-plan.json');previous_result=read(PRIOR/'diagnostic-result.json')
    new_function,_=function_source(harness,'protect_parents')
    previous_function,_=function_source(PRIOR/'inherited/tests/install-entry-native-composition.py','protect_parents')
    require(new_function==previous_function,'Prior successful protect_parents source differs')
    require(plan['host']==previous_plan['host'] and plan['python']==previous_plan['python'],
        'Recorded prior native executable facts differ')
    require((ROOT/'version/observer.stdout.raw').read_bytes()==(PRIOR/'version/observer.stdout.raw').read_bytes(),
        'Prior raw native version differs')
    require((PRIOR/'inherited/tests/install-entry-native-composition.py').read_bytes()==
        git_bytes(previous_result['sourceCommit'],'tests/install-entry-native-composition.py'),
        'Prior source no longer matches original immutable source')
    cases=[]
    report=read(next((PRIOR/'m0/f').glob('*/entry-composition-report.json')))
    for row in report['results']:
        c=next((PRIOR/'m0/f').glob('*/'+('c10' if row['case']=='positive' else 'c11')))
        before=read(c/'parent-acl-before.json');after=read(c/'parent-acl-after.json')
        a={r['path']:r for r in before};b={r['path']:r for r in after}
        require(len(a)==len(before) and len(b)==len(after) and a.keys()==b.keys(),'Prior ACL ancestor denominator differs')
        native=WPath(row['observation']['fixture']);owned={str(native.parent),str(native),str(native/'subject'),
            str(native/'subject/temp'),str(native/'host-home')}
        require(owned.issubset(a),'Prior owned ACL path missing')
        for path,record in b.items():
            if path in owned:
                rules=record['rules']
                require(record['protected'] is True and len(rules)==1 and rules[0]['sid']==record['owner']
                    and rules[0]['type']=='Allow' and rules[0]['rights']==2032127,'Prior ACL readback differs')
            else:require(a[path]['sddl']==record['sddl'],'Prior external ancestor ACL changed')
        raw=(c/'parent-acl-setup.stderr.txt').read_bytes()
        require(raw.startswith(b'#< CLIXML\r\n'),'Prior CLIXML preamble differs')
        xml=ET.fromstring(raw.split(b'\n',1)[1]);ns={'p':'http://schemas.microsoft.com/powershell/2004/04'}
        records=[dict(stream=n.get('S'),activities=[x.text for x in n.findall('.//p:AV',ns)],
            states=[x.text for x in n.findall('.//p:PR/p:T',ns)]) for n in xml.findall('p:Obj',ns)]
        require(len(records)==3 and all(x['stream']=='progress' and x['states']==['Completed'] for x in records),
            'Prior completed progress records differ')
        cases.append(dict(case=row['case'],originalPass=row['pass_'],ownedAclEntries=5,
            ancestorEntries=len(after),stderrBytes=len(raw),stderrRecords=records))
    return dict(run=43216080799,sourceCommit=previous_result['sourceCommit'],
        protectParentsExactSourceEqual=True,protectParentsBytes=len(new_function.encode()),
        protectParentsSha256=sha(new_function.encode()),nativeExecutableFactsEqual=True,
        rawNativeVersionEqual=True,cases=cases,
        limitation='No separate actual ACL child environment/terminal journal exists in the failed run; source equality does not establish environmental equality or explain the timeout.')

def main():
    global GROUP
    GROUP='archive';archive=original_archive()
    GROUP='source'
    plan=read(ROOT/'plan.json');result=read(ROOT/'route-result.json');remote=WPath(plan['root'])
    WPath.mappings=[(remote,ROOT)]
    require(plan['sourceCommit']==result['sourceCommit']==HEAD and result['fixture']==str(remote),
        'Immutable source/root association differs')
    require(subprocess.run(['git','rev-parse',HEAD+'^{tree}'],cwd=REPO,check=True,
        stdout=subprocess.PIPE,text=True).stdout.strip()==TREE,'Immutable tree differs')
    source_facts={}
    require(len(plan['copiedInputs'])==14 and len(plan['launchedInputs'])==12,'Source-role denominators differ')
    original_root=WPath(plan['originals'][0]['path']).parent
    originals={WPath(r['path']).relative_to(original_root).as_posix():r for r in plan['originals']}
    for role,record in plan['copiedInputs'].items():
        path=remote/'control'/role;verify_fact(record,path,remote)
        require(path.read_bytes()==git_bytes(HEAD,role),'Copied source differs from immutable commit: '+role)
        require(all(originals[role][k]==record[k] for k in ('bytes','sha256')),'Original/copied input fact differs')
        source_facts[role]=record
    require(set(originals)==set(source_facts),'Original source denominator differs')
    outer=ROOT/'control/tools/qualification/installer_preview_windows_full_entry.py'
    pure=dict(require=require,math=math,re=re,read_json=native_read,verify_fact=verify_fact)
    exec(helper.select_definitions(outer,['validate_terminal','validate_version','build_command'],
        ['INPUTS','CASES']),pure)
    require(set(pure['INPUTS'])==set(plan['launchedInputs']),'Outer pin denominator differs')
    for role,pin in pure['INPUTS'].items():
        require(plan['launchedInputs'][role]==source_facts[role]
            and tuple(pin)==(source_facts[role]['bytes'],source_facts[role]['sha256']),
            'Launched source pin differs')
    GROUP='process'
    executable=WPath(plan['host']['path'])
    process_observation(result['phases']['version'],plan['version']['command'],remote/'version',60,0)
    pure['validate_terminal'](result['phases']['version'],plan['version']['command'],remote/'version',60)
    require(pure['validate_version']((remote/'version/observer.stdout.raw').read_bytes(),'ps51',executable)
        ==result['nativeHost'],'Native version raw facts differ')
    command=pure['build_command'](plan['launchedInputs'],WPath(plan['python']['path']),'ps51',executable,remote/'f')
    require(command==plan['fullEntry']['command'],'Full twenty-scenario command differs')
    process_observation(result['phases']['fullEntry'],command,remote/'run',6550,1)
    rejected=None
    try:pure['validate_terminal'](result['phases']['fullEntry'],command,remote/'run',6550)
    except AssertionError as error:rejected=str(error)
    require(rejected=='Outer terminal is not integer zero' and result['error']=='Rejected: '+rejected,
        'Original admission rejection differs')
    require(result['status']=='FULL_ENTRY_NOT_ADMITTED' and result['fullEntryAccepted'] is False,
        'Adverse original was relabeled')
    require(not (remote/'run/observer.stderr.raw').read_bytes(),'Outer stderr differs')
    envelope=read(remote/'run/observer.stdout.raw');report_path=WPath(envelope['report']['path'])
    verify_fact(envelope['report'],report_path,remote/'f');report=read(report_path)
    fixture=report_path.parent;case=fixture/'c00'
    require(envelope['status']==report['status']=='FAIL' and envelope['fixture']==report['fixture']==str(fixture),
        'Failure envelope/report join differs')
    require(report['selectedScenarios']==result['expectedCases']==list(pure['CASES']) and len(pure['CASES'])==20,
        'Declared twenty scenarios differ')
    require(report['selectedHosts']==['ps51'] and report['expectedHost']==envelope['expectedHost']=='ps51',
        'Host association differs')
    require(report['sourceBefore']==report['source']==source_facts['install.ps1']['sha256']
        and report['sourceUnchanged'] is True and result['sourceAndInputsUnchanged'] is True,
        'Source continuity receipt differs')
    for field,role in [('sourceFact','install.ps1'),('presetFact','presets/salah-widget.tablissng.json')]:
        require(report[field]==source_facts[role],'Report source/preset fact differs')
    for field,role in [('testSha256','tests/install-entry-native-composition.py'),
        ('supportSha256','tests/install-entry-coverage-support.py'),
        ('compositionSha256','tests/install-entry-product-support.py'),
        ('compositionCoreSha256','tests/install-entry-composition-support.py'),
        ('diagnosticSha256','tests/install-entry-driver-diagnostic.py'),
        ('heldDriverSha256','tests/install-entry-held.ps1')]:
        require(report[field]==source_facts[role]['sha256'],'Report instrument identity differs')
    GROUP='failure'
    require(len(report['results'])==1,'Unexpected executed-row denominator')
    row=report['results'][0]
    require(row['case']=='github' and row['host']=='ps51' and row['pass_'] is False
        and row['classification']=='BOOTSTRAP_BLOCKED','Original blocked row differs')
    require(row['observation']==dict(fixture=str(case),stage='owned-parent-acl-setup',installerExecuted=False),
        'Unexpected installer observation')
    error=row['error'];prefix="Command '";suffix="' timed out after 60 seconds"
    require(error.startswith(prefix) and error.endswith(suffix),'Original timeout report differs')
    acl_command=ast.literal_eval(error[len(prefix):-len(suffix)])
    require(acl_command[:3]==[str(executable),'-NoProfile','-EncodedCommand'] and len(acl_command)==4,
        'Nested setup command differs')
    code=base64.b64decode(acl_command[3],validate=True).decode('utf-16le')
    harness=ROOT/'control/tests/install-entry-native-composition.py'
    function,node=function_source(harness,'protect_parents')
    source_code=next(ast.literal_eval(n.value) for n in ast.walk(node) if isinstance(n,ast.Assign)
        and any(isinstance(t,ast.Name) and t.id=='code' for t in n.targets))
    require(code==source_code,'Actual encoded ACL command differs from exact immutable source')
    require((case/'parent-acl-setup.stdout.txt').read_bytes()==b''
        and (case/'parent-acl-setup.stderr.txt').read_bytes()==b'#< CLIXML\r\n',
        'Nested setup raw stream bytes differ')
    missing=['parent-acl-before.json','parent-acl-after.json','direct-launch-inputs.json',
        'direct-full-before-launch.json','direct-full-after-exit.json','entry-profile-window',
        'host-only-control','modules','fixture.zip','canonical-preset.json','ready','effects']
    require(all(not (case/path).exists() for path in missing),'Unexpected later-stage or ACL snapshot evidence')
    require({p.name for p in fixture.iterdir() if p.is_dir()}=={'c00'},'Unexpected later scenario directory')
    cache=fact(case/'acl-host-state/analysis-cache')
    comparison=prior_acl_comparison(harness,plan)
    analysis=dict(status='FINAL',classification='BOOTSTRAP_BLOCKED',run=43220592915,attempt=1,
        head=HEAD,tree=TREE,base=MAIN,sourceFacts=source_facts,nativeHost=result['nativeHost'],
        originalOuterProcess=result['phases']['fullEntry'],originalRow=row,
        setupStdout=fact(case/'parent-acl-setup.stdout.txt'),setupStderr=fact(case/'parent-acl-setup.stderr.txt'),
        setupStderrDecoded='#< CLIXML\r\n',nestedAclCommand=acl_command,setupCodeSha256=sha(code.encode()),
        nestedActualPid=None,nestedActualExit=None,nestedStageTrace=None,nestedDeadlineSeconds=60,
        missingLaterEvidence=missing,retainedAclHostCache=cache,
        installerLaunchesCredited=0,scenarioPassesCredited=0,declaredScenarios=20,blockedRows=1,
        unattemptedScenarios=list(pure['CASES'][1:]),priorComparison=comparison,
        minimumFinding='The ACL setup subprocess.run capture did not complete within 60 seconds; no installer launch is evidenced. The raw header alone identifies no failing PowerShell operation.',
        remainingLimits=['No actual inner PID, inner exit, ready marker, stage journal, separate terminal timing, or actual ACL environment receipt was acquired.',
            'subprocess.run capture_output uses redirected pipes; this artifact cannot distinguish an unfinished child from an unfinished pipe/capture condition.',
            'No ACL before/after JSON exists, so no ACL denial, failed Set-Acl, completed ACL mutation, or external ancestor change is established.',
            'A later success cannot explain or erase attempt 1; a recurrence locates the same acquisition boundary, not its underlying cause.',
            'Native executable content facts remain original observations; binary contents are not archived.'],
        recommendation='No concrete correction is established. One exact-candidate, same-bound PS5.1-only new attempt is technically informative if distinctly preserved. If this boundary recurs, add bounded ACL child launch/terminal and staged direct-file observation before changing behavior or deadlines.')
    (BASE/'analysis.json').write_text(json.dumps(analysis,indent=2)+'\n')
    (BASE/'archive-inventory.json').write_text(json.dumps(archive,indent=2)+'\n')
    (BASE/'acl-setup-decoded.ps1').write_text(code)
    checks=dict(status='FINAL',requested_model='gpt-6-astra',actual_model='gpt-6-astra',
        authoring_context_reuse='no',other_reviewer_visibility='no',base=MAIN,head=HEAD,tree=TREE,
        rootContinuity='G0027 supplied by root',checks=dict(COUNTS),assertionChecks=sum(COUNTS.values()),
        verdict='Original adverse run received; zero installer/scenario pass credit; underlying ACL acquisition timeout cause undetermined.',
        scope='Read-only original source/byte/process receiving. No repo mutation, native execution, publication, acceptance, or closure.')
    (BASE/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(json.dumps(dict(status='FINAL',assertionChecks=checks['assertionChecks'],originalFiles=36,
        scenarioPassesCredited=0,nestedTimeoutSeconds=60,outerExit=1,outerTimedOut=False),indent=2))

if __name__=='__main__':main()
