
$ErrorActionPreference='Stop'
$sid=[Security.Principal.WindowsIdentity]::GetCurrent().User
$owned=@($env:INSTALL_OWNED_PARENTS.Split('|'))
$observed=@()
foreach($parent in $owned) {
    $cursor=[IO.DirectoryInfo]::new($parent)
    while($cursor) {
        if($observed -notcontains $cursor.FullName){$observed += $cursor.FullName}
        $cursor=$cursor.Parent
    }
}
function Read-ParentFacts([string[]]$Paths) {
    foreach($path in $Paths) {
        $item=Get-Item -LiteralPath $path -Force
        $acl=Get-Acl -LiteralPath $path
        [pscustomobject]@{
            path=$item.FullName; attributes=[int]$item.Attributes;
            owner=$acl.GetOwner([Security.Principal.SecurityIdentifier]).Value;
            group=$acl.GetGroup([Security.Principal.SecurityIdentifier]).Value;
            sddl=$acl.GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]'Access,Owner,Group');
            protected=$acl.AreAccessRulesProtected;
            rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier])|ForEach-Object{
                [pscustomobject]@{sid=$_.IdentityReference.Value; rights=[int64]$_.FileSystemRights; type=[string]$_.AccessControlType; inherited=$_.IsInherited; inheritance=[string]$_.InheritanceFlags; propagation=[string]$_.PropagationFlags}
            })
        }
    }
}
$before=@(Read-ParentFacts $observed)
[IO.File]::WriteAllText($env:INSTALL_ACL_BEFORE,($before|ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false))
foreach($parent in $owned) {
    $full=[IO.Path]::GetFullPath($parent)
    if($full -cne $env:INSTALL_FIXTURE_ROOT -and -not $full.StartsWith($env:INSTALL_FIXTURE_ROOT+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'ACL setup escaped owned root'}
    if(([IO.File]::GetAttributes($full) -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'ACL setup refused reparse point'}
    $acl=New-Object Security.AccessControl.DirectorySecurity
    $acl.SetOwner($sid); $acl.SetAccessRuleProtection($true,$false)
    $rule=New-Object Security.AccessControl.FileSystemAccessRule($sid,[Security.AccessControl.FileSystemRights]::FullControl,[Security.AccessControl.InheritanceFlags]'ContainerInherit,ObjectInherit',[Security.AccessControl.PropagationFlags]::None,[Security.AccessControl.AccessControlType]::Allow)
    $acl.AddAccessRule($rule)
    Set-Acl -LiteralPath $parent -AclObject $acl
}
$after=@(Read-ParentFacts $observed)
[IO.File]::WriteAllText($env:INSTALL_ACL_AFTER,($after|ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false))
foreach($row in $after) {
    if($owned -contains $row.path) {
        if($row.owner -cne $sid.Value -or -not $row.protected -or $row.rules.Count -ne 1 -or $row.rules[0].sid -cne $sid.Value -or $row.rules[0].type -cne 'Allow' -or $row.rules[0].rights -ne [int64][Security.AccessControl.FileSystemRights]::FullControl){throw 'Owned parent ACL readback failed'}
    } else {
        $prior=@($before|Where-Object{$_.path -ceq $row.path})
        if($prior.Count -ne 1 -or $prior[0].sddl -cne $row.sddl){throw 'An external ancestor ACL changed'}
    }
}
