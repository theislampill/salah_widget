"""Independent data-only receiving of original PS7 full20. No native execution/import."""
import ast,collections,copy,hashlib,json,math,ntpath,os,pathlib,re,stat,subprocess,tarfile,types,zipfile
import xml.etree.ElementTree as ET
HERE=pathlib.Path(__file__).resolve().parent
ORIGINAL=HERE.parents[1]/'recovery/full20-a89/ps766'
EXTRACTED=ORIGINAL/'extracted';ROOT=EXTRACTED/'installer-evidence'
REPO=HERE.parents[1]/'salah_widget'
COMMIT='a89bbb3ddac639cc787ba08d030e8b2539057387'
checks=collections.Counter();stages=[]
def require(value,reason):
    if not value:raise AssertionError(reason)
    checks[reason]+=1
def sha(raw):return hashlib.sha256(raw).hexdigest()
def parse(raw):
    def unique(pairs):
        value={}
        for key,item in pairs:
            require(key not in value,'No duplicate JSON member');value[key]=item
        return value
    def nonfinite(value):raise AssertionError('Nonfinite JSON: '+value)
    return json.loads(raw.decode('utf-8-sig'),object_pairs_hook=unique,parse_constant=nonfinite)
def local_json(path):return parse(path.read_bytes())
def write(name,value):(HERE/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
for name,size,digest in [('ps766-full20-43220592915.zip',5222627,'692c309ed1f00ebc4fd4b044505c5837be0c43497eb66eb6d69d3266cf029dda'),('original.tar.gz',5386442,'ef7ddea4de756e6ed770daa68513f50f9cfb65f990340fd069ac4aa3870a33a1')]:
    raw=(ORIGINAL/name).read_bytes();require((len(raw),sha(raw))==(size,digest),'Assigned original archive size/hash '+name)
with zipfile.ZipFile(ORIGINAL/'ps766-full20-43220592915.zip') as z:
    require(z.testzip() is None,'ZIP all member CRCs');require(len(z.infolist())==1,'ZIP sole original TAR')
    require(z.read(z.infolist()[0])==(ORIGINAL/'original.tar.gz').read_bytes(),'ZIP original TAR exact bytes')
inventory=[];members={}
with tarfile.open(ORIGINAL/'original.tar.gz','r:gz') as archive:
    for item in archive.getmembers():
        path=pathlib.PurePosixPath(item.name)
        require(not path.is_absolute() and '..' not in path.parts and path.parts[0]=='installer-evidence' and '\\' not in item.name,'Safe TAR member path')
        require(item.name not in members and (item.isfile() or item.isdir()),'Unique regular/directory TAR member')
        members[item.name]=item
        local=EXTRACTED/item.name
        require(not local.is_symlink() and (local.is_file() if item.isfile() else local.is_dir()),'Extracted original member type')
        if item.isfile():
            raw=archive.extractfile(item).read();require(len(raw)==item.size and raw==local.read_bytes(),'Extracted bytes exactly equal original TAR')
            inventory.append(dict(path=item.name,bytes=len(raw),sha256=sha(raw)))
require(len(members)==2981 and len(inventory)==1709,'Assigned complete original membership counts')
require(set(members)=={p.relative_to(EXTRACTED).as_posix() for p in ROOT.rglob('*')}|{'installer-evidence'},'Complete extraction membership including directories')
inventory.sort(key=lambda r:r['path'])
require(inventory==sorted(local_json(ORIGINAL/'inventory.json'),key=lambda row:row['path']),'Independent inventory equals supplied inventory')
write('archive-inventory.json',inventory)
plan=local_json(ROOT/'plan.json');route=local_json(ROOT/'route-result.json');WINROOT=pathlib.PureWindowsPath(plan['root'])
require(plan['sourceCommit']==route['sourceCommit']==COMMIT,'Exact immutable source commit')
source_joins=[]
for role,fact in plan['copiedInputs'].items():
    raw=(ROOT/'control'/role).read_bytes();gitraw=subprocess.check_output(['git','-C',str(REPO),'show',COMMIT+':'+role])
    require(raw==gitraw,'Archived source equals immutable Git '+role)
    require((len(raw),sha(raw))==(fact['bytes'],fact['sha256']),'Archived source pin '+role)
    original=next(v for v in plan['originals'] if pathlib.PureWindowsPath(v['path']).parts[-len(pathlib.PurePosixPath(role).parts):]==pathlib.PureWindowsPath(role).parts)
    require((original['bytes'],original['sha256'])==(fact['bytes'],fact['sha256']),'Original/copied source size/hash '+role)
    source_joins.append(dict(role=role,bytes=len(raw),sha256=sha(raw)))
require(len(source_joins)==14,'All fourteen exact source roles')
write('source-joins.json',dict(commit=COMMIT,tree=subprocess.check_output(['git','-C',str(REPO),'rev-parse',COMMIT+'^{tree}'],text=True).strip(),roles=source_joins))
stages.append('archive/source verified')
print(json.dumps(dict(stage=stages[-1],members=len(members),files=len(inventory),roles=len(source_joins))),flush=True)

# Windows lexical paths preserve original serialized values. Reads map only into
# verified archive members. No local extraction stat is presented as a native stat.
class WPath(pathlib.PureWindowsPath):
    def local(self):
        require(self.is_absolute() and self.is_relative_to(WINROOT),'Archive path within original owned root')
        relative=self.relative_to(WINROOT)
        require('..' not in relative.parts,'Archive path has no traversal')
        return ROOT.joinpath(*relative.parts)
    def read_bytes(self):return self.local().read_bytes()
    def read_text(self,encoding='utf-8',errors=None):return self.read_bytes().decode(encoding,errors or 'strict').replace('\r\n','\n')
    def exists(self):return self.local().exists()
    def is_file(self):return self.local().is_file()
    def is_dir(self):return self.local().is_dir()
    def resolve(self,strict=False):
        if strict:require(self.exists(),'Mapped original path exists')
        return self
    def stat(self):return self.local().stat()
    def glob(self,pattern):return [WPath(WINROOT,*p.relative_to(ROOT).parts) for p in self.local().glob(pattern)]
    def iterdir(self):return [WPath(WINROOT,*p.relative_to(ROOT).parts) for p in self.local().iterdir()]

external_paths={plan['host']['path'],plan['python']['path']}
def checked_path(value,owner=None,directory=False):
    path=WPath(value)
    require(path.is_absolute() and '..' not in path.parts,'Original Windows absolute nontraversing path')
    if owner is not None:require(path==WPath(owner) or path.is_relative_to(WPath(owner)),'Original path owner association')
    if str(path) in external_paths:
        require(owner is None and not directory,'External host/path observation only');return path
    require(path.is_dir() if directory else path.is_file(),'Archived original path type')
    return path
def fact(value,owner=None):
    path=checked_path(value,owner);raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=sha(raw))
def save_receive(path,value):
    require(parse(WPath(path).read_bytes())==json.loads(json.dumps(value)),'Recomputed receiver journal equals original '+WPath(path).name)
def definitions(role):
    source=ROOT/'control'/role;tree=ast.parse(source.read_bytes())
    ns=dict(require=require,Path=WPath,pathlib=types.SimpleNamespace(Path=WPath),os=types.SimpleNamespace(sep='\\',path=ntpath,name='nt'),
        re=re,math=math,json=json,copy=copy,hashlib=hashlib,ntpath=ntpath,ast=ast,collections=collections,ET=ET,SimpleNamespace=types.SimpleNamespace,Rejected=AssertionError)
    for node in tree.body:
        if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
            try:value=ast.literal_eval(node.value)
            except (ValueError,TypeError):
                if isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Name) and node.value.func.id=='frozenset':value=frozenset(ast.literal_eval(node.value.args[0]))
                elif all(isinstance(item,(ast.Constant,ast.Name,ast.BinOp,ast.UnaryOp,ast.Tuple,ast.List,ast.Set,ast.Dict,ast.Subscript,ast.Load,ast.Add,ast.Mult,ast.Sub,ast.USub)) for item in ast.walk(node.value)) and all(item.id in ns for item in ast.walk(node.value) if isinstance(item,ast.Name)):
                    value=eval(compile(ast.Expression(node.value),str(source),'eval'),{'__builtins__':{}},ns)
                else:continue
            ns[node.targets[0].id]=value
    nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef)]
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),ns)
    ns.update(require=require,fact=fact,save=save_receive)
    return ns,tree
core,coretree=definitions('tests/install-entry-composition-support.py')
core['SCENARIOS']=core['ORIGINAL_SCENARIOS']+('env-source-default','explicit-source-override')
support,_=definitions('tests/install-entry-coverage-support.py')
driver,_=definitions('tests/install-entry-driver-diagnostic.py');driver['c']=types.SimpleNamespace(**core)
product,_=definitions('tests/install-entry-product-support.py')
for name in ('TIMEOUT','ACK_TIMEOUT','SCENARIOS','FAILURE_SCENARIOS','ROW_FIELDS','ROLE_PATHS','CLONE_FIELDS','require','sha','fact','save','complete_json','owned_environment','direct_parameters','exact_exit','validate_rows','map_inputs','verify_input_mapping','mapped_environment','require_positive_confinement'):product[name]=core[name]
product['diagnostic']=types.SimpleNamespace(**driver)
harness,htree=definitions('tests/install-entry-native-composition.py')
harness.update(SCENARIOS=core['SCENARIOS'],composition=types.SimpleNamespace(**product),support=types.SimpleNamespace(**support),SOURCE_HASH_BEFORE=product['PREVIEW_SOURCE_SHA'])
outer,_=definitions('tools/qualification/installer_preview_windows_full_entry.py')
outer.update(checked_path=checked_path,file_fact=fact)
modules={'tests/install-entry-composition-support.py':core,'tests/install-entry-coverage-support.py':support,'tests/install-entry-driver-diagnostic.py':driver}
def load_exact(path,digest,name):
    require(fact(path)['sha256']==digest,'Pinned replay dependency exact source')
    role=WPath(path).relative_to(WPath(WINROOT)/'control').as_posix()
    require(role in modules,'Only inert explicitly selected modules loaded')
    return types.SimpleNamespace(**modules[role])
outer['load_exact']=load_exact
root=WPath(WINROOT);envelope=parse((root/'run/observer.stdout.raw').read_bytes())
report=parse(WPath(envelope['report']['path']).read_bytes());fixture=WPath(report['fixture'])
for role,pin in outer['INPUTS'].items():require((fact(root/'control'/role)['bytes'],fact(root/'control'/role)['sha256'])==pin,'Runtime source pin '+role)
require(plan['budget']==outer['BUDGET'],'Original unchanged complete budget')
require(plan['expectedHost']==route['expectedHost']=='ps7','Original PS7 host role')
require((plan['host']['bytes'],plan['host']['sha256'])==(301368,outer['PS7_EXE_SHA']),'Original PS7 binary pinned observation')
for phase,capture,budget in [('version','version',60),('fullEntry','run',6550)]:
    command=plan[phase]['command'];process=route['phases'][phase]
    outer['validate_terminal'](process,command,root/capture,budget)
    require(parse((root/capture/'observer.launch.json').read_bytes())['command']==command,'Original suspended launch exact command')
    require(not any(key.upper()=='COMPLUS_MULTICOREJITNOPROFILEGATHER' for key in plan[phase]['environment']),'Outer inherited gather setting absent')
host=outer['validate_version']((root/'version/observer.stdout.raw').read_bytes(),'ps7',WPath(plan['host']['path']))
require(host==route['nativeHost'],'Independent host version equals original observation')
received=outer['validate_report'](route['phases']['fullEntry'],plan['fullEntry']['command'],root/'run',root/'f',root,WPath(plan['python']['path']),WPath(plan['host']['path']),'ps7',plan['launchedInputs'])
require(received==route['association'],'Entire recomputed outer association equals original')
write('outer-received.json',received)
print(json.dumps(dict(stage='full original outer receiver PASS',caseCount=received['caseCount'],custodyFacts=len(received['custodyFiles']))),flush=True)

native_bindings=[]
def retained_native_binding(value,label,journal_path,journal,reason='Unbound actual read module/assembly file'):
    original=parse(WPath(journal_path).read_bytes())
    require({k:v for k,v in journal.items() if k!='comparisons'}=={k:v for k,v in original.items() if k!='comparisons'},'Original native binding journal header')
    matching=[r for r in original['comparisons'] if r['label']==label]
    require(len(matching)==1,'Exactly one retained original native binding label')
    row=matching[0];child=row['childFact'];parent=row['parentFact'];identity=row['nativeFileIdentity']
    require(value==child and row['matches'] is True and row['error'] is None,'Original native child and successful binding')
    for field in (child,parent):
        require(set(field)=={'path','bytes','sha256'} and WPath(field['path']).is_absolute() and '..' not in WPath(field['path']).parts and type(field['bytes']) is int and field['bytes']>0 and re.fullmatch('[0-9a-f]{64}',field['sha256']),'Complete native file fact schema')
    require(child['bytes']==parent['bytes'] and child['sha256']==parent['sha256'],'Native content hash/size association')
    require(all(identity.get(key) is True for key in ('resolutionMatches','sameFile','stable','contentMatches')),'All native same-file/stability/content observations')
    require(identity['rawPath']==child['path'] and all(identity[key]==parent['path'] for key in ('canonicalPath','resolvedRawPath','resolvedCanonicalPath')) and identity['rawReadbackFact']==identity['canonicalReadbackFact']==parent,'Native raw/canonical readback association')
    observations=identity['observations'];require(set(observations)=={'rawBefore','canonicalBefore','rawAfter','canonicalAfter'},'All four native file observations')
    first=observations['rawBefore'];require(all(v==first for v in observations.values()),'Native complete metadata/identity stability')
    require(set(first)=={'device','inode','mode','bytes','mtimeNs','ctimeNs','attributes','links'} and all(type(v) is int and v>=0 for v in first.values()) and first['inode']>0 and first['links']>0 and stat.S_ISREG(first['mode']) and first['bytes']==child['bytes'] and not first['attributes']&0x400,'Complete native regular-file identity fields')
    fields=sorted(k for k in child if child[k]!=parent[k]);diff={k:dict(childPresent=True,parentPresent=True,child=child[k],parent=parent[k]) for k in fields}
    require(row['differingFields']==fields and row['differences']==diff,'Original native spelling differences retained exactly')
    if WPath(parent['path']).is_relative_to(WINROOT):require(fact(parent['path'])==parent,'Archived native binding raw bytes')
    journal['comparisons'].append(copy.deepcopy(row))
    require(journal['comparisons']==original['comparisons'][:len(journal['comparisons'])],'Original native binding order')
    native_bindings.append(dict(journal=str(journal_path),label=label,child=child,parent=parent,identity=first,external=not WPath(parent['path']).is_relative_to(WINROOT)))
driver['record_probe_file_binding']=retained_native_binding
product['diagnostic']=types.SimpleNamespace(**driver)
cases=[];all_nonces=[];relations=[]
def pair_for(case):
    control=case/'h/control';association=parse((control/'association.json').read_bytes());spec=parse((control/'spec.json').read_bytes())
    return dict(root=case/'h',directRoot=case,control=control,spec=spec,specPath=control/'spec.json',env=association['heldEnvironment'],association=association,
        directPrepared=parse((control/'direct-after-directory-restoration.json').read_bytes()),heldPrepared=parse((control/'held-prepared.json').read_bytes()))
def receive_pair(pair,support_unused,direct):
    control=pair['control'];association=pair['association'];spec=pair['spec']
    receipt=parse((control/'held-observation.json').read_bytes());result=parse((control/'result.json').read_bytes())
    expected_env=core['mapped_environment'](association['directEnvironment'],pair['directRoot'],pair['root'],spec['nonce'])
    expected_env['R0016_COMPOSITION_SPEC']=str(pair['specPath'])
    require(expected_env==pair['env']==association['heldEnvironment'],'Complete actual held environment constructor')
    expected=dict(receipt,command=association['heldCommand'],cwd=association['cwd'],nonce=spec['nonce'],hostName=spec['expectedHost'],host=spec['host'],parameters=spec['parameters'],heldEnvironment=expected_env,heldRoot=str(pair['root']),heldPreparedRows=pair['heldPrepared']['rows'])
    for key in ('sourceFact','driverFact','guardFact','windowFact','probeFact'):expected[key]=fact(spec[key]['path'])
    for key,path in [('specFact',pair['specPath']),('stdout',control/'stdout.raw'),('stderr',control/'stderr.raw'),('eventsFact',control/'events.jsonl'),('resultFact',control/'result.json')]:expected[key]=fact(path)
    for phase in ('before','after'):
        for kind in ('Signal','Ack'):expected[phase+kind+'Fact']=fact(spec[phase+kind])
    product['validate_held'](receipt,result,expected,pair,direct)
    require(receipt==parse((control/'held-observation.json').read_bytes()),'Entire recomputed held receipt equals original')
    all_nonces.append(receipt['nonce'])
    relations.append(dict(case=spec['scenario'],relation=receipt['sourceInputRelation']))
    return dict(observation=receipt,result=result,association=association)
product['invoke_pair']=receive_pair
harness['composition']=types.SimpleNamespace(**product)
case_fn=next(n for n in htree.body if isinstance(n,ast.FunctionDef) and n.name=='_case_impl')
validation=next(n for n in case_fn.body if isinstance(n,ast.Try) and any(isinstance(c,ast.Call) and isinstance(c.func,ast.Name) and c.func.id=='require_normal_preparation' for c in ast.walk(n)))
validation_code=compile(ast.Module(body=validation.body,type_ignores=[]),'original-case-post-acquisition-validation','exec')

def final_inventory(value,case):
    keyed=core['validate_rows'](value['rows'])
    for role,rel in core['ROLE_PATHS'].items():
        base=case/rel;rows={k[1]:r for k,r in keyed.items() if k[0]==role}
        if rows['.']['kind']=='absent':require(not base.exists(),'Final absent input absent in archive');continue
        actual={'.'}|({p.relative_to(base.local()).as_posix() for p in base.local().rglob('*')} if base.is_dir() else set())
        require(actual==set(rows),'Complete final input membership equals original inventory')
        for name,row in rows.items():
            path=base if name=='.' else base/name
            require(path.is_file() if row['kind']=='file' else path.is_dir(),'Final input original kind')
            if row['kind']=='file':require((len(path.read_bytes()),sha(path.read_bytes()))==(row['bytes'],row['sha256']),'Final input bytes equal original inventory')

for index,row in enumerate(report['results']):
    scenario=row['case'];case=fixture/('c%02d'%index);original=row['observation'];obs=copy.deepcopy(original);normal=scenario in ('positive','no-open')
    window=obs['profileWindow'];warm=obs['hostOnlyBaseline'];all_nonces.extend([window['nonce'],warm['nonce']])
    for name,receipt in [('entry-profile-window',window),('host-only-control',warm)]:
        for delta,left,right in [('startupDelta','before','atReady'),('entryDelta','atReady','after'),('fullDelta','before','after')]:
            expected=support['profile_delta'](receipt[left],receipt[right]) if receipt.get(left) is not None and receipt.get(right) is not None else None
            require(receipt.get(delta)==expected,'Original full profile delta recomputed without field removal')
        require(not any(step['step']=='kill-owned-process' for step in receipt['cleanup']['steps']),'No actual direct/warm forced process kill')
    require((case/'host-only-control/host-only.ps1').read_bytes().replace(b'\r\n',b'\n')==harness['warm_control_body']('no-gather' if normal else 'default').encode('ascii'),'Every actual PS7 source-free script exact body')
    effect_path=case/'effects';effects=[tuple(line.split('\t',1)) for line in effect_path.read_text(encoding='utf-8-sig').splitlines()] if effect_path.exists() else []
    require(json.loads(json.dumps(effects))==obs['effects'],'Actual raw product effects bind report')
    for stream in ('stdout','stderr'):require((case/(stream+'.txt')).read_bytes()==(case/'entry-profile-window'/(stream+'.raw')).read_bytes(),'Direct semantic output equals actual raw process capture')
    before=parse((case/'subject-before.json').read_bytes());after=parse((case/'subject-after.json').read_bytes())
    require(before==after and obs['snapshotUnchanged'] is True,'All original subject names/modes/bytes unchanged')
    keyed=core['validate_rows'](obs['fullInputsAfter']['rows'])
    expected_subject=sorted([[str(WPath(r['path'])),r['mode'],r['sha256'] if r['kind']=='file' else ''] for r in keyed.values() if r['role']=='subject' and r['path']!='.'],key=lambda r:r[0])
    require(sorted(after,key=lambda r:r[0])==expected_subject,'Raw subject snapshot joins complete final native fields')
    final_inventory(obs['fullInputsAfter'],case)
    env=dict(obs['directLaunchInputs']['environment'],INSTALL_EXPECTED_PID=str(window['pid']))
    pair=None if normal else pair_for(case)
    cache=obs.get('normalPreparation',{}).get('cacheCaptures',{})
    phases={k:parse(WPath(v['path']).read_bytes()) for k,v in obs.get('normalPreparation',{}).get('phaseFacts',{}).items()}
    ns=dict(harness,observation=obs,host_name='ps7',scenario=scenario,normal=normal,root=case,host_home=case/'host-home',subject=case/'subject',env=env,
        profile_window=window,run=types.SimpleNamespace(returncode=obs['entryExit']),stdout=(case/'stdout.txt').read_bytes().decode('utf-8'),stderr=(case/'stderr.txt').read_bytes().decode('utf-8'),
        effects=effects,unchanged=before==after,paired=pair,direct_inputs_before=obs['fullInputsBefore'],host_control=case/'host-only-control/host-only.ps1',startup=case/'host-only-control',
        preparation_cache=cache,preparation_phases=phases,warm_json=None,RESULTS=[])
    exec(validation_code,ns)
    require(len(ns['RESULTS'])==1 and ns['RESULTS'][0]['pass_'] is True,'Original per-case semantic predicate block passed')
    require(json.loads(json.dumps(obs))==original,'All recomputed product observation fields equal original')
    if not normal:final_inventory(obs['heldComposition']['observation']['postexit'],case/'h')
    cases.append(dict(case=scenario,status='PASS',entryExit=obs['entryExit'],directReady=window['ready'],directPid=window['pid'],warmPid=warm['pid'],directElapsed=window['terminalObservedElapsedSeconds'],warmElapsed=warm['terminalObservedElapsedSeconds'],
        profileStartupEqual=window['before']==window['atReady'],profileFullEqual=window['before']==window['after'],directCompleteInputsEqual=obs['fullInputsBefore']['rows']==obs['fullInputsAfter']['rows'],
        heldBeforeAfterEqual=None if normal else obs['heldComposition']['observation']['before']['rows']==obs['heldComposition']['observation']['after']['rows'],
        sourceInputRelationMode=None if normal else obs['sourceInputRelation']['mode'],normalPostcondition=obs.get('normalInputPostcondition'),effects=obs['effects']))
    print(json.dumps(dict(stage='original producer predicates PASS',case=scenario)),flush=True)
require(len(all_nonces)==58 and len(set(all_nonces))==58,'All 58 actual direct/warm/held process nonces distinct')
write('case-received.json',cases)
write('native-binding-received.json',native_bindings)
write('source-relations-received.json',relations)

raw_inventories=[];acl_records=[];restorations=[];method_inventory=None;source_inventory=None
for item in ROOT.rglob('*.json'):
    if item.name in ('entry-composition-report.json','route-result.json'):continue
    value=local_json(item)
    if type(value) is dict and value.get('schema')=='r0016-entry-full-input-inventory.v1':
        require(value.get('complete') is True and value.get('passes')==[value['rows'],value['rows']],'Every retained full inventory has complete agreeing passes')
        core['validate_rows'](value['rows'])
        for row in value['rows']:
            if row['kind']!='absent':require(type(row['attributes']) is int and type(row['security']) is str and row['security'] and row['inode']>0,'Original Windows identity/attributes/security retained')
        raw_inventories.append(dict(path=item.relative_to(ROOT).as_posix(),rows=len(value['rows'])))
for index,row in enumerate(report['results']):
    scenario=row['case'];case=fixture/('c%02d'%index);obs=row['observation'];normal=scenario in ('positive','no-open')
    current=obs['directLaunchInputs']['sourceInventory']
    require(len(current)==1 and current[0]['path']=='.' and current[0]['kind']=='file' and (current[0]['bytes'],current[0]['sha256'])==outer['INPUTS']['install.ps1'],'Actual source metadata snapshot exact source bytes')
    if source_inventory is None:source_inventory=current
    require(current==source_inventory,'Exact complete source metadata unchanged across all20 launches')
    for base in ([case] if normal else [case,case/'h']):
        before=parse((base/'parent-acl-before.json').read_bytes());after=parse((base/'parent-acl-after.json').read_bytes())
        own=[base,base/'subject',base/'subject/temp',base/'host-home']
        if base==case:own=[fixture]+own
        expected=set()
        for path in own:expected.update(str(x) for x in [path,*path.parents])
        require({r['path'] for r in before}=={r['path'] for r in after}==expected and len(before)==len(after)==len(expected),'Complete ACL parent/ancestor observations')
        bypath={r['path']:r for r in before};owned={str(p) for p in own}
        sid=after[0]['owner']
        for entry in after:
            require(type(entry['attributes']) is int and not entry['attributes']&0x400,'ACL original ancestor without reparse observation')
            if entry['path'] in owned:
                require(entry['owner']==sid and entry['protected'] is True and len(entry['rules'])==1,'Owned parent exact owner/protected ACL')
                rule=entry['rules'][0]
                require(rule==dict(sid=sid,rights=2032127,type='Allow',inherited=False,inheritance='ContainerInherit, ObjectInherit',propagation='None'),'Owned parent exact sole full-control rule')
            else:require(entry['sddl']==bypath[entry['path']]['sddl'],'Non-target original ancestor SDDL unchanged')
        require((base/'parent-acl-setup.stderr.txt').read_bytes()==b'','Original ACL setup stderr empty')
        acl_records.append(dict(root=str(base),targets=sorted(owned),observedAncestors=len(after),sid=sid))
    if not normal:
        control=case/'h/control';prepared=parse((control/'directory-preparation.json').read_bytes())
        require(prepared['schema']=='r0016-entry-directory-preparation.v1' and prepared['complete'] is True and prepared['errors']==[] and prepared['plan']==prepared['operations']==[],'Original clone preparation complete with no restoration operations')
        for value in prepared['snapshots'].values():require(fact(value['path'])==value,'Original directory preparation snapshot custody')
        result=obs['heldComposition']['result'];inventory=result['methodInventory']
        if method_inventory is None:method_inventory=inventory
        require(inventory==method_inventory and len(inventory)==295,'Exact same full pinned-source method inventory in all18 held results')
        source_lines=(root/'control/install.ps1').read_bytes().decode('utf-8-sig').splitlines()
        for point in inventory:require(type(point['line']) is int and type(point['column']) is int and 1<=point['line']<=len(source_lines) and 1<=point['column']<=len(source_lines[point['line']-1]) and type(point['detail']) is str and point['detail'],'Every recorded source coverage point has actual source line/column')
        held=obs['heldComposition']['observation']
        require(not any(s['step']=='kill-owned-process' for s in held['cleanup']['steps']),'No held forced process kill')
        if scenario in ('readable','unreadable'):
            proof=parse((case/'h/unreadable-child-proof.json').read_bytes());env=held['environment']
            require(held['metadataProof']==proof and held['metadataProofFact']==fact(case/'h/unreadable-child-proof.json'),'Held raw metadata proof joins original receipt')
            require(type(proof['pid']) is int and proof['pid']==held['pid'] and proof['nonce']==held['nonce'] and proof['path']==env['INSTALL_UNREADABLE_FILE'],'Held actual metadata proof PID/nonce/path')
            require(proof['exists'] is True and proof['peerReadable'] is True and proof['peerSha256']==env['INSTALL_METADATA_SHA'],'Held actual existence/readable-peer control')
            if scenario=='unreadable':require(proof['readSucceeded'] is False and proof['nativeCode']==32 and proof['exceptionType']=='System.IO.IOException','Held original Windows share-mode refusal')
            else:require(proof['readSucceeded'] is True and proof['nativeCode'] is None and proof['targetSha256']==env['INSTALL_METADATA_SHA'],'Held healthy readable counterpart')
    if scenario=='unreadable':
        for base,control,inventory in [(case,case,obs['fullInputsAfter']),(case/'h',case/'h/control',obs['heldComposition']['observation']['postexit'])]:
            restored=parse((control/'unreadable-restoration.json').read_bytes());initial=parse((control/'unreadable-held-before.json').read_bytes())
            require(restored['before']==restored['heldAfter']==initial and restored['restored'] is True and restored['restoredSha256']==initial['sha256'],'Original unreadable lock stable and restored')
            relative=WPath(initial['path']).relative_to(base/'subject').as_posix();native=next(r for r in inventory['rows'] if r['role']=='subject' and r['path']==relative)
            require(restored['restoredIdentity']==[native['device'],native['inode']] and native['inode']==(initial['indexHigh']<<32)|initial['indexLow'],'Original restored lock file identity joins full inventory')
            require((native['bytes'],native['sha256'],native['attributes'],native['links'],native['security'])==(initial['bytes'],initial['sha256'],initial['attributes'],initial['links'],initial['security']),'Original lock bytes/attributes/links/security retained')
            require(fact(initial['path'])['sha256']==restored['restoredSha256'],'Actual archived restored bytes')
            restorations.append(dict(root=str(base),receipt=restored))
    if normal:
        stage=case/'host-home'/obs['normalConfinement']['retainedRelative'];asset=(case/'fixture.zip').read_bytes()
        for pattern in ('*-tabliss-chromium.zip','*-tabliss-firefox-signed.xpi'):
            payload=list((stage/'downloads').glob(pattern));require(len(payload)==1 and payload[0].read_bytes()==asset,'Normal retained fixture download exact bytes')
        import io
        with zipfile.ZipFile(io.BytesIO(asset)) as zip_:
            require(zip_.namelist()==['manifest.json'],'Exact inert archive membership')
            unpacked=list(stage.glob('unpacked-*'));require(len(unpacked)==1 and (unpacked[0]/'manifest.json').read_bytes()==zip_.read('manifest.json'),'Actual bounded extraction exact manifest bytes')
        require((case/'canonical-preset.json').read_bytes()==(root/'control/presets/salah-widget.tablissng.json').read_bytes(),'Normal actual preset fixture source custody')
        output=list((stage/'presets').glob('*-salah-widget.tablissng.json'))[0];configured=parse(output.read_bytes());canonical=parse((case/'canonical-preset.json').read_bytes())
        canonical['data/orpul7IDXSSP']['input']=configured['data/orpul7IDXSSP']['input']
        require(configured==canonical,'Normal configured preset preserves all other canonical data')
require(len(acl_records)==38 and len(restorations)==2,'All38 ACL setups and both metadata lock restorations received')
outer_states=[]
for capture,state in [('version','v'),('run','s')]:
    values=[]
    for phase in ('before','after'):
        value=parse((root/capture/('state.'+phase+'.json')).read_bytes());values.append(value)
        require(value['schema']=='r0016-double-inventory.v2' and value['root']==str(root/state) and value['complete'] is True and value['passesAgree'] is True and len(value['passes'])==2,'Original outer state double inventory')
        passes=value['passes'];require(all(p['schema']=='r0016-inventory-pass.v1' and p['root']==value['root'] and p['complete'] is True for p in passes) and passes[0]['rows']==passes[1]['rows'],'Original outer state passes agree')
    before,after=[v['passes'][0]['rows'] for v in values]
    outer_states.append(dict(capture=capture,before=before,after=after,equal=before==after))
require(route['independentHardContainment']=='NOT_ACQUIRED' and route['independentGlobalTransportTelemetry'] is None,'Original containment and global telemetry limitation retained')
write('additional-received.json',dict(rawInventories=raw_inventories,acl=acl_records,restorations=restorations,sourceMetadata=source_inventory,methodInventory=method_inventory,outerStates=outer_states))
write('checks.json',dict(status='PASS',runId=43220592915,jobId=131190813338,artifactId=13944574998,commit=COMMIT,
    requested_model='gpt-6-astra (parent dispatch for this reviewer)',actual_model='unknown exact deployment variant; host self-report Codex/GPT-6',
    prior_code_review_context=True,candidate_author=False,other_current_reviewer_visibility=False,root_continuity='G0027 (supplied)',
    nativeExecution=False,nativeHarnessImported=False,archiveNativeFilesExecuted=False,externalNativeFilesReopened=False,
    caseCount=20,previewCount=18,normalCount=2,earlyRefusals=2,nonceCount=len(all_nonces),nativeBindingCount=len(native_bindings),
    rawFullInventoryCount=len(raw_inventories),aclSetupCount=len(acl_records),assertionAndKeyIntegrityChecks=sum(checks.values()),checks=dict(sorted(checks.items())),
    adapterBoundary='Original function ASTs replayed with original Windows lexical paths; archived bytes replace physical reads. Original native binding journal replaces acquisition, and save compares recalculated JSON to originals. No extracted Linux metadata substitutes for original native identity/ACL/timestamps.',
    limitations=['Independent hard containment NOT_ACQUIRED','No independent global transport telemetry','Native external DLL/module bytes and host/Python executables are not archived; their original observed bindings are received, not independently re-read','Only PS7 original receiving; no PS51 inference','No acceptance, release or closure authority']))
print(json.dumps(dict(status='PASS',cases=20,preview=18,normal=2,rawInventories=len(raw_inventories),nativeBindings=len(native_bindings),checks=sum(checks.values()))),flush=True)
