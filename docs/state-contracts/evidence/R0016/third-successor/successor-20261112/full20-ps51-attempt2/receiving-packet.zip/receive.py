#!/usr/bin/env python3
"""Receive immutable full20 original data, without importing/executing archive modules.

AST-select original receiver definitions. File access maps only archive members
whose original bytes were verified. External native paths are received as original
launch facts, never local files. Native acquisition and save operations are replaced
with exact retained-journal comparison; no native facts are measured or invented.
"""
import ast
import collections
import copy
from datetime import datetime
import hashlib
import io
import json
import math
import ntpath
from pathlib import Path,PureWindowsPath,PurePosixPath
import re
import stat
import subprocess
import sys
import tarfile
import types
import xml.etree.ElementTree as ET
import zipfile

sys.dont_write_bytecode=True
import archive_helpers as helpers

BASE=Path(__file__).parent
RECOVERY=Path('/workspace/scratch/0dd4b9b6a244/recovery/full20-a89/ps51-attempt2')
ROOT=RECOVERY/'extracted/installer-evidence'
REPO=Path('/workspace/scratch/0dd4b9b6a244/salah_widget')
HEAD='a89bbb3ddac639cc787ba08d030e8b2539057387'
TREE='efa716f4c8f1fe61c1a5a85b48bd97e813305d16'
MAIN='3b0e614114ef066de40db117d0e85c0031cf3e30'
COUNTS=collections.Counter();GROUP='setup'
NATIVE_REFERENCES={};NATIVE_REFERENCE_READS=[];NATIVE_JOURNALS={};SAVES=[]
WIN_OS=types.SimpleNamespace(sep='\\')

def require(value,reason,*args):
    COUNTS[GROUP]+=1
    if not value:raise AssertionError(reason)

helpers.require=require
WPath=helpers.WPath
sha=helpers.sha
read=helpers.strict_json
fact=helpers.fact
verify_fact=helpers.verify_fact

def checked_path(value,owner=None,directory=False):
    p=WPath(value)
    if p in NATIVE_REFERENCES:
        # An external executable is never mapped to fake archive bytes. This
        # receives its original source-bound launch reference, not current lstat.
        require(owner is None and not directory and p.is_absolute(),'Native reference role differs')
        NATIVE_REFERENCE_READS.append(dict(fact=NATIVE_REFERENCES[p],currentNativeFilesystemRechecked=False))
        return p
    return helpers.checked_path(value,owner,directory)

def read_json(path,owner=None):return read(checked_path(path,owner))

def canonical(value):return json.loads(json.dumps(value))

def save_received(path,value):
    require(read(path)==canonical(value),'Original producer-derived receipt differs: '+str(path))
    SAVES.append(fact(path))

def select(path,names,assignments=(),**bindings):
    namespace=dict(require=require,Path=WPath,json=json,re=re,math=math,hashlib=hashlib,
        ntpath=ntpath,os=WIN_OS,copy=copy,sha=sha,save=save_received,fact=fact,complete_json=read)
    namespace.update(bindings)
    exec(helpers.select_definitions(path,names,assignments),namespace)
    return namespace

def git_bytes(role):
    return subprocess.run(['git','show',HEAD+':'+role],cwd=REPO,check=True,stdout=subprocess.PIPE).stdout

def archive_receive():
    raw=(RECOVERY/'ps51-full20-43220592915-attempt2.zip').read_bytes()
    require((len(raw),sha(raw))==(3067872,'4247cb1eee4043d59c950936b84ac1b9ce09dbf4041edaad323d2857357c37b1'), 'ZIP original differs')
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        require(z.namelist()==['installer-full-entry-evidence.tar.gz'] and z.testzip() is None,'ZIP membership/CRC differs')
        packed=z.read(z.namelist()[0])
    require((len(packed),sha(packed))==(3219546,'6e633fd69f2b94b8680b5a88c8d92b8889947a6df76a54f36abdfb0ff02bf9cb'), 'TAR original differs')
    require(packed==(RECOVERY/'original.tar.gz').read_bytes(),'Retained TAR differs')
    inventory=[];directories=[]
    with tarfile.open(fileobj=io.BytesIO(packed),mode='r:gz') as t:
        members=t.getmembers();names=[m.name for m in members]
        require(len(members)==2769 and len(set(names))==len(names),'TAR member count/uniqueness differs')
        for member in members:
            name=PurePosixPath(member.name)
            require(not name.is_absolute() and '..' not in name.parts and name.parts[0]=='installer-evidence','Unsafe TAR path')
            require(member.isfile() or member.isdir(),'TAR link or special member')
            local=ROOT.joinpath(*name.parts[1:]);require(not local.is_symlink(),'Extracted link')
            if member.isfile():
                data=t.extractfile(member).read()
                require(len(data)==member.size and local.read_bytes()==data,'Extracted bytes differ: '+member.name)
                inventory.append(dict(path=member.name,bytes=len(data),sha256=sha(data)))
            else:
                require(local.is_dir(),'Missing extracted directory');directories.append(member.name)
    require(len(inventory)==1648,'Original file denominator differs')
    require({p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}==
        {str(PurePosixPath(x['path']).relative_to('installer-evidence')) for x in inventory},'Extra/missing extracted file')
    require(sorted(inventory,key=lambda x:x['path'])==sorted(read(RECOVERY/'inventory.json'),key=lambda x:x['path']),
        'Supplied inventory differs')
    return dict(zipBytes=len(raw),zipSha256=sha(raw),tarBytes=len(packed),tarSha256=sha(packed),
        members=len(members),regularFiles=len(inventory),inventory=inventory,directories=directories)

def receive_native_comparison(row):
    require(type(row) is dict and set(row)=={'label','childFact','parentFact','matches','differingFields',
        'differences','nativeFileIdentity','error'},'Incomplete original native file row')
    child=row['childFact'];parent=row['parentFact'];identity=row['nativeFileIdentity']
    for value in (child,parent):
        require(type(value) is dict and set(value)=={'path','bytes','sha256'} and WPath(value['path']).is_absolute()
            and type(value['bytes']) is int and value['bytes']>=0 and re.fullmatch('[0-9a-f]{64}',value['sha256']),
            'Malformed original native file fact')
    differences=sorted(k for k in child.keys()|parent.keys() if child.get(k)!=parent.get(k))
    require(row['differingFields']==differences and row['differences']==
        {k:dict(childPresent=k in child,parentPresent=k in parent,child=child.get(k),parent=parent.get(k)) for k in differences},
        'Native path/content differences omitted')
    require(row['matches'] is True and row['error'] is None and identity['rawPath']==child['path']
        and identity['canonicalPath']==identity['resolvedRawPath']==identity['resolvedCanonicalPath']==parent['path'],
        'Native raw/canonical association differs')
    observations=identity['observations']
    require(set(observations)=={'rawBefore','canonicalBefore','rawAfter','canonicalAfter'},'Incomplete native identity window')
    first=observations['rawBefore']
    require(set(first)=={'device','inode','mode','bytes','mtimeNs','ctimeNs','attributes','links'},
        'Incomplete native physical identity')
    require(all(type(first[k]) is int and first[k]>=0 for k in ('device','inode','mode','bytes','mtimeNs','ctimeNs','links'))
        and first['inode']>0 and first['links']>0 and stat.S_ISREG(first['mode'])
        and (first['attributes'] is None or type(first['attributes']) is int and not first['attributes']&0x400),
        'Invalid recorded native file identity')
    require(all(v==first for v in observations.values()) and first['bytes']==parent['bytes'],
        'Native physical identity/metadata changed')
    require(identity['rawReadbackFact']==identity['canonicalReadbackFact']==parent
        and all(child[k]==parent[k] for k in ('bytes','sha256'))
        and all(identity[k] is True for k in ('resolutionMatches','sameFile','stable','contentMatches')),
        'Native readback or identity predicates differ')

def retained_native_binding(value,label,path,journal,reason=None):
    original=read(path)
    require({k:v for k,v in journal.items() if k!='comparisons'}==
        {k:v for k,v in original.items() if k!='comparisons'},'Native journal process/source header differs')
    index=len(journal['comparisons'])
    require(journal['comparisons']==original['comparisons'][:index] and index<len(original['comparisons']),
        'Native journal ordering differs')
    row=original['comparisons'][index]
    require(row['label']==label and row['childFact']==value,'Native journal command/file join differs')
    receive_native_comparison(row)
    journal['comparisons'].append(copy.deepcopy(row))
    NATIVE_JOURNALS[str(path)]=dict(fact=fact(path),comparisons=len(original['comparisons']),
        receivedComparisons=index+1,currentNativeFilesystemRechecked=False)

def build_receivers(remote):
    control=remote/'control'
    common=select(control/'tests/install-entry-composition-support.py',
        ['direct_parameters','exact_exit','validate_rows','map_inputs','verify_input_mapping',
         'mapped_environment','require_positive_confinement'],
        ['ORIGINAL_SCENARIOS','SCENARIOS','FAILURE_SCENARIOS','ROW_FIELDS','ROLE_PATHS','CLONE_FIELDS','PATH_ENV','TIMEOUT','ACK_TIMEOUT'])
    common['require']=require;common['fact']=fact;common['complete_json']=read
    composition=types.SimpleNamespace(**common)
    coverage=select(control/'tests/install-entry-coverage-support.py',['assert_profile_window','profile_delta'])
    support=types.SimpleNamespace(**coverage)
    driver=select(control/'tests/install-entry-driver-diagnostic.py',
        ['validate_host','validate_window','validate_gate','validate_original_ready'],c=composition)
    driver['record_probe_file_binding']=retained_native_binding
    diagnostic=types.SimpleNamespace(**driver)
    product=select(control/'tests/install-entry-product-support.py',
        ['read_query_contract','bind_source_read_rows','normalized_read_context','validate_child_read_context',
         'early_option_refusal','source_input_relation','validate_held'],['PREVIEW_SOURCE_SHA'],
        diagnostic=diagnostic,**{name:common[name] for name in ['validate_rows','direct_parameters','exact_exit',
         'verify_input_mapping','ROW_FIELDS','TIMEOUT']})
    composition.PREVIEW_SOURCE_SHA=product['PREVIEW_SOURCE_SHA']
    def selected_receiver(path,name,digest,bindings=None):
        require(fact(path)['sha256']==digest,'Original pure function source differs')
        return select(path,[name],**(bindings or {}))[name]
    def data_only_load(path,digest,name):
        require(fact(path)['sha256']==digest,'Original receiver dependency differs')
        if path.name=='install-entry-composition-support.py':return composition
        if path.name=='install-entry-coverage-support.py':return support
        if path.name=='install-entry-driver-diagnostic.py':return diagnostic
        raise AssertionError('Unapproved archived-module import: '+str(path))
    outer=select(control/'tools/qualification/installer_preview_windows_full_entry.py',
        ['parse_json','validate_terminal','validate_version','build_command','expected_entry_command',
         'validate_source_relation','bind_preparation_receipt','read_json_array','validate_normal_preparation',
         'validate_case_headers','validate_report'],
        ['INPUTS','CASES','FAILURE_CASES','CHILD_SECONDS','BUDGET','OUTER_SECONDS','JSON_LIMIT','SOURCE_FREE_PREREQUISITE'],
        checked_path=checked_path,read_json=read_json,file_fact=fact,verify_fact=verify_fact,
        selected_pure_receiver=selected_receiver,load_exact=data_only_load,SimpleNamespace=types.SimpleNamespace)
    return composition,support,diagnostic,product,outer

def pair_from_archive(case):
    control=case/'h/control';association=read(control/'association.json');spec=read(control/'spec.json')
    return dict(root=case/'h',directRoot=case,control=control,env=association['heldEnvironment'],spec=spec,
        specPath=control/'spec.json',association=association,
        directPrepared=read(control/'direct-after-directory-restoration.json'),heldPrepared=read(control/'held-prepared.json'))

def producer_held(case,observation,composition,product,diagnostic):
    pair=pair_from_archive(case);spec=pair['spec'];association=pair['association'];control=pair['control']
    held=observation['heldComposition'];receipt=copy.deepcopy(held['observation']);result=held['result']
    mapped=composition.mapped_environment(association['directEnvironment'],case,pair['root'],spec['nonce'])
    mapped['R0016_COMPOSITION_SPEC']=str(pair['specPath'])
    require(mapped==pair['env']==association['heldEnvironment'],'Original complete held environment constructor differs')
    expected=dict(command=association['heldCommand'],cwd=association['cwd'],nonce=spec['nonce'],
        hostName=spec['expectedHost'],host=spec['host'],parameters=spec['parameters'],
        heldEnvironment=mapped,heldRoot=str(pair['root']),heldPreparedRows=pair['heldPrepared']['rows'])
    for key in ('sourceFact','driverFact','guardFact','windowFact','probeFact'):expected[key]=fact(spec[key]['path'])
    for key,path in [('specFact',pair['specPath']),('stdout',control/'stdout.raw'),('stderr',control/'stderr.raw'),
        ('resultFact',control/'result.json'),('eventsFact',control/'events.jsonl')]:expected[key]=fact(path)
    for phase in ('before','after'):
        for kind in ('Signal','Ack'):expected[phase+kind+'Fact']=fact(spec[phase+kind])
    product['validate_held'](receipt,result,expected,pair,observation)
    require(receipt==held['observation'],'Recomputed original producer held receipt differs')
    diagnostic.validate_original_ready(receipt,pair)
    for phase in ('before','after'):diagnostic.validate_gate(receipt,spec,phase)
    # Receive the native preparation-only directory journal without repeating its mutations.
    journal_path=control/'directory-preparation.json';verify_fact(association['directoryPreparation'],journal_path,case)
    journal=read(journal_path)
    require(journal['schema']=='r0016-entry-directory-preparation.v1' and journal['complete'] is True
        and journal['errors']==[],'Prepared clone directory journal failed')
    require(journal['plan']==journal['operations']==[], 'Unexpected native directory repair in this original')
    snapshots={}
    for phase,record in journal['snapshots'].items():
        path=WPath(record['path']);verify_fact(record,path,case);value=read(path)
        expected_root=case/'h' if phase.startswith('held') else case
        diagnostic.validate_window(value,expected_root,path);snapshots[phase]=value
    require(set(snapshots)=={'directBeforeClone','directPrepared','heldBeforeRestoration','directAfter','heldAfter'}
        and snapshots['directBeforeClone']==snapshots['directPrepared']==snapshots['directAfter']==pair['directPrepared']
        and snapshots['heldBeforeRestoration']==snapshots['heldAfter']==pair['heldPrepared'],
        'Preparation-only complete snapshot relation differs')
    return pair

def acl_journals(case,expected_owned):
    before=read(case/'parent-acl-before.json');after=read(case/'parent-acl-after.json')
    a={x['path']:x for x in before};b={x['path']:x for x in after}
    require(len(a)==len(before) and len(b)==len(after) and a.keys()==b.keys(),'ACL ancestor membership differs')
    owned={str(p) for p in expected_owned};require(owned.issubset(a),'ACL owned path omitted')
    for path,row in b.items():
        if path in owned:
            rules=row['rules'];require(row['protected'] is True and len(rules)==1 and rules[0]['sid']==row['owner']
                and rules[0]['type']=='Allow' and rules[0]['rights']==2032127,'Owned ACL readback differs')
        else:require(a[path]['sddl']==row['sddl'],'External ancestor ACL changed')
    return dict(owned=len(owned),observed=len(after),stdout=fact(case/'parent-acl-setup.stdout.txt'),
        stderr=fact(case/'parent-acl-setup.stderr.txt'))

def final_inventory_bytes(root,inventory,roles):
    for role,relative in roles.items():
        path=root.local()/relative;rows=[r for r in inventory['rows'] if r['role']==role]
        expected={r['path'] for r in rows}
        actual={'.'}|({p.relative_to(path).as_posix() for p in path.rglob('*')} if path.is_dir() else set())
        require(expected==actual,'Final owned inventory membership differs: '+str(root)+'/'+role)
        for row in rows:
            p=path if row['path']=='.' else path/row['path']
            if row['kind']=='absent':require(not p.exists(),'Absent role exists after acquisition')
            elif row['kind']=='directory':require(p.is_dir(),'Final directory missing')
            else:require(p.is_file() and len(p.read_bytes())==row['bytes'] and sha(p.read_bytes())==row['sha256'],
                'Final regular input content differs')

def direct_predicates(case,scenario,o,normal_check):
    stdout=(case/'stdout.txt').read_text(encoding='utf-8-sig');stderr=(case/'stderr.txt').read_text(encoding='utf-8-sig')
    effects=[] if not (case/'effects').exists() else [x.split('\t',1) for x in (case/'effects').read_text(encoding='utf-8-sig').splitlines()]
    require(effects==o['effects'],'Raw direct effect log differs')
    for stream in ('stdout','stderr'):
        require((case/(stream+'.txt')).read_bytes()==(case/'entry-profile-window'/(stream+'.raw')).read_bytes(),
            'Direct original raw capture copy differs')
    if scenario in ('positive','no-open'):
        return normal_check(case,o,scenario,WPath(o['command'][3]).parent/'tests/install-entry-native-composition.py')
    require(not effects and not list((case.local()/'host-home').glob('SalahWidgetBundle-*')),
        'Preview emitted effects or retained a bundle')
    require(read(case/'subject-before.json')==read(case/'subject-after.json') and o['snapshotUnchanged'] is True,
        'Preview subject snapshot differs')
    failures={'legacy','none','bad-option','unreadable','invalid-env-source'}
    if scenario=='invalid-env-source':require(('InstallSource' in stdout+stderr or 'SALAH_INSTALL_SOURCE' in stdout+stderr)
        and 'Preview only; no changes made' not in stdout,'Invalid environment refusal attribution differs')
    if scenario not in failures:
        require('Preview only; no changes made' in stdout and 'Importing the preset replaces your current TablissNG dashboard' in stdout,
            'Useful preview completion/replacement warning missing')
        if scenario=='ask':require('Install source unresolved' in stdout,'Unresolved choice fabricated')
        if scenario in ('github','cached','mixed','env-source-default'):require('release/version/path unresolved' in stdout,'Remote facts fabricated')
        if scenario=='missing-preset':require('No preset URL configured' in stdout,'Empty preset ignored')
        if scenario in ('valid-env-store','explicit-source-override'):
            for url in ('https://chromewebstore.google.com/detail/tablissng/dlaogejjiafeobgofajdlkkhjlignalk','https://addons.mozilla.org/en-US/firefox/addon/tablissng/'):
                require(re.search(r'^Would open official store: '+re.escape(url)+r'\r?$',stdout,re.M),'Resolved store plan differs')
            require('Install source unresolved' not in stdout,'Resolved store remained unresolved')
        if scenario in ('preview-noopen-github','preview-noopen-store'):
            require(not [x for x in re.split(r'[;\r\n]+',stdout) if re.search(r'\bwould\b.*\b(open|launch)\b',x,re.I)],
                'NoOpen preview promises automatic open')
            require(re.search(r'NoOpen|NO_OPEN|open(?:ed)? manually|pages? yourself',stdout,re.I),'NoOpen manual guidance missing')
    return dict(effects={},legacyLifecycleChecks=o['legacyLifecycleChecks'])

def metadata_proofs(case,scenario,o,pair):
    if scenario not in ('readable','unreadable'):return None
    proofs=[]
    for root,window,environment,key in [(case,o['profileWindow'],o['directLaunchInputs']['environment'],'unreadability'),
        (case/'h',o['heldComposition']['observation'],pair['env'],'metadataProof')]:
        proof=read(root/'unreadable-child-proof.json')
        expected=o[key] if root==case else window[key]
        require(proof==expected and proof['pid']==window['pid'] and proof['nonce']==window['nonce']
            and proof['path']==environment['INSTALL_UNREADABLE_FILE'],'Metadata proof process/path association differs')
        require(proof['exists'] is True and proof['peerReadable'] is True
            and proof['peerSha256']==environment['INSTALL_METADATA_SHA'],'Metadata readable peer control differs')
        if scenario=='unreadable':require(proof['readSucceeded'] is False and proof['nativeCode']==32
            and proof['exceptionType']=='System.IO.IOException','Native share refusal missing')
        else:require(proof['readSucceeded'] is True and proof['nativeCode'] is None
            and proof['targetSha256']==environment['INSTALL_METADATA_SHA'],'Readable counterpart differs')
        if root!=case:verify_fact(window['metadataProofFact'],root/'unreadable-child-proof.json',root)
        if scenario=='unreadable':
            control=root if root==case else root/'control'
            initial=read(control/'unreadable-held-before.json');restoration=read(control/'unreadable-restoration.json')
            require(restoration['before']==restoration['heldAfter']==initial and restoration['restored'] is True
                and restoration['restoredSha256']==initial['sha256']==environment['INSTALL_METADATA_SHA'],
                'Original share-refusal handle/readability restoration differs')
            relative=WPath(initial['path']).relative_to(root/'subject').as_posix()
            rows=o['fullInputsAfter']['rows'] if root==case else window['postexit']['rows']
            row=next(r for r in rows if r['role']=='subject' and r['path']==relative)
            require(restoration['restoredIdentity']==[row['device'],row['inode']]
                and (initial['indexHigh']<<32|initial['indexLow'])==row['inode']
                and all(initial[k]==row[k] for k in ('bytes','sha256','attributes','links','security')),
                'Restored native handle identity/content differs from full physical row')
        proofs.append(proof)
    text=(case/'stdout.txt').read_text(encoding='utf-8-sig')
    if scenario=='unreadable':require(all(s in text for s in ['discovery unknown: HELD (metadata-unreadable)',
        'Preview targets: 0 eligible, 1 held, 0 refused.','No eligible target; preview made no changes.']),
        'Unreadable metadata outcome differs')
    else:require('Preview targets: 1 eligible, 0 held, 0 refused.' in text and 'release/version/path unresolved' in text,
        'Readable counterpart preview outcome differs')
    return proofs

def guard_binding(case,pair,result,remote):
    core=(remote/'control/tests/install-preview.ps1').read_text(encoding='ascii')
    drivers=re.findall(r"(?m)^\$DriverText=@'\n(.*?)\n'@\s*$",core,re.S)
    helpers_text=re.findall(r"(?m)^\$EffectHelpers=@\(\n(.*?)\n\)\s*$",core,re.S)
    require(len(drivers)==len(helpers_text)==1,'Embedded guard definitions ambiguous')
    effect_helpers=re.findall(r"'([^']+)'",helpers_text[0])
    require(pair['spec']['effectHelpers']==effect_helpers and
        (pair['control']/'original-guard-driver.ps1').read_bytes()==drivers[0].encode('ascii'),
        'Held guard driver/helper inventory differs from pinned original')
    require((pair['control']/'original-window-support.ps1').read_bytes()==
        (remote/'control/tests/install-preview-window.ps1').read_bytes(),'Held window/gate source differs')
    require((pair['control']/'held-driver.ps1').read_bytes()==(remote/'control/tests/install-entry-held.ps1').read_bytes()
        and (pair['control']/'input-probe.ps1').read_bytes()==(remote/'control/tests/install-entry-input-probe.ps1').read_bytes(),
        'Held driver/input probe exact copied bytes differ')
    inventory=result['methodInventory'];lines=(remote/'control/install.ps1').read_text().splitlines()
    require(len(inventory)==295,'Native source guard inventory denominator differs')
    keys=[]
    for row in inventory:
        require(set(row)=={'line','column','detail'} and type(row['line']) is int and type(row['column']) is int
            and 1<=row['line']<=len(lines) and 1<=row['column']<=len(lines[row['line']-1])+1
            and isinstance(row['detail'],str) and row['detail'].startswith(('method ','command ')),
            'Native guard row/source coordinate is invalid')
        keys.append((row['line'],row['column'],row['detail']))
    require(len(keys)==len(set(keys)),'Duplicate native source guard inventory row')
    require(result['guardEstablished'] is True and result['preparationError'] is None
        and result['scope']=='product' and result['guardMode']=='deny' and result['events']==[]
        and (pair['control']/'events.jsonl').read_bytes()==b'','Held guard/effect observations differ')
    return dict(effectHelpers=effect_helpers,methodInventory=inventory,
        guardSha256=sha(drivers[0].encode('ascii')),nativeAstInventoryReexecuted=False)

def main():
    global GROUP
    GROUP='archive';archive=archive_receive();(BASE/'archive-inventory.json').write_text(json.dumps(archive,indent=2)+'\n')
    GROUP='source'
    plan=read(ROOT/'plan.json');result=read(ROOT/'route-result.json');remote=WPath(plan['root']);WPath.mappings=[(remote,ROOT)]
    require(plan['sourceCommit']==result['sourceCommit']==HEAD and result['fixture']==str(remote),'Source/root association differs')
    require(subprocess.run(['git','rev-parse',HEAD+'^{tree}'],cwd=REPO,check=True,text=True,stdout=subprocess.PIPE).stdout.strip()==TREE,'Immutable source tree differs')
    for record in (plan['host'],plan['python']):NATIVE_REFERENCES[WPath(record['path'])]=record
    source_root=WPath(plan['originals'][0]['path']).parent
    originals={WPath(x['path']).relative_to(source_root).as_posix():x for x in plan['originals']}
    require(len(originals)==len(plan['copiedInputs'])==14,'Original copied source denominator differs')
    for role,record in plan['copiedInputs'].items():
        p=remote/'control'/role;verify_fact(record,p,remote)
        require(p.read_bytes()==git_bytes(role),'Immutable source bytes differ: '+role)
        require(all(record[k]==originals[role][k] for k in ('bytes','sha256')),'Original copied source fact differs')
    composition,support,diagnostic,product,outer=build_receivers(remote)
    require(set(plan['launchedInputs'])==set(outer['INPUTS']),'Launched input denominator differs')
    for role,pin in outer['INPUTS'].items():require(tuple(pin)==(plan['launchedInputs'][role]['bytes'],plan['launchedInputs'][role]['sha256']),
        'Immutable outer launched-source pin differs')
    GROUP='outer'
    outer['validate_terminal'](result['phases']['version'],plan['version']['command'],remote/'version',60)
    require(outer['validate_version']((remote/'version/observer.stdout.raw').read_bytes(),'ps51',WPath(plan['host']['path']))
        ==result['nativeHost'],'Actual raw native version differs')
    received=outer['validate_report'](result['phases']['fullEntry'],plan['fullEntry']['command'],remote/'run',remote/'f',remote,
        WPath(plan['python']['path']),WPath(plan['host']['path']),'ps51',plan['launchedInputs'])
    require(received==result['association'],'Original complete outer association differs')
    require(result['status']=='ACQUIRED_WINDOWS_FULL_ENTRY20' and result['fullEntryAccepted'] is True
        and result['sourceAndInputsUnchanged'] is True,'Original acquisition scope/continuity differs')
    report=read(WPath(received['report']['path']));fixture=WPath(report['fixture'])
    harness_tree=ast.parse((remote/'control/tests/install-entry-native-composition.py').read_bytes())
    module=next(ast.literal_eval(n.value) for n in harness_tree.body if isinstance(n,ast.Assign)
        and any(isinstance(t,ast.Name) and t.id=='MODULE' for t in n.targets)).encode('ascii').replace(b'\n',b'\r\n')
    manifests=[n.value for n in ast.walk(harness_tree) if isinstance(n,ast.Constant) and isinstance(n.value,str)
        and n.value.startswith("@{RootModule='Microsoft.PowerShell.Utility.psm1';")]
    require(len(manifests)==1,'Ambiguous original Utility manifest')
    normal_globals=dict(require=require,ast=ast,collections=collections,Path=Path,WPath=WPath,read=read,fact=fact,
        PureWindowsPath=PureWindowsPath,stat=stat,sha=sha,zipfile=zipfile,ET=ET)
    exec(helpers.select_definitions(BASE/'normal_receiving.py',['normal_evidence']),normal_globals)
    case_checks=[];inventory_reference=None;all_held_nonces=[];lifecycle=[]
    for i,row in enumerate(report['results']):
        scenario=row['case'];o=row['observation'];case=fixture/('c%02d'%i);GROUP='case/'+scenario
        require((case/'canonical-preset.json').read_bytes()==(remote/'control/presets/salah-widget.tablissng.json').read_bytes(),
            'Case canonical preset differs from immutable input')
        require((case/'modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psm1').read_bytes()==module
            and (case/'modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1').read_bytes()==
            manifests[0].encode('ascii').replace(b'\n',b'\r\n'),'Case Utility wrapper source literal differs')
        for leg in ('profileWindow','hostOnlyBaseline'):
            window=o[leg]
            require(window['fullDelta']==support.profile_delta(window['before'],window['after']),
                'Raw complete profile delta differs')
            if window['atReady'] is not None:
                require(window['startupDelta']==support.profile_delta(window['before'],window['atReady'])
                    and window['entryDelta']==support.profile_delta(window['atReady'],window['after']),
                    'Raw startup/entry profile delta differs')
            else:require(window['startupDelta'] is None and window['entryDelta'] is None,
                'Early refusal invents profile readiness delta')
        acl=acl_journals(case,[fixture,case,case/'subject',case/'subject/temp',case/'host-home'])
        direct=direct_predicates(case,scenario,o,normal_globals['normal_evidence'])
        entry=dict(index=i,scenario=scenario,directExit=o['entryExit'],directPid=o['profileWindow']['pid'],
            directNonce=o['readinessNonce'],directDiscoveryObserved=o['profileWindow']['ready'],
            directTerminalSeconds=o['profileWindow']['terminalObservedElapsedSeconds'],
            legacyLifecycleChecks=o['legacyLifecycleChecks'],effects=direct['effects'],acl=acl)
        final_inventory_bytes(case,o['fullInputsAfter'],composition.ROLE_PATHS)
        if scenario in ('positive','no-open'):
            require(o['profileWindow']['before']==o['profileWindow']['atReady'],
                'Original normal startup-quiescence predicate fails')
            prep=o['normalPreparation'];cache=prep['cacheCaptures']
            require(cache['warmBefore']['inventoryRow']['kind']=='absent','Normal cache initially exists')
            require(cache['warmAfter']['inventoryRow']==cache['productBefore']['inventoryRow']==cache['productAfter']['inventoryRow'],
                'Normal cache full physical row changed after preparation')
            for name in ('warm-json-assembly-binding.json','warm-json-assembly-received.json'):
                journal=read(case/name);require(len(journal['comparisons'])==1,'Native JSON journal count differs')
                receive_native_comparison(journal['comparisons'][0])
                NATIVE_JOURNALS[str(case/name)]=dict(fact=fact(case/name),comparisons=1,receivedComparisons=1,currentNativeFilesystemRechecked=False)
            entry.update(normalPreparation=prep,normalPostcondition=o['normalInputPostcondition'],
                warmTerminalSeconds=o['hostOnlyBaseline']['terminalObservedElapsedSeconds'])
        else:
            pair=producer_held(case,o,composition,product,diagnostic)
            held=o['heldComposition'];r=held['result'];h=held['observation'];all_held_nonces.append(h['nonce'])
            held_acl=acl_journals(case/'h',[case/'h',case/'h/subject',case/'h/subject/temp',case/'h/host-home'])
            guards=guard_binding(case,pair,r,remote)
            if inventory_reference is None:inventory_reference=guards
            else:require(guards==inventory_reference,'Same exact source native guard inventory differs across cases')
            metadata=metadata_proofs(case,scenario,o,pair)
            final_inventory_bytes(case/'h',h['postexit'],composition.ROLE_PATHS)
            relation=o['sourceInputRelation']
            lifecycle.append(dict(scenario=scenario,phaseFacts=relation['phaseFacts'],absentPhases=relation['absentPhases'],
                comparisons=relation['comparisons'],differences=[dict(role=physical['role'],path=physical['path'],**change)
                    for physical in relation['physicalRows'] for change in physical['changes']]))
            entry.update(heldPid=h['pid'],heldNonce=h['nonce'],heldWrapperExit=h['exit'],heldSemanticExit=r['entryExit'],
                sourceCompletion=r['sourceCompletion'],heldTerminalSeconds=h['elapsedSeconds'],heldAcl=held_acl,
                physicalRows=len(relation['physicalRows']),sourceReadQueries={name:relation[name]['readContract']['queries']
                    for name in ('heldModuleContext','heldBeforeContext','directContext') if relation[name] is not None},
                fullHeldBeforeEqualsAfter=h['before']['rows']==h['after']['rows'],
                heldPreparedEqualsBefore=pair['heldPrepared']['rows']==h['before']['rows'],
                earlyOptionRefusal=relation['earlyOptionRefusal'],metadataProofs=metadata)
        case_checks.append(entry)
        print('received '+scenario,flush=True)
    GROUP='aggregate'
    require(len(case_checks)==20 and len(all_held_nonces)==18 and len(set(all_held_nonces))==18,'Full actual/held denominator differs')
    direct_nonces=[r['observation'][leg]['nonce'] for r in report['results'] for leg in ('profileWindow','hostOnlyBaseline')]
    require(len(set(all_held_nonces+direct_nonces))==58,'Original direct/held/preparation nonce reuse')
    require(all(x['comparisons']==x['receivedComparisons'] for x in NATIVE_JOURNALS.values()),'Incomplete original native journal receiving')
    api=read(RECOVERY/'api-association.json')
    artifact=api['artifact'];run=api['run'];jobs=[j for j in api['jobs']['jobs'] if j['id']==131197436545]
    require(artifact['id']==13947627028 and artifact['size_in_bytes']==3067872
        and artifact['digest']=='sha256:'+archive['zipSha256']
        and artifact['name']=='r0016-full-entry-Windows-ps51-43220592915-2'
        and artifact['workflow_run']['id']==43220592915 and artifact['workflow_run']['head_sha']==HEAD,
        'Retained original artifact API association differs')
    require(run['id']==43220592915 and run['run_attempt']==2 and run['head_sha']==HEAD
        and run['status']=='completed' and run['conclusion']=='success','Retained original run API association differs')
    require(len(jobs)==1,'Actual PS5.1 job identity ambiguous');job=jobs[0]
    require(job['run_id']==43220592915 and job['run_attempt']==2 and job['head_sha']==HEAD
        and job['name']=='windows (ps51)' and job['status']=='completed' and job['conclusion']=='success'
        and job['started_at']=='2026-11-12T12:56:36Z' and job['completed_at']=='2026-11-12T13:13:18Z',
        'Actual PS5.1 attempt-two job association differs')
    date=lambda value:datetime.fromisoformat(value.replace('Z','+00:00'))
    require(date(job['started_at'])<=date(plan['preparedUtc'])<=date(result['phases']['fullEntry']['startedUtc'])
        <=date(result['phases']['fullEntry']['finishedUtc'])<=date(job['completed_at']),
        'Actual acquisition timestamps fall outside selected job')
    checks=dict(status='FINAL',requested_model='gpt-6-astra',actual_model='gpt-6-astra',authoring_context_reuse='no',
        other_current_reviewer_visibility='no',rootContinuity='G0028 supplied by root',base=MAIN,head=HEAD,tree=TREE,
        run=43220592915,attempt=2,artifact=13947627028,job=131197436545,
        originals=dict(zipSha256=archive['zipSha256'],tarSha256=archive['tarSha256'],members=2769,regularFiles=1648),
        cases=case_checks,jobAssociation=job,guardCoverage=inventory_reference,nativeJournals=list(NATIVE_JOURNALS.values()),
        nativeLaunchReferences=NATIVE_REFERENCE_READS,outerCustodyFacts=len(received['custodyFiles']),
        producerReceiptsCompared=len(SAVES),checks=dict(COUNTS),assertionChecks=sum(COUNTS.values()),
        limits=['Native DLL/executable/OS metadata and PowerShell AST inventory remain original Windows observations; no local native remeasurement or PowerShell parsing was performed.',
            'External executable checked_path acquisition was received through original source-bound launch references; no fake local native file was created or mapped.',
            'Original native file binding acquisition was replaced by exact retained journal comparisons and independently checked raw/canonical identity/content fields.',
            'Original save calls only compare existing archived receipts and write nothing.',
            'Source-read probes prove the fixed source-bound input association, not a global installer call trace.',
            'Independent OS containment and global transport telemetry remain unacquired.',
            'Attempt 1 remains a failed preinstaller ACL setup/capture timeout; attempt 2 does not explain its cause.',
            'PS5.1 technical evidence receiving only; no acceptance, closure, mutation, publication, or PS7 qualification.'])
    (BASE/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
    (BASE/'outer-received.json').write_text(json.dumps(received,indent=2)+'\n')
    (BASE/'api-association-received.json').write_text(json.dumps(api,indent=2)+'\n')
    (BASE/'lifecycle-deltas.json').write_text(json.dumps(dict(schema='r0016-independent-full20-lifecycle-deltas.v1',
        scope='Every changed physical field value retained; complete unchanged phase rows remain in hash-bound originals.',
        cases=lifecycle),indent=2)+'\n')
    print(json.dumps(dict(status='FINAL',cases=20,held=18,normal=2,assertionChecks=sum(COUNTS.values()),
        nativeJournals=len(NATIVE_JOURNALS),nativeComparisons=sum(x['comparisons'] for x in NATIVE_JOURNALS.values())),indent=2))

if __name__=='__main__':main()
