"""Prior independent normal raw-effect/file receiver; AST-selected with explicit read-only bindings."""
def normal_evidence(case,observation,scenario,source):
    local=case.local();o=observation
    for name,key in [('entry-profile-window','profileWindow'),('host-only-control','hostOnlyBaseline')]:
        window=o[key]
        for phase,file in [('before','profile-before-launch.json'),('atReady','profile-at-ready.json'),
                           ('after','profile-after-exit.json')]:
            require(read(case/name/file)==window[phase], 'Retained complete profile phase differs')
    require(o['entryExit']==0 and o['interceptionLoaded'] is True, 'Normal entry exit/interception differs')
    require(o['legacyLifecycleChecks']==dict(startupQuiescent=True,fullProfileUnchanged=False),
        'Raw lifecycle findings differ')
    require((case/'bootstrap-phases.txt').read_text(encoding='utf-8-sig').splitlines()==
        ['utility-wrapper-entered','native-utility-imported','output-encoding-set',
         'discovery-environment-set','all-spies-exported'], 'Bootstrap phases differ')
    tree=ast.parse(source.read_bytes())
    module=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign)
        and any(isinstance(t,ast.Name) and t.id=='MODULE' for t in n.targets))
    manifest=[n.value for n in ast.walk(tree) if isinstance(n,ast.Constant)
        and isinstance(n.value,str) and n.value.startswith("@{RootModule='Microsoft.PowerShell.Utility.psm1';")]
    require(len(manifest)==1, 'Ambiguous module manifest source')
    require((case/'modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psm1').read_bytes()
        ==module.encode('ascii').replace(b'\n',b'\r\n'), 'Interception module bytes differ')
    require((case/'modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1').read_bytes()
        ==manifest[0].encode('ascii').replace(b'\n',b'\r\n'), 'Interception manifest bytes differ')
    effects=[s.split('\t',1) for s in (case/'effects').read_text(encoding='utf-8-sig').splitlines()]
    require(effects==o['effects'],'Raw effects differ from observation')
    by=collections.defaultdict(list)
    for kind,value in effects: by[kind].append(value)
    require(set(by)==({'prompt','metadata','download','clipboard'}|
        ({'open'} if scenario=='positive' else set())), 'Unexpected effect kind')
    require(by['metadata']==['https://api.github.com/repos/BookCatKid/TablissNG/releases/latest'], 'Metadata effect differs')
    require(by['download']==['https://example.invalid/chromium','https://example.invalid/preset',
        'https://example.invalid/firefox'], 'Download sequence differs')
    require(len(by['prompt'])==3,'Prompt count differs')
    require(by['open']==(['chrome://extensions/ ','chrome://newtab/ ','about:addons ','about:newtab ']
        if scenario=='positive' else []),'Positive/NoOpen effects differ')
    bundles=list((local/'host-home').glob('SalahWidgetBundle-*'))
    require(len(bundles)==1, 'Retained bundle count differs')
    bundle=bundles[0]
    unpacked=list(bundle.glob('unpacked-*'));xpi=list((bundle/'downloads').glob('*-tabliss-firefox-signed.xpi'))
    presets=list((bundle/'presets').glob('*-salah-widget.tablissng.json'));zips=list((bundle/'downloads').glob('*-tabliss-chromium.zip'))
    require(len(unpacked)==len(xpi)==len(presets)==len(zips)==1,'Retained assets differ')
    native=lambda p:str(case.joinpath(*p.relative_to(local).parts))
    require(by['clipboard']==[native(unpacked[0]),native(presets[0]),native(xpi[0]),native(presets[0])],
        'Clipboard sequence differs')
    require(xpi[0].read_bytes()==zips[0].read_bytes()==(local/'fixture.zip').read_bytes(),
        'Retained download bytes differ from exact fixture')
    with zipfile.ZipFile(local/'fixture.zip') as z:
        require(z.namelist()==['manifest.json'] and z.read('manifest.json')==
            (unpacked[0]/'manifest.json').read_bytes(),'Extracted manifest differs')
    configured=read(presets[0]);frame=ET.fromstring(configured['data/orpul7IDXSSP']['input'])
    require(frame.tag=='iframe' and frame.attrib['src']==
        'https://theislampill.github.io/salah_widget/#lat=24.47&lon=39.61&method=4',
        'Configured canonical iframe differs')
    require(not list((local/'subject/temp').glob('SalahWidgetAttempt-*')), 'Attempt scratch retained')
    require('Manual browser installation/import remain pending' in (case/'stdout.txt').read_text(encoding='utf-8-sig'),
        'Normal completion wording differs')
    require(not (case/'stderr.txt').read_bytes(),'Normal stderr is nonempty')
    require((case/'stdout.txt').read_bytes()==(case/'entry-profile-window/stdout.raw').read_bytes()
        and (case/'stderr.txt').read_bytes()==(case/'entry-profile-window/stderr.raw').read_bytes(),
        'Normal raw stream copies differ')
    before=read(case/'subject-before.json');after=read(case/'subject-after.json')
    require(before==after and o['snapshotUnchanged'] is True, 'Subject snapshot differs')
    for rel,mode,digest in after:
        p=local/'subject'/PureWindowsPath(rel).as_posix()
        require((stat.S_ISDIR(mode) and p.is_dir() and digest=='') or
            (stat.S_ISREG(mode) and p.is_file() and sha(p.read_bytes())==digest),
            'Retained subject type/bytes differ')
    require(set(r[0] for r in after)==set(str(PureWindowsPath(p.relative_to(local/'subject')))
        for p in (local/'subject').rglob('*')), 'Retained subject membership differs')
    for rel,mode,digest in o['hostStartupState']:
        p=local/'host-home'/PureWindowsPath(rel).as_posix()
        require((stat.S_ISDIR(mode) and p.is_dir() and digest=='') or
            (stat.S_ISREG(mode) and p.is_file() and sha(p.read_bytes())==digest),
            'Retained final profile type/bytes differ')
    # Validate every final full input file byte and each role's complete membership.
    roles={'subject':'subject','profile':'host-home','modules':'modules','asset':'fixture.zip',
        'preset':'canonical-preset.json','analysisCache':'analysis-cache'}
    for role,name in roles.items():
        rows=[x for x in o['fullInputsAfter']['rows'] if x['role']==role];r=local/name
        expected={x['path'] for x in rows}
        actual={'.'}|({p.relative_to(r).as_posix() for p in r.rglob('*')} if r.is_dir() else set())
        require(expected==actual,'Final full inventory membership differs: '+role)
        for row in rows:
            p=r if row['path']=='.' else r/row['path']
            require((row['kind']=='directory' and p.is_dir()) or
                (row['kind']=='file' and p.is_file() and len(p.read_bytes())==row['bytes']
                 and sha(p.read_bytes())==row['sha256']), 'Final full inventory byte/type differs')
    return dict(effects=dict(collections.Counter(x[0] for x in effects)),retainedEntries=8,
        legacyLifecycleChecks=o['legacyLifecycleChecks'])
