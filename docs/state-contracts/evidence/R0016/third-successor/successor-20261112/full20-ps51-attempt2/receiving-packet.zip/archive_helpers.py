"""Read-only archive path and strict-JSON helpers, copied from the previously received reviewer helper. No acquisition code."""
import ast
import collections
import hashlib
import json
from pathlib import Path, PureWindowsPath, PurePosixPath
COUNTS=collections.Counter()
GROUP="standalone"

def require(condition, message, *args):
    COUNTS[GROUP] += 1
    if not condition:
        raise AssertionError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def strict_json(data):
    if isinstance(data, (Path, WPath)):
        data = data.read_bytes()
    if isinstance(data, bytes):
        data = data.decode('utf-8-sig')
    def pairs(items):
        d = {}
        for k,v in items:
            require(k not in d, 'duplicate JSON key: ' + k)
            d[k] = v
        return d
    def bad(value):
        raise ValueError('nonfinite JSON: ' + value)
    return json.loads(data, object_pairs_hook=pairs, parse_constant=bad)

class WPath(PureWindowsPath):
    """Read-only adapter; raw Windows paths and JSON values are never rewritten."""
    mappings = []

    def local(self):
        for remote, local in self.mappings:
            if self.is_relative_to(remote):
                return local.joinpath(*self.relative_to(remote).parts)
        raise ValueError('No archive mapping for requested read: ' + str(self))

    def resolve(self, strict=False):
        if strict:
            require(self.local().exists(), 'missing archived path: ' + str(self))
        return self

    def read_bytes(self):
        return self.local().read_bytes()

    def read_text(self, encoding=None, errors=None):
        return self.local().read_text(encoding=encoding, errors=errors)

    def is_file(self):
        return self.local().is_file()

    def is_dir(self):
        return self.local().is_dir()

    def exists(self):
        return self.local().exists()

    def is_symlink(self):
        return self.local().is_symlink()

    def stat(self):
        return self.local().stat()

    def lstat(self):
        return self.local().lstat()

    def iterdir(self):
        return (self / p.name for p in self.local().iterdir())

def fact(path, owner=None):
    p = WPath(path).resolve(strict=True)
    require(p.is_file(), 'file fact is not a regular member')
    if owner is not None:
        require(p.is_relative_to(WPath(owner)), 'file fact escaped the owner')
    b = p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=sha(b))

def checked_path(path, owner=None, directory=False):
    p = WPath(path).resolve(strict=True)
    require(p.is_dir() if directory else p.is_file(), 'wrong file type')
    require(not p.is_symlink(), 'unexpected link')
    if owner is not None:
        require(p.is_relative_to(WPath(owner)), 'path escaped owner')
    return p

def verify_fact(record, path, owner=None):
    value = fact(path, owner)
    require(record == value, 'archived file fact mismatch: ' + str(path))
    return value

def select_definitions(path, function_names, assignments=(), class_names=()):
    tree = ast.parse(path.read_text(encoding='utf-8-sig'))
    nodes=[]
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in function_names:
            nodes.append(node)
        elif isinstance(node, ast.ClassDef) and node.name in class_names:
            nodes.append(node)
        elif isinstance(node, ast.Assign) and any(isinstance(t,ast.Name) and t.id in assignments for t in node.targets):
            nodes.append(node)
    require(len([n for n in nodes if isinstance(n,ast.FunctionDef)])==len(function_names), 'missing selected pure function')
    return compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec')
