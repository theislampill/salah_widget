#!/usr/bin/env python3
"""Data-only preservation, source, receipt-link and private patch verification."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import posixpath
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent.parent
REPO = WORK / 'salah_widget'
PRIOR = ROOT.parent / 'docs_candidate'
HEAD = 'a89bbb3ddac639cc787ba08d030e8b2539057387'
TREE = 'efa716f4c8f1fe61c1a5a85b48bd97e813305d16'
BASE = '3b0e614114ef066de40db117d0e85c0031cf3e30'
PREVIOUS = '9c05df0b7546a7c897c6e1ab5b197f0087b5c2e4'
DIAGNOSTIC = '12904a880c38b749db2d7c79ec1e7cebde2e04e2'
MD = 'docs/state-contracts/R0016.md'
MATRIX = 'docs/state-contracts/evidence/R0016/current-acceptance-matrix.json'
HISTORY = 'docs/state-contracts/evidence/R0016/historical-matrix.json'
EVIDENCE = 'docs/state-contracts/evidence/R0016/'
PUB = 'third-successor/successor-20261112/'
checks = []

def check(name, value, detail=None):
    checks.append(dict(name=name, passed=bool(value), **({'detail':detail} if detail is not None else {})))

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(path, commit=HEAD):
    return subprocess.check_output(['git', '-C', str(REPO), 'show', commit + ':' + path])

def read(name):
    return json.loads((ROOT/name).read_text())

def strings(value):
    if isinstance(value, str):
        yield value
    elif isinstance(value, list):
        for item in value:
            yield from strings(item)
    elif isinstance(value, dict):
        for item in value.values():
            yield from strings(item)

baseline = {p:(ROOT/'baseline'/p).read_bytes() for p in (MD,MATRIX,HISTORY)}
candidates = {p:(ROOT/'candidate'/p).read_bytes() for p in (MD,MATRIX)}
old = json.loads(baseline[MATRIX])
new = json.loads(candidates[MATRIX])
history = json.loads(baseline[HISTORY])
prior = json.loads((PRIOR/'candidate'/MATRIX).read_text())
mapping = json.loads(git(EVIDENCE+PUB+'mapping/current-mapping-reconciled.json'))
inputs = read('input-bindings.json')
bindings = read('candidate-bindings.json')
reuse = read('source-reuse-validation.json')
links = read('publication-link-manifest.json')
gaps = read('per-obligation-gaps.json')

for path in (MD,MATRIX,HISTORY):
    check('immutable baseline ' + path, baseline[path] == git(path))
    check('shared file unchanged at verification ' + path, (REPO/path).read_bytes() == baseline[path])
check('exact head tree', subprocess.check_output(['git','-C',str(REPO),'show','-s','--format=%T',HEAD],text=True).strip()==TREE)
check('accepted base ancestor', subprocess.run(['git','-C',str(REPO),'merge-base','--is-ancestor',BASE,HEAD],capture_output=True).returncode==0)
check('historical matrix exact digest', sha(baseline[HISTORY])=='828638072d532c8e2e2167248c89d3ad19e707addac7db65e4742e4112e61dac')
check('historical matrix absent from candidate writes', not (ROOT/'candidate'/HISTORY).exists())
for item in inputs['priorPrivateInputs']:
    data=(PRIOR/item['path']).read_bytes()
    check('prior private candidate custody ' + item['path'], len(data)==item['bytes'] and sha(data)==item['sha256'])
check('prior private exact expected matrix digest', sha((PRIOR/'candidate'/MATRIX).read_bytes())=='de27adf926924d521adbf044efc04cad324e9a81081aba4bb027c691daade4f2')
check('prior private exact expected Markdown digest', sha((PRIOR/'candidate'/MD).read_bytes())=='964a9d7e773fdc126761c38c8575d0d196b04a1429cae1b39e7488ad958c8980')

check('schema unchanged', new['schema']==old['schema'])
check('contract and common references unchanged', all(new[k]==old[k] for k in ('contract','common','historySha256')))
check('exact original denominator', new['denominator']==old['denominator']==dict(requirements=14,residual_acceptance=6,branch_matrix=15,effects=11,total=46))
check('exact 46 rows in all projections',len(new['rows'])==len(old['rows'])==len(prior['rows'])==len(mapping['rows'])==len(gaps['rows'])==46)
check('exact IDs and order', [r['id'] for r in new['rows']]==[r['id'] for r in old['rows']]==[r['id'] for r in prior['rows']]==[r['id'] for r in mapping['rows']]==[r['id'] for r in gaps['rows']])
check('unique original IDs',len(set(r['id'] for r in new['rows']))==46)
check('category counts unchanged',Counter(r['category'] for r in new['rows'])==dict(requirements=14,residual_acceptance=6,branch_matrix=15,effects=11))
mutable={'currentStatus','currentEvidence','remaining'}
for i,(before,after,private,mapped,gap) in enumerate(zip(old['rows'],new['rows'],prior['rows'],mapping['rows'],gaps['rows'])):
    rid=before['id']
    for key in ('id','category','obligation','historicalStatus','historicalPointer'):
        check(rid+': original '+key, before[key]==after[key]==private[key]==mapped[key])
    check(rid+': every original noncurrent field preserved',all(after[k]==v for k,v in before.items() if k not in mutable))
    check(rid+': prior private noncurrent fields preserved',all(after[k]==v for k,v in private.items() if k not in mutable))
    expected=dict(id=rid,**{k:before[k] for k in ('currentStatus','currentEvidence','remaining')})
    check(rid+': replaced published current fields archived exactly',new['historicalPublishedRowProjectionBeforeA89Reconciliation'][i]==expected)
    node=history
    for part in after['historicalPointer'].split('#',1)[1].strip('/').split('/'):
        part=part.replace('~1','/').replace('~0','~')
        node=node[int(part)] if isinstance(node,list) else node[part]
    check(rid+': historical pointer resolves',isinstance(node,dict) and node.get('id',rid)==rid)
    check(rid+': all receipt joins resolve',all(j in new['currentEvidenceReceiptJoins'] for j in after['currentReceiptJoins']))
    check(rid+': mapping row link retains exact index',any('current-mapping-reconciled.json#/rows/'+str(i)+';' in s for s in after['currentEvidence']))
    check(rid+': original gates only',after['currentRemainingGateIds']==mapped['remainingTechnicalGates']+['T05']+mapped['externalGates'])
    check(rid+': per-obligation gap exact identity',gap['id']==rid and gap['category']==after['category'] and gap['obligation']==after['obligation'])
    check(rid+': per-obligation gate mapping unchanged',gap['originalTechnicalGates']==mapped['remainingTechnicalGates'] and gap['originalExternalGates']==mapped['externalGates'] and gap['finalIndependentGate']=='T05')
    check(rid+': no acceptance',gap['proposedAcceptance'] is None and 'NO_ACCEPTANCE' in after['currentStatus'] and bool(after['remaining']))
    check(rid+': current PS7 receiving not falsely pending',not any('PS7' in s and 'awaiting independent receiving' in s for s in after['currentEvidence']))

for key in set(old)-{'recordedUtc','scope','dependency','rows','deltaFrontier','scopedCurrentPowerShell','scopedCurrentLinux'}:
    check('published historical top level retained '+key,new[key]==old[key])
for historical_key,original in [('historicalDependencyAt9c05','dependency'),('historicalDeltaFrontierAt9c05','deltaFrontier'),('historicalScopedPowerShell69','scopedCurrentPowerShell'),('historicalScopedLinux45Candidate4','scopedCurrentLinux')]:
    check('replaced top-level projection archived '+original,new[historical_key]==old[original])
check('delta IDs/order exact',list(new['deltaFrontier'])==list(old['deltaFrontier']))
check('unchanged D04 and D08',all(new['deltaFrontier'][k]==old['deltaFrontier'][k] for k in ('D04','D08')))
check('only existing T01-T05',list(new['technicalFrontier'])==list(mapping['technicalFrontier'])==['T01','T02','T03','T04','T05'])
check('only existing X01-X04',list(new['externalGates'])==list(mapping['externalGates'])==['X01','X02','X03','X04'])
check('external gates unchanged except explicit owner merge requirement',all(new['externalGates'][k]==mapping['externalGates'][k] for k in ('X01','X03','X04')))
check('owner approval remains prior to main merge','owner merge approval before integration into main' in new['externalGates']['X02']['minimum'])
check('no acceptance numerator',new['acceptanceNumerator'] is None)
check('all satisfaction flags remain false',all(new[k] is False for k in ('wholeContractSatisfied','nativeAppleSatisfied','nativeWindowsSatisfied','finalPublicDeliverySatisfied')))
check('root admission and final review unclaimed',new['currentReconciliation']['rootAdmission'] is False and new['currentReconciliation']['finalIndependentExact46Review'] is False)

check('current dependency exact head/tree/base',new['dependency']['head']==HEAD and new['dependency']['tree']==TREE and new['dependency']['acceptedMain']==BASE)
for entry in new['dependency']['sourceAncestry']:
    parents=subprocess.check_output(['git','-C',str(REPO),'show','-s','--format=%P',entry['commit']],text=True).strip().split()
    check('ancestry exact parents '+entry['commit'],parents==entry['parents'])
for path,item in new['currentReconciliation']['sourceBindings'].items():
    data=git(path)
    blob=subprocess.check_output(['git','-C',str(REPO),'rev-parse',HEAD+':'+path],text=True).strip()
    check('current exact source bytes/blob '+path,item['commit']==HEAD and len(data)==item['bytes'] and sha(data)==item['sha256'] and blob==item['gitBlob'])
for path,digest,blob in [('install.sh','27442c0e6a6dbd6390ba1ea9b8b3efa2bfb2a910037e2c415756f9169a5c7b3f','e2e2640eb85adf302c87305cd68d642743785bb1'),('install.ps1','07671cb9e6a0afb8eb9051a0a5f378d12e577877453a773860b3cf94d5e2951a','28cfdae73305a2a2e5a58e30878bffea7b5142b8')]:
    for commit in (PREVIOUS,DIAGNOSTIC,HEAD):
        data=git(path,commit)
        actual_blob=subprocess.check_output(['git','-C',str(REPO),'rev-parse',commit+':'+path],text=True).strip()
        check('installer unchanged '+path+' at '+commit,sha(data)==digest and actual_blob==blob)
changed=[]
for entry in reuse['roles']:
    data=git(entry['path'])
    current=entry['current']
    check('source role physical equality '+entry['lane']+'/'+entry['path'],len(data)==current['bytes'] and sha(data)==current['sha256'] and entry['equal']==(sha(data)==entry['receiptSha256']))
    if not entry['equal']:
        changed.append((entry['lane'],entry['path']))
check('exact one broad-catalog exception',changed==[('posix-mac','tests/install-entry-native-composition.py')])
check('source association has 92 received roles',len(reuse['roles'])==92)
check('Mac captured catalog exactly49/50 unchanged',len([r for r in reuse['roles'] if r['lane']=='posix-mac'])==50 and sum(r['equal'] for r in reuse['roles'] if r['lane']=='posix-mac')==49)
for entry in reuse['macExecutedScope']:
    check('Mac executed-scope exact input '+entry['path'],git(entry['path'],entry['acquired']['commit'])==git(entry['path']) and entry['equal'])
check('changed Windows owner absent from Mac executed-scope list','tests/install-entry-native-composition.py' not in [r['path'] for r in reuse['macExecutedScope']])
check('Mac native carrier omits changed owner',b'install-entry-native-composition.py' not in git('tools/qualification/installer_native.py'))
for entry in reuse['reuseFixtures']:
    check('bounded reuse fixture still exact '+entry['path'],sha(git(entry['path']))==entry['receipt']['sha256'] and entry['equal'])
check('presets/generated/authored config/V1 unchanged from accepted base',not subprocess.check_output(['git','-C',str(REPO),'diff','--name-only',BASE,HEAD,'--',*reuse['preservationAgainstAcceptedBase']['paths']],text=True))

ps7_checks=json.loads((ROOT.parent/'full20_ps7_a89/checks.json').read_text())
ps51_checks=json.loads((ROOT.parent/'full20_ps51_a89/checks.json').read_text())
check('PS7 actual20 receipt facts',ps7_checks['status']=='PASS' and ps7_checks['commit']==HEAD and all(ps7_checks[k]==v for k,v in [('caseCount',20),('previewCount',18),('normalCount',2),('earlyRefusals',2),('nonceCount',58),('nativeBindingCount',468),('rawFullInventoryCount',244),('aclSetupCount',38)]))
check('PS51 adverse receipt exact head and zero credit',ps51_checks['status']=='FINAL' and ps51_checks['head']==HEAD and 'zero installer/scenario pass credit' in ps51_checks['verdict'])
check('PS7 receiving report digest',sha((ROOT.parent/'full20_ps7_a89/report.md').read_bytes())=='6df2d3a516debe53c1faf86adbb4027237c865e72b2f03e5779ac0602ea80606')
check('PS7 manifest exact parent supplied digest',sha((ROOT.parent/'full20_ps7_a89/manifest.json').read_bytes())=='47cdbe297448e5d5ef629895816c1edad1b3bd7d4cdc16ce029da47612a50b38')
check('PS51 adverse report digest',sha((ROOT.parent/'full20_ps51_a89/report.md').read_bytes())=='a5aea3347022083facb0cd6f3b19ea882adaa3d30fbe186355cf64ae0c9c8ad0')
full20=new['currentEvidenceReceiptJoins']['J_WFULL20']
case_breakdown=full20['caseBreakdown']
check('correct case denominator20=18preview+2normal',case_breakdown['total']==20 and case_breakdown['preview']==18 and case_breakdown['normal']==2 and case_breakdown['earlyOptionRefusalsWithinPreview']==2)
check('18 held belong to preview not normal',case_breakdown['heldRelationships']==18 and 'All18 preview cases' in case_breakdown['note'] and '2 normal cases instead' in case_breakdown['note'])
check('no two-host full20 claim',full20['full20Passed'] is False and new['scopedCurrentPowerShell']['fullEntryPassed'] is False and new['currentReconciliation']['candidateQualificationUpdate']['full20Passed'] is False)
check('PS7 received scope and PS51 failure received',full20['attempts'][0]['hosts']['ps766']['independentReceiving']=='FINAL_PASS_ALL20_SCOPED_ROOT_ADMISSION_PENDING' and full20['attempts'][0]['hosts']['ps51']['independentReceiving']=='FINAL_ADVERSE_BOOTSTRAP_RECEIVED_ZERO_INSTALLER_CASES')
check('PS51 completed installer cases exactly0',full20['attempts'][0]['hosts']['ps51']['completedInstallerCases']==0)
check('PS7 observed cases exactly20',full20['attempts'][0]['hosts']['ps766']['completedInstallerCases']==20)
check('attempt2 PS51 pending not assumed green',full20['attempts'][1]['ps51']['state']=='IN_PROGRESS' and full20['attempts'][1]['ps51']['qualifiedCases'] is None)
check('attempt2 PS7 not double-counted',full20['attempts'][1]['ps766']['newNativeExecution'] is False and full20['attempts'][1]['ps766']['originalJob']=='131190813338')
check('T01 and T05 remain open',new['technicalFrontier']['T01']['state']=='OPEN' and new['technicalFrontier']['T05']['state']=='OPEN')
for entry in read('retained-archive-joins.json')['originals']:
    for key in ('summaryFact','archive','route','composition'):
        item=entry[key];data=(WORK/item['path']).read_bytes()
        check('retained archive custody '+entry['host']+'/'+key,len(data)==item['bytes'] and sha(data)==item['sha256'])
    artifact=entry['artifact']
    check('retained artifact metadata exact '+entry['host'],artifact['workflow_run']['id']==43220592915 and artifact['workflow_run']['head_sha']==HEAD and artifact['size_in_bytes']==entry['archive']['bytes'] and artifact['digest']=='sha256:'+entry['archive']['sha256'])
    route=json.loads((WORK/entry['route']['path']).read_text())
    report=json.loads((WORK/entry['composition']['path']).read_text())
    check('retained current source/test source association '+entry['host'],route['sourceCommit']==HEAD and report['sourceFact']['sha256']==sha(git('install.ps1')) and report['testSha256']==sha(git('tests/install-entry-native-composition.py')))
    if entry['host']=='ps51':
        row=report['results'][0]
        check('PS51 original bootstrap classification preserved',len(report['results'])==1 and row['classification']=='BOOTSTRAP_BLOCKED' and row['observation']['installerExecuted'] is False and route['fullEntryAccepted'] is False)
    else:
        check('PS7 original reported20 distinct ordered cases preserved',report['status']=='PASS' and len(report['results'])==20 and all(r['pass_'] is True for r in report['results']) and [r['case'] for r in report['results']]==route['expectedCases'])

preparation=new['windowsNormalPreparationHistory']
check('old warm20 failure unchanged738to8917',preparation['oldWarm20']['strictFailures']==2 and preparation['oldWarm20']['strictPasses']==0 and preparation['oldWarm20']['cacheBytesBefore']==738 and preparation['oldWarm20']['cacheBytesAfter']==8917)
check('later warm20 plus warm-json four strict passes',preparation['laterWarm20AndWarmJson']['warm20StrictPasses']==2 and preparation['laterWarm20AndWarmJson']['warmJsonStrictPasses']==2 and preparation['laterWarm20AndWarmJson']['stableCacheBytes']==738)
check('diagnostic gives zero full20 credit',preparation['productCredit']==0)
check('causality and immutable diagnostic remain explicit','Unresolved' in preparation['causality'] and 'not established as unique, necessary or sufficient' in preparation['causality'] and preparation['diagnosticHead']==DIAGNOSTIC)
check('historical diagnostic not silently repinned',git('tools/qualification/installer_preview_windows_normal_profile_diagnostic.py',DIAGNOSTIC)==git('tools/qualification/installer_preview_windows_normal_profile_diagnostic.py'))

destinations={r['destination']:r for r in links['links']}
for item in links['links']:
    data=Path(item['source']).read_bytes()
    check('parent-proposed evidence destination exact '+item['destination'],len(data)==item['bytes'] and sha(data)==item['sha256'] and item['publicationState']=='PARENT_SPECIFIED_DESTINATION_NOT_PUBLISHED_BY_THIS_TASK')
def link_data(relative):
    path=EVIDENCE+relative
    if path in destinations:
        return Path(destinations[path]['source']).read_bytes()
    return git(path)
for item in new['currentReconciliation']['receivingReports']:
    data=link_data(item['path'])
    check('receiving report exact bytes/hash '+item['path'],len(data)==item['bytes'] and sha(data)==item['sha256'])
for key,join in new['currentEvidenceReceiptJoins'].items():
    for field in ('receipt','reuseManifest','preparationReview','calibrationReceipt','historicalDiagnosticBoundary'):
        if field in join:
            item=join[field];data=link_data(item['path'])
            check('receipt alias target '+key+'/'+field,('sha256' not in item or sha(data)==item['sha256']) and ('bytes' not in item or len(data)==item['bytes']))
for target in sorted(set(re.findall(r'\]\(([^)]+)\)',candidates[MD].decode()))):
    if re.match(r'^[a-z]+://',target):
        continue
    path=posixpath.normpath(posixpath.join(posixpath.dirname(MD),target.split('#',1)[0]))
    exists=path in destinations or subprocess.run(['git','-C',str(REPO),'cat-file','-e',HEAD+':'+path],capture_output=True).returncode==0
    check('Markdown relative link existing or exact parent destination '+target,exists)
newlinks=set()
for s in strings(new):
    newlinks.update(re.findall(r'third-successor/successor-20261112/[A-Za-z0-9_./-]+',s))
for relative in sorted(newlinks):
    path=EVIDENCE+relative
    exists=path in destinations or subprocess.run(['git','-C',str(REPO),'cat-file','-e',HEAD+':'+path],capture_output=True).returncode==0
    check('matrix current relative link resolves '+relative,exists)
check('candidate files contain no private machine paths',all('/workspace/' not in data.decode() and '/home/agent/' not in data.decode() for data in candidates.values()))

md=candidates[MD].decode()
prior_md=(PRIOR/'candidate'/MD).read_text()
for prefix in ('The original Bash42 attempt','Independent PowerShell evidence-parser review','Actual Apple run43099184164','The G0006 recovery checkpoint'):
    original=next(p for p in prior_md.split('\n\n') if p.startswith(prefix))
    check('historical narrative paragraph retained '+prefix,original in md)
for label,needle in {
    'Linux adverse37/45':'FAIL37/45',
    'Mac targeted-log gap':'ACQUISITION_GAP',
    'Mac41 cache delta':'adds41 Python-cache entries',
    'Windows unequal lifecycles':'152 unequal full lifecycles',
    'Windows independent containment gap':'independentHardContainment=NOT_ACQUIRED',
    'documentation clipped command':'horizontally clipped',
    'documentation blank widget':'blank widget',
    'new PS7 unequal direct lifecycles':'All20 PS7 direct full-profile and complete-input before/after lifecycles remain unequal.',
    'new PS7 held scope':'All18 preview held source windows are equal',
    'early direct refusal boundary':'Those2 direct refusals have no discovery boundary',
    'PS51 bootstrap zero credit':'product credit is0',
    'cache causality':'not established as unique, necessary or sufficient',
    'owner merge gate':'separate owner merge approval',
}.items():
    check('retained boundary '+label,needle in md)
check('no stale full20 PS7 receiving-pending prose','PS7 producer reports20-case PASS awaiting independent receiving' not in md and 'Independent receiving is pending in this projection' not in md)
check('no incorrect held normal attribution','16 non-early preview and2 normal' not in md and 'sixteen non-early preview plus two normal' not in json.dumps(new))

patch=(ROOT/'candidate.patch').read_bytes()
paths=re.findall(r'^diff --git a/(\S+) b/(\S+)$',patch.decode(),re.M)
check('patch exactly requested two paths',paths==[(MD,MD),(MATRIX,MATRIX)])
with tempfile.TemporaryDirectory(prefix='patch-proof-',dir=ROOT) as temp:
    target=Path(temp)
    for path,data in baseline.items():
        dest=target/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    dry=subprocess.run(['git','apply','--check',str(ROOT/'candidate.patch')],cwd=target,capture_output=True,text=True)
    check('patch dry-run against exact immutable private baseline',dry.returncode==0,dict(exit=dry.returncode,stderr=dry.stderr))
    applied=subprocess.run(['git','apply',str(ROOT/'candidate.patch')],cwd=target,capture_output=True,text=True)
    check('patch actual private application',applied.returncode==0,dict(exit=applied.returncode,stderr=applied.stderr))
    for path,data in candidates.items():
        check('applied file equals candidate '+path,(target/path).read_bytes()==data)
    check('private application leaves historical matrix untouched',(target/HISTORY).read_bytes()==baseline[HISTORY])
for item in bindings['candidate']:
    data=candidates[item['path']]
    check('candidate manifest '+item['path'],len(data)==item['bytes'] and sha(data)==item['sha256'])
check('patch manifest exact',len(patch)==bindings['patch']['bytes'] and sha(patch)==bindings['patch']['sha256'])
ast.parse((ROOT/'prepare_projection.py').read_text())
check('preparation script parses',True)
failed=[r for r in checks if not r['passed']]
out=dict(status='PASS_PRIVATE_PROJECTION' if not failed else 'GAP',
    head=HEAD, tree=TREE, acceptedBase=BASE,
    authority='Author-side data/source/preservation/link/patch verification only. No independent acceptance or native receiving is executed here.',
    authoringContextReuse=True, otherReviewerVisibility=True,
    checksPassed=len(checks)-len(failed), checksTotal=len(checks), failures=failed, checks=checks,
    historicalMatrixSha256=sha(baseline[HISTORY]), candidate=bindings['candidate'], patchSha256=sha(patch),
    remaining=['PS5.1 attempt2 terminal and independent full20 receiving','Root admission of scoped receipts/reuse','Final independent original46 reconciliation','Existing owner approval/integration, dependency handoff, public delivery/certificate/closure gates'],
    limits=['Parent-specified new receiving destinations are not publication by this task.',
            'Current-state cutoff is the supplied in-progress PS5.1 attempt2 checkpoint.',
            'Original case receipts are used as evidence; no installer, PowerShell, native acquisition, archived module or rendered site was executed.'])
(ROOT/'checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ('status','head','checksPassed','checksTotal','failures')},indent=2))
raise SystemExit(0 if not failed else 1)
