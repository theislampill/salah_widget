#!/usr/bin/env python3
"""Prepare data-only R0016 documentation projection. Writes only beside this file."""
import copy
import datetime as dt
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent.parent
REPO = WORK / 'salah_widget'
PRIOR = ROOT.parent / 'docs_candidate'
HEAD = 'a89bbb3ddac639cc787ba08d030e8b2539057387'
TREE = 'efa716f4c8f1fe61c1a5a85b48bd97e813305d16'
PREVIOUS = '9c05df0b7546a7c897c6e1ab5b197f0087b5c2e4'
DIAGNOSTIC = '12904a880c38b749db2d7c79ec1e7cebde2e04e2'
BASE = '3b0e614114ef066de40db117d0e85c0031cf3e30'
MD = 'docs/state-contracts/R0016.md'
MATRIX = 'docs/state-contracts/evidence/R0016/current-acceptance-matrix.json'
HISTORY = 'docs/state-contracts/evidence/R0016/historical-matrix.json'
EVIDENCE = 'docs/state-contracts/evidence/R0016/'
PUB = 'third-successor/successor-20261112/'
NOW = dt.datetime.now(dt.timezone.utc).isoformat()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write_json(path, obj):
    path = ROOT / path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')

def git_bytes(path, commit=HEAD):
    return subprocess.check_output(['git', '-C', str(REPO), 'show', commit + ':' + path])

def fact(path, commit=HEAD):
    data = git_bytes(path, commit)
    blob = subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', commit + ':' + path], text=True).strip()
    return dict(commit=commit, path=path, bytes=len(data), sha256=sha(data), gitBlob=blob)

def file_fact(path, label=None):
    data = path.read_bytes()
    return dict(path=label or str(path.relative_to(ROOT)), bytes=len(data), sha256=sha(data))

def receipt(relative):
    data = git_bytes(EVIDENCE + relative)
    return dict(path=relative, bytes=len(data), sha256=sha(data))

def load_pub(relative):
    return json.loads(git_bytes(EVIDENCE + PUB + relative))

def pending_receipt(directory, lane, filename='report.md'):
    source = ROOT.parent / directory / filename
    data = source.read_bytes()
    return dict(path=PUB + lane + '/' + filename, bytes=len(data), sha256=sha(data))

baseline = {}
for path in (MD, MATRIX, HISTORY):
    data = git_bytes(path)
    baseline[path] = data
    dest = ROOT / 'baseline' / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
prior_matrix_bytes = (PRIOR / 'candidate' / MATRIX).read_bytes()
prior_md_bytes = (PRIOR / 'candidate' / MD).read_bytes()
prior = json.loads(prior_matrix_bytes)
old = json.loads(baseline[MATRIX])
new = copy.deepcopy(prior)
mapping = load_pub('mapping/current-mapping-reconciled.json')
prior_inputs = [file_fact(p, str(p.relative_to(PRIOR))) for p in sorted(PRIOR.rglob('*')) if p.is_file()]
future_links = []
for directory, lane in [('full20_ps7_a89', 'full20-ps7-attempt1'), ('full20_ps51_a89', 'full20-ps51-attempt1')]:
    for filename in ('report.md', 'checks.json', 'manifest.json'):
        source = ROOT.parent / directory / filename
        item = pending_receipt(directory, lane, filename)
        future_links.append(dict(source=str(source), destination=EVIDENCE + item['path'],
            bytes=item['bytes'], sha256=item['sha256'],
            publicationState='PARENT_SPECIFIED_DESTINATION_NOT_PUBLISHED_BY_THIS_TASK'))
ps7_receipt = pending_receipt('full20_ps7_a89', 'full20-ps7-attempt1')
ps51_receipt = pending_receipt('full20_ps51_a89', 'full20-ps51-attempt1')
assert ps7_receipt['sha256'] == '6df2d3a516debe53c1faf86adbb4027237c865e72b2f03e5779ac0602ea80606'
assert ps51_receipt['sha256'] == 'a5aea3347022083facb0cd6f3b19ea882adaa3d30fbe186355cf64ae0c9c8ad0'
write_json('publication-link-manifest.json', dict(head=HEAD, links=future_links,
    note='These six exact existing private receipt files have parent-specified publication destinations. The author performs no publication.'))

# Exact present-source association; no archived execution or source imports.
source_roles = []
posix = load_pub('posix/source-bindings.json')
for row in posix:
    actual = fact(row['path'])
    source_roles.append(dict(lane='posix-' + row['platform'], path=row['path'],
        receiptSha256=row['declared_sha256'], current=actual,
        equal=row['declared_sha256'] == actual['sha256']))
windows = load_pub('windows/checks.json')
for host in ('ps51', 'ps766'):
    for path, row in windows[host]['inputSources'].items():
        actual = fact(path)
        source_roles.append(dict(lane='windows-core-normal-' + host, path=path,
            receiptSha256=row['sha256'], current=actual, equal=row['sha256'] == actual['sha256']))
routes = load_pub('windows/routes-checks.json')
for host in ('ps51', 'ps766'):
    for row in routes['routes'][host]['sourceInputs']:
        path = row['role']
        actual = fact(path)
        source_roles.append(dict(lane='windows-routes-' + host, path=path,
            receiptSha256=row['sha256'], current=actual, equal=row['sha256'] == actual['sha256']))
docs = load_pub('docs/source-bindings.json')
for row in docs['inputs'] + [docs['producer'], docs['workflow']]:
    actual = fact(row['path'])
    source_roles.append(dict(lane='docs', path=row['path'], receiptSha256=row['sha256'],
        current=actual, equal=row['sha256'] == actual['sha256']))

mac_executed = [
    'install.sh', 'tests/install-bash.py', 'tests/install-entry-bash.py',
    'tests/install-discovery.py', 'tests/install-detectors.py',
    'tests/install-discovery-mutations.py', 'tests/install-mutations.py',
    'tests/install-builder.cjs', 'tests/install-staging-native.py',
    'tests/install-staging-parent.py', 'tests/install-staging-readonly.py',
    'tests/install-preview.py', 'tools/qualification/installer_native.py',
    '.github/workflows/installer-preview-macos-native.yml',
    'src/native/builder.html', 'src/native/config.js', 'presets/salah-widget.tablissng.json',
]
mac_scope = [dict(path=p, acquired=fact(p, '8a360f549a7d9ff291b91d2e62e848c72b78d38d'),
                  current=fact(p), equal=git_bytes(p, '8a360f549a7d9ff291b91d2e62e848c72b78d38d') == git_bytes(p))
             for p in mac_executed]
reuse_manifest = load_pub('mapping/unchanged-region-reuse.reconstructed.json')
reuse_fixtures = [dict(path=p, current=fact(p), receipt=rows[-1],
                       equal=fact(p)['sha256'] == rows[-1]['sha256'])
                  for p, rows in reuse_manifest['fixtures'].items()]
preserved_paths = ['src/native/builder.html', 'src/native/config.js', 'builder.html', 'config.js', 'presets', 'v1']
preserved_diff = subprocess.check_output(['git', '-C', str(REPO), 'diff', '--name-only', BASE, HEAD, '--', *preserved_paths], text=True)
source_reuse = dict(schema='r0016-a89-source-reuse.v1', authority='Data/source association only; no native receiving or acceptance.',
    head=HEAD, tree=TREE, acceptedBase=BASE, originalReceiverHead=PREVIOUS,
    roles=source_roles, macExecutedScope=mac_scope, reuseFixtures=reuse_fixtures,
    macCatalogDifference=dict(path='tests/install-entry-native-composition.py',
        role='Broad tests/install* inventory member; not an executed Darwin suite input.',
        actualMacSuites=[r['name'] for r in load_pub('posix/mac-suites.json')],
        producer='tools/qualification/installer_native.py',
        note='49 of 50 catalogued Mac source roles remain equal. The changed Windows-only composition owner does not acquire Mac execution credit.'),
    preservationAgainstAcceptedBase=dict(paths=preserved_paths, diff=preserved_diff),
    limits=['Source equality preserves recorded scope, not remote currentness or a native rerun.',
            'Original18 transfers only the 15 reviewed behavior rows, not the 3 historical parser/ASCII rows.',
            'Current full20 has changed owner bytes and needs its own exact native acquisition/receiving.'])
write_json('source-reuse-validation.json', source_reuse)

# Record original a89 archive metadata and terminal summaries without replaying any receiver.
attempt1 = {}
local_archive_joins = []
for host, job in (('ps51', '131190813869'), ('ps766', '131190813338')):
    root = WORK / 'recovery/full20-a89' / host
    summary_path = root / 'summary.json'
    summary = json.loads(summary_path.read_text())
    artifact = summary['artifact']
    archive_path = root / summary['zip_file']
    route_path = root / 'extracted/installer-evidence/route-result.json'
    route = json.loads(route_path.read_text())
    composition_path = next((root / 'extracted/installer-evidence/f').glob('*/entry-composition-report.json'))
    composition = json.loads(composition_path.read_text())
    item = dict(host='PS5.1' if host == 'ps51' else 'PS7.6.6', job=job,
        jobConclusion='failure' if host == 'ps51' else 'success',
        jobConclusionSource='Parent live status; archive terminal summary checked locally.',
        artifact=str(artifact['id']), archive=dict(name=archive_path.name, bytes=archive_path.stat().st_size, sha256=sha(archive_path.read_bytes())),
        artifactUrl=artifact['url'], artifactDownloadUrl=artifact['archive_download_url'],
        routeResult=dict(name='route-result.json', bytes=route_path.stat().st_size, sha256=sha(route_path.read_bytes()), status=route['status']),
        compositionReport=dict(name='entry-composition-report.json', bytes=composition_path.stat().st_size, sha256=sha(composition_path.read_bytes()), status=composition['status']),
        nativeVersion=route['nativeHost']['version'], sourceCommit=route['sourceCommit'],
        reportedFullEntryAccepted=route['fullEntryAccepted'],
        sourceAndInputsUnchanged=route['sourceAndInputsUnchanged'],
        completedInstallerCases=0 if host == 'ps51' else 20,
        independentReceiving=('FINAL_ADVERSE_BOOTSTRAP_RECEIVED_ZERO_INSTALLER_CASES' if host == 'ps51' else 'FINAL_PASS_ALL20_SCOPED_ROOT_ADMISSION_PENDING'),
        receivingReceipt=ps51_receipt if host == 'ps51' else ps7_receipt,
        rootAdmission=False,
        limits=('c00 parent ACL setup timed out at the unchanged 60-second bound before any installer case; zero product-case credit. No cause or repair is established here.' if host == 'ps51' else
                'Independent receiver verifies all20 actual cases. All20 direct full-profile/complete-input lifecycles remain unequal; all18 preview held source windows are equal. Early refusals have no direct discovery boundary. No hard containment/global telemetry or PS5.1 inference.'))
    attempt1[host] = item
    local_archive_joins.append(dict(host=host,
        summaryFact=file_fact(summary_path, str(summary_path.relative_to(WORK))),
        archive=file_fact(archive_path, str(archive_path.relative_to(WORK))),
        route=file_fact(route_path, str(route_path.relative_to(WORK))),
        composition=file_fact(composition_path, str(composition_path.relative_to(WORK))),
        artifact=artifact, summary=summary))
write_json('retained-archive-joins.json', dict(head=HEAD, run='43220592915', attempt=1,
    authority='Custody/metadata/terminal summary association only; independent original receiving is another lane.',
    originals=local_archive_joins))

attempt2 = dict(attempt=2, state='IN_PROGRESS_PARENT_REPORTED', sourceCommit=HEAD,
    statusSource='Root G0027 live checkpoint supplied to this projection; no fresh external query by this task.',
    ps51=dict(job='131197436545', state='IN_PROGRESS', startedAt='2026-11-12T12:56:36Z',
              executionStepStartedAt='2026-11-12T12:56:46Z',
              independentReceiving='PENDING', qualifiedCases=None),
    ps766=dict(job='131197440277', state='REUSED_ORIGINAL_SUCCESS',
               executionStartedAt='2026-11-12T12:43:59Z', executionFinishedAt='2026-11-12T12:46:23Z',
               newNativeExecution=False, originalAttempt=1, originalJob='131190813338',
               independentReceiving='ORIGINAL_ATTEMPT1_FINAL_PASS_RECEIPT_REUSED'),
    limits='One PS5.1-only rerun of the same immutable source; no deadline change, corrective source change, or transient-cause claim. Preserve attempt 1 originals.')

new['recordedUtc'] = NOW
new['scope'] = 'All original 46 obligations retained in original order, text, categories and history. Current a89 projection joins unchanged scoped receipts and records full20 attempt states; it supplies no acceptance numerator, certificate, closure or native receiving decision.'
new['historicalPublishedRowProjectionBeforeA89Reconciliation'] = [
    dict(id=r['id'], currentStatus=r['currentStatus'], currentEvidence=copy.deepcopy(r['currentEvidence']), remaining=copy.deepcopy(r['remaining']))
    for r in old['rows']]
new['previousPrivateProjectionAt9c05'] = dict(status='UNAPPLIED_PRIVATE_AUTHORING_INPUT', sourceHead=PREVIOUS,
    markdown=dict(bytes=len(prior_md_bytes), sha256=sha(prior_md_bytes)),
    matrix=dict(bytes=len(prior_matrix_bytes), sha256=sha(prior_matrix_bytes)),
    note='The earlier private candidate remains unchanged in its original custody. It was not the published current projection.')
dep = new['dependency']
dep.update(head=HEAD, tree=TREE)
dep['sourceAncestry'] = []
for commit in (HEAD, DIAGNOSTIC, PREVIOUS, '8a360f549a7d9ff291b91d2e62e848c72b78d38d', 'a4c617ebeedfb507c0cb7a472683cce47ad62522'):
    parents = subprocess.check_output(['git', '-C', str(REPO), 'show', '-s', '--format=%P', commit], text=True).strip().split()
    dep['sourceAncestry'].append(dict(commit=commit, parents=parents))
dep['state'] = 'Accepted main3b is an explicit parent of combined sourcea4, retained through8a/9c05/12904/a89. Both installer blobs are unchanged from the reviewed9c05 source. R0013/R0015 protections remain integrated inputs; exact final current-main reconciliation and owner merge approval remain separate.'
dep['qualificationReservation'] = 'a89 contains reviewed Windows full20 preparation in two instrument owners. Run43220592915 attempt1 PS7 all20 and PS5.1 c00 adverse bootstrap are independently received; PS5.1 has0 installer cases. Same-source PS5.1-only attempt2 is parent-reported in progress. This projection grants no two-host full20 pass or obligation acceptance.'

for key in ('scopedCurrentPowerShell', 'scopedCurrentLinux', 'scopedCurrentMacOS'):
    new[key]['projectionHead'] = HEAD
    new[key]['sourceReuseState'] = 'UNCHANGED_EXECUTED_SCOPE_ASSOCIATION_FOR_ROOT_REVIEW'
    new[key]['sourceReuseLimit'] = 'Original receiver stays bound to9c05 and its actual acquisition environment; this is a byte/role association to a89, not a new native execution.'
new['scopedCurrentMacOS']['cataloguedButUnexecutedChangedInput'] = source_reuse['macCatalogDifference']
new['scopedCurrentPowerShell']['fullEntryCaseBreakdown'] = dict(total=20, preview=18, normal=2,
    earlyOptionRefusalsWithinPreview=2, heldRelationships=18,
    note='All18 preview cases, including both early refusals, have separate held source observations. The2 normal cases instead have strict normal postconditions. Early refusals have no direct discovery boundary.')

joins = new['currentEvidenceReceiptJoins']
for key, join in joins.items():
    if key == 'J_WFULL20':
        continue
    join['sourceReuseAtA89'] = dict(head=HEAD,
        state='UNCHANGED_EXECUTED_SCOPE_ASSOCIATION_FOR_ROOT_REVIEW',
        originalReceiverHead=PREVIOUS,
        limits=('The broad Mac source catalog has one changed Windows-only composition file. The eleven executed Mac suites, installer, actual carrier/workflow and builder/config/preset inputs remain unchanged; no current Windows full20 credit is transferred.' if key == 'J_MAC' else
                'Only the exact installer/function/fixture/producer roles and the recorded native or local-render scope transfer. Root admission and final independent reconciliation remain pending.'))

full20 = joins['J_WFULL20']
full20['receiptRole'] = 'Preserved original failed full20 receipt, not the current attempt receiving.'
full20.update(state='A89_PS7_ALL20_RECEIVED_PS51_ADVERSE_RECEIVED_ATTEMPT2_PENDING',
    expected='Receive all20 current direct-entry cases on each native host:18 preview including2 early-option refusals, plus2 normal. The18 held relationships are separate. Preserve original comparators, scopes, failed attempts and lifecycle evidence.',
    candidateQualificationHead=HEAD, full20Passed=False,
    limits='PS7 technical receiving is complete for all20 actual cases and preserves all lifecycle inequalities; PS5.1 remains open. No core75, normal18, original18/behavior15, routes8, diagnostic or reused job substitutes for current two-host qualification.',
    caseBreakdown=copy.deepcopy(new['scopedCurrentPowerShell']['fullEntryCaseBreakdown']),
    run='43220592915', attempts=[dict(attempt=1, sourceCommit=HEAD, hosts=attempt1), attempt2],
    instrumentBindings={p:fact(p) for p in ('tests/install-entry-native-composition.py', 'tools/qualification/installer_preview_windows_full_entry.py')},
    preparationReview=receipt(PUB + 'full20-integration/review/report.md'),
    calibrationReceipt=receipt(PUB + 'windows-normal-cache/report.md'),
    historicalDiagnosticBoundary=receipt(PUB + 'full20-integration/diagnostic-reproducibility.md'))
new['windowsNormalPreparationHistory'] = dict(
    status='BOUNDED_PREPARATION_RECEIVED_COMPOSED_FULL20_NOT_YET_RECEIVED',
    diagnosticHead=DIAGNOSTIC, diagnosticRun='43216080799', diagnosticArtifact='13943627660',
    receipt=receipt(PUB + 'windows-normal-cache/report.md'),
    currentInstrumentReview=receipt(PUB + 'full20-integration/review/report.md'),
    oldWarm20=dict(run='43173988834', normalCases=2, strictPasses=0, strictFailures=2, cacheBytesBefore=738, cacheBytesAfter=8917),
    laterWarm20AndWarmJson=dict(run='43216080799', warm20StrictPasses=2, warmJsonStrictPasses=2, strictFailures=0, stableCacheBytes=738),
    causality='Unresolved. Later warm20 also passes; the native JSON exercise is not established as unique, necessary or sufficient. No deterministic cache repair or universal20-second guarantee is established.',
    changedOwners={p:fact(p) for p in ('tests/install-entry-native-composition.py', 'tools/qualification/installer_preview_windows_full_entry.py')},
    preparation='PS7 normal-only COMPlus_MultiCoreJitNoProfileGather=1; PS5.1 normal-only native JSON preparation with20-second hold in the existing source-free host leg. Eighteen preview cases and original strict product comparators remain outside the preparation change.',
    reproduction='Historical diagnostic remains pinned to immutable12904 and deliberately fails closed against changed a89 owner bytes. Reproduce it at its original commit; it is not the current full20 carrier.',
    productCredit=0)

new['deltaFrontier']['D02'] = 'Native readable/unreadable metadata and sharing-violation32/healthy-peer predicates remain in current full20. PS7 attempt1 all20 is independently received; PS5.1 attempt1 adverse receipt has0 installer cases after c00 ACL acquisition timeout, and same-source attempt2 is pending. No refusal credit comes from bootstrap failure.'
new['deltaFrontier']['D05'] = 'Current full20 is20 direct cases:18 preview including2 early-option refusals plus2 normal, with18 separate held relationships. Reviewed normal-only preparation preserves complete prepared-input/security/content/timestamp and USERPROFILE comparators. Later PS5.1 warm20 and warm-json diagnostics pass, while earlier warm20 failures and unresolved cause remain. Current two-host receiving remains OPEN.'
new['deltaFrontier']['D07'] = 'Accepted R0013/R0015 protections are retained through accepted-main3b/combineda4 to a89. Current Windows core75 and normal18 receipts have unchanged executed scope on both hosts; current full20 has separate a89 acquisition/receiving states.'
new['deltaFrontier']['D11'] = 'Both Windows core75/normal18 receipts remain complete within their original scope. Per host152 equal held windows coexist with152 unequal full lifecycles and no independent OS containment. a89 PS7 full20 is independently received: all20 direct full-profile/full-input lifecycles differ, while all18 preview held source windows are equal. PS5.1 attempt1 adverse receipt has0 installer cases; same-source attempt2 is pending. Reused PS7 attempt2 job supplies no new execution.'

front = new['technicalFrontier']
front['T01']['minimum'] = 'Root admits the independently received PS7 a89 all20 receipt and completes/independently receives all20 exact PS5.1 cases. Attempt1 PS5.1 adverse receipt has0 installer cases at c00 ACL acquisition/capture timeout; preserve it while receiving pending same-source attempt2. Keep18 preview including2 early-option refusals plus2 normal,18 preview held source windows, strict normal postconditions and all complete lifecycle differences. Calibration43216080799 and code review do not supply product qualification.'
front['T01']['currentRun'] = '43220592915'
front['T01']['currentSource'] = HEAD
front['T01']['scopeLimit'] = 'Core75, normal18, original18, routes8, diagnostics, static review and a reused successful-job listing do not replace actual composed qualification. No new OS-wide containment, denominator or blanket native campaign is introduced.'
front['T04']['minimum'] = 'Root admits the published scoped FINAL POSIX/Windows receipts and the unchanged executed-scope association to a89: Mac11 suites/248 rows, Linux45/61 plus named passing entry25, Windows core75/normal18 on both hosts. Preserve the Mac broad catalog exception for the changed unexecuted Windows composition file, all actual acquisition environments and adverse observations. Supply the admitted packet for Fable-owned21-13/ES15-14.'
front['T05']['minimum'] = 'After root receipt/reuse admission and T01 receiving, independently reconcile the actual final candidate and all original46 rows, exact instrument/source associations, valid unchanged-source reuse, rendered guidance, all failed attempts and measurement limits. This private projection prepares that review and is not its result.'
new['externalGates']['X02']['minimum'] = 'Reconcile the actual final reviewed head/base/tree against then-current main and obtain the separately required owner merge approval before integration into main, using the nonclosing Implements #22 PR. This private projection neither requests nor supplies that approval.'

gap_notes = {
 '22-01':'Receive actual Windows option/platform/discovery/refusal entry results; c00 bootstrap failure supplies no refusal evidence.',
 '22-02':'Receive the composed Windows offline/effect observations; retain null general transport telemetry and bounded interception/denial scope.',
 '22-03':'Admit received helper/mutant guards and receive the separate composed Windows entry scope; keep Boolean-false copy and native-staging context.',
 '22-04':'Admit suppression/caller-stop observations and receive composed Windows no-usable-path results.',
 '22-05':'Receive Windows fresh/cached/source/metadata/refusal composition; preserve the named Linux/Mac cache-free subgroup and separate N03 caller evidence.',
 '22-06':'Receive complete Windows prepared-input/profile/security/timestamp/content and lifecycle comparisons after reviewed preparation; exclude no cache names or fields.',
 '22-07':'Admit existing normal18/POSIX consumers and received PS7 full20 normal2; receive PS5.1 positive/NoOpen under unchanged strict postconditions.',
 '22-08':'Root admission of the already received exact causal mutants, matched healthy controls and same-mutant normal survival; no new native campaign follows from this row.',
 '22-09':'Admit received PS7 a89 all20 and receive actual PS5.1 full20; existing scoped Mac/Linux entry observations remain reusable.',
 '22-10':'Admit unchanged integrated interface evidence and complete Windows entry receiving; then supply the existing Fable-owned dependency handoff.',
 '22-11':'Receive mode-specific current Windows output, refusals and normal manual-pending wording; retain prior false accepts and no installation/import completion inference.',
 '22-12':'Root admission of published docs71 and final source association; local rendering does not establish public delivery.',
 '22-13':'Final exact-candidate preservation review against accepted base; current authored/generated config, presets and V1 are unchanged. No new geometry/physics campaign.',
 '22-14':'Final owner-approved integration and actual script/document/generated-command public-byte and rendered readback, then the existing certificate/closure record.',
 'R0016-A01':'Root admission of native Apple preview46/entry25 in the eleven-suite receipt, with targeted-log gap and null general telemetry retained.',
 'R0016-A02':'Root admission of native Apple no-terminal refusals and actual normal/NoOpen consumers; no imposed cross-platform effect total.',
 'R0016-A03':'Root admission of native Apple parse-valid mutants and matched healthy/normal companions; keep adverse original attempts.',
 'R0016-A04':'Admit exact unchanged source/fixture reuse and current scoped receipts, plus complete current Windows full20 receiving; original18 parser3 stays historical.',
 'R0016-A05':'Root admission of docs71 with original ZIP/API/source/PNG joins and retained clipping/blank-widget limits.',
 'R0016-A06':'Owner-approved exact final public delivery, raw/Pages/GitHub and rendered readback, evidence certificate and deliberate closure/readback.',
 'P01':'Receive current Windows cache-free github case; admit named Linux/Mac offline github entry25 observations without relabeling cache-containing preview fixtures.',
 'P02':'Receive Windows cached-artifact/metadata composition with unchanged existing sentinels and no usable return.',
 'P03':'Receive Windows store preview: would-open plan, no prompt/effect; N03 normal routes do not fill this preview row.',
 'P04':'Receive Windows ask preview: both choices unresolved, no question/effect; normal choices remain N03.',
 'P05':'Receive Windows installed plan and unchanged preset/copy/open state with manual replacement warning.',
 'P06':'Receive Windows missing-preset case and actual reason; retain the historical ACK failure.',
 'P07':'Receive Windows mixed legacy/eligible plan with explicit legacy refusal and useful eligible peer.',
 'P08':'Receive actual Windows legacy-only nonzero diagnostic; retain unrelated historical banner false PASS as false.',
 'P09':'Receive actual Windows literal zero-target refusal; do not substitute unknown-only or bootstrap failure.',
 'P10':'Receive exact Windows invalid source/option/environment refusals; two early-option refusals are already inside18 preview.',
 'P11':'Receive Windows readable/unreadable pair and sharing-violation32/healthy-peer reasons; preserve unknown/eligible separation.',
 'P12':'Receive the declared composed Windows failure/exit scope and admit existing helper/carrier/POSIX signal evidence without substituting source-free rows for installer rows.',
 'N01':'Receive current full20 positive entry with declared downloads/staging/configuration/clipboard/manual consumers and unchanged strict complete-input postcondition.',
 'N02':'Receive current full20 NoOpen entry with normal consumers and suppressed open; preserve earlier cache failures and unresolved calibration variation.',
 'N03':'Root admission of received routes8, original18 behavior15 reuse and named Linux/Mac store/ask/fallback entry25 rows. No new original18 run is required.',
}
for row in new['rows']:
    if row['category'] == 'effects':
        gap_notes[row['id']] = 'Admit the received exact ' + row['id'] + ' helper/effect observation and receive its applicable composed Windows entry scope; preserve no usable path, false suppressed copy and clean result-channel semantics.'
for mapped in mapping['rows']:
    if 'T01' in mapped['remainingTechnicalGates']:
        key = mapped['id']
        gap_notes[key] = gap_notes[key].replace('Windows', 'PS5.1')
        if 'PS7' not in gap_notes[key]:
            gap_notes[key] += ' The corresponding a89 PS7 full20 scope is already independently received; root admission remains.'

gap_rows = []
for index, (row, mapped) in enumerate(zip(new['rows'], mapping['rows'])):
    assert row['id'] == mapped['id']
    row['currentEvidence'][0] = 'Exact immutable a89 source association to published scoped receivers at9c05: dependency/currentEvidenceReceiptJoins. Original environments, bounds and adverse results remain; no obligation acceptance.'
    if row['id'] == '22-07':
        row['currentEvidence'][-1] = 'Both Windows core75/normal18 originals and POSIX normal consumers retain independently received unchanged scope. a89 PS7 full20 normal2 is independently received under strict postconditions; PS5.1 attempt1 adverse receipt has0 installer cases and attempt2 is pending. Historical cache failures remain.'
    if row['id'] in ('N01', 'N02'):
        row['currentEvidence'].append('a89 normal-only preparation is code-reviewed; diagnostic43216080799 has warm20 and warm-json PASS but no unique/sufficient JSON cause. Current full20 receiving states are in J_WFULL20; diagnostic passes do not fill this row.')
    if row['id'] == 'R0016-A04':
        row['currentEvidence'].append('Relevant Linux, Windows core/normal/routes, docs and executed Mac source roles are unchanged at a89. Mac broad catalog includes one changed unexecuted Windows composition owner; its old bytes are not relabeled current.')
    gates = mapped['remainingTechnicalGates']
    remaining = []
    if 'T01' in gates:
        remaining.append('T01: root admits independently received a89 PS7 all20 and completes/receives PS5.1 full20; attempt1 PS5.1 adverse receipt has0 installer cases and same-source attempt2 remains pending. See exact20 breakdown and attempt custody in J_WFULL20.')
    if 'T02' in gates:
        remaining.append('T02: root admits received routes8, original18 behavioral15 unchanged-source reuse and named Linux/Mac entry25 caller associations;3 old parser/ASCII rows remain historical.')
    if 'T03' in gates:
        remaining.append('T03: root admits completed local docs71 original/API/PNG receiving and unchanged input/producer association to a89; actual public delivery stays separate.')
    if 'T04' in gates:
        remaining.append('T04: root admits published scoped FINAL native receipts and named passing subgroup with exact a89 executed-scope reuse, original adverse aggregates and measurement limits.')
    remaining.append('T05: independent final exact-candidate reconciliation of this original obligation remains; no acceptance is supplied by this projection.')
    for external in mapped['externalGates']:
        remaining.append(external + ': ' + new['externalGates'][external]['minimum'])
    row['remaining'] = remaining
    row['currentRemainingGateIds'] = gates + ['T05'] + mapped['externalGates']
    row['currentGapDetail'] = gap_notes[row['id']]
    if 'T01' in gates:
        row['currentStatus'] = 'SCOPED_RECEIPTS_SOURCE_JOINED; WINDOWS_FULL20_RECEIVING_OPEN; NO_ACCEPTANCE'
    elif 'T03' in gates:
        row['currentStatus'] = 'LOCAL_DOCS_RECEIVED_SOURCE_JOINED; ROOT_ADMISSION_AND_FINAL_REVIEW_OPEN; NO_ACCEPTANCE'
    elif gates:
        row['currentStatus'] = 'SCOPED_RECEIPTS_REUSE_AVAILABLE; ROOT_ADMISSION_AND_FINAL_REVIEW_OPEN; NO_ACCEPTANCE'
    else:
        row['currentStatus'] = 'FINAL_REVIEW_AND_APPLICABLE_EXTERNAL_GATES_OPEN; NO_ACCEPTANCE'
    gap_rows.append(dict(id=row['id'], category=row['category'], obligation=row['obligation'],
        receiptJoins=row['currentReceiptJoins'], originalTechnicalGates=gates,
        finalIndependentGate='T05', originalExternalGates=mapped['externalGates'],
        remaining=row['currentGapDetail'], proposedAcceptance=None))
write_json('per-obligation-gaps.json', dict(schema='r0016-original46-gaps-a89.v1',
    head=HEAD, sameOriginalDenominator=True, authority='Preparation only; no acceptance or new obligations.', rows=gap_rows))

recon = new['currentReconciliation']
recon.update(status='PRIVATE_A89_CURRENT_PROJECTION_FOR_ROOT_REVIEW', exactSourceHead=HEAD, tree=TREE)
recon['sourceBindings'] = {p:fact(p) for p in recon['sourceBindings']}
for path in ('tests/install-entry-native-composition.py', 'tools/qualification/installer_preview_windows_full_entry.py',
             'tests/install-entry-product-support.py', 'tests/install-entry-composition-support.py',
             'tests/install-entry-coverage-support.py', 'tools/qualification/installer_native.py',
             '.github/workflows/installer-preview-macos-native.yml', '.github/workflows/installer-preview-docs.yml'):
    # The docs workflow's exact repository spelling comes from its received binding.
    if path.endswith('installer-preview-docs.yml'):
        path = docs['workflow']['path']
    recon['sourceBindings'][path] = fact(path)
recon['receivingReports'].extend([receipt(PUB + 'windows-normal-cache/report.md'), receipt(PUB + 'full20-integration/review/report.md'), ps7_receipt, ps51_receipt])
recon['candidateQualificationUpdate'] = dict(state='ACTUAL_A89_ACQUISITION_TWO_HOST_RECEIVING_INCOMPLETE',
    currentImmutableSourceHead=HEAD, currentInstrumentHead=HEAD, run='43220592915',
    full20Passed=False, nextCommit=None,
    note='PS7 all20 and PS5.1 attempt1 adverse bootstrap are independently received. PS5.1 same-source attempt2 is pending. No new PS7 execution is credited for its reused attempt2 job listing.')
recon['historicalInterpretation'] += ' historicalPublishedRowProjectionBeforeA89Reconciliation additionally preserves every replaced published currentStatus/currentEvidence/remaining field. Original receivers remain bound to9c05; their current source associations are explicitly scoped.'
recon['publication'] = 'The earlier successor-20261112 receipts are present in immutable a89. New full20-ps7-attempt1 and full20-ps51-attempt1 receipt links are exact parent-specified publication destinations. This private projection publishes neither the receipts nor the two candidate files.'
recon['authority'] = 'No root receipt admission, obligation acceptance, acceptance numerator, completion certificate, merge, publication, lifecycle transition or closure.'
write_json('candidate/' + MATRIX, new)

# Use the existing reviewed private prose as authoring input; replace only current projection text.
md = prior_md_bytes.decode()
def paragraph(prefix, replacement):
    global md
    parts = md.split('\n\n')
    indices = [i for i, p in enumerate(parts) if p.startswith(prefix)]
    assert len(indices) == 1, (prefix, indices)
    parts[indices[0]] = replacement.replace('@', chr(96))
    md = '\n\n'.join(parts)

paragraph('This source projection is bound',
    'This source projection is bound to immutable head @' + HEAD + '@, tree @' + TREE + '@. Current installer hashes are Bash @27442c0e6a6dbd6390ba1ea9b8b3efa2bfb2a910037e2c415756f9169a5c7b3f@ and PowerShell @07671cb9e6a0afb8eb9051a0a5f378d12e577877453a773860b3cf94d5e2951a@; both installer blobs are unchanged through reviewed9c05, diagnostic12904 and currenta89. Accepted-main @' + BASE + '@ is an explicit parent of combined-source @a4c617ebeedfb507c0cb7a472683cce47ad62522@, retained through8a/9c05/12904/a89. The accepted R0013/R0015 discovery, eligibility, private-staging, artifact-admission and transaction protections remain integrated inputs. R0016 retains the preview guards, resolved environment-source validation, truthful dry-run/NoOpen wording and Apple non-spooling repairs. The earlier bf566/87318/7fbe projection remains historical. Currenta89 changes two Windows full20 instrument owners for reviewed normal-only preparation; the actual run and independent-receiving boundary are recorded below. This source projection supplies no full20 pass or obligation acceptance.')
md = md.replace('This source projection supplies no full20 pass or obligation acceptance.', 'This source projection supplies no two-host full20 pass or obligation acceptance.')
paragraph('The [POSIX report]',
    'The [POSIX report](evidence/R0016/' + PUB + 'posix/report.md), [Windows report](evidence/R0016/' + PUB + 'windows/report.md), [documentation report](evidence/R0016/' + PUB + 'docs/report.md) and [original46 mapping](evidence/R0016/' + PUB + 'mapping/REPORT.md) retain their original9c05 review and acquisition bindings. Exact relevant source/fixture/producer comparisons support the bounded association to currenta89 below; no original receipt is relabeled as a fresh a89 execution. The mapping\'s earlier pending-receipt states are updated by the published FINAL receipts in the current matrix, while the mapping remains preserved evidence.')
old_line = next(line for line in md.splitlines() if line.startswith('| Windows full20 |'))
new_line = '| Windows full20 | Run43220592915 at a89: PS7 all20 independently received; PS5.1 attempt1 adverse bootstrap independently received with0 installer cases. Same-source PS5.1-only attempt2 is pending. | Two-host gate OPEN. Required20 =18 preview, including2 early-option refusals, plus2 normal. All18 preview cases have separate held source windows; the2 normal cases have strict normal postconditions. |'
md = md.replace(old_line, new_line)
anchor = 'The [named entry-subgroup association]'
position = md.index(anchor)
scope_paragraph = 'The broad Mac source catalog contains50 files:49 remain byte-identical at a89, while its catalogued Windows-only @tests/install-entry-native-composition.py@ changed. The actual eleven Mac command groups, installer, carrier/workflow and builder/config/preset inputs remain unchanged, so their executed scope can be reused without claiming the old Windows composition bytes are current. All retained Linux inputs, Windows core/normal/routes inputs and local documentation inputs/producers remain unchanged in their relevant scopes. The current two-owner Windows full20 composition requires its own acquisition and receiving.\n\n'.replace('@', chr(96))
md = md[:position] + scope_paragraph + md[position:]
paragraph(chr(96) + 'tests/install-entry-native-composition.py',
    '@tests/install-entry-native-composition.py@, @tests/install-entry-product-support.py@ and @tools/qualification/installer_preview_windows_full_entry.py@ define the current full20 direct-entry instrument. Its20 cases are18 preview, including2 early-option refusals, plus2 normal. All18 preview cases have separate held source observations; the2 normal cases instead have strict normal postconditions. Early refusals have no direct discovery boundary and receive only attributable refusal credit there. The older18-case coverage instrument remains historical support. Full prepared-input inventories retain security, attributes, identity, content and timestamps alongside owned USERPROFILE lifecycle observations. No AppData/cache filename is exempted. Held preview source windows require complete exact equality; direct lifecycle differences remain explicit source/host associations, never silently subtracted. Normal permits only the independently validated bundle, its exact inventory/profile-parent rule and the already declared subject/temp parent mtime change. Reviewed source-free normal preparation precedes the actual product baseline and cannot excuse a product-phase cache or input change. Current two-host full20 receiving remains OPEN.')
paragraph('The readable/unreadable Firefox pair',
    'The readable/unreadable Firefox pair uses native Windows sharing semantics. The parent retains a readable exclusive handle while the actual installer child must prove sharing violation32 and a healthy readable peer. Snapshots use the held handle, and cleanup verifies restored readability, unchanged bytes, identity and security. Readable metadata must reach a useful one-eligible-target plan. The current full20 retains these predicates, resolved-source/NoOpen regressions, complete prepared-input comparisons and actual lifecycle observations. Both hosts still require independently received current full20 evidence; source-free diagnostics and core75/normal18 receipts cannot substitute for that composition.')
new_section = '''## Current Windows full20 acquisition

The [normal-cache receiver](evidence/R0016/PUBwindows-normal-cache/report.md) preserves both older warm20 normal failures in run43173988834 (738 to8,917 cache bytes) and four later strict passes in diagnostic43216080799 at immutable12904: positive/NoOpen under both warm20 and warm-json, with738-byte caches unchanged after preparation. The old/new variation remains unexplained. Native JSON is not established as unique, necessary or sufficient, and a20-second hold is not a universal guarantee. These diagnostics contribute zero current full20 product cases.

The [bounded implementation review](evidence/R0016/PUBfull20-integration/review/report.md) covers the exact a89 composition harness SHA256 @0b787803e3536393c4963eb9884c81eddc1a1198508877a600d7b51e4c64f85f@ and outer receiver @1d7d15074fa541e9bb67b02e3442677503e3ba2297e892738458fca8be87fd12@. PS7 normal alone receives @COMPlus_MultiCoreJitNoProfileGather=1@. PS5.1 normal alone runs the observed native JSON exercise and20-second hold inside the existing source-free host leg before the product baseline. All18 preview cases retain their original preparation scope; complete warm/cache observations and original product comparators remain. Code review and inert controls do not supply native qualification. The [historical diagnostic boundary](evidence/R0016/PUBfull20-integration/diagnostic-reproducibility.md) remains immutable12904; it is not silently repinned to a89.

Actual run43220592915 attempt1 is bound to a89. The [PS7 original receiver](evidence/R0016/PUBfull20-ps7-attempt1/report.md) independently verifies all20 actual cases from job131190813338, artifact13944574998:5,222,627 bytes, SHA256 @692c309ed1f00ebc4fd4b044505c5837be0c43497eb66eb6d69d3266cf029dda@. Its exact14 source roles, original outer/per-case predicates,930 custody facts,244 full inventories,468 native file bindings,58 nonces and38 ACL setups join; strict normal2 passes. These receiving counts are not additional product cases.

All20 PS7 direct full-profile and complete-input before/after lifecycles remain unequal. All18 preview held source windows are equal, including the held observations corresponding to the2 early refusals. Those2 direct refusals have no discovery boundary and receive no invented direct readiness/at-ready proof. Startup/profile/TEMP changes, clone identity differences and normal retained-bundle effects remain in the original physical relations. @independentHardContainment=NOT_ACQUIRED@ and null global transport telemetry remain; the receipt supplies no host-wide absence-of-effects claim or PS5.1 result.

The [PS5.1 adverse original receiver](evidence/R0016/PUBfull20-ps51-attempt1/report.md) verifies that job131190813869 stops during c00 parent ACL acquisition/capture at the unchanged60-second bound before any installer launch. Original artifact13945063071 is150,750 bytes, SHA256 @e6c4a2a5c8b505a5166acaf17321ddbc6b7c56b758256a55cd1a740e3d1a7fdc@. The one row is BOOTSTRAP_BLOCKED, installerExecuted=false, with19 later cases unattempted; product credit is0. Empty stdout and only an11-byte CLIXML preamble do not identify a failed ACL operation or cause. The outer exits1 after60.5 seconds within its separate6,550-second bound. No normal-preparation verdict follows. The adverse original remains intact.

The root's live checkpoint records one PS5.1-only attempt2 at the same a89 source, job131197436545, started2026-11-12T12:56:36Z with execution step at12:56:46Z; it is in progress at this projection's cutoff. Attempt2's PS7 listing131197440277 reuses the original12:43:59 to12:46:23 success and its attempt1 receiving, supplying no new native execution. This status is attributed to the root checkpoint, not a fresh API observation by the documentation author. No transient cause, source repair, deadline change, second-host success or acceptance is inferred; root must update the exact PS5.1 terminal/receiving association before final reconciliation.

'''.replace('PUB', PUB).replace('@', chr(96))
md = md.replace('## Preserved failures and acquisition corrections\n', new_section + '## Preserved failures and acquisition corrections\n')
paragraph('The [current documentation receiver]',
    'The [current documentation receiver](evidence/R0016/' + PUB + 'docs/report.md) joins the original archive,47 existing checks, three PNGs and actual retained artifact/run API record; its additional source/provenance checks yield71/71. README @b5df3f58f87368077798c205ac6cd682dee09ac2492e1f89d0dd6f6ec940923d@, builder @873e8dedfd4380d5bb8271945b23d73dc5afd3b5c8b848f67017cc4aaa41fd9f@, config @719efed90a9173a7ca42216b0131631a2e0e219e5e45d8567e791784f425ed80@ and renderer @34ee696999b70115e7ef3154d54b02200cb1fe9d0486017ede877451ac806f15@ are identical at rendering commit8a, receiver head9c05 and currenta89. Its workflow is also unchanged. All four a4 installer links remain valid by exact installer-byte identity. These unchanged inputs do not require a repeat local render solely because Windows diagnostic/instrument/evidence commits advanced.')
paragraph('The [exact46 reconciliation]',
    'The [exact46 reconciliation](evidence/R0016/' + PUB + 'mapping/current-mapping-reconciled.json) preserves the original obligations and existing technical/external gates. T01 remains OPEN: root admits the independently received PS7 a89 all20 receipt and completes/receives PS5.1 full20, preserving attempt1\'s received pre-installer bootstrap failure and pending same-source attempt2. T02 has received Windows routes8 and named Linux/Mac entry25 associations; root admission of original18 behavioral15 unchanged-source reuse remains. T03 local-documentation provenance/visual receiving and T04 scoped POSIX/Windows/subgroup receiving are complete as bounded receipts and await root admission with the a89 source associations. T05 remains the final independent exact-candidate46-row reconciliation after the outstanding qualification and joins. No scoped suite count is an acceptance numerator.')
paragraph('Accepted dependency inputs are already integrated',
    'Accepted dependency inputs remain integrated in the ancestry above. The existing Fable handoff, exact final-head/then-current-main reconciliation, separate owner merge approval, authorized integration, actual merged/served byte and rendered-guidance readback, complete evidence certificate and deliberate issue closure remain open in their original scopes. This private projection supplies no approval or certificate. Root must replace pending acquisition/receiving states with verified final records and re-associate any relevant subsequent source change before final review. All46 obligations remain, and no issue is closed by this candidate or its PR wording.')
dest = ROOT / 'candidate' / MD
dest.parent.mkdir(parents=True, exist_ok=True)
dest.write_text(md.rstrip() + '\n')

patch_parts = []
for path in (MD, MATRIX):
    before = baseline[path].decode().splitlines(keepends=True)
    after = (ROOT / 'candidate' / path).read_text().splitlines(keepends=True)
    patch_parts.append('diff --git a/' + path + ' b/' + path + '\n')
    patch_parts.extend(difflib.unified_diff(before, after, fromfile='a/' + path, tofile='b/' + path))
(ROOT / 'candidate.patch').write_text(''.join(patch_parts))

write_json('input-bindings.json', dict(head=HEAD, tree=TREE, acceptedBase=BASE, priorPrivateInputs=prior_inputs,
    baseline=[file_fact(ROOT / 'baseline' / p, p) for p in (MD, MATRIX, HISTORY)],
    priorPrivateCandidate=dict(markdown=file_fact(PRIOR / 'candidate' / MD, MD), matrix=file_fact(PRIOR / 'candidate' / MATRIX, MATRIX)),
    parentStatus=dict(controller='G0027', attempt2=attempt2),
    authority='Parent-supplied status is attributed; data/source checks do not issue continuity/currentness or acceptance.'))
write_json('candidate-bindings.json', dict(head=HEAD, tree=TREE,
    candidate=[file_fact(ROOT / 'candidate' / p, p) for p in (MD, MATRIX)],
    patch=file_fact(ROOT / 'candidate.patch')))
print(json.dumps(dict(status='PREPARED_PRIVATE_ONLY', head=HEAD,
    candidateFiles=2, sourceRoleComparisons=len(source_roles),
    changedCatalogRoles=[dict(lane=r['lane'], path=r['path']) for r in source_roles if not r['equal']],
    obligations=len(new['rows']), full20Passed=new['currentEvidenceReceiptJoins']['J_WFULL20']['full20Passed']), indent=2))
