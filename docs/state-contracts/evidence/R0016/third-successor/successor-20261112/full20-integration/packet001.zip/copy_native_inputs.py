import hashlib,json,pathlib,shutil
HERE=pathlib.Path(__file__).resolve().parent
source=HERE.parents[1]/'recovery/native-43216080799/extracted/installer-evidence'
fixture=next((source/'m1/f').iterdir())
roles=['entry-composition-report.json']
for case in ('c10','c11'):
    for rel in ('host-only-control/host-only.ps1','host-only-control/stdout.raw',
        'host-only-control/full-before-launch.json','host-only-control/full-at-ready.json',
        'host-only-control/full-after-exit.json','host-only-control/cache-after.raw',
        'direct-full-before-launch.json','entry-profile-window/full-at-ready.json',
        'direct-full-after-exit.json','cache-product-before.raw','cache-product-after.raw',
        'warm-json-assembly-binding.json'):
        roles.append(case+'/'+rel)
facts=[]
for role in roles:
    old=fixture/role;new=HERE/'fixtures/native-43216080799'/role
    new.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(old,new)
    raw=old.read_bytes();facts.append(dict(original=str(old),retained=str(new.relative_to(HERE)),
        bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
(HERE/'NATIVE_INPUTS.json').write_text(json.dumps(dict(runId=43216080799,
    sourceCommit='12904a880c38b749db2d7c79ec1e7cebde2e04e2',
    originalZipSha256='d8580fd76a88766d88619a2dd3eb81920c6a7e4fc7df50bb9e4bd33c6931d00d',
    scope='Original diagnostic bytes only; no new native execution, no full20 qualification.',files=facts),indent=2)+'\n')
