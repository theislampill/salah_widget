"""Independent source/AST/pin checks; no acquisition or native import."""
import ast, collections, hashlib, json, pathlib
HERE=pathlib.Path(__file__).resolve().parent
REPO=HERE.parents[1]/'salah_widget'
HARNESS='tests/install-entry-native-composition.py';OUTER='tools/qualification/installer_preview_windows_full_entry.py'
checks=[]
def check(name,value,detail=None):
    checks.append(dict(check=name,pass_=bool(value),detail=detail));assert value,name
def dump(node):return ast.dump(node,include_attributes=False)
def tree(path):return ast.parse(path.read_bytes())
def constants(parsed):
    result={}
    for n in parsed.body:
        if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
            try:result[n.targets[0].id]=ast.literal_eval(n.value)
            except (ValueError,TypeError):pass
    return result
def functions(parsed):return {n.name:n for n in parsed.body if isinstance(n,ast.FunctionDef)}
def requires(parsed):return collections.Counter(dump(n) for n in ast.walk(parsed)
    if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='require')
for role,allowed in ((HARNESS,{'_case_impl'}),(OUTER,{'validate_case_headers','validate_report'})):
    baseline=HERE/'baseline'/role;candidate=HERE/'candidate'/role
    check('immutable baseline bytes '+role,baseline.read_bytes()==(REPO/role).read_bytes())
    a,b=tree(baseline),tree(candidate);before,after=functions(a),functions(b)
    for name,node in before.items():
        if name not in allowed:check('unchanged function AST '+role+'::'+name,dump(node)==dump(after[name]))
    old=requires(a);new=requires(b)
    check('every original require-call AST retained '+role,not(old-new),dict(originalCalls=sum(old.values()),candidateCalls=sum(new.values())))
    oldconst,newconst=constants(a),constants(b)
    for name,value in oldconst.items():
        if name!='INPUTS':check('unchanged constant '+role+'::'+name,value==newconst[name])
outer_before=constants(tree(HERE/'baseline'/OUTER))['INPUTS']
outer_after=constants(tree(HERE/'candidate'/OUTER))['INPUTS']
check('same full20 source roles',set(outer_after)==set(outer_before))
for role,pin in outer_after.items():
    path=HERE/'candidate'/role if role==HARNESS else REPO/role;raw=path.read_bytes()
    check('current exact outer pin '+role,(len(raw),hashlib.sha256(raw).hexdigest())==pin)
    if role!=HARNESS:check('unchanged outer pin '+role,pin==outer_before[role])
native_manifest=json.loads((HERE/'NATIVE_INPUTS.json').read_bytes())
for entry in native_manifest['files']:
    raw=(HERE/entry['retained']).read_bytes()
    check('retained original native bytes '+entry['retained'],len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256'])
basefn=functions(tree(HERE/'baseline'/HARNESS))['_case_impl'];newfn=functions(tree(HERE/'candidate'/HARNESS))['_case_impl']
def calls(fn,name):return [n for n in ast.walk(fn) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id==name]
check('same two direct/baseline acquisition call sites',len(calls(basefn,'invoke_with_profile_boundary'))==len(calls(newfn,'invoke_with_profile_boundary'))==2)
gather=[]
for n in ast.walk(newfn):
    if isinstance(n,ast.If) and dump(n.test)==dump(ast.parse("normal and host_name=='ps7'",mode='eval').body):gather.append(n)
check('exact scoped PS7-normal gather authoring guard',len(gather)==1 and len(gather[0].body)==1 and
    dump(gather[0].body[0])==dump(ast.parse("env['COMPlus_MultiCoreJitNoProfileGather']='1'").body[0]))
flag_assignments=[n for n in ast.walk(newfn) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Subscript)
    and isinstance(t.value,ast.Name) and t.value.id=='env' and isinstance(t.slice,ast.Constant)
    and str(t.slice.value).upper()=='COMPLUS_MULTICOREJITNOPROFILEGATHER' for t in n.targets)]
check('no unscoped gather authoring assignment',len(flag_assignments)==1)
check('complete environment assigned before scoped flag',gather[0].lineno>next(n.lineno for n in ast.walk(newfn)
    if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name)
    and n.func.value.id=='env' and n.func.attr=='update' and any(k.arg=='PSModulePath' for k in n.keywords)))
check('scoped flag before source-free startup',gather[0].lineno<next(n.lineno for n in ast.walk(newfn)
    if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='startup' for t in n.targets)))
diagnostic=tree(HERE/'diagnostic-source.py');candidate=tree(HERE/'candidate'/HARNESS)
for name in ('digest','warm_control_body','receive_cache_bytes','parse_warm_context','receive_native_assembly','receive_warm_context'):
    check('reviewed diagnostic helper copied exactly '+name,dump(functions(diagnostic)[name])==dump(functions(candidate)[name]))
diagnostic_pins=constants(diagnostic)['INPUTS']
check('historical diagnostic source preserved',(REPO/'tools/qualification/installer_preview_windows_normal_profile_diagnostic.py').read_bytes()==(HERE/'diagnostic-source.py').read_bytes())
check('historical diagnostic inherited pins intentionally fail closed on new owners',all(diagnostic_pins[role]!=(len((HERE/'candidate'/role).read_bytes()),hashlib.sha256((HERE/'candidate'/role).read_bytes()).hexdigest()) for role in (HARNESS,OUTER)))
out=dict(status='PASS',checks=checks,checkCount=len(checks),
    scope='Source, AST, exact input joins and acquisition authoring only; no native process executed.')
(HERE/'source-checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(status='PASS',checks=len(checks))))
