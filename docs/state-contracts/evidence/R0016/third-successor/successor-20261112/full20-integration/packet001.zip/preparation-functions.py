def require_scoped_preparation_environment(host, scenario, environments):
    require(host in ('ps51','ps7') and scenario in SCENARIOS,'Unknown normal preparation host/case')
    require(type(environments) is list and len(environments)==3
        and all(type(env) is dict for env in environments),'Missing actual preparation environments')
    for env in environments:
        flags={key:value for key,value in env.items() if key.upper()=='COMPLUS_MULTICOREJITNOPROFILEGATHER'}
        require(len(flags)==(1 if host=='ps7' and scenario in ('positive','no-open') else 0)
            and all(value=='1' for value in flags.values()),'Wrong scoped prelaunch gather environment')


def capture_preparation_cache(path, inventory, destination):
    raw=path.read_bytes() if path.is_file() else None
    row=receive_cache_bytes(raw,inventory['rows'])
    capture=None
    if raw is not None:
        destination.write_bytes(raw);capture=composition.fact(destination)
    return dict(inventoryRow=row,capture=capture)


def require_normal_preparation(observation, host, scenario, script, phases, cache_raw, warm_raw, assembly_binding):
    require(scenario in ('positive','no-open') and host in ('ps51','ps7'),'Wrong normal preparation host/case')
    preparation=observation.get('normalPreparation')
    require(type(preparation) is dict and set(preparation)=={'schema','mode','holdSeconds','script',
        'phaseFacts','cacheCaptures','warmJsonContext'},'Missing complete normal preparation')
    mode='warm-json' if host=='ps51' else 'no-gather'
    require(preparation['schema']=='r0016-normal-preparation.v1' and preparation['mode']==mode
        and type(preparation['holdSeconds']) is int and preparation['holdSeconds']==(20 if host=='ps51' else 0),
        'Wrong host-specific normal preparation mode/hold')
    require(type(script) is bytes and script.replace(b'\r\n',b'\n')==warm_control_body(mode).encode('ascii'),
        'Source-free normal preparation body differs')
    warm=observation['hostOnlyBaseline'];product=observation['profileWindow'];launch=observation['directLaunchInputs']
    require(launch.get('environment')==product.get('environment'),'Actual normal product launch environment differs')
    require_scoped_preparation_environment(host,scenario,[launch.get('environment'),warm.get('environment'),product.get('environment')])
    require(warm['environment'].get('INSTALL_FIXTURE_NORMAL')=='0'
        and product['environment'].get('INSTALL_FIXTURE_NORMAL')=='1','Wrong source-free/product effect environment')
    shared=('PSModulePath','PSModuleAnalysisCachePath','INSTALL_NATIVE_UTILITY','USERPROFILE','HOME',
        'INSTALL_SUBJECT_ROOT','INSTALL_ASSET_ZIP','INSTALL_PRESET_FIXTURE','INSTALL_FIXTURE_PF','INSTALL_FIXTURE_PF86')
    require(all(type(warm['environment'].get(key)) is str and warm['environment'][key]==product['environment'].get(key)
        for key in shared),'Preparation used different fixture/native inputs')
    require(warm.get('nonce')==warm['environment'].get('INSTALL_READY_NONCE')
        and product.get('nonce')==product['environment'].get('INSTALL_READY_NONCE')==observation.get('readinessNonce')
        and warm['nonce']!=product['nonce'] and warm.get('pid')!=product.get('pid'),
        'Preparation PID/nonce is missing or replayed')
    require(warm.get('ready') is True and product.get('ready') is True
        and type(warm.get('entryExit')) is int and warm['entryExit']==0
        and type(warm.get('terminalObservedElapsedSeconds')) in (int,float)
        and warm['terminalObservedElapsedSeconds']>=preparation['holdSeconds']
        and not any(step.get('step')=='kill-owned-process' for step in warm.get('cleanup',{}).get('steps',[])),
        'Source-free preparation did not naturally complete its bounded hold')
    names={'warmBefore','warmReady','warmAfter','productBefore','productReady','productAfter'}
    require(type(phases) is dict and set(phases)==names
        and type(preparation['phaseFacts']) is dict and set(preparation['phaseFacts'])==names,
        'Missing normal preparation inventory phase')
    for inventory in phases.values():
        require(type(inventory) is dict and inventory.get('schema')=='r0016-entry-full-input-inventory.v1'
            and inventory.get('root')==observation['fixture'] and inventory.get('complete') is True
            and type(inventory.get('rows')) is list and inventory.get('passes')==[inventory['rows'],inventory['rows']],
            'Incomplete normal preparation double inventory')
        composition.validate_rows(inventory['rows'])
    require(phases['warmReady']==warm.get('fullReady') and phases['productReady']==product.get('fullReady')
        and phases['productBefore']==observation.get('fullInputsBefore')
        and phases['productReady']==observation.get('fullInputsAtReady')
        and phases['productAfter']==observation.get('fullInputsAfter'),
        'Normal preparation phase differs from actual receipt')
    require(phases['warmAfter']['rows']==phases['productBefore']['rows'],
        'Normal inputs changed between completed preparation and product baseline')
    cache_names={'warmBefore','warmAfter','productBefore','productAfter'}
    require(type(cache_raw) is dict and set(cache_raw)==cache_names
        and type(preparation['cacheCaptures']) is dict and set(preparation['cacheCaptures'])==cache_names,
        'Missing normal raw cache phase')
    for name in cache_names:
        row=receive_cache_bytes(cache_raw[name],phases[name]['rows'])
        entry=preparation['cacheCaptures'][name]
        require(type(entry) is dict and set(entry)=={'inventoryRow','capture'} and entry['inventoryRow']==row,
            'Normal raw cache inventory binding differs')
        capture=entry['capture'];raw=cache_raw[name]
        require((raw is None and capture is None) or (type(raw) is bytes and type(capture) is dict
            and capture.get('bytes')==len(raw) and capture.get('sha256')==digest(raw)),
            'Normal raw cache fact differs')
    if host=='ps51':
        context=receive_warm_context(warm_raw,warm,assembly_binding)
        expected=preparation['warmJsonContext']
        require(type(expected) is dict and set(expected)=={'context','assemblyBinding','bindingFact'}
            and expected['context']==context and expected['assemblyBinding']==assembly_binding,
            'Native JSON preparation proof differs')
    else:
        require(assembly_binding is None and preparation['warmJsonContext'] is None,
            'PS7 normal preparation contains an invented native JSON proof')
    return preparation
