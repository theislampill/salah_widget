$ErrorActionPreference='Stop'
Write-Host 'R0016 independent host startup control'

$command=Get-Command -Name ConvertFrom-Json -CommandType Cmdlet -ErrorAction Stop
if(@($command).Count -ne 1){throw 'Ambiguous native JSON command'}
$parsed=& $command -InputObject '{"r0016Probe":"source-free","value":16}'
if($parsed.r0016Probe -cne 'source-free' -or $parsed.value -ne 16){throw 'Native JSON warm-up failed'}
$assemblyPath=$command.ImplementingType.Assembly.Location
$assemblyBytes=[IO.File]::ReadAllBytes($assemblyPath)
$hasher=[Security.Cryptography.SHA256]::Create()
try{$assemblySha=([BitConverter]::ToString($hasher.ComputeHash($assemblyBytes))).Replace('-','').ToLowerInvariant()}finally{$hasher.Dispose()}
$context=[ordered]@{schema='r0016-source-free-json-context.v1';pid=$PID;nonce=$env:INSTALL_READY_NONCE;normal=$env:INSTALL_FIXTURE_NORMAL;command=$command.Name;commandType=[string]$command.CommandType;module=$command.ModuleName;nativeUtility=$env:INSTALL_NATIVE_UTILITY;analysisCachePath=$env:PSModuleAnalysisCachePath;parsedMarker=$parsed.r0016Probe;parsedValue=$parsed.value;assemblyPath=$assemblyPath;assemblyBytes=$assemblyBytes.Length;assemblySha256=$assemblySha;moduleSearchPath=$env:PSModulePath}
[Console]::WriteLine('R0016_WARM_JSON_CONTEXT '+($context|ConvertTo-Json -Depth 4 -Compress))
[Threading.Thread]::Sleep(20000)
exit 0
