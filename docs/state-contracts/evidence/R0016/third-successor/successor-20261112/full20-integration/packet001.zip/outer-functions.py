def bind_preparation_receipt(receipt, case, capture, facts):
    environment=receipt.get('environment');nonce=receipt.get('nonce');pid=receipt.get('pid')
    require(type(environment) is dict and type(nonce) is str and re.fullmatch(r'[0-9a-f]{32}',nonce)
        and type(pid) is int and pid>0 and environment.get('INSTALL_READY_NONCE')==nonce,
        'Missing actual native preparation identity')
    token=str(pid)+'\t'+nonce
    if capture.name=='host-only-control':
        require(receipt.get('ready') is True,'Source-free preparation readiness is missing')
    # Early option refusals intentionally need no direct readiness; the source-free leg always does.
    if receipt.get('ready') is True:
        require(receipt.get('readyToken')==token,'Actual native PID/nonce token differs')
        for key,variable,filename in (('readyFact','INSTALL_READY_FILE','ready'),('ackFact','INSTALL_PROFILE_ACK',
            'ack' if capture.name=='host-only-control' else 'profile-ack')):
            expected=(capture/filename) if capture.name=='host-only-control' else case/filename
            path=checked_path(environment.get(variable),case)
            require(path==expected,'Native preparation readiness path differs')
            facts.append(verify_fact(receipt.get(key),path,case))
            require(path.read_bytes().decode('utf-8-sig')==token,'Native readiness raw bytes differ')
    for stream in ('stdout','stderr'):
        facts.append(verify_fact(receipt.get(stream),capture/(stream+'.raw'),case))
    for field,filename in (('before','profile-before-launch.json'),('after','profile-after-exit.json')):
        require(receipt.get(field)==read_json_array(capture/filename,case),'Original native profile inventory differs')
        facts.append(file_fact(capture/filename,case))
    if receipt.get('ready') is True:
        require(receipt.get('atReady')==read_json_array(capture/'profile-at-ready.json',case),
            'Original native ready profile inventory differs')
        facts.append(file_fact(capture/'profile-at-ready.json',case))
    return nonce


def read_json_array(path, owner):
    path=checked_path(path,owner)
    require(path.stat().st_size<=JSON_LIMIT,'Profile evidence exceeds bounded size')
    # Reuse the duplicate-member/nonfinite-aware object receiver for an array root.
    value=parse_json(b'{"rows":'+path.read_bytes()+b'}')['rows']
    require(type(value) is list,'Missing original profile inventory array')
    return value


def validate_normal_preparation(observation, case, host, scenario, composition, receivers):
    preparation=observation.get('normalPreparation')
    require(type(preparation) is dict,'Missing original normal preparation evidence')
    startup=case/'host-only-control';facts=[];phases={}
    locations=dict(warmBefore=startup/'full-before-launch.json',warmReady=startup/'full-at-ready.json',
        warmAfter=startup/'full-after-exit.json',productBefore=case/'direct-full-before-launch.json',
        productReady=case/'entry-profile-window/full-at-ready.json',productAfter=case/'direct-full-after-exit.json')
    require(type(preparation.get('phaseFacts')) is dict and set(preparation['phaseFacts'])==set(locations),
        'Missing raw normal preparation phase facts')
    for name,path in locations.items():
        facts.append(verify_fact(preparation['phaseFacts'][name],path,case))
        phases[name]=read_json(path,case)
    script=startup/'host-only.ps1'
    facts.append(verify_fact(preparation.get('script'),script,case))
    caches={}
    cache_locations=dict(warmBefore=startup/'cache-before.raw',warmAfter=startup/'cache-after.raw',
        productBefore=case/'cache-product-before.raw',productAfter=case/'cache-product-after.raw')
    require(type(preparation.get('cacheCaptures')) is dict and set(preparation['cacheCaptures'])==set(cache_locations),
        'Missing raw normal cache facts')
    for name,path in cache_locations.items():
        entry=preparation['cacheCaptures'][name]
        require(type(entry) is dict,'Malformed raw normal cache binding')
        capture=entry.get('capture')
        if capture is None:
            require(not path.exists(),'Unreported normal cache byte capture')
            caches[name]=None
        else:
            facts.append(verify_fact(capture,path,case));caches[name]=path.read_bytes()
    effect=startup/'effects'
    require(not effect.exists() or not effect.read_bytes(),'Normal preparation reached an installer effect spy')
    if effect.exists():facts.append(file_fact(effect,case))
    binding=None
    if host=='ps51':
        context=preparation.get('warmJsonContext')
        require(type(context) is dict,'Missing native JSON preparation context')
        binding_path=case/'warm-json-assembly-binding.json'
        facts.append(verify_fact(context.get('bindingFact'),binding_path,case))
        journal=read_json(binding_path,case)
        require(journal.get('schema')=='r0016-warm-json-native-file-binding.v1'
            and journal.get('comparisons')==[context.get('assemblyBinding')],
            'Original native JSON binding journal differs')
        binding=context['assemblyBinding']
        # Only the pinned native binding helper may associate raw spelling with canonical identity.
        received_path=case/'warm-json-assembly-received.json'
        received=dict(schema='r0016-warm-json-native-file-binding.v1',comparisons=[])
        receivers['record_probe_file_binding'](binding.get('childFact'),'warm-json/assembly',received_path,received)
        require(received['comparisons']==[binding],'Native JSON file identity changed after preparation')
        facts.append(file_fact(received_path,case))
    receivers['require_normal_preparation'](observation,host,scenario,script.read_bytes(),phases,caches,
        (startup/'stdout.raw').read_bytes(),binding)
    return facts
