import ast, hashlib, pathlib, difflib
HERE=pathlib.Path(__file__).resolve().parent
HARNESS='tests/install-entry-native-composition.py'
OUTER='tools/qualification/installer_preview_windows_full_entry.py'
diagnostic=(HERE/'diagnostic-source.py').read_text()
tree=ast.parse(diagnostic)
def definition(name):
    node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
    return ast.get_source_segment(diagnostic,node)+'\n'
helpers='\n'.join(definition(n) for n in ('digest','warm_control_body','receive_cache_bytes','parse_warm_context','receive_native_assembly','receive_warm_context'))
helpers+='\n'+(HERE/'preparation-functions.py').read_text()
text=(HERE/'baseline'/HARNESS).read_text()
def replace(old,new):
    global text
    assert text.count(old)==1,old
    text=text.replace(old,new,1)
replace('def snapshot(root):',helpers+'\n\ndef snapshot(root):')
replace("    route = 'store'", "    if normal and host_name=='ps7':\n        env['COMPlus_MultiCoreJitNoProfileGather']='1'\n    route = 'store'")
old='    host_control.write_text("$ErrorActionPreference=\'Stop\'\\nWrite-Host \'R0016 independent host startup control\'\\nexit 0\\n",encoding=\'ascii\')'
replace(old,"    # This is a measured source-free calibration workload, not a unique causal repair.\n    # Historical warm20 variation remains unresolved; product cache changes still fail.\n    preparation_mode='warm-json' if normal and host_name=='ps51' else 'no-gather' if normal else 'default'\n    host_control.write_text(warm_control_body(preparation_mode),encoding='ascii')\n    preparation_phases={};preparation_cache={}\n    if normal:\n        preparation_phases['warmBefore']=composition.double_inventory(root,support,startup/'full-before-launch.json',LOCKS)\n        preparation_cache['warmBefore']=capture_preparation_cache(root/'analysis-cache',preparation_phases['warmBefore'],startup/'cache-before.raw')")
replace('startup_env,startup,host_home,ENTRY_TIMEOUT_SECONDS)', 'startup_env,startup,host_home,ENTRY_TIMEOUT_SECONDS,root if normal else None)\n        if normal:\n            preparation_phases[\'warmReady\']=startup_window.get(\'fullReady\')\n            preparation_phases[\'warmAfter\']=composition.double_inventory(root,support,startup/\'full-after-exit.json\',LOCKS)\n            preparation_cache[\'warmAfter\']=capture_preparation_cache(root/\'analysis-cache\',preparation_phases[\'warmAfter\'],startup/\'cache-after.raw\')')
anchor="        require(not (startup/'effects').exists() or not (startup/'effects').read_bytes(),'Host-only control reached an installer effect spy')"
replace(anchor,anchor+"\n        warm_json=None\n        if normal and host_name=='ps51':\n            warm_raw=(startup/'stdout.raw').read_bytes()\n            binding_path=root/'warm-json-assembly-binding.json'\n            assembly_binding=receive_native_assembly(composition.diagnostic,parse_warm_context(warm_raw),binding_path)\n            warm_json=dict(context=receive_warm_context(warm_raw,startup_window,assembly_binding),\n                assemblyBinding=assembly_binding,bindingFact=composition.fact(binding_path))")
for variable,phase,capture in [('direct_inputs_before','productBefore','cache-product-before.raw'),('direct_inputs_after','productAfter','cache-product-after.raw')]:
    filename='direct-full-before-launch.json' if phase=='productBefore' else 'direct-full-after-exit.json'
    anchor='    '+variable+"=composition.double_inventory(root,support,root/'"+filename+"',LOCKS)"
    replace(anchor,anchor+"\n    if normal:\n        preparation_phases['"+phase+"']="+variable+"\n        preparation_cache['"+phase+"']=capture_preparation_cache(root/'analysis-cache',"+variable+",root/'"+capture+"')")
anchor="    try:\n        if scenario not in ('bad-option','invalid-env-source'):"
replace(anchor,"    if normal:\n        preparation_phases['productReady']=profile_window.get('fullReady')\n        phase_paths=dict(warmBefore=startup/'full-before-launch.json',warmReady=startup/'full-at-ready.json',\n            warmAfter=startup/'full-after-exit.json',productBefore=root/'direct-full-before-launch.json',\n            productReady=root/'entry-profile-window/full-at-ready.json',productAfter=root/'direct-full-after-exit.json')\n        observation['normalPreparation']=dict(schema='r0016-normal-preparation.v1',mode=preparation_mode,\n            holdSeconds=20 if host_name=='ps51' else 0,script=composition.fact(host_control),\n            phaseFacts={name:composition.fact(path) for name,path in phase_paths.items()},\n            cacheCaptures=preparation_cache,warmJsonContext=warm_json)\n    try:\n        if normal:\n            raw_cache={name:pathlib.Path(value['capture']['path']).read_bytes() if value['capture'] else None\n                for name,value in preparation_cache.items()}\n            require_normal_preparation(observation,host_name,scenario,host_control.read_bytes(),preparation_phases,\n                raw_cache,(startup/'stdout.raw').read_bytes(),warm_json['assemblyBinding'] if warm_json else None)\n        if scenario not in ('bad-option','invalid-env-source'):")
(HERE/'candidate'/HARNESS).write_text(text)
new_harness=text.encode()
text=(HERE/'baseline'/OUTER).read_text()
outer_helpers=(HERE/'outer-functions.py').read_text()
replace('def validate_case_headers(',outer_helpers+'\n\ndef validate_case_headers(')
replace('normal_receiver,composition,product_receivers):','normal_receiver,composition,product_receivers,preparation_receivers):')
anchor="        require(type(observation['hostOnlyBaseline'].get('entryExit')) is int and observation['hostOnlyBaseline']['entryExit']==0,'Host-only baseline failed')"
replace(anchor,anchor+"\n        launch=read_json(case/'direct-launch-inputs.json',case)\n        require(launch==direct and launch.get('environment')==observation['profileWindow'].get('environment'),\n            'Stored actual prelaunch environment differs')\n        facts.append(file_fact(case/'direct-launch-inputs.json',case))\n        preparation_receivers['require_scoped_preparation_environment'](host,scenario,[\n            direct.get('environment'),observation['hostOnlyBaseline'].get('environment'),observation['profileWindow'].get('environment')])\n        for name,capture_name in (('profileWindow','entry-profile-window'),('hostOnlyBaseline','host-only-control')):\n            receipt=observation[name];capture_path=case/capture_name\n            require(read_json(capture_path/'profile-window.json',case)==receipt,'Stored actual native receipt differs')\n            facts.append(file_fact(capture_path/'profile-window.json',case))\n            nonces.append(bind_preparation_receipt(receipt,case,capture_path,facts))\n        if scenario in ('positive','no-open'):\n            facts+=validate_normal_preparation(observation,case,host,scenario,composition,preparation_receivers)")
# The list now contains each direct nonce twice (report field and physical receipt), plus warm nonces.
replace("    return dict(cases=list(CASES)","    require(len(set(nonces))==2*len(CASES),'Replayed direct or preparation nonce')\n    return dict(cases=list(CASES)")
# Retain the original direct-nonce assertion exactly by using a separate complete list.
text=text.replace("nonces.append(bind_preparation_receipt(receipt,case,capture_path,facts))","preparation_nonces.append(bind_preparation_receipt(receipt,case,capture_path,facts))")
text=text.replace("    facts=[];pids=[];nonces=[]\n", "    facts=[];pids=[];nonces=[];preparation_nonces=[]\n",1)
text=text.replace("len(set(nonces))==2*len(CASES)","len(set(preparation_nonces))==2*len(CASES)")
anchor="    path_budget=report.get('pathBudget');"
replace(anchor,"    preparation_receivers={}\n    preparation_bindings=dict(SCENARIOS=CASES,hashlib=hashlib,json=json,re=re,composition=composition)\n    for name in ('digest','warm_control_body','receive_cache_bytes','parse_warm_context','receive_warm_context',\n+        'require_scoped_preparation_environment','require_normal_preparation'):\n        preparation_receivers[name]=selected_pure_receiver(Path(launched['tests/install-entry-native-composition.py']['path']),\n            name,INPUTS['tests/install-entry-native-composition.py'][1],preparation_bindings)\n        preparation_bindings[name]=preparation_receivers[name]\n    "+anchor.strip())
# Remove a literal patch marker from the generated insertion.
text=text.replace("\n+        'require_scoped", "\n        'require_scoped")
replace("    path_budget=report.get('pathBudget');", "    native_driver=load_exact(Path(launched['tests/install-entry-driver-diagnostic.py']['path']),\n        INPUTS['tests/install-entry-driver-diagnostic.py'][1],'r16_full_entry_native_preparation_binding')\n    preparation_receivers['record_probe_file_binding']=native_driver.record_probe_file_binding\n    path_budget=report.get('pathBudget');")
replace('normal_receiver,composition,product_receivers)\n','normal_receiver,composition,product_receivers,preparation_receivers)\n')
old_pin="(56398, 'a453230b3527bdc5a81dcf7279d9af2aad14b32c07756a4700c97eab2ce24646')"
replace(old_pin,repr((len(new_harness),hashlib.sha256(new_harness).hexdigest())))
(HERE/'candidate'/OUTER).write_text(text)
patch=''
for role in (HARNESS,OUTER):
    before=(HERE/'baseline'/role).read_text().splitlines(True)
    after=(HERE/'candidate'/role).read_text().splitlines(True)
    patch+=''.join(difflib.unified_diff(before,after,fromfile='a/'+role,tofile='b/'+role))
(HERE/'candidate.patch').write_text(patch)
