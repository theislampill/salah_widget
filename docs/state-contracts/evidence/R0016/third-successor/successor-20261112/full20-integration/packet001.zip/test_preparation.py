"""Inert controls: original native records, pure AST receivers, and local evidence files.

No native harness import, PowerShell, installer, child process, or network request.
"""
import argparse, ast, copy, hashlib, importlib.util, json, math, os, pathlib, re, stat, sys, tempfile, types, unittest
sys.dont_write_bytecode=True
HERE=pathlib.Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--variant',choices=('baseline','candidate'),default='candidate')
ARGS,UNIT=parser.parse_known_args()
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module);return module
COMMON=load(HERE/'inputs/tests/install-entry-composition-support.py','inert_common')
SUPPORT=load(HERE/'inputs/tests/install-entry-coverage-support.py','inert_support')
OUTER=load(HERE/ARGS.variant/'tools/qualification/installer_preview_windows_full_entry.py','inert_outer')
HARNESS=HERE/ARGS.variant/'tests/install-entry-native-composition.py'
SOURCE=OUTER.INPUTS['install.ps1'][1]
def require(value,message):
    if not value:raise AssertionError(message)
def pure(names,namespace):
    tree=ast.parse(HARNESS.read_bytes());found={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
    for name in names:
        require(name in found,'Missing new normal preparation receiver: '+name)
        exec(compile(ast.Module(body=[found[name]],type_ignores=[]),str(HARNESS),'exec'),namespace)
    return namespace
NAMES=('digest','warm_control_body','receive_cache_bytes','parse_warm_context','receive_warm_context',
    'require_scoped_preparation_environment','require_normal_preparation')
def receivers():
    composition=types.SimpleNamespace(PREVIEW_SOURCE_SHA=SOURCE,validate_rows=COMMON.validate_rows,
        require_positive_confinement=COMMON.require_positive_confinement,ROW_FIELDS=COMMON.ROW_FIELDS)
    return pure(NAMES,dict(require=require,json=json,hashlib=hashlib,re=re,math=math,
        composition=composition,SCENARIOS=COMMON.SCENARIOS))
def fact(path):
    return dict(path=str(path),bytes=len(path.read_bytes()),sha256=hashlib.sha256(path.read_bytes()).hexdigest())
LOCATIONS=dict(warmBefore='host-only-control/full-before-launch.json',warmReady='host-only-control/full-at-ready.json',
    warmAfter='host-only-control/full-after-exit.json',productBefore='direct-full-before-launch.json',
    productReady='entry-profile-window/full-at-ready.json',productAfter='direct-full-after-exit.json')
CACHES=dict(warmBefore='host-only-control/cache-before.raw',warmAfter='host-only-control/cache-after.raw',
    productBefore='cache-product-before.raw',productAfter='cache-product-after.raw')
def native(case='c10'):
    fixture=HERE/'fixtures/native-43216080799';base=fixture/case
    report=json.loads((fixture/'entry-composition-report.json').read_bytes())
    obs=copy.deepcopy(next(r['observation'] for r in report['results'] if r['case']==('positive' if case=='c10' else 'no-open')))
    phases={name:json.loads((base/path).read_bytes()) for name,path in LOCATIONS.items()}
    raw={name:(base/path).read_bytes() if (base/path).exists() else None for name,path in CACHES.items()}
    journal=json.loads((base/'warm-json-assembly-binding.json').read_bytes());binding=journal['comparisons'][0]
    warm_raw=(base/'host-only-control/stdout.raw').read_bytes()
    context=receivers()['parse_warm_context'](warm_raw)
    captures={}
    for name,path in CACHES.items():
        row=next(r for r in phases[name]['rows'] if r['role']=='analysisCache')
        captures[name]=dict(inventoryRow=row,capture=fact(base/path) if raw[name] is not None else None)
    obs['normalPreparation']=dict(schema='r0016-normal-preparation.v1',mode='warm-json',holdSeconds=20,
        script=fact(base/'host-only-control/host-only.ps1'),phaseFacts={name:fact(base/path) for name,path in LOCATIONS.items()},
        cacheCaptures=captures,warmJsonContext=dict(context=context,assemblyBinding=binding,bindingFact=fact(base/'warm-json-assembly-binding.json')))
    return dict(observation=obs,host='ps51',scenario='positive' if case=='c10' else 'no-open',
        script=(base/'host-only-control/host-only.ps1').read_bytes(),phases=phases,cache_raw=raw,
        warm_raw=warm_raw,assembly_binding=binding)
def receive(data):
    return receivers()['require_normal_preparation'](**data)

class PreparationReceiving(unittest.TestCase):
    def test_original_native_rows_admit_complete_preparation(self):
        for case in ('c10','c11'):
            with self.subTest(case=case):
                data=native(case);self.assertEqual(receive(data),data['observation']['normalPreparation'])
    def test_missing_new_preparation_is_rejected(self):
        data=native();data['observation'].pop('normalPreparation')
        with self.assertRaisesRegex(AssertionError,'Missing complete normal preparation'):receive(data)
    def test_ps7_normal_mode_accepts_only_scoped_no_gather(self):
        data=native();data.update(host='ps7',script=receivers()['warm_control_body']('no-gather').encode(),assembly_binding=None)
        preparation=data['observation']['normalPreparation'];preparation.update(mode='no-gather',holdSeconds=0,warmJsonContext=None)
        observation=data['observation']
        for environment in (observation['directLaunchInputs']['environment'],observation['profileWindow']['environment'],observation['hostOnlyBaseline']['environment']):
            environment['COMPlus_MultiCoreJitNoProfileGather']='1'
        self.assertEqual(receive(data),preparation)
        observation['directLaunchInputs']['environment'].pop('COMPlus_MultiCoreJitNoProfileGather')
        with self.assertRaises(AssertionError):receive(data)
    def test_forced_preparation_cleanup_cannot_be_credited(self):
        data=native();data['observation']['hostOnlyBaseline']['cleanup']['steps'].append(dict(step='kill-owned-process',completed=True,error=None))
        with self.assertRaisesRegex(AssertionError,'naturally complete'):receive(data)
    def test_wrong_host_mode_hold_or_preview_is_rejected(self):
        for key,value in [('host','ps7'),('host','ps766'),('scenario','github')]:
            data=native();data[key]=value
            with self.subTest(key=key,value=value),self.assertRaises(AssertionError):receive(data)
        for key,value in [('mode','warm20'),('holdSeconds',0),('holdSeconds',True)]:
            data=native();data['observation']['normalPreparation'][key]=value
            with self.subTest(key=key),self.assertRaises(AssertionError):receive(data)
    def test_crosscase_nonce_and_pid_rejected(self):
        other=native('c11')
        for field in ('nonce','pid'):
            data=native();data['observation']['hostOnlyBaseline'][field]=other['observation']['hostOnlyBaseline'][field]
            with self.subTest(field=field),self.assertRaises(AssertionError):receive(data)
    def test_source_free_body_and_native_command_proof_rejected(self):
        data=native();data['script']=data['script'].replace(b'value":16',b'value":17')
        with self.assertRaisesRegex(AssertionError,'body differs'):receive(data)
        data=native();data['warm_raw']=data['warm_raw'].replace(b'ConvertFrom-Json',b'ConvertTo-Json')
        with self.assertRaisesRegex(AssertionError,'command/cache binding'):receive(data)
    def test_same_length_cache_corruption_and_missing_capture_rejected(self):
        for name in CACHES:
            data=native();raw=data['cache_raw'][name]
            data['cache_raw'][name]=(bytes([raw[0]^1])+raw[1:]) if raw else b'invented'
            with self.subTest(phase=name),self.assertRaises(AssertionError):receive(data)
        data=native();data['cache_raw']['productBefore']=None
        with self.assertRaises(AssertionError):receive(data)
    def test_every_inventory_phase_and_pass_is_mandatory(self):
        for name in LOCATIONS:
            data=native();data['phases'].pop(name)
            with self.subTest(phase=name),self.assertRaisesRegex(AssertionError,'inventory phase'):receive(data)
            data=native();data['phases'][name]['passes']=data['phases'][name]['passes'][:1]
            with self.subTest(pass_=name),self.assertRaisesRegex(AssertionError,'double inventory'):receive(data)
    def test_after_preparation_baseline_change_rejected(self):
        data=native();data['phases']['warmAfter']['rows'][0]['mtimeNs']+=1
        with self.assertRaisesRegex(AssertionError,'double inventory|between completed'):receive(data)
    def test_every_native_identity_observation_is_mandatory(self):
        for name in ('rawBefore','canonicalBefore','rawAfter','canonicalAfter'):
            data=native();data['assembly_binding']['nativeFileIdentity']['observations'].pop(name)
            with self.subTest(observation=name),self.assertRaisesRegex(AssertionError,'Incomplete native JSON'):receive(data)
    def test_native_content_canonical_identity_and_environment_corruption_rejected(self):
        for name,value in [('contentMatches',False),('sameFile',False),('stable',False),('resolutionMatches',False),
            ('canonicalPath','C:\\unrelated.dll')]:
            data=native();data['assembly_binding']['nativeFileIdentity'][name]=value
            with self.subTest(field=name),self.assertRaises(AssertionError):receive(data)
        data=native();data['warm_raw']=data['warm_raw'].replace(b'analysis-cache',b'elsewhere-file')
        with self.assertRaises(AssertionError):receive(data)
    def test_scoped_flag_acceptance_matrix_and_case_insensitivity(self):
        function=receivers()['require_scoped_preparation_environment']
        for host in ('ps51','ps7'):
            for scenario in COMMON.SCENARIOS:
                expected={'complus_multicorejitnoprofilegather':'1'} if host=='ps7' and scenario in ('positive','no-open') else {}
                function(host,scenario,[dict(expected) for _ in range(3)])
                wrong={} if expected else {'COMPlus_MultiCoreJitNoProfileGather':'1'}
                with self.subTest(host=host,scenario=scenario),self.assertRaisesRegex(AssertionError,'scoped prelaunch'):
                    function(host,scenario,[expected,wrong,expected])
        for value in ('0',1,None):
            with self.assertRaises(AssertionError):function('ps7','positive',[{'COMPlus_MultiCoreJitNoProfileGather':value}]*3)
        with self.assertRaises(AssertionError):function('ps7','positive',[{'COMPlus_MultiCoreJitNoProfileGather':'1','COMPLUS_MULTICOREJITNOPROFILEGATHER':'1'}]*3)
    def test_original_postcondition_still_rejects_any_product_cache_mutation(self):
        namespace=receivers();namespace.update(support=SUPPORT,SOURCE_HASH_BEFORE=SOURCE)
        function=pure(('require_normal_input_postcondition',),namespace)['require_normal_input_postcondition']
        data=native();obs=data['observation'];self.assertTrue(function(obs)['complete'])
        changed=copy.deepcopy(obs);inv=changed['fullInputsAfter'];row=next(r for r in inv['rows'] if r['role']=='analysisCache')
        row['sha256']='0'*64;inv['passes']=[copy.deepcopy(inv['rows']),copy.deepcopy(inv['rows'])]
        with self.assertRaisesRegex(AssertionError,'undeclared owned input fields'):function(changed)

class PhysicalEvidenceReceiving(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=HERE,prefix='inert-');self.addCleanup(self.tmp.cleanup)
        self.case=pathlib.Path(self.tmp.name).resolve();self.r=receivers();self.data=native();obs=self.data['observation']
        obs['fixture']=str(self.case)
        for phase in self.data['phases'].values():phase['root']=str(self.case)
        obs['hostOnlyBaseline']['fullReady']=self.data['phases']['warmReady']
        obs['profileWindow']['fullReady']=self.data['phases']['productReady']
        for field,phase in (('fullInputsBefore','productBefore'),('fullInputsAtReady','productReady'),('fullInputsAfter','productAfter')):
            obs[field]=self.data['phases'][phase]
        for name,relative in LOCATIONS.items():
            path=self.case/relative;path.parent.mkdir(parents=True,exist_ok=True)
            path.write_text(json.dumps(self.data['phases'][name]));obs['normalPreparation']['phaseFacts'][name]=fact(path)
        for name,relative in CACHES.items():
            path=self.case/relative
            if self.data['cache_raw'][name] is not None:
                path.write_bytes(self.data['cache_raw'][name]);obs['normalPreparation']['cacheCaptures'][name]['capture']=fact(path)
        script=self.case/'host-only-control/host-only.ps1';script.write_bytes(self.data['script']);obs['normalPreparation']['script']=fact(script)
        # Real local same-file lexical alias; never feed the raw spelling to strict canonical-only paths.
        (self.case/'native').mkdir();(self.case/'native/sub').mkdir();assembly=self.case/'native/utility.dll';assembly.write_bytes(b'local inert assembly bytes')
        child=dict(fact(assembly),path=str(self.case/'native/sub/../utility.dll'))
        namespace=dict(c=COMMON,Path=pathlib.Path,stat=stat,re=re)
        tree=ast.parse((HERE/'inputs/tests/install-entry-driver-diagnostic.py').read_bytes())
        node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='record_probe_file_binding')
        exec(compile(ast.Module(body=[node],type_ignores=[]),'pinned-native-file-binding','exec'),namespace)
        self.r['record_probe_file_binding']=namespace['record_probe_file_binding']
        journal=dict(schema='r0016-warm-json-native-file-binding.v1',comparisons=[])
        path=self.case/'warm-json-assembly-binding.json';self.r['record_probe_file_binding'](child,'warm-json/assembly',path,journal)
        binding=journal['comparisons'][0];context=self.r['parse_warm_context'](self.data['warm_raw'])
        context.update(assemblyPath=child['path'],assemblyBytes=child['bytes'],assemblySha256=child['sha256'])
        warm_raw=('R0016_WARM_JSON_CONTEXT '+json.dumps(context)+'\n').encode();(self.case/'host-only-control/stdout.raw').write_bytes(warm_raw)
        obs['normalPreparation']['warmJsonContext']=dict(context=context,assemblyBinding=binding,bindingFact=fact(path))
    def run_receiver(self):
        return OUTER.validate_normal_preparation(self.data['observation'],self.case,'ps51','positive',COMMON,self.r)
    def test_physical_raw_custody_and_canonical_native_binding(self):
        facts=self.run_receiver();self.assertEqual(len(facts),12)
        self.assertEqual(len({f['path'] for f in facts}),len(facts))
    def test_changed_physical_cache_rejected_even_if_report_unchanged(self):
        path=self.case/'cache-product-before.raw';raw=path.read_bytes();path.write_bytes(bytes([raw[0]^1])+raw[1:])
        with self.assertRaisesRegex(OUTER.Rejected,'File path/size/SHA differs'):self.run_receiver()
    def test_crosscase_script_fact_rejected(self):
        self.data['observation']['normalPreparation']['script']['path']=str(self.case/'c11/host-only.ps1')
        with self.assertRaisesRegex(OUTER.Rejected,'File path/size/SHA differs'):self.run_receiver()
    def test_missing_raw_inventory_rejected(self):
        (self.case/'host-only-control/full-at-ready.json').unlink()
        with self.assertRaises((FileNotFoundError,OUTER.Rejected)):self.run_receiver()
    def test_altered_original_native_binding_journal_rejected(self):
        path=self.case/'warm-json-assembly-binding.json';value=json.loads(path.read_bytes());value['comparisons'][0]['matches']=False
        path.write_text(json.dumps(value));self.data['observation']['normalPreparation']['warmJsonContext']['bindingFact']=fact(path)
        with self.assertRaisesRegex(OUTER.Rejected,'binding journal differs'):self.run_receiver()
    def test_actual_native_content_change_rejected_and_failed_journal_retained(self):
        (self.case/'native/utility.dll').write_bytes(b'changed actual assembly bytes')
        with self.assertRaisesRegex(AssertionError,'Unbound actual read module/assembly file'):self.run_receiver()
        failure=json.loads((self.case/'warm-json-assembly-received.json').read_bytes())
        self.assertIs(failure['comparisons'][0]['matches'],False)
    def test_preparation_effect_spy_cannot_be_credited(self):
        (self.case/'host-only-control/effects').write_bytes(b'download\tfixture\n')
        with self.assertRaisesRegex(OUTER.Rejected,'effect spy'):self.run_receiver()

    def local_receipt(self):
        capture=self.case/'entry-profile-window';nonce='a'*32;pid=1234;token=str(pid)+'\t'+nonce
        receipt=dict(environment=dict(INSTALL_READY_NONCE=nonce,INSTALL_READY_FILE=str(self.case/'ready'),
            INSTALL_PROFILE_ACK=str(self.case/'profile-ack')),pid=pid,nonce=nonce,ready=True,readyToken=token)
        for key,path in (('readyFact',self.case/'ready'),('ackFact',self.case/'profile-ack')):
            path.write_text(token);receipt[key]=fact(path)
        for stream in ('stdout','stderr'):
            path=capture/(stream+'.raw');path.write_bytes(b'');receipt[stream]=fact(path)
        for field,filename in (('before','profile-before-launch.json'),('atReady','profile-at-ready.json'),('after','profile-after-exit.json')):
            path=capture/filename;path.write_text('[]');receipt[field]=[]
        return receipt,capture
    def test_raw_readiness_and_all_profile_snapshots_are_bound(self):
        receipt,capture=self.local_receipt();facts=[]
        self.assertEqual(OUTER.bind_preparation_receipt(receipt,self.case,capture,facts),'a'*32)
        self.assertEqual(len(facts),7)
        (capture/'profile-at-ready.json').write_text('[{"path":"altered"}]')
        with self.assertRaisesRegex(OUTER.Rejected,'ready profile inventory differs'):
            OUTER.bind_preparation_receipt(receipt,self.case,capture,[])
    def test_replayed_raw_ready_token_is_rejected(self):
        receipt,capture=self.local_receipt();path=self.case/'ready';path.write_text('1234\t'+'b'*32)
        receipt['readyFact']=fact(path)
        with self.assertRaisesRegex(OUTER.Rejected,'readiness raw bytes differ'):
            OUTER.bind_preparation_receipt(receipt,self.case,capture,[])

if __name__=='__main__':unittest.main(argv=[sys.argv[0]]+UNIT,verbosity=2)
