"""Serial R0017 case list; no browser overlap and no automatic retries."""
import sys,subprocess,json
from pathlib import Path
B=Path(__file__).resolve().parent
jobs=[]
for engine in ['chromium','firefox']:
    for mode,storage in [('reject','malformed'),('hang','absent'),('bootstrap-error','valid')]:
        name=engine+'-'+mode+'-01'
        jobs.append((name,[str(B/'run_smoke.py'),'--engine',engine,'--mode',mode,'--storage',storage,'--out',str(B/'evidence/native'/name)]))
for engine in ['chromium','firefox']:
    for group in (['storage','identity','transport'] if engine=='chromium' else ['motion','storage','identity','transport']):
        name=engine+'-'+group+'-01'
        jobs.append((name,[str(B/'run_controls.py'),'--engine',engine,'--group',group,'--out',str(B/'evidence/controls'/name)]))
for engine in ['chromium','firefox']:
    name=engine+'-public-healthy-01'
    jobs.append((name,[str(B/'run_smoke.py'),'--engine',engine,'--public','--out',str(B/'evidence/delivery'/name)]))
receipts=[]
for name,command in jobs:
    logfile=B/'evidence'/('command-'+name+'.log')
    assert not logfile.exists(),'Retain previous command; no automatic replay'
    with logfile.open('wb') as log:
        result=subprocess.run([sys.executable,'-I','-S','-B',*command],stdout=log,stderr=subprocess.STDOUT)
    receipts.append({'name':name,'command':[sys.executable,'-I','-S','-B',*command],'exitCode':result.returncode,'log':logfile.name})
    (B/'evidence/remaining-command-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(receipts[-1]),flush=True)
