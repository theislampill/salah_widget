"""Requalify existing raw negative records with specific reached-consumer predicates.
No browsers or replay. Original records are immutable inputs, never overwritten.
"""
import hashlib,json
from pathlib import Path
B=Path(__file__).resolve().parent;E=B/'evidence'
sha=lambda b:hashlib.sha256(b).hexdigest()
result={'schema':'r0017-strict-control-readback/v1','scope':__doc__,'inputs':[]}
for engine in ['chromium','firefox']:
 p=E/'controls'/(engine+'-transport-01')/'result.json';raw=p.read_bytes();r=json.loads(raw)
 item={'path':p.relative_to(E).as_posix(),'sha256':sha(raw),'engine':engine,'cases':[]};result['inputs'].append(item)
 for case in r['cases']:
  name=case['id'];v=case['result'];f=v.get('fixture') or {};q=v.get('qa') or {};ledger=f.get('ledger',[])
  today=[x for x in ledger if '/v1/timings/07-09-2026?' in x['url']]
  checks={'notAdmitted':v['admitted'] is False,'noDriverException':not case.get('exception'),'outerPreserved':case['outer']['before']==case['outer']['after'] and case['outer']['getterAccesses']==0}
  if name in ['body-pending','malformed-json','wrong-response-day','missing-timings','bypass-json']:
   checks.update(readyActualFixture=f['state']=='ready' and f['error'] is None and f['storageIsolated'] and f['clockFixed'] and f['fetchIntercepted'],
    originalEightSecondTimeout=v.get('error') is None and v.get('reason')=='required scene readiness deadline exceeded' and case['elapsedSeconds']>=8,
    noUnrelatedPageError=not case['pageErrors'])
   if name=='bypass-json':checks.update(realPrayerLoaded=q.get('cache',{}).get('prayerLoaded') is True,noJsonCalls=len(today)>0 and all(x['jsonReads']==0 for x in ledger))
   else:checks.update(actualTodayJsonReached=len(today)>0 and all(x['attempt']==1 and x['jsonReads']==1 and x['result']=='json-consumed' and x['cache']=='no-store' for x in today),prayerNotAdopted=q.get('cache',{}).get('prayerLoaded') is False)
  elif name=='extra-request':
   error='Unexpected fixture request: https://api.aladhan.com/v1/timings/07-09-2026?latitude=24.47&longitude=39.61&method=4&school=0&unapproved=1'
   checks.update(exactUnexpectedUrl=f['error']==v['error']==error,exactRequestFailure=len(today)>0 and all(x['result']=='unexpected-request' and x['jsonReads']==0 for x in today),noPrayerAdoption=q.get('cache',{}).get('prayerLoaded') is False)
  else:
   error={'source-anchor':'Unreviewed widget script anchors','source-digest':'First-paint source identity mismatch'}[name]
   checks.update(exactBootstrapFailure=f['state']=='error' and f['error']==v['error']==error,beforeHooks=f['storageIsolated'] is False and f['fetchIntercepted'] is False and f['clockFixed'] is False,noConsumerRequests=ledger==[])
  item['cases'].append({'id':name,'checks':checks,'status':'PASS' if all(checks.values()) else 'FAIL'})
result['status']='PASS' if all(c['status']=='PASS' for i in result['inputs'] for c in i['cases']) else 'FAIL'
p=E/'controls/strict-transport-readback.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
