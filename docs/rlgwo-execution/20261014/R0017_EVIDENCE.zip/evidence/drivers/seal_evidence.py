"""Seal and independently read back local custody; no publication or acceptance implied."""
import hashlib,json
from pathlib import Path
B=Path(__file__).resolve().parent;E=B/'evidence'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert (E/'review/final-review.json').is_file(),'Final independent review must be retained first'
assert sha(E/'ledger.json')=='d9de0619495acf6991123cc9af69f1f5b48a8a8b45e088097c6aa246acac7d28'
reject=lambda x:(_ for _ in ()).throw(ValueError('Non-JSON constant: '+x))
json_paths=sorted(E.rglob('*.json'))
for p in json_paths:json.loads(p.read_text(encoding='utf-8-sig'),parse_constant=reject)
(E/'drivers/seal_evidence.py').write_bytes(Path(__file__).read_bytes())
files={p.relative_to(E).as_posix():{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(E.rglob('*')) if p.is_file() and p.name not in ['manifest.json','manifest-readback.json']}
manifest={'schema':'r0017-local-custody-manifest/v1','scope':'Local evidence only; not published or accepted for closure. Raw failures retained. Source snapshot/archive outside this packet is referenced by exact Git/runtime identity.','files':files,'fileCount':len(files),'totalBytes':sum(x['bytes'] for x in files.values())}
target=E/'manifest.json';assert not target.exists();target.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
actual=json.loads(target.read_bytes());failures=[]
for rel,entry in actual['files'].items():
 p=(E/rel).resolve()
 if not p.is_relative_to(E.resolve()) or not p.is_file() or p.stat().st_size!=entry['bytes'] or sha(p)!=entry['sha256']:failures.append(rel)
readback={'schema':'r0017-local-custody-readback/v1','manifestSha256':sha(target),'filesChecked':len(actual['files']),'bytesChecked':sum(x['bytes'] for x in actual['files'].values()),'strictJsonFilesBeforeSeal':len(json_paths),'failures':failures,'status':'PASS' if not failures else 'FAIL','scope':'Same-executor mechanical custody check, not independent native/issue acceptance.'}
(E/'manifest-readback.json').write_text(json.dumps(readback,indent=2)+'\n',encoding='utf-8');print(json.dumps(readback))
assert not failures
