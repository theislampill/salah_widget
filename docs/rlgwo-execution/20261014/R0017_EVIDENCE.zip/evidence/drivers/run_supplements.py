"""Fixed serial commands for outstanding reviewer gaps; preserve every prior attempt."""
import subprocess,sys,json
from pathlib import Path
B=Path(__file__).resolve().parent;E=B/'evidence'
jobs=[('chromium-matching-tomorrow-02',[str(B/'run_supplement.py'),'--engine','chromium','--only','matching-tomorrow','--out',str(E/'controls/chromium-matching-tomorrow-02')]),
 ('firefox-supplement-01',[str(B/'run_supplement.py'),'--engine','firefox','--out',str(E/'controls/firefox-supplement-01')]),
 ('normal-public-consumer-01',[str(B/'normal_public_consumer.py')])]
results=[]
for name,args in jobs:
 p=E/(name+'-command.log');assert not p.exists()
 with p.open('wb') as log:r=subprocess.run([sys.executable,'-I','-S','-B',*args],stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':[sys.executable,'-I','-S','-B',*args],'exitCode':r.returncode,'log':p.name})
 (E/'supplement-command-receipts.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8');print(json.dumps(results[-1]),flush=True)
