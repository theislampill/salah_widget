<!-- salah-widget-audit-20260907:SW-023 -->
# R0017: Make smoke outcomes prove required execution without erasing saved settings

**Repository-local identity:** `R0017` in `theislampill/salah_widget`; existing tracker [#23](https://github.com/theislampill/salah_widget/issues/23). The SW identifier is historical draft provenance.


Campaign draft alias: SW-023. Instrument/acceptance defect; proposed priority P1. A smoke PASS must mean its required widget checks executed successfully, its persistence tests must leave real settings untouched, and a correctly respected reduced-motion preference must not produce a false failure. These are three accepted subcases of one existing instrument owner, VAL-001/002/009. This issue does not assert that the underlying widget always fails or authorize implementation/publication.

## Bind the repair to main and preserve the evidence limits

The repair target is main `fd2972ba64225fe9d6848e92497e6d0ed20ea624`. Candidate `9d9c43649748555afbe09e3ca49bc47db2d7e7bb` supplies comparison evidence only; do not merge or import its extra tests wholesale. In the future authorized checkout:

```text
git --no-optional-locks rev-parse --show-toplevel
git --no-optional-locks remote get-url origin
git --no-optional-locks status --short --branch
git --no-optional-locks rev-parse HEAD
git --no-optional-locks diff fd2972ba64225fe9d6848e92497e6d0ed20ea624 HEAD -- tests/smoke.html config.js index.html README.md
```

Confirm the intended `theislampill/salah_widget` checkout and closer guidance; preserve unrelated dirty work. Reconcile relevant readiness, storage, response-consumer and test-interface differences before mutation. Stop on incompatible drift rather than claim the pinned defect exists on arbitrary future HEAD. Main’s tracked tests contain only `tests/smoke.html`; this plan therefore preserves the static-server/browser workflow and adds no browser framework or package dependency.

Exact owners are [harness readiness/persistence/scene handling](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/tests/smoke.html#L49-L127), [motion and summary](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/tests/smoke.html#L167-L203), [config storage methods](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/config.js#L132-L162), [resolve storage consumers](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/config.js#L228-L251), and [candidate harness comparison](https://github.com/theislampill/salah_widget/blob/9d9c43649748555afbe09e3ca49bc47db2d7e7bb/tests/smoke.html). Runtime source is read to design faithful fixtures, not to authorize renderer edits.

## What happened and why the existing green is not evidence

The retained 7 September controlled-source probe evaluated the actual `config.js` and smoke script against a Node VM DOM/Storage fixture whose `iframe.contentWindow` was null. The widget never executed. Main reported `21 passed · 0 failed · 13 skipped`, `className=pass`, `__smoke={pass:21,fail:0,skip:13}`; candidate reported 21/0/16 and pass. Missing-config control reported 0/1/13 or 0/1/16 and fail. The harness can detect a missing config module, but its required widget/scene checks turn unavailable execution into skips and the final color only asks whether `fail` is nonzero. Neither a real broken widget nor healthy deterministic integration was exercised by that VM witness.

The same fixture seeded `salah_widget:config:v1` with exact bytes `{"v":1,"lat":12,"lon":34,"label":"fixture-user-setting","method":"4","savedAt":42}` and `unrelated-origin-key=retained`. After the actual smoke, the settings value was null; the unrelated key survived. The missing-config control preserved the original bytes. Calls to `clearLocal()` before precedence/persistence tests and after save/load operate on the loaded production module’s real origin storage. Cleanup is therefore destructive preparation, even if the widget never boots. The audit itself used in-memory storage and changed no real user settings.

Finally, the reduced-motion test installs a reduce=true `matchMedia`, samples the pulse, restores the user’s actual function and unconditionally requires `live!==1`. Main’s [live preference decision](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/index.html#L661-L665) correctly keeps motion reduced when the restored OS preference is true; the [sun-pulse expression](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/index.html#L1844-L1849) then yields 1. This is a source-proved false-red conditional, not evidence that accessibility or animation is broken.

## Public RED recipe without private evidence files

Save this as `red-smoke.cjs` in a disposable directory and run `node red-smoke.cjs /absolute/pinned/source-root`. It reads source, evaluates only config/smoke against an in-memory unavailable iframe, and prohibits network. It does not open the public smoke page or touch browser storage.

```js
const fs=require('fs'),path=require('path'),vm=require('vm');
const root=process.argv[2];
function scripts(html){return [...html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)]
  .filter(m=>! /\bsrc\s*=/.test(m[1])&&! /type=["']application\//.test(m[1]))
  .map(m=>m[2]);}
async function run(configPresent){
  let ticks=0;const log=[];
  const elements={out:{appendChild(s){log.push({class:s.className,text:s.textContent});}},sum:{},w:{contentWindow:null}};
  class Storage{
    constructor(){this.data=new Map();}
    getItem(k){return this.data.has(k)?this.data.get(k):null;}
    setItem(k,v){this.data.set(k,String(v));}
    removeItem(k){this.data.delete(k);}
  }
  const storage=new Storage(),key='salah_widget:config:v1';
  const before='{"v":1,"lat":12,"lon":34,"label":"fixture-user-setting","method":"4","savedAt":42}';
  storage.setItem(key,before);storage.setItem('unrelated-origin-key','retained');
  class FakeDate extends Date{static now(){return 1800000000000+ticks;}}
  const ctx=vm.createContext({URLSearchParams,Storage,localStorage:storage,Date:FakeDate,Intl,DOMException,console,
    document:{getElementById(k){return elements[k];},createElement(){return {}; }},
    setTimeout(fn,ms){ticks+=ms;queueMicrotask(fn);},clearTimeout(){},
    fetch(){throw Error('Network prohibited in RED fixture');}});
  ctx.window=ctx;
  if(configPresent)vm.runInContext(fs.readFileSync(path.join(root,'config.js'),'utf8'),ctx);
  for(const js of scripts(fs.readFileSync(path.join(root,'tests/smoke.html'),'utf8')))
    await vm.runInContext(js,ctx);
  return {configPresent,summary:elements.sum.textContent,className:elements.sum.className,
    smoke:ctx.__smoke,before,after:storage.getItem(key),unrelated:storage.getItem('unrelated-origin-key'),log};
}
(async()=>console.log(JSON.stringify({unavailable:await run(true),missingConfig:await run(false)},null,2)))()
  .catch(e=>{console.error(e);process.exitCode=1;});
```

At the pinned RED, the unavailable-widget result is green and settings are deleted; the missing-config result is fail and preserves settings. Those are the historical oracles. The reproduced counts do not become a future acceptance target. Keep the before/after bytes and required-case names so adding tests cannot accidentally satisfy a magic count. This public recipe is transcribed for future use; no new probe execution is claimed by this work order.

## Repair in four ordered stages

### 1. Give required execution an explicit terminal result

Keep `loadUntil`’s exact requested hash check and navigation counter: they prevent a previous iframe scene from satisfying a new request. Add explicit required-case accounting alongside existing pass/fail/skip counters. Each named required case moves from pending to executed only when its actual callback finishes; assertion failure records executed+failed, whereas timeout/missing module remains missing. Await asynchronous callbacks and image decoding with a finite deadline so a hung image cannot leave the summary running forever.

Preserve `window.__smoke.pass/fail/skip` for existing readers. Add an in-memory `status` and named required totals/executed/failed/missing. The terminal rule is: observed assertion or bootstrap error => FAIL; otherwise any missing required case => INCOMPLETE; only complete required execution with zero failures => PASS. Show status, executed/required counts and missing names. Use the existing fail/non-pass style with truthful labels; do not build a dashboard or persisted report schema. A top-level catch/finally must finalize non-pass even when an unexpected callback throws.

All current main checks stay required: config parsing/serialization/precedence/persistence; gateWeatherCode/wxClass availability; dry forecast-thunder, supported rain, fog; calendar and physical moon; absence of painted dawn; cloud identity and observability; waxing/waning orientation; reduced-motion behavior; cloud continuity. Optional live-provider diagnostics must have their own label and cannot substitute for this deterministic required path. Do not call a timeout “offline” unless the fixture/transport actually identified that cause; a missing script, failed bootstrap and unresponsive provider are different observations.

### 2. Isolate storage without changing production settings semantics

Add an optional Storage-like dependency to the existing `storageAvailable(storage)`, `loadLocal(storage)`, `saveLocal(cfg,storage)`, `clearLocal(storage)` and `resolve(hashStr,storage)` methods. Existing omitted-argument callers keep current behavior. Resolve the default `root.localStorage` getter inside the current try/catch boundaries, so blocked storage still returns the current safe failure shape. Thread the same explicit dependency through both local/preferLocal calls to `loadLocal`; this is the easy-to-miss consumer edge.

Use a fresh Map-backed storage object for the smoke’s config/persistence tests and pass it everywhere. A second fixture whose `setItem` throws `DOMException('blocked','SecurityError')` tests denial. Remove the global `Storage.prototype.setItem` monkeypatch. Keep KEY `salah_widget:config:v1`, version 1, normalize/serialize/resolve semantics and default callers unchanged. No storage migration, global mutable test mode or second production config store is introduced.

Sentinel-protect real origin storage outside these fixtures. Original settings, malformed raw bytes, initially absent config and unrelated keys must be byte-identical after pass, assertion failure, callback throw and timeout. The persistence fixture should log or throw on any attempted real-storage access, including the `__sw_probe__` availability check. Do not normalize and resave the sentinel; that is not exact restoration. A save/restore-finally workaround remains vulnerable to another tab and process termination, so do not choose it over a dependency that never reaches real storage.

### 3. Make the healthy browser fixture use the actual widget path

Main’s [fetchTimings](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/index.html#L743-L758) fetches `/v1/timings/DD-MM-YYYY` with latitude/longitude/method/school, calls `response.json()`, adopts `data.meta.timezone` and returns `data`. [loadPrayerData](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/index.html#L2142-L2154) assigns today, writes its cache and renders. [model](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/index.html#L1200-L1223) consumes the six prayer timings plus Sunset; [date formatting](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/index.html#L686-L691) consumes day/year/month number/name. Supply those inputs rather than setting `prayerLoaded` or replacing render/qaState.

**Selected transport:** add one test-owned static wrapper, proposed `tests/widget-fixture.html`, reached by the default deterministic `loadUntil` path. It uses the same origin and ordinary browser APIs; no Playwright install, new provider, service worker or production hash flag is needed. Load it with the exact requested scene hash and a unique query attempt number. It fetches `../index.html` as source using a captured native fetch, verifies the expected document/script anchors, and records a digest of the fetched source for final-tree binding. Fetch failure/anchor mismatch must display a fixture bootstrap error and never continue with a fabricated widget.

Before parsing the widget document, the wrapper installs its isolated Storage-like object, fixed Date and transport in its own window. Verify the localStorage override by identity before proceeding; if the browser forbids it, fail setup before loading any widget code. The wrapper replaces its document with the fetched HTML, preserving the wrapper URL/hash, adding a base URL pointing to the repo root so `config.js` still loads from its actual public path. Keep wrapper declarations in an IIFE to avoid colliding with widget globals. Instrumentation must be installed before the first widget/config script executes and remain verifiably in place afterward. All widget script bodies stay unchanged; only the test transport/document wrapper differs. Do not evaluate a modified copy of `fetchTimings`.

The pinned head contains [three Google-font resource links](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/index.html#L3-L10). Suppress those external links in this fixture and add a test-only restrictive resource policy allowing same-origin scripts, inline widget script/style and required data images while blocking remote resources. This makes the healthy fixture independent of external fonts. It therefore qualifies runtime/control behavior only; it cannot certify typography, screenshot parity or M0. Fail on unreviewed added external-resource anchors instead of silently widening the policy.

Freeze no-argument `new Date()` and `Date.now()` to `2026-09-07T09:30:00.000Z`; retain real Date argument construction, UTC and parse operations. Add `tz=Asia/Riyadh` to each deterministic scene hash before navigation, preserving its other simulation parameters and the exact expected hash. With that location/time, the ordinary no-sim-time scene is 12:30 local; explicit `simTime` still drives its existing scene. Performance/rAF may continue normally; this is not the real-time liveness fixture. Start the iframe’s private storage empty on every navigation, so an old prayer cache cannot mask a failed response.

The complete healthy data fixture below is deliberately synthetic, including its Hijri dates. These are test values, not claimed actual prayer times or a conversion of 7 September 2026. Only requested Gregorian date and target request parameters are factual fixture identities.

```js
function prayerFixture(day) {
  // Admit exactly the initial day and its existing tomorrow prefetch.
  if(day !== '07-09-2026' && day !== '08-09-2026')
    throw Error('Unexpected fixture date: '+day);
  const tomorrow=day === '08-09-2026';
  return {data:{
    timings:{Fajr:'05:00',Sunrise:'06:00',Dhuhr:'12:00',Asr:'15:30',
             Sunset:'18:00',Maghrib:'18:00',Isha:'19:30'},
    meta:{timezone:'Asia/Riyadh'},
    date:{
      gregorian:{date:day,day:tomorrow?'08':'07',month:{number:9,en:'September'},year:'2026'},
      hijri:{day:tomorrow?'02':'01',month:{number:1,en:'Synthetic month'},year:'1500'}
    }
  }};
}
```

The fixture-only transport must implement the actual `fetch`/Response interface, log each request and JSON consumption, and have no network fallback. This is the complete decisive routing logic; `mode` and `attempt` come only from the test wrapper query, and `ledger` is new for that navigation:

```js
function fixtureFetch(input, init) {
  const u=new URL(typeof input==='string'?input:input.url, location.href);
  const row={attempt, url:u.href, jsonReads:0, result:'requested'};
  ledger.push(row);
  const day=u.pathname.slice('/v1/timings/'.length);
  const expected={latitude:'24.47',longitude:'39.61',method:'4',school:'0'};
  const allowed=u.origin==='https://api.aladhan.com' &&
    u.pathname.startsWith('/v1/timings/') &&
    Object.entries(expected).every(([k,v])=>u.searchParams.get(k)===v) &&
    [...u.searchParams.keys()].length===4 &&
    (day==='07-09-2026'||day==='08-09-2026');
  if(!allowed){row.result='unexpected-request';return Promise.reject(Error('Unexpected fixture request'));}
  if(mode==='reject'){row.result='rejected';return Promise.reject(Error('Controlled prayer rejection'));}
  if(mode==='hang'){row.result='pending';return new Promise(()=>{});}
  const response=new Response(JSON.stringify(prayerFixture(day)),
    {status:200,headers:{'Content-Type':'application/json'}});
  const nativeJson=response.json.bind(response);
  response.json=()=>{row.jsonReads++;row.result='json-consumed';return nativeJson();};
  return Promise.resolve(response);
}
```

All main scene hashes already carry `simWx`, which bypasses both weather and radar fetches in [the actual weather/radar guards](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/index.html#L771-L773) and [radar guard](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/index.html#L816-L821). Hardcoded coordinates avoid coarse geolocation. Unexpected provider calls must fail the fixture and appear in its ledger; do not silently return success-shaped data for them. The ordinary same-origin source/config resource loads happen before or outside this fetch interception and are explicitly permitted static inputs.

For healthy readiness, require the current attempt/hash, successful fixture setup, at least one logged/JSON-consumed request for `07-09-2026`, actual `qaState().cache.prayerLoaded`, a produced render summary and completion of the named scene assertions. This rejects stale data and a helper that returns without using the real consumer. At fixed 12:30, the supplied timings yield current Dhuhr, next Asr at 15:30 and 180 minutes remaining at the frozen reference instant; allow only the explicitly measured rAF elapsed-time tolerance when using the no-sim-time route. Prefer a frozen `simTime=12:30` integration control for exact 180. Normal tomorrow prefetch may request `08-09-2026`; it receives its matching Gregorian day, not a duplicate current-day body.

Expose wrapper modes `healthy`, `reject`, `hang` and `bootstrap-error` only under tests; reject an unknown mode before loading widget source. Bootstrap-error reports a known fixture failure before widget parsing; reject exercises actual three-attempt fetch failure; hang leaves prayer pending until the harness’s finite required-scene deadline. Start each in a new iframe with empty private storage. All three negative modes must end non-pass, even when the 21 config checks pass. A separate explicitly selected live diagnostic can navigate unchanged `../index.html`, but its provider unavailability must not be counted as a deterministic healthy PASS.

The future local browser command remains the existing workflow: from an authorized disposable copy of the final tree, run `python3 -m http.server 8765 --bind 127.0.0.1` if Python is already available, or use the existing static server, then open `http://127.0.0.1:8765/tests/smoke.html` in an isolated browser profile. The default selects the healthy wrapper. Run the instrument negatives as separate page invocations with `?fixture=reject`, `?fixture=hang` and `?fixture=bootstrap-error`; their expected non-pass summaries are successful negative-control evidence, not failures to hide inside the healthy summary. A `?fixture=healthy` invocation is the explicit positive. Forward only these validated test modes to each wrapper navigation; optional live mode is separately labeled. Capture every run’s summary, case ledger and console errors. The wrapper is a test-only consumer variation; final integration also needs a bounded check that the actual unchanged index entry still loads on the same final tree. Do not claim exact public entry, production storage safety in every embedding environment or deployed success solely from the wrapper.

### 4. Control reduced motion and restore it without assumptions

Save the iframe’s actual `matchMedia` function. Explicitly set reduce=true, call the real `applyTheme(model())`, and assert the pulse is 1. Then explicitly set reduce=false at a fixed deterministic simTime where the pulse is distinguishable from 1 and check the full-motion branch. Restore the exact original function in finally, including thrown assertions/timeouts; do not assert that restoration must enable motion. If an isolated sample can equal 1, choose the controlled time/interval before execution rather than weaken the oracle afterward.

Run `motion=full` as a separate hash fixture with reduce=true: the override must win. Exercise true/false OS settings in the actual browser while keeping the test’s explicit cases deterministic. A mutant ignoring reduction must fail the reduced case; a mutant ignoring motion=full must fail its override case. Do not change the product’s OS-respecting default to make the smoke pass.

## GREEN and discriminating controls

| Case | Required final observation |
|---|---|
| Null iframe / missing config | Both non-pass; missing required case names differ from an observed missing-module failure. Original storage bytes survive. |
| Healthy fixed response | Actual request and JSON consumption for current attempt; actual prayer load/render; every required scene callback executed; zero required failures/missing. |
| Rejected, hanging or known failed bootstrap | Fresh private cache; bounded non-pass; no blanket offline explanation; successful config checks cannot turn overall status green. |
| Stale previous frame/hash/attempt | Never admitted for the new scene. No late callback can mark another case executed. |
| Existing valid config, malformed raw config, absent config, unrelated key | Exact real-origin bytes/absence preserved after pass/fail/throw/timeout; zero real-storage persistence-fixture calls. |
| Explicit fake saved config + local/preferLocal/hardcoded modes | Same normalization/precedence as default API; test dependency reaches both resolve/load consumers. |
| Fake blocked storage | Existing `{ok:false}`/safe-load failure behavior; no global prototype replacement. |
| OS reduce true/false and separate motion=full | Correct behavior passes under either OS setting; exact function restored; ignoring reduction/override mutants fail. |
| Mutants: suppress required callback, mark timeout executed, seed stale prayer cache, bypass fetch/JSON, omit storage argument in resolve | Named execution/transport/storage oracle fails separately. Useful existing scenes remain required. |
| Default API callers with omitted storage argument | Existing product load/save/clear/resolve behavior retained in an isolated normal-entry control; no schema/key migration. |

Do not use cloud checksums or direct `paintClouds` samples as normal-live M0 evidence. The fixture can check existing weather truth, opaque/calendar moon and no painted dawn behavior, but visual claims still require the UI owner’s crops and real 15–60s motion evidence. Preserve 325×530 widget dimensions, header/footer readability, opaque moon and accessibility. External-font-suppressed/frozen-clock fixture output is explicitly unsuitable as the production appearance/liveness oracle.

## Why this scope, and how it closes

Making all network failures FAIL would confuse flaky provider availability with code regressions while leaving execution unspecified. Leaving all skips green creates the observed false assurance. A deterministic required path plus optional live diagnostics distinguishes those outcomes. A private storage argument is smaller and safer than a global test mode or finally restoring another tab’s changing state. The single reached wrapper replaces neither the widget’s prayer parser nor its renderer; fake qaState/prayerLoaded would bypass the causal path. Adding a package/build system or mandatory browser farm is unnecessary for this static project.

This owner writes `tests/smoke.html`, the narrow config storage seam, the one test wrapper and directly necessary README test instructions. Existing feature owners retain their specific regressions; one test/docs integrator reconciles shared insertions. Smoke trust is required before relying on its result, not a new whole-issue prerequisite for every repair. No new typed dependency or candidate-test adoption is proposed. Installer, builder/preset payload, production rendering and application cache-schema repairs remain outside this owner.

IMPLEMENTAUDIT R001D applies to README’s safe-origin/outcome instructions and any public Pages smoke page: deployed HTML/config/wrapper must match the qualified tree before public safety is claimed. IMPLEMENTAUDIT R001E requires actual wrapper/transport/scene/storage-seam reachability; helper files existing on disk are not acceptance. Historical Pages workflow green is deployment evidence, not application validation.

Rollback must not restore a green missing-widget result or real-storage erasure. If the optional seam harms existing callers, keep the harness explicitly non-pass/safely disabled while reverting or repairing the seam; do not sacrifice settings for a test green. No production data cleanup or schema migration is part of rollback. Stop on incompatible source drift, inability to isolate storage before widget parsing, unsupported wrapper behavior in the actual browser, unexpected network, missing required execution or absent evidence for a claimed public/visual/native result.

DONE requires final-tree RED→GREEN/control results, the real isolated browser transport/healthy/negative paths, default-caller compatibility, and an evidence comment binding commit, source digest, exact commands/fixtures, required-case ledger, storage snapshots, results and limits. Independent exact-tree review is required before relying on the repaired instrument for other acceptance. Public/deployed claims additionally need authorized served-file readback and the public entry evidence actually claimed. Use non-closing `Implements #23` PR wording and manual closure after evidence. This authored work order is not an executed or independently reviewed PASS.

Methodology references (separate repository, not Salah work owners): [R001D in IMPLEMENTAUDIT](https://github.com/theislampill/IMPLEMENTAUDIT.md/issues/155), [R001E in IMPLEMENTAUDIT](https://github.com/theislampill/IMPLEMENTAUDIT.md/issues/157).

Identity provenance: first repository-local allocation batch; existing GitHub object order was used to assign distinct monotonic hex-4 IDs. Closed/held IDs are not reused. Issue number is not implementation priority.

Shared storage-function integration: coordinate with [R0011](https://github.com/theislampill/salah_widget/issues/17) at config.js saveLocal/clearLocal and their callers. Persistence-result feedback and the optional isolated-test storage argument have distinct invariants but touch the same function contract. One writer integrates them, preserving omitted-argument behavior and actual failure results. This is a shared-write constraint, not a requirement to complete either entire issue before preparing the other's controls.

