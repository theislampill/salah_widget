RLGWO remaining-work specification — R0017 — revision 1
Priority: P1 | Residual class: evidence, docs

<!-- COORDINATOR-READINESS:rev1 -->

## Coordinator reconciliation — ready specification, open execution gates

**READY_WITH_EXPLICIT_EXECUTION_GATES.** Author F; independent cold reader E; primary coordinator reconciled this exact revision. [Cold-read report](../reviews/E-F.json), [readiness and source hashes](../SPECIFICATION_READINESS.json), [consolidated execution graph](../CLOSURE_DAG.md). This qualifies the work order as executable. It does not claim that its future tests, platform proofs, repairs, merges or closure have happened. The AWAITING_COLD_REVIEW / READY_PENDING_REVIEW labels retained in the author text below record its pre-review drafting stage; this paragraph supersedes those labels only for specification cold-read readiness. Actual input, owner-decision, implementation, platform, qualification, delivery and closure gates remain binding. The issue remains open.

The consolidated graph separates exact candidate review, required effect authority, actual delivery and final closure. For documentation-only work, accurate DOC/DOCS output can receive its own review and authorized delivery before unrelated native proof completes. Where the authored stage combined both, DELIVERY-CONFIRM preserves all original output interfaces and proof requirements; CLOSE still consumes every mandatory row and delivered document. This refines ordering only, waiving no acceptance obligation. One actual approval/delivery receipt may satisfy several nodes for the same exact head/base/effects; duplicate approvals or merges are not required. Runtime delivery still requires its full affected qualification and separate exact-head release authority.

### Retained author specification

<!-- RLGWO-SPEC:18ff14860ff41c084b1db5f396bb62aa9c22b1be:R0017:rev1:2026-10-08 -->

Status: **AWAITING_COLD_REVIEW**. Owner authority: remaining specifications/triage/DAG; execution and publication are separate leases.

## A. Identity, objective and retained decisions

Close only when the exact final 30-case instrument executes all original named checks against the real browser widget, its hostile modes remain bounded non-pass, both motion-preference envelopes and semantic negatives discriminate, and safe public usage is documented/delivered. Accepted rows17-01/02/04/05/06 remain accepted; residual17-03/07/08/09/10/11 are not declared product defects. The README omission is demonstrated; absent native receipts are evidence gaps.

All work is bound to main `18ff14860ff41c084b1db5f396bb62aa9c22b1be`, tree `35208181eea714c17f5e77b2644e76434345db60`, runtime `f443cf0820e6879dfa7c3ce857d6b2baf554b1fdd2f889433d22e2c532cec260` and root index `ff728552442f4bcce7f213a089bf01d4cf70ea8d74040bdd3323768ca453beee`. The read-only reviewed checkout `C:/Users/theis/.codex/worktrees/hotfix-startup-clouds/salah_widget` is HEAD `4bccdf43363926c3077f60de87e5617ccb9abcb9` with the same tree and clean status. The published audit is `b879573c298f19189d1f2392108b8b9f3b2cda0b`. Before future execution, reacquire repository root, origin, HEAD/tree, dirty state, this issue's complete body/discussion and in-scope hashes. Stop on unexplained source/contract drift. Existing audit comments remain the parent record; this revision adds an executable residual work order and does not overwrite the issue body or accepted proof.

Planning operations in this package are source/packet inspection and artifact authoring only. No product test, browser, build, source edit or public effect occurred during spec preparation. Historic executed results below keep their original source/configuration/environment limits. Commands marked **proposed** require a future execution lease. Existing installed Node is `C:/workspace/ai/cp9-integration-20261005/toolchain/node-v22.16.0-win-x64/node.exe` and Python is `C:/workspace/ai/cp9-integration-20261005/venv/Scripts/python.exe`; do not add a dependency/framework. Use an isolated `codex/` worktree for future source changes, and preserve unrelated dirty work.

Issue [#23](https://github.com/theislampill/salah_widget/issues/23); original UTF-8 body SHA-256 `d06ff2f42ea259578d46ab0ca17dae2cd46d6b8cf556878696c0e3c4616f5aaf`. Current complete packet: [issues/23.json](../issues/23.json). Accepted audit: [assessment](https://github.com/theislampill/salah_widget/blob/b879573c298f19189d1f2392108b8b9f3b2cda0b/docs/rlgwo-audit/20261008/workers/F/23-assessment.json) and existing discussion in that packet.

| Accepted row | Disposition and bounded credit |
|---|---|
| `17-01` | satisfied: Reviewed clean source and delivered tree identities agree; authored/generated ownership is known. |
| `17-02` | satisfied: The current 35 source controls verify complete callback accounting, missing/failure semantics, late results and bounded timeouts; actual native healthy execution remains a separate residual. |
| `17-04` | satisfied: Private/default/denied Storage-like APIs and both local/preferLocal resolve consumers preserve normalization and precedence. |
| `17-05` | satisfied: Exact valid/malformed/absent config and unrelated sentinel bytes survive recorder outcomes in contained source controls; no native 30-case result is inferred. |
| `17-06` | satisfied: Current 17 wrapper transport controls exercise pre-parser source/digest/hooks and Response.json. The deliberate DOMParser boundary stop is not actual widget execution. |

Priority rationale: Current required native execution and hostile-mode proof is missing despite implemented recorder/transport controls; this is a significant closure-confidence gap. Impact: A healthy-looking instrument can be trusted beyond actual executed consumer coverage; README omission makes scope easy to misread. Conditions/exposure: Final current 30-case smoke wrapper and browser preference/mode envelope / Maintainer verification; not evidence of production data loss. Confidence: High on missing specific receipts and README facts; product mechanisms remain accepted. Containment: Honest INCOMPLETE/FAIL and private storage already implemented; leave issue open until actual native proof. Label reconciliation: Original priority does not decide residual scheduling; P1 for material native closure confidence, P2 docs subtask; no P0 evidence.

| Remaining row | Class / priority | Why it remains; exposure, confidence and containment |
|---|---|---|
| `17-03` | evidence / P1 | Significant final-consumer closure-confidence gap; source controls alone cannot prove all native callbacks. Impact: Incorrect confidence in smoke PASS; documentation confusion for 17-10; conditions: Current root under deterministic frozen test fixture; exposure: Maintainer/test harness, not demonstrated prayer-product corruption; confidence: High confidence in exact evidence/doc gap; no new runtime defect asserted; containment: Keep #23 open; use existing honest status/private store; no production storage effects. |
| `17-07` | evidence / P1 | Prayer readiness can be falsely green if response consumption/attempt identity is not exercised by a native consumer. Impact: Incorrect confidence in smoke PASS; documentation confusion for 17-10; conditions: Current root under deterministic frozen test fixture; exposure: Maintainer/test harness, not demonstrated prayer-product corruption; confidence: High confidence in exact evidence/doc gap; no new runtime defect asserted; containment: Keep #23 open; use existing honest status/private store; no production storage effects. |
| `17-08` | evidence / P1 | The positive ledger is not discriminating without actual hostile-mode bounded non-pass. Impact: Incorrect confidence in smoke PASS; documentation confusion for 17-10; conditions: Current root under deterministic frozen test fixture; exposure: Maintainer/test harness, not demonstrated prayer-product corruption; confidence: High confidence in exact evidence/doc gap; no new runtime defect asserted; containment: Keep #23 open; use existing honest status/private store; no production storage effects. |
| `17-09` | evidence / P1 | Native preference/override failure and restoration need the real consumer, not an assumed restored OS signal. Impact: Incorrect confidence in smoke PASS; documentation confusion for 17-10; conditions: Current root under deterministic frozen test fixture; exposure: Maintainer/test harness, not demonstrated prayer-product corruption; confidence: High confidence in exact evidence/doc gap; no new runtime defect asserted; containment: Keep #23 open; use existing honest status/private store; no production storage effects. |
| `17-10` | docs / P2 | Missing bounded safe-use/outcome docs can be repaired without product behavior changes. Impact: Incorrect confidence in smoke PASS; documentation confusion for 17-10; conditions: Current root under deterministic frozen test fixture; exposure: Maintainer/test harness, not demonstrated prayer-product corruption; confidence: High confidence in exact evidence/doc gap; no new runtime defect asserted; containment: Keep #23 open; use existing honest status/private store; no production storage effects. |
| `17-11` | evidence / P1 | Final current public consumer and independent denominator proof are mandatory closure gates. Impact: Incorrect confidence in smoke PASS; documentation confusion for 17-10; conditions: Current root under deterministic frozen test fixture; exposure: Maintainer/test harness, not demonstrated prayer-product corruption; confidence: High confidence in exact evidence/doc gap; no new runtime defect asserted; containment: Keep #23 open; use existing honest status/private store; no production storage effects. |

## B. Witness and reproducible consumer recipe

Retained execution: final current source-bound recorder/storage controls35 PASS and wrapper transport17 PASS. The transport fixture deliberately stops at DOMParser; it never proves actual loaded widget callbacks. An earlier actual native30/30,141/0/0 run belongs to runtime13fb06, not the current runtime. The audit found no exact current native mode/preference matrix, and README has no smoke/INCOMPLETE instructions.

Use a fresh private document for `http://127.0.0.1:8765/tests/smoke.html?fixture=healthy` and separately `?fixture=reject`, `?fixture=hang`, `?fixture=bootstrap-error`. The existing wrapper fixes no-argument Date/Date.now to2026-09-07T09:30:00.000Z, retains explicit Date arguments, carries lat24.47/lon39.61/labelMadinah/method4/school0/tzAsia-Riyadh/qa1 plus a unique run/attempt/document. It fetches unchanged candidate source and verifies exact SHA/anchors before document.write and actual scripts. Private Map storage starts empty for each wrapper. Admit only expected Aladhan requests for07/08-09-2026 with exactly latitude/longitude/method/school. Current timings are Fajr05:00, Sunrise06:00, Dhuhr12:00, Asr15:30, Sunset/Maghrib18:00, Isha19:30; both day/date bodies match their requests. Hijri values are synthetic inputs. At frozen12:30 currentDhuhr, nextAsr15:30, leftMin180 must be actual render output.

Preserve all current named families: config parsing/precedence/private/denied storage; weather availability/assertions and actual prayer response/countdown; dry thunder/rain/fog; labelled live model wet/expiry/recovery; synthetic installation/override/snow/lightning/lease/end/outage/coverage/source-age/nearby/target-generation; new/below/above Moon; unpainted dawn; stable cloud identity; observability; waxing/waning orientation; explicit reduced/full and full override; bounded accelerated cloud continuity. Extract exact30 names/minima from CASES into the driver before execution; a changed denominator is a hard mismatch. The current model/precip bridge allows only its precisely validated Open-Meteo/RainViewer fixture inputs and must keep lane/estimation labels; do not revert to the original older weather policy or return success-shaped data to unexpected requests.

For origin safety, seed valid raw config, malformed raw config, absent config, `__sw_probe__` and an unrelated sentinel on the disposable harness origin, record exact bytes/absence before/after each success/failure/throw/timeout; spy on calls separately from the private iframe map. Never point this storage experiment at an owner production origin. Run each actual browser under reduce=true and reduce=false, while keeping the existing explicit in-iframe cases deterministic. Separate motion=full with reduce=true. Restore the original function object in finally, including a thrown assertion and a controlled timeout. Save __smoke, every attempt/fixture/request/json/render ledger, console/error trace, raw summary/crop and source/fixture/browser/config hashes. Driver120s/mode is a proposed outer safety bound; retain actual4s callback,8s scene and3s image limits. A negative-mode FAIL/INCOMPLETE is expected evidence, not a failure to hide.

## C. Authored owners, interfaces and test ownership

Authored and delivered test owner [tests/smoke.html](https://github.com/theislampill/salah_widget/blob/18ff14860ff41c084b1db5f396bb62aa9c22b1be/tests/smoke.html) owns CASES39–55, required65–80, loadUntil89–119, actual response assertions337–342, reducer395–409 and summary422–429. [tests/widget-fixture.html](https://github.com/theislampill/salah_widget/blob/18ff14860ff41c084b1db5f396bb62aa9c22b1be/tests/widget-fixture.html) owns pre-script fixed clock/private storage/fetch/Response/json and source anchors104–182. [src/native/config.js](https://github.com/theislampill/salah_widget/blob/18ff14860ff41c084b1db5f396bb62aa9c22b1be/src/native/config.js) storage178–218 and both resolve298–317 produce unchanged `{version,key,normalized saved config}` semantics; generated rootconfig is the deployed equivalent. No edit to config is preselected.

Existing tests/r0017-contract.cjs and r0017-transport.cjs plus the ordinary static server form the pattern. Add only tests/r0017-native-proof.py if an automated envelope is needed; use the already installed Playwright/browser launch paths and current audit driver's isolated-context/readback pattern. Test-only interception precedes parsing and does not edit product script bodies or fabricate prayerLoaded/render. README owns user-facing limitations. Root generatedindex/config owners remain tools/build_native.py; future fixture-only work does not require product regeneration.

## D. Ordered bounded work

First implement the driver output schema: top-level exact source/fixture/runtime IDs, engine/OS preference, mode, terminal __smoke and attempted scene ledgers; each negative includes reached oracle and expected failure. Acquire current healthy evidence before editing any product. Then run separate hostile modes and current identity/denominator/reducer mutants. If a healthy failure is caused by a current-script anchor change, record the exact failed anchor and adapt only the wrapper/test ownership binding, preserving all assertions and original failing evidence. If the real product violates an assertion, stop with that counterexample rather than broadening this planning issue into a renderer change. Add README facts in parallel with read-only receipt preparation; publish neither until independent review. The review and delivery nodes below are mandatory residual work, not optional paperwork.

### R0017-NATIVE — qualification (READY_PENDING_REVIEW)

Owner: smoke native executor with one browser lease. Scope: Add a narrow Playwright driver around existing tests/smoke.html and actual widget-fixture.html; no renderer or permission rewrite.

- [ ] Entry: Plan cold-approved; owner execution lease; exact candidate source/fixture hashes and isolated origin; no concurrent browser/terrain job
- [ ] Produce: `r0017-native-proof/v1` — All original required consumers and their healthy/negative controls on exact candidate at `evidence/R0017/native/results.json`
- [ ] Exit: 30/30 actual callbacks complete with all declared assertion minima, zero failure/missing/skip on healthy; Reject/hang/bootstrap-error and stale identity never PASS; reducer/override mutants are detected at reached assertions; Every real-origin storage byte/absence and exact matchMedia function survives; current response is JSON-consumed and rendered

Verification commands/actions (all future work unless explicitly labelled retained execution):

- Proposed, existing command: node tests/r0017-contract.cjs -> preserve 35 passing controls, including private/default/denied storage and both resolve-edge mutants.
- Proposed, existing command: node tests/r0017-transport.cjs -> preserve 17 passing transport controls; DOMParser boundary stop remains honestly labelled.
- Proposed new driver tests/r0017-native-proof.py --workspace <isolated-candidate> --engine chromium|firefox --output <new-dir>; implement using installed Playwright and the existing public/native audit driver pattern, then serialize the two engines.
- Manual fallback equivalent: existing static server at 127.0.0.1:8765, healthy/reject/hang/bootstrap-error query routes; export actual __smoke, fixture ledgers, console and final crop. Expected terminals are defined in F.

### R0017-DOC — documentation (READY_PENDING_REVIEW)

Owner: shared docs integrator. Scope: Add one README smoke-testing subsection and preserve test-page scope notice; no broader accessibility/art claim.

- [ ] Entry: Read exact current README/test-page notices; coordinate the shared README writer
- [ ] Produce: `r0017-doc-delta/v1` — Exact safe-origin/outcome instructions and limitations at `evidence/R0017/docs/diff.patch`
- [ ] Exit: README names separate modes and precise PASS/FAIL/INCOMPLETE accounting, storage isolation, current clock/provider recipe and font/appearance/M0 limits; Instructions work on the delivered static origin; no production storage-clear or synthetic observational claim

Verification commands/actions (all future work unless explicitly labelled retained execution):

- Proposed read-only verification: rg -n "smoke|INCOMPLETE|fixture|isolat|M0" README.md tests/smoke.html -> every stated fact agrees with the native receipt and existing 30-case instrument.

### R0017-REVIEW — independent-review (READY_PENDING_REVIEW)

Owner: independent smoke reviewer and primary. Scope: Review exact-source native RED/GREEN/mutant proof, accepted 35+17 controls and docs; inventory every retained legacy exception separately.

- [ ] Entry: Native and docs outputs complete; same source/fixture/runtime identity
- [ ] Produce: `r0017-review/v1` — Signed complete row-by-row residual and preservation disposition at `evidence/R0017/review.json`
- [ ] Exit: Independent reviewer reads every case ledger and negative, views smoke and actual normal-entry crops, checks denominator and storage restoration; No VM/cached/earlier-runtime receipt is promoted to a final healthy native result; only mapped exceptions are accepted

Verification commands/actions (all future work unless explicitly labelled retained execution):

- Proposed readback: parse native/results.json, all mode logs and request ledgers; compare required names/counts to exact tests/smoke.html and independent __smoke readback. Expected healthy 30/30 and all required assertion minima; negative modes non-pass.

### R0017-DELIVER — delivery (READY_PENDING_REVIEW)

Owner: authorized integration/public-readback owner. Scope: Integrate only required docs/fixture driver repairs; deliver wrapper and source on authorized branch and verify static public consumer before closure.

- [ ] Entry: Exact change review; separate explicit commit/push/merge/deploy/publication authorization
- [ ] Produce: `r0017-delivery/v1` — Immutable merge/public source plus rendered smoke/readiness readback and evidence comment at `evidence/R0017/delivery.json`
- [ ] Exit: Public tests/smoke.html and widget-fixture.html content hashes match final qualified source; actual public healthy ledger and unchanged index entry are verified; Evidence comment precedes any manual #23 closure; all issues/legacy failures not in this scope retain their state

Verification commands/actions (all future work unless explicitly labelled retained execution):

- Proposed public read-only check after authorized delivery: retrieve exact smoke/wrapper/config/root resources and run one healthy public instrument per required engine with controlled Response/JSON inputs, plus normal index entry; compare final digests and actual __smoke.

## E. Scope, preservation and containment

Preserve the accepted physical sky/catalogue, current V5 Moon kernel/profile/reference inputs, opaque calendar disc and independent stellar occlusion, registered solar optics/defined nucleus, honest dawn, structured cloud morphology and weather permission, prayer/date/countdown/settings precedence, generation/accepted-time currentness, real normal motion and reduced/full preference. V1 is a frozen separate product; exclude PR #38 and its rejected/growing/zooming captures. The actual root card is 325x530; the approved production V1 iframe wrapper is 330x534 and is a separate amendment, not permission to resize the card or legacy builder literals. Never edit generated root files first; change a specific authored owner and regenerate only through its existing build owner under a later lease.

Use disposable origins/profiles with private test records. Do not clear owner storage, request location, replace shared clipboard values or modify production configuration. Keep failing/raw originals and labelled diagnostic images alongside candidate results. Revert only an issue-local unaccepted change if preservation fails; do not erase receipts or restore a known permission leak. If broader source owners, a new renderer/dependency, unreviewed source-thread changes, or a threshold reduction appear necessary, stop for a bounded revised handoff. Browser/terrain/performance work has one exclusive queue; no parallel benchmark or preview controllers.

Extra containment: no optional live-provider route can certify deterministic healthy readiness. Do not fake module exposure, JSON reads, source digests, case completion or skipped callbacks. Keep source anchors strict; reject unknown modes before parsing.

## F. Complete residual acceptance matrix and closure certificate

The accepted unit/transport controls are reused; the following matrix supplies the missing actual native consumer envelope. Every new test must preserve the full current denominator and distinguish a setup error from a semantic fault. A separately loaded unchanged root index is the integration positive. Negative response/body/image modes are explicit, not generic asset-unavailability claims.

| Acceptance / mandatory row | Fixture → actual consumer | Assertion and expected terminal result | Environment; planned evidence; independent gate |
|---|---|---|---|
| `R0017-A01` / `17-03` | Fresh healthy iframe for each declared scene; all current 30 names and minima from CASES, including joined model/synthetic weather branches → Actual classic product scripts through widget-fixture.html -> tests/smoke.html required()/summary() | All 30 named required callbacks execute; assertions >= declared expected; status PASS, failures=missing=skip=0; no optional live result substitutes. Expected: Healthy PASS with full case/request/source ledger | Windows; installed Chromium and Firefox serially, record exact versions (audit used Chromium 148.0.7778.96 / Firefox 150.0.2); isolated localhost profile/context; actual 325x530 CSS card, desktop 1100x900 and constrained 375x800 viewport where UI matters; DPR 1 and 2 where raster/geometry matters. These are future runs, not claimed execution. Evidence: `evidence/R0017/native/healthy-{engine}-{os}.json`. Gate: Independent reviewer compares each name/minimum and actual consumers; current H5 model policy stays labelled. |
| `R0017-A02` / `17-07` | Date 2026-09-07T09:30:00.000Z; lat24.47/lon39.61/method4/school0/Asia-Riyadh; private empty cache; prayer dates07/08-09-2026 → Actual fetch -> Response.json -> loadPrayer/prayer cache -> render/model/countdown; actual fixture attempt/hash/document/source ownership | Only matching four-parameter Aladhan requests; current-day JSON read>0; prayerLoaded and render exist; Dhuhr current, Asr next15:30, leftMin180 at frozen12:30. Prior hash/attempt/document/source and duplicate current-day tomorrow body cannot pass. Expected: Exact positive render and all stale/malformed identity controls rejected | Windows; installed Chromium and Firefox serially, record exact versions (audit used Chromium 148.0.7778.96 / Firefox 150.0.2); isolated localhost profile/context; actual 325x530 CSS card, desktop 1100x900 and constrained 375x800 viewport where UI matters; DPR 1 and 2 where raster/geometry matters. These are future runs, not claimed execution. Evidence: `evidence/R0017/native/transport-{engine}.json`. Gate: Reviewer verifies request/JSON/render linkage; no manually assigned prayerLoaded/render. |
| `R0017-A03` / `17-08` | Separate healthy/reject/hang/bootstrap-error documents, null iframe/missing config, known source-anchor failure; zero/throw/pending Response paths → Actual wrapper before parse, real scene() with 8000ms deadline and required()4000ms; real config checks retained | Each reject/hang/bootstrap mode is terminal non-PASS with exact reason; no blanket offline skip. No late callback marks another case or inflates execution. Driver bound 120s per mode is proposed orchestration limit; inherited scene/callback bounds remain unchanged. Expected: Healthy PASS; hostile modes FAIL/INCOMPLETE and stored bytes unchanged | Windows; installed Chromium and Firefox serially, record exact versions (audit used Chromium 148.0.7778.96 / Firefox 150.0.2); isolated localhost profile/context; actual 325x530 CSS card, desktop 1100x900 and constrained 375x800 viewport where UI matters; DPR 1 and 2 where raster/geometry matters. These are future runs, not claimed execution. Evidence: `evidence/R0017/native/adverse-{engine}.json`. Gate: Independent control review checks reached terminal and expected mode; source failure is not a detected semantic mutant. |
| `R0017-A04` / `17-09` | Fresh OS/emulated prefers-reduced-motion true and false; explicit in-fixture true/false; separate motion=full with reduce=true; controlled simTime12:30 → Actual applyTheme(model()), --sunpulse and original iframe matchMedia function identity | Reduced pulse=1, deterministic full pulse!=1, full hash overrides reduce=true. Original matchMedia function restores exactly on success/throw/timeout. Independent ignore-reduction and ignore-full mutants each fail their own reached assertion. Expected: Both native OS envelopes and both mutants discriminate without changing product default | Windows; installed Chromium and Firefox serially, record exact versions (audit used Chromium 148.0.7778.96 / Firefox 150.0.2); isolated localhost profile/context; actual 325x530 CSS card, desktop 1100x900 and constrained 375x800 viewport where UI matters; DPR 1 and 2 where raster/geometry matters. These are future runs, not claimed execution. Evidence: `evidence/R0017/native/motion-controls-{engine}.json`. Gate: Reviewer checks distinct mutants and exact function restoration, not assumed OS behavior after restore. |
| `R0017-A05` / `17-10` | Delivered README + current static smoke/wrapper; same private origin and explicit four modes → User follows README -> actual public tests/smoke.html, fixture and unchanged root index | README gives isolated profile/origin, no storage clearing, exact outcomes/modes, fixed date/providers, source/attempt identity, font suppression and no appearance/normal-live M0 certification; served hashes match. Expected: Truthful public instructions and wrapper/source delivery | Windows; installed Chromium and Firefox serially, record exact versions (audit used Chromium 148.0.7778.96 / Firefox 150.0.2); isolated localhost profile/context; actual 325x530 CSS card, desktop 1100x900 and constrained 375x800 viewport where UI matters; DPR 1 and 2 where raster/geometry matters. These are future runs, not claimed execution. Evidence: `evidence/R0017/delivery.json`. Gate: Independent docs/runtime reader executes stated route after authorized deployment. |
| `R0017-A06` / `17-11` | All native/case/mutant/doc outputs on one final candidate and delivered source identity; accepted geometry/occlusion/dawn/config controls mapped → Independent final evidence review + actual normal entry + public readback | Review signs every residual acceptance ID, rejects weakened checks and stale-runtime promotions, accounts eight old native byte/array failures and four TODOs individually, and publishes evidence before any manual closure. Expected: Complete bounded closure certificate only after delivery | Windows; installed Chromium and Firefox serially, record exact versions (audit used Chromium 148.0.7778.96 / Firefox 150.0.2); isolated localhost profile/context; actual 325x530 CSS card, desktop 1100x900 and constrained 375x800 viewport where UI matters; DPR 1 and 2 where raster/geometry matters. These are future runs, not claimed execution. Evidence: `evidence/R0017/review.json`. Gate: Different reviewer and primary; no all-green aggregate inferred from legacy exclusions. |

Closure certificate `CLOSE-R0017` must list every acceptance ID above and every required output below with final source/runtime/fixture hashes, environment, timestamps, raw artifacts, exceptions and independent signature. A plan, VM receipt, late still or threshold alone cannot close the issue.

`r0017-native-proof/v1`, `r0017-doc-delta/v1`, `r0017-review/v1`, `r0017-delivery/v1`

- Every residual acceptance ID has a source-bound terminal result and named artifact; failures remain visible.
- Independent cold review and primary reconciliation approve the plan before executor authorization.
- Independent actual-consumer/pixel review approves the exact final candidate and all mapped preservation gates.
- Any source/docs/test change is integrated by the one authorized writer, then merged/deployed only with explicit owner authorization.
- Actual public files/digests and required rendered behavior match the final candidate; an evidence comment precedes any manual issue closure.

Preparation is not implementation, merge, deployment, publication or closure. Future effects require the owner/primary exact authorization; use non-closing Implements #23.

## G. Dependencies, queue and realistic cost

Hard inputs are the existing smoke instrument and configuration/storage/accepted attempt interfaces, all SATISFIED at this source. R0011 is an interface preservation relationship, not a requirement to finish that whole issue. DOC may draft alongside read-only native-driver preparation; actual browser modes and final public checks run serially. No Apple-specific browser acquisition is required by this residual owner; report this Windows Chromium/Firefox scope honestly.

| Node | Input interface/status | Exact predecessors | Active hours | Exclusive machine minutes |
|---|---|---|---:|---:|
| `R0017-NATIVE` | `smoke-instrument/v1` (SATISFIED): 30 named required callbacks; actual original wrapper, private Storage-like seam, 4 s callback / 8 s scene / 3 s image bounds; unchanged product scripts | None | 3–6 | 20–45 |
| `R0017-DOC` | `smoke-instrument/v1` (SATISFIED): 30 named required callbacks; actual original wrapper, private Storage-like seam, 4 s callback / 8 s scene / 3 s image bounds; unchanged product scripts | None | 0.5–1.5 | 0–0 |
| `R0017-REVIEW` | `r0017-native-proof/v1` (PENDING): Complete actual execution ledger including adverse runs; `r0017-doc-delta/v1` (PENDING): Safe use and outcome documentation | `R0017-NATIVE`: Actual required consumer evidence; `R0017-DOC`: Safe usage claim | 1–2 | 0–0 |
| `R0017-DELIVER` | `r0017-review/v1` (PENDING): Independent approved exact final proof | `R0017-REVIEW`: Review before public effects | 0.5–1.5 | 5–12 |

Uncoalesced issue estimate: 5.0–11.0 active hours and 25–57 exclusive machine minutes. Ranges are planning estimates, not promises or measured results; shared closure/readback can be coalesced by the primary. Each node records confidence and basis in [machine metadata](../metadata/R0017.json). Waiting for authority/hardware/another source thread is separate from active work.

## H. Cold-read and handoff checklist

Cold reviewer must inspect that actual mode deadlines and required counts are unweakened, private storage never touches owner state, actual Response.json leads to prayer/render output, and OS preference is not guessed after restoration. Readiness is AWAITING_COLD_REVIEW. No unresolved owner product-policy decision remains; any observed healthy runtime failure needs a bounded amendment before product repair.

- [ ] All accepted and residual rows retain the exact original identity or explicit parent-linked child; no accepted interface is reopened merely because an old byteguard changed.
- [ ] The complete recipe, intended consumer, positive/boundary/hostile/recovery control, artifact and independent gate are present for every residual acceptance ID.
- [ ] Proposed thresholds/commands and unknown decisions are labelled; no preparation action is represented as native execution, repair or public completion.
- [ ] Shared source integration and heavy browser/performance work are serialized; no all-issue prerequisite or unapproved source effect is introduced.
- [ ] A different reviewer cold-reads this revision, then the primary reconciles exact comments/metadata before publication and before executor authorization.

Documentation facts for the future integrator:

- README Testing/smoke subsection: exact static server route and modes; required-case denominator versus optional live diagnostic.
- Storage isolation is a per-fixture dependency; do not clear owner origin or patch global Storage prototype.
- Fixed clock2026-09-07T09:30Z, synthetic Gregorian/Hijri/prayer records, current H5 model estimate labels and real Response.json consumption.
- PASS requires all callbacks; failures versus missing distinguish FAIL/INCOMPLETE; late callbacks and timers cannot convert missing to executed.
- Fixture blocks fonts and freezes scene: no aesthetic/readability/normal-live motion or all-platform certificate.

Affected regression set:

- Actual unchanged index boots, 325x530 card and approved wrapper; current prayer/cache/config shared R0011 seam.
- Current Moon opaque calendar presence, honest dawn, model/synthetic weather permissions and explicit reduced/full behavior at unchanged owners.

Reuse rules:

- Retain 35 contract +17 transport receipts, scoped to recorder/storage/pre-parser transport; rerun only after affected fixture/source changes.
- Earlier 13fb06 30/30 browser success is historical context, never the current final proof.
- Reuse exact final-v49/public pixels only at unchanged geometry/material/currentness interfaces; native smoke remains its own gap.

Decisions/non-goals:

- No new policy amendment is needed; joined weather policy is already explicit in the current denominator.
- A proposed 120s driver mode deadline only contains orchestration; do not alter inherited4s/8s/3s per-case bounds.
- No framework, global storage patch, production weather reinterpretation, phase/terrain campaign or normal-live M0 credit from smoke.
