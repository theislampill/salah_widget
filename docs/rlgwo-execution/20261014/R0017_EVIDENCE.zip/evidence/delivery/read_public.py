"""Fresh read-only Pages identity check for the exact existing R0017 consumer."""
import sys,json,datetime,urllib.request,subprocess
from pathlib import Path
B=Path(__file__).resolve().parent;sys.path.insert(0,str(B))
from run_smoke import ROOT,sha,dump,identity
out=B/'evidence/delivery';out.mkdir(parents=True,exist_ok=True)
files=['README.md','tests/smoke.html','tests/widget-fixture.html','index.html','config.js','real-sky/native-sky.js','real-sky/native-data.js','moon/moon-host.js','moon/moon-worker.js','moon/moon_kernel.wasm']
report={'schema':'r0017-pages-source-readback/v1','timeUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':identity(),'files':[],
        'baseUrl':'https://theislampill.github.io/salah_widget/','scope':'Fresh material R0017 entry/config/wrapper/runtime resources. Full135-file runtime identity reuses exact delivered R000B commit763a460; no full-tree redeployment claimed from this subset.'}
for relative in files:
    url=report['baseUrl']+relative
    try:
        with urllib.request.urlopen(urllib.request.Request(url,headers={'Cache-Control':'no-cache'}),timeout=45) as r:
            data=r.read();row={'path':relative,'status':r.status,'finalUrl':r.url,'bytes':len(data),'sha256':sha(data),'headers':dict(r.headers)}
            row['expectedSha256']=sha((ROOT/relative).read_bytes());row['matches']=row['sha256']==row['expectedSha256']
    except Exception as e:row={'path':relative,'error':str(e),'matches':False}
    report['files'].append(row);dump(out/'source-readback.json',report)
report['main']=subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=r'C:\workspace\ai\salah_widget',text=True).strip().split()[0]
report['status']='PASS' if all(x['matches'] for x in report['files']) and report['main']==report['source']['commit'] else 'FAIL'
(out/'read_public.py').write_bytes(Path(__file__).read_bytes());dump(out/'source-readback.json',report)
print(json.dumps({'status':report['status'],'main':report['main'],'files':[{'path':x['path'],'matches':x['matches'],'error':x.get('error')} for x in report['files']]},indent=2))
