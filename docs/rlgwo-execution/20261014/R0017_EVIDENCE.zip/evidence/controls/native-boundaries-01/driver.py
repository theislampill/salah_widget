"""Native missing-module, null-frame and literal retained-document controls only."""
import os,sys,json,time,traceback
from pathlib import Path
B=Path(__file__).resolve().parent;sys.path.insert(0,str(B))
from run_smoke import ROOT,Server,OUTER,seeds,identity,sha,dump,sync_playwright,browser_options
from run_controls import HELD,HASH
E=B/'evidence/controls/native-boundaries-01';assert not E.exists();E.mkdir();(E/'driver.py').write_bytes(Path(__file__).read_bytes())
report={'schema':'r0017-native-document-boundaries/v1','scope':__doc__,'source':identity(),'heldSmokeSha256':sha(HELD),'cases':[]};srv=Server({'tests/smoke.html':HELD})
try:
 with sync_playwright() as pw:
  for engine in ['chromium','firefox']:
   os.environ['SALAH_BROWSER']=engine;family,opts=browser_options();opts['executable_path']=getattr(pw,family).executable_path;browser=getattr(pw,family).launch(**opts)
   for name in ['missing-config','null-frame','retained-document-same-hash','retained-document-new-hash']:
    raw='absent' if name=='missing-config' else 'malformed' if name=='null-frame' else 'valid'
    c=browser.new_context(viewport={'width':1100,'height':900},device_scale_factor=1,timezone_id='Asia/Riyadh',reduced_motion='reduce',service_workers='block');c.add_init_script('('+OUTER+')('+json.dumps(seeds(raw))+');')
    p=c.new_page();r={'engine':engine,'browser':browser.version,'executableSha256':sha(Path(opts['executable_path']).read_bytes()),'id':name,'seed':raw,'checks':{},'pageErrors':[]};report['cases'].append(r);p.on('pageerror',lambda e:r['pageErrors'].append(str(e)))
    try:
     p.goto(srv.origin+'/tests/smoke.html',wait_until='domcontentloaded');p.wait_for_function('()=>__r0017HelpersReady')
     if name=='missing-config':
      script='window.SalahConfig=undefined;await run();finalize();return {smoke:__smoke,log:out.innerText};'
     elif name=='null-frame':
      script='fr.remove();const initialNull=fr.contentWindow===null;await scene('+json.dumps(HASH)+',"weather gate availability",()=>{throw Error("unavailable frame incorrectly executed");});finalize();return {initialNull,finalNull:fr.contentWindow===null,smoke:__smoke,log:out.innerText};'
     else:
      newhash=HASH if name=='retained-document-same-hash' else HASH.replace('12:30','12:40')
      script='''const positive=await loadUntil('''+json.dumps(HASH)+''',8000,prayerReady);if(!positive.w)throw Error('Original positive did not load');const oldWindow=positive.w,oldDocument=oldWindow.document;
      const before={fixture:JSON.parse(JSON.stringify(oldWindow.__widgetFixture)),qa:oldWindow.qaState()},requests=[];
      Object.defineProperty(fr,'src',{configurable:true,set(value){requests.push(value);},get(){return oldWindow.location.href;}});
      let admitted=false;try{await scene('''+json.dumps(newhash)+''',"weather gate availability",()=>{admitted=true;});}finally{delete fr.src;}
      finalize();return {before,requests,admitted,sameWindow:fr.contentWindow===oldWindow,sameDocument:fr.contentWindow.document===oldDocument,after:{fixture:oldWindow.__widgetFixture,qa:oldWindow.qaState()},smoke:__smoke,log:out.innerText};'''
     r['script']=script;start=time.monotonic();r['result']=p.evaluate('async()=>{'+script+'}');r['elapsed']=time.monotonic()-start;v=r['result'];s=v['smoke']
     r['checks']['denominatorUnchanged']=s['required']['total']==30 and len(s['required']['cases'])==30 and sum(x['expected'] for x in s['required']['cases'])==141
     if name=='missing-config':r['checks']['exactMissingConfig']=s['status']=='FAIL' and s['fail']==1 and s['pass']==0 and 'config.js did not load (window.SalahConfig missing)' in v['log']
     else:
      entry=next(x for x in s['required']['cases'] if x['name']=='weather gate availability')
      r['checks']['originalEightSecondMissing']=s['status']=='INCOMPLETE' and s['fail']==0 and entry['state']=='missing' and entry['assertions']==0 and entry['reason']=='required scene readiness deadline exceeded' and r['elapsed']>=8
      if name=='null-frame':r['checks']['actualNullFrame']=v['initialNull'] and v['finalNull']
      else:r['checks']['actualOldDocumentRejected']=not v['admitted'] and v['sameWindow'] and v['sameDocument'] and len(v['requests'])==1 and 'attempt=2#' in v['requests'][0] and v['before']['fixture']['documentId']==v['after']['fixture']['documentId'] and v['before']['fixture']['attempt']==v['after']['fixture']['attempt']==1 and v['before']['qa']['cache']['prayerLoaded'] and v['after']['qa']['cache']['prayerLoaded']
    except Exception:r['exception']=traceback.format_exc()
    finally:
     r['outer']=p.evaluate('()=>({before:__r0017Outer.before,after:__r0017Outer.snapshot(),getterAccesses:__r0017Outer.getterAccesses})');r['checks']['outerUntouched']=r['outer']['before']==r['outer']['after']==seeds(raw) and r['outer']['getterAccesses']==0
     r['status']='PASS' if r['checks'] and all(r['checks'].values()) and not r.get('exception') and not r['pageErrors'] else 'FAIL';c.close();dump(E/'result.json',report);print(json.dumps({'engine':engine,'id':name,'status':r['status'],'checks':r['checks']}),flush=True)
   browser.close()
finally:
 srv.close();report['status']='PASS' if len(report['cases'])==8 and all(r['status']=='PASS' for r in report['cases']) else 'FAIL';dump(E/'result.json',report)
