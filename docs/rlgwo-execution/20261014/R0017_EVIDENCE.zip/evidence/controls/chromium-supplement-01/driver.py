"""R0017 reviewer-requested gaps only; never a replacement for the 30-case run."""
import argparse,json,os,sys,time,traceback
from pathlib import Path
B=Path(__file__).resolve().parent;sys.path.insert(0,str(B))
from run_smoke import ROOT,Server,OUTER,seeds,identity,sha,dump,sync_playwright,browser_options
from run_controls import SMOKE,HELD,MEDIA,MOTION,HASH,once
CONFIG=SMOKE[SMOKE.index('  const SC=window.SalahConfig;'):SMOKE.index('  head("actual fixture transport + weather gate")')]
READ=r'''w=>({fixture:w.__widgetFixture,qa:w.qaState(),model:w.model(),
  dom:{current:w.document.querySelector('.cn').innerText,next:w.document.querySelector('.nt').innerText,countdown:w.document.querySelector('.left').innerText,times:w.document.querySelector('.times').innerText},
  rect:(()=>{const r=w.document.querySelector('.c').getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height};})(),
  originalMatchMediaRestored:w.matchMedia===w.__r0017OriginalMatchMedia})'''
OBSERVER=r'''const observations=[];const originalScene=scene;
scene=(hash,name,fn,ready)=>originalScene(hash,name,(ww,q,ok)=>{
  try{return fn(ww,q,ok);}finally{observations.push({name,documentId:ww.__widgetFixture.documentId,
    exact:ww.matchMedia===ww.__r0017OriginalMatchMedia,
    nativeReduced:ww.__r0017OriginalMatchMedia('(prefers-reduced-motion: reduce)').matches,
    pulse:+ww.getComputedStyle(ww.document.querySelector('.c')).getPropertyValue('--sunpulse')});}
},ready);'''
STORES=r'''const originalPrivateStorage=privateStorage,privateStores=[];
privateStorage=()=>{const s=originalPrivateStorage(),keys=['salah_widget:config:v1','__sw_probe__','private-unrelated'],events=[];
  s.setItem('__sw_probe__','private intentional probe');s.setItem('private-unrelated','private retained bytes Ω');
  const snapshot=()=>Object.fromEntries(keys.map(k=>[k,s.getItem(k)]));
  const r={initial:snapshot(),events,snapshot};privateStores.push(r);
  return {getItem(k){const v=s.getItem(k);events.push(['get',k,v]);return v;},
    setItem(k,v){events.push(['set',k,v]);s.setItem(k,v);},removeItem(k){events.push(['remove',k]);s.removeItem(k);}};
};'''

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--engine',required=True,choices=['chromium','firefox']);ap.add_argument('--out',type=Path,required=True);o=ap.parse_args()
    out=o.out.resolve();out.mkdir(parents=True,exist_ok=False);(out/'driver.py').write_bytes(Path(__file__).read_bytes())
    report={'schema':'r0017-native-supplement/v1','engine':o.engine,'source':identity(),'cases':[],'scope':__doc__}
    overrides={'tests/smoke.html':HELD};srv=Server(overrides);os.environ['SALAH_BROWSER']=o.engine
    with sync_playwright() as pw:
      family,opts=browser_options();opts['executable_path']=getattr(pw,family).executable_path
      browser=getattr(pw,family).launch(**opts);report['browser']={'version':browser.version,'executable':opts['executable_path'],'sha256':sha(Path(opts['executable_path']).read_bytes())}
      def begin(name,raw='valid',viewport=None,dpr=1):
        overrides.pop('tests/widget-fixture.html',None)
        c=browser.new_context(viewport=viewport or {'width':1100,'height':900},device_scale_factor=dpr,timezone_id='Asia/Riyadh',reduced_motion='reduce',service_workers='block')
        c.add_init_script('('+OUTER+')('+json.dumps(seeds(raw))+');window.__r0017OriginalMatchMedia=window.matchMedia;')
        p=c.new_page();r={'id':name,'seed':raw,'viewport':viewport or {'width':1100,'height':900},'dpr':dpr,'checks':{},'pageErrors':[],'startedUtc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())};report['cases'].append(r)
        p.on('pageerror',lambda e:r['pageErrors'].append(str(e)))
        p.goto(srv.origin+'/tests/smoke.html',wait_until='domcontentloaded');p.wait_for_function('()=>__r0017HelpersReady');return c,p,r
      def end(c,p,r):
        r['outer']=p.evaluate('()=>({before:__r0017Outer.before,after:__r0017Outer.snapshot(),getterAccesses:__r0017Outer.getterAccesses})')
        r['checks']['outerUntouched']=r['outer']['before']==r['outer']['after']==seeds(r['seed']) and r['outer']['getterAccesses']==0
        r['status']='PASS' if r['checks'] and all(r['checks'].values()) and not r.get('exception') and not r['pageErrors'] else 'FAIL'
        r['finishedUtc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());c.close();dump(out/'result.json',report);print(json.dumps({'id':r['id'],'status':r['status'],'checks':r['checks']}),flush=True)
      try:
        for mode in ['assertion-throw','timeout-exception']:
          c,p,r=begin('each-frame-finally-'+mode)
          try:
            setup='const originalRequired=required;required=(name,fn)=>originalRequired(name,ok=>fn((label,cond,detail)=>{if(label==="reduce=true freezes sunpulse to 1"||label==="motion=full wins over reduce=true"){const e=new Error("controlled '+mode+'");'+('e.name="RequiredTimeout";' if mode=='timeout-exception' else '')+'throw e;}return ok(label,cond,detail);}));'
            r['script']=OBSERVER+setup+MEDIA+MOTION
            r['result']=p.evaluate('async()=>{'+r['script']+'finalize();return {observations,smoke:__smoke,log:out.innerText};}')
            obs=r['result']['observations'];sel=[x for x in r['result']['smoke']['required']['cases'] if x['name'] in [y['name'] for y in obs]]
            r['checks']['bothOriginalCallbacksReached']=len(obs)==2 and len({x['documentId'] for x in obs})==2
            r['checks']['eachExactFunctionRestored']=len(obs)==2 and all(x['exact'] and x['nativeReduced'] for x in obs)
            r['checks']['correctDisposition']=len(sel)==2 and all(x['state']==('failed' if mode=='assertion-throw' else 'missing') and 'controlled '+mode in x['reason'] for x in sel)
          except Exception:r['exception']=traceback.format_exc()
          end(c,p,r)
        for raw in ['valid','malformed','absent']:
          for outcome in ['success','failure','exception','timeout']:
            c,p,r=begin('original-config-'+raw+'-'+outcome,raw)
            try:
              setup=''
              if outcome!='success':
                after='return new Promise(()=>{});' if outcome=='timeout' else 'return result;'
                check='if(label==="clearLocal removes the private saved config"){'+('cond=false;' if outcome=='failure' else 'throw Error("controlled post-persistence exception");' if outcome=='exception' else '')+'}'
                setup='const originalRequired=required;required=(name,fn)=>originalRequired(name,async ok=>{if(name!=="config private persistence")return fn(ok);const result=await fn((label,cond,detail)=>{'+check+'return ok(label,cond,detail);});'+after+'});'
              r['script']=STORES+setup+CONFIG
              start=time.monotonic();r['result']=p.evaluate('async()=>{'+r['script']+'finalize();return {smoke:__smoke,stores:privateStores.map(s=>({initial:s.initial,final:s.snapshot(),events:s.events})),log:out.innerText};}');r['elapsed']=time.monotonic()-start
              cases=r['result']['smoke']['required']['cases'][:3];expected={'success':'executed','failure':'failed','exception':'failed','timeout':'missing'}[outcome]
              r['checks']['originalConfigCallbacks']=cases[0]['state']==cases[2]['state']=='executed' and cases[0]['assertions']==14 and cases[2]['assertions']==4
              r['checks']['intendedPersistenceOutcome']=cases[1]['state']==expected and cases[1]['assertions']==(7 if outcome=='exception' else 8)
              stores=r['result']['stores'];r['checks']['privateOperationsDistinguished']=len(stores)==1 and stores[0]['final']=={'salah_widget:config:v1':None,'__sw_probe__':None,'private-unrelated':'private retained bytes Ω'} and any(e[0]=='set' and e[1]=='salah_widget:config:v1' for e in stores[0]['events'])
              if outcome=='timeout':r['checks']['originalFourSecondBound']=r['elapsed']>=4
            except Exception:r['exception']=traceback.format_exc()
            end(c,p,r)
        for raw in ['valid','malformed','absent']:
          c,p,r=begin('native-private-default-and-injected-'+raw,raw)
          try:
            r['script']='''async seed=>{const t=await loadUntil('''+json.dumps(HASH)+''',8000,prayerReady);if(!t.w)throw Error('No actual widget positive');const w=t.w,S=w.SalahConfig,store=w.localStorage,desc=Object.getOwnPropertyDescriptor(w,'localStorage');
            for(const [k,v] of Object.entries(seed)){if(v!==null)store.setItem(k,v);else store.removeItem(k);}
            const snap=()=>Object.fromEntries(Object.keys(seed).map(k=>[k,store.getItem(k)])),before=snap();
            const normal={injected:S.loadLocal(store),default:S.loadLocal(),localInjected:S.resolve('#local=1',store),localDefault:S.resolve('#local=1'),preferInjected:S.resolve('#preferLocal=1&lat=10&lon=20',store),preferDefault:S.resolve('#preferLocal=1&lat=10&lon=20')};
            let denied;try{Object.defineProperty(w,'localStorage',{configurable:true,get(){throw new DOMException('controlled private getter denial','SecurityError');}});
              denied={available:S.storageAvailable(),load:S.loadLocal(),save:S.saveLocal({lat:1,lon:2}),clear:S.clearLocal()};}
            finally{Object.defineProperty(w,'localStorage',desc);}
            return {before,after:snap(),normal,denied,exactPrivateGetterRestored:Object.getOwnPropertyDescriptor(w,'localStorage').get===desc.get,fixture:w.__widgetFixture};}'''
            r['result']=p.evaluate(r['script'],seeds(raw));v=r['result'];n=v['normal']
            r['checks']['bothNormalPaths']=n['injected']==n['default'] and n['localInjected']==n['localDefault'] and n['preferInjected']==n['preferDefault']
            r['checks']['correctResolution']=n['localDefault']['needsDetect']==(raw!='valid') and (n['preferDefault']['cfg']['lat']==(12 if raw=='valid' else 10))
            r['checks']['privateBytesUntouched']=v['before']==v['after']==seeds(raw)
            r['checks']['throwingBoundary']=v['denied']['load'] is None and all(v['denied'][k]['ok'] is False for k in ['available','save','clear']) and v['exactPrivateGetterRestored']
          except Exception:r['exception']=traceback.format_exc()
          end(c,p,r)
        for mode in ['matching-tomorrow','duplicate-current-day-tomorrow']:
          c,p,r=begin(mode,viewport={'width':375,'height':800},dpr=2)
          try:
            if mode=='duplicate-current-day-tomorrow':
              wrapper=once((ROOT/'tests/widget-fixture.html').read_text(encoding='utf-8'),'return jsonResponse(prayerFixture(day),row);','return jsonResponse(prayerFixture("07-09-2026"),row);')
              overrides['tests/widget-fixture.html']=wrapper.encode();(out/'duplicate-current-day-tomorrow-wrapper.html').write_bytes(wrapper.encode());r['wrapperSha256']=sha(wrapper.encode())
            p.evaluate('()=>fr.setAttribute("style","position:fixed;left:20px;top:60px;width:325px;height:530px;border:0")')
            start=time.monotonic();r['result']=p.evaluate('async()=>{const t=await loadUntil('+json.dumps(HASH)+',8000,w=>prayerReady(w)&&w.__widgetFixture.ledger.filter(r=>r.url.includes("/v1/timings/08-09-2026")&&r.jsonReads>0).length>='+("3" if mode=='duplicate-current-day-tomorrow' else "1")+');if(!t.w)throw Error(JSON.stringify(t));return ('+READ+')(t.w);}')
            r['elapsed']=time.monotonic()-start;v=r['result'];q=v['qa'];f=v['fixture']
            r['checks']['currentDayRealConsumer']=f['state']=='ready' and f['error'] is None and q['cache']['prayerLoaded'] and q['cache']['prayerDate']=='07-09-2026' and q['render']['currentKey']=='Dhuhr' and q['render']['nextKey']=='Asr' and q['render']['leftMin']==180 and v['model']['nextTime']=='15:30'
            r['checks']['actualCountdownDOM']=v['dom']['countdown']=='3h 0m left until Asr'
            r['checks']['tomorrowAdmission']=q['cache']['tomorrowLoaded']==(mode=='matching-tomorrow')
            r['checks']['withinOriginalSceneBound']=r['elapsed']<8
            r['checks']['actualCard']=v['rect']['width']==325 and v['rect']['height']==530
            p.locator('#w').screenshot(path=str(out/(mode+'.png')))
          except Exception:r['exception']=traceback.format_exc()
          end(c,p,r)
      finally:
        browser.close();srv.close();report['status']='PASS' if report['cases'] and all(r.get('status')=='PASS' for r in report['cases']) else 'FAIL';report['serverRequests']=srv.requests;dump(out/'result.json',report)
    return 0 if report['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
