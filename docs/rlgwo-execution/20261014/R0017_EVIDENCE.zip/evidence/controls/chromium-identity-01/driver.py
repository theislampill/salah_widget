"""Narrow R0017 native discriminators using original smoke helpers/callbacks.

Only the automatic run invocation is held in the helper document. The original
30-case denominator, recorder, readiness, timeout and selected callbacks remain
unchanged. Controlled fault inputs are explicitly retained; these control runs
are NOT substituted for the unmodified 30-case native instrument.
"""
import argparse,sys,json,os,time,re,traceback
from pathlib import Path
B=Path(__file__).resolve().parent;sys.path.insert(0,str(B))
from run_smoke import ROOT,Server,OUTER,seeds,identity,sha,dump,sync_playwright,browser_options

SMOKE=(ROOT/'tests/smoke.html').read_text(encoding='utf-8')
START='(async()=>{try{await run();}catch(e){line("fail","harness error: "+e.message);}finally{finalize();}})();'
assert SMOKE.count(START)==1
HELD=SMOKE.replace(START,'window.__r0017HelpersReady=true;').encode()
MEDIA=SMOKE[SMOKE.index('  const media=reduce=>'):SMOKE.index('  await scene(base+"&simTime=12:30&simWx=0","explicit reduced')]
MOTION=SMOKE[SMOKE.index('  await scene(base+"&simTime=12:30&simWx=0","explicit reduced'):SMOKE.index('  head("cloud continuity (bounded accelerated')]
HASH='lat=24.47&lon=39.61&label=Madinah&method=4&simTime=12:30&simWx=0'
READ=r'''w=>({fixture:w.__widgetFixture,qa:w.qaState(),nextTime:w.model().nextTime,
  dom:{times:w.document.querySelector('.times').innerText,next:w.document.querySelector('.nt').innerText,countdown:w.document.querySelector('#count')?.innerText},
  pulse:+w.getComputedStyle(w.document.querySelector('.c')).getPropertyValue('--sunpulse'),
  transforms:[...w.document.querySelectorAll('.suncorner .corona,.suncorner .rays')].map(e=>w.getComputedStyle(e).transform),
  motionFull:w.document.querySelector('.c').classList.contains('motionfull'),nativeReduced:w.__r0017OriginalMatchMedia('(prefers-reduced-motion: reduce)').matches,
  originalMatchMediaRestored:w.matchMedia===w.__r0017OriginalMatchMedia})'''

def once(s,a,b):
    assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)

def main():
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('--engine',required=True,choices=['chromium','firefox']);a.add_argument('--group',required=True,choices=['motion','storage','identity','transport']);a.add_argument('--out',required=True,type=Path);o=a.parse_args()
    out=o.out.resolve();out.mkdir(parents=True,exist_ok=False)
    (out/'driver.py').write_bytes(Path(__file__).read_bytes());(out/'server-driver.py').write_bytes((B/'run_smoke.py').read_bytes())
    (out/'held-smoke.html').write_bytes(HELD)
    overrides={'tests/smoke.html':HELD};srv=Server(overrides);os.environ['SALAH_BROWSER']=o.engine
    report={'schema':'r0017-native-controls/v1','scope':__doc__,'engine':o.engine,'group':o.group,'source':identity(),'heldInvocation':START,'heldSmokeSha256':sha(HELD),'cases':[]}
    def save():dump(out/'result.json',report)
    with sync_playwright() as pw:
      family,opts=browser_options();opts['executable_path']=getattr(pw,family).executable_path
      browser=getattr(pw,family).launch(**opts);report['browser']={'version':browser.version,'executable':opts['executable_path'],'executableSha256':sha(Path(opts['executable_path']).read_bytes()),'headless':True}
      def begin(name,raw='valid',preference='reduce'):
        overrides.pop('index.html',None);overrides.pop('tests/widget-fixture.html',None)
        c=browser.new_context(viewport={'width':1100,'height':900},device_scale_factor=1,timezone_id='Asia/Riyadh',reduced_motion=preference,service_workers='block')
        c.add_init_script('('+OUTER+')('+json.dumps(seeds(raw))+');window.__r0017OriginalMatchMedia=window.matchMedia;')
        p=c.new_page();r={'id':name,'preference':preference,'storageSeed':raw,'startedUtc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'pageErrors':[],'checks':{}}
        report['cases'].append(r);p.on('pageerror',lambda e:r['pageErrors'].append(str(e)))
        p.goto(srv.origin+'/tests/smoke.html?fixture=healthy',wait_until='domcontentloaded');p.wait_for_function('()=>window.__r0017HelpersReady');return c,p,r
      def end(c,p,r):
        r['outer']=p.evaluate('()=>({before:__r0017Outer.before,after:__r0017Outer.snapshot(),getterAccesses:__r0017Outer.getterAccesses})')
        r['checks']['outerBytes']=r['outer']['before']==r['outer']['after']==seeds(r['storageSeed'])
        r['checks']['noOuterGetterAccess']=r['outer']['getterAccesses']==0
        r['status']='PASS' if r['checks'] and all(r['checks'].values()) and not r.get('exception') else 'FAIL'
        r['finishedUtc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());c.close();save();print(json.dumps({'case':r['id'],'status':r['status'],'checks':r['checks']}),flush=True)
      try:
        if o.group=='motion':
          for mode in ['native-no-preference','native-reduce','ignore-reduction','ignore-full-override','assertion-throw','timeout-exception','actual-callback-timeout']:
            c,p,r=begin(mode,preference='no-preference' if mode=='native-no-preference' else 'reduce')
            try:
              if mode.startswith('ignore-'):
                source=(ROOT/'index.html').read_text(encoding='utf-8')
                anchor='const isMotionReduced = () => !MOTIONFULL && !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);'
                replacement='const isMotionReduced = () => false;' if mode=='ignore-reduction' else anchor.replace('!MOTIONFULL && ','')
                changed=once(source,anchor,replacement).encode();overrides['index.html']=changed
                r['mutation']={'owner':'index.html in-memory negative only','anchor':anchor,'replacement':replacement,'sha256':sha(changed)}
              r['before']=p.evaluate('async()=>{const t=await loadUntil('+json.dumps(HASH)+',8000,prayerReady);if(!t.w)throw Error(JSON.stringify(t));return ('+READ+')(t.w);}')
              setup=''
              if mode in ['assertion-throw','timeout-exception']:
                setup='const originalRequired=required;required=(name,fn)=>originalRequired(name,ok=>fn((label,cond,detail)=>{if(label==="reduce=true freezes sunpulse to 1"||label==="motion=full wins over reduce=true"){const e=new Error("controlled '+mode+'");'+('e.name="RequiredTimeout";' if mode=='timeout-exception' else '')+'throw e;}return ok(label,cond,detail);}));'
              if mode=='actual-callback-timeout':
                setup='const originalRequired=required;required=(name,fn)=>originalRequired(name,async ok=>{await fn(ok);return new Promise(()=>{});});'
              r['controlScript']=setup+MEDIA+MOTION
              start=time.monotonic();r['result']=p.evaluate('async()=>{'+r['controlScript']+'finalize();return {smoke:__smoke,after:('+READ+')(fr.contentWindow),log:out.innerText};}')
              r['elapsedSeconds']=time.monotonic()-start
              cases=r['result']['smoke']['required']['cases'];selected={x['name']:x for x in cases if x['name'] in ['explicit reduced + full motion','motion=full overrides reduction']};r['selected']=selected
              first=selected['explicit reduced + full motion'];second=selected['motion=full overrides reduction'];checks=r['checks']
              checks['restoredExactNativeFunction']=r['result']['after']['originalMatchMediaRestored']
              if mode in ['native-no-preference','native-reduce']:
                checks['originalCallbacksReached']=first['state']==second['state']=='executed' and first['assertions']==3 and second['assertions']==2
                checks['nativePulse']=(r['before']['pulse']==1)==(mode=='native-reduce')
                checks['fullOverridePulse']=r['result']['after']['pulse']!=1 and r['result']['after']['motionFull']
              elif mode.startswith('ignore-'):
                target=first if mode=='ignore-reduction' else second
                checks['mutantReachedAssertion']=target['state']=='failed' and target['assertions']==target['expected']
                label='reduce=true freezes sunpulse to 1' if mode=='ignore-reduction' else 'motion=full wins over reduce=true'
                checks['intendedFailLine']=any('FAIL' in line and label in line for line in r['result']['log'].splitlines())
              elif mode=='assertion-throw':checks['throwRecorded']=first['state']==second['state']=='failed' and 'controlled assertion-throw' in first['reason']
              elif mode=='timeout-exception':checks['timeoutFinallyRecorded']=first['state']==second['state']=='missing' and 'controlled timeout-exception' in first['reason']
              else:checks['realFourSecondTimeouts']=first['state']==second['state']=='missing' and first['assertions']==3 and second['assertions']==2 and r['elapsedSeconds']>=8
              p.screenshot(path=str(out/(mode+'.png')),full_page=True)
            except Exception:r['exception']=traceback.format_exc()
            end(c,p,r)
        elif o.group=='storage':
          for raw in ['valid','malformed','absent']:
            for outcome in ['success','failure','exception','timeout']:
              c,p,r=begin(raw+'-'+outcome,raw)
              try:
                callback={'success':'ok=>ok("native recorder control",true)','failure':'ok=>ok("native recorder control",false)','exception':'()=>{throw Error("controlled callback exception");}','timeout':'ok=>{window.lateOk=ok;return new Promise(()=>{});}'}[outcome]
                r['controlScript']='await required("weather gate availability",'+callback+');finalize();'
                start=time.monotonic();r['result']=p.evaluate('async()=>{'+r['controlScript']+'return {smoke:__smoke,log:out.innerText};}');r['elapsedSeconds']=time.monotonic()-start
                entry=next(x for x in r['result']['smoke']['required']['cases'] if x['name']=='weather gate availability')
                r['checks']['recordedOutcome']=entry['state']=={'success':'executed','failure':'failed','exception':'failed','timeout':'missing'}[outcome]
                if outcome=='timeout':
                  r['late']=p.evaluate('async()=>{const before=pass;await required("cloud identity is stable (no reseed per read)",ok=>{lateOk("late result cannot count for newer callback",true);ok("current callback",true);});lateOk("late after missing",true);finalize();return {before,after:pass,smoke:__smoke};}')
                  r['checks']['lateCannotCompleteMissingOrNewer']=r['late']['after']==r['late']['before']+1 and next(x for x in r['late']['smoke']['required']['cases'] if x['name']=='weather gate availability')['state']=='missing'
                  r['checks']['originalFourSecondBound']=r['elapsedSeconds']>=4
              except Exception:r['exception']=traceback.format_exc()
              end(c,p,r)
        elif o.group=='identity':
          for field in ['positive','attempt','run','documentId','hash','sourceSha256']:
            c,p,r=begin('identity-'+field)
            try:
              r['positive']=p.evaluate('async()=>{const t=await loadUntil('+json.dumps(HASH)+',8000,prayerReady);if(!t.w)throw Error("positive not ready");return ('+READ+')(t.w);}')
              if field!='positive':
                value=0 if field=='attempt' else 'b'*64 if field=='sourceSha256' else '00000000-0000-4000-8000-000000000099' if field=='documentId' else 'stale-'+field
                r['injectedFault']={'field':field,'value':value}
                c.add_init_script('(()=>{if(window===top)return;let f;Object.defineProperty(window,"__widgetFixture",{configurable:true,get:()=>f,set(v){f=v;Object.defineProperty(v,'+json.dumps(field)+',{configurable:true,get:()=>'+json.dumps(value)+',set(){}});}});})();')
              start=time.monotonic();r['negative']=p.evaluate('async()=>{const t=await loadUntil('+json.dumps(HASH)+',8000,prayerReady);return {admitted:!!t.w,error:t.error,reason:t.reason,attempts};}');r['elapsedSeconds']=time.monotonic()-start
              r['checks']['exactExpectedAdmission']=r['negative']['admitted']==(field=='positive')
              if field=='sourceSha256':r['checks']['explicitSourceMismatch']=r['negative']['error']=='Widget source changed within smoke run'
              elif field!='positive':r['checks']['originalEightSecondBound']=r['elapsedSeconds']>=8
            except Exception:r['exception']=traceback.format_exc()
            end(c,p,r)
        else:
          for mode in ['body-pending','malformed-json','wrong-response-day','missing-timings','bypass-json','extra-request','source-anchor','source-digest']:
            c,p,r=begin(mode)
            try:
              wrapper=(ROOT/'tests/widget-fixture.html').read_text(encoding='utf-8')
              if mode=='body-pending':
                replacement='const response=new Response(row.url.includes("api.aladhan.com")?new ReadableStream({start(){}}):JSON.stringify(value),{status:200,headers:{"Content-Type":"application/json"}}),nativeJson=response.json.bind(response);'
                wrapper=once(wrapper,'const response=new Response(JSON.stringify(value),{status:200,headers:{"Content-Type":"application/json"}}),nativeJson=response.json.bind(response);',replacement)
              elif mode=='malformed-json':wrapper=once(wrapper,'JSON.stringify(value),{status:200','(row.url.includes("api.aladhan.com")?"{malformed":JSON.stringify(value)),{status:200')
              elif mode=='wrong-response-day':wrapper=once(wrapper,'return jsonResponse(prayerFixture(day),row);','return jsonResponse(prayerFixture(day==="07-09-2026"?"08-09-2026":"07-09-2026"),row);')
              elif mode=='missing-timings':wrapper=once(wrapper,'return jsonResponse(prayerFixture(day),row);','const body=prayerFixture(day);delete body.data.timings.Asr;return jsonResponse(body,row);')
              elif mode=='bypass-json':wrapper=once(wrapper,'response.json=()=>{row.jsonReads++;row.result="json-consumed";return nativeJson();};','response.json=()=>Promise.resolve(value);')
              elif mode=='extra-request':wrapper=once(wrapper,'const u=new URL(typeof input===','const u=new URL(typeof input===') if False else once(wrapper,'const day=u.pathname.slice("/v1/timings/".length),expected=', 'u.searchParams.set("unapproved","1");const day=u.pathname.slice("/v1/timings/".length),expected=')
              else:
                source=(ROOT/'index.html').read_text(encoding='utf-8')
                if mode=='source-anchor':changed=once(source,'<script src="config.js"></script>','<script src="other.js"></script>')
                else:
                  digest=re.search(r'id="native-first-paint-code"[^>]*data-sha256="([a-f0-9]{64})"',source).group(1);changed=once(source,'data-sha256="'+digest+'"','data-sha256="'+'0'*64+'"')
                overrides['index.html']=changed.encode();r['mutantSourceSha256']=sha(changed.encode())
              if wrapper!=(ROOT/'tests/widget-fixture.html').read_text(encoding='utf-8'):
                overrides['tests/widget-fixture.html']=wrapper.encode();(out/(mode+'-wrapper.html')).write_bytes(wrapper.encode());r['mutantWrapperSha256']=sha(wrapper.encode())
              start=time.monotonic();r['result']=p.evaluate('async()=>{const t=await loadUntil('+json.dumps(HASH)+',8000,prayerReady);const w=fr.contentWindow;return {admitted:!!t.w,error:t.error,reason:t.reason,attempts,fixture:w.__widgetFixture,qa:w.qaState?.()};}');r['elapsedSeconds']=time.monotonic()-start
              r['checks']['nonAdmitted']=not r['result']['admitted']
              f=r['result'].get('fixture') or {};r['checks']['reasonReached']=bool(r['result'].get('error') or r['result'].get('reason'))
              if mode=='body-pending':r['checks']['headersAndPendingBody']=any(x['jsonReads']>0 for x in f.get('ledger',[])) and not r['result'].get('qa',{}).get('cache',{}).get('prayerLoaded') and r['elapsedSeconds']>=8
              if mode=='bypass-json':r['checks']['realRenderWithoutJsonRejected']=bool(r['result'].get('qa',{}).get('cache',{}).get('prayerLoaded')) and all(x['jsonReads']==0 for x in f.get('ledger',[]))
              if mode.startswith('source-'):r['checks']['beforePrivateHooks']=f.get('storageIsolated') is False and f.get('state')=='error'
            except Exception:r['exception']=traceback.format_exc()
            end(c,p,r)
      finally:
        browser.close();srv.close();report['serverRequests']=srv.requests;report['status']='PASS' if report['cases'] and all(r.get('status')=='PASS' for r in report['cases']) else 'FAIL';save()
    return 0 if report['status']=='PASS' else 1

if __name__=='__main__':raise SystemExit(main())
