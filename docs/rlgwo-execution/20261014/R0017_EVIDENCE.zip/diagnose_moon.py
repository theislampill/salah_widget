import sys,json,time,os,traceback
from pathlib import Path
B=Path(__file__).resolve().parent;sys.path.insert(0,str(B))
from run_smoke import *
out=B/'evidence/diagnostic/firefox-moon-default-server-01';out.mkdir(parents=True,exist_ok=False)
srv=Server();os.environ['SALAH_BROWSER']='firefox'
row={'purpose':'Diagnose exact pending Moon stage with README standard server headers; no smoke PASS claim','source':identity(),'samples':[],'requests':[],'finished':[],'errors':[],'console':[]}
try:
 with sync_playwright() as pw:
  family,opts=browser_options();opts['executable_path']=pw.firefox.executable_path;b=pw.firefox.launch(**opts)
  c=b.new_context(viewport={'width':375,'height':800},device_scale_factor=1,timezone_id='Asia/Riyadh',reduced_motion='no-preference');p=c.new_page()
  start=time.monotonic()
  p.on('request',lambda q:row['requests'].append({'url':q.url,'t':time.monotonic()-start}))
  p.on('requestfinished',lambda q:row['finished'].append({'url':q.url,'t':time.monotonic()-start,'timing':q.timing}))
  p.on('pageerror',lambda e:row['errors'].append(str(e)))
  p.on('console',lambda m:row['console'].append({'type':m.type,'text':m.text}))
  p.goto(srv.origin+'/tests/widget-fixture.html?mode=healthy&attempt=1&run=moon-diagnostic#lat=24.47&lon=39.61&label=Madinah&method=4&simTime=01:00&simWx=0&simMoon=0.01&simWax=1&simMoonAlt=-20&tz=Asia/Riyadh&qa=1',wait_until='domcontentloaded')
  for sec in [2,5,8,15]:
   remain=sec-(time.monotonic()-start)
   if remain>0:p.wait_for_timeout(remain*1000)
   row['samples'].append({'t':time.monotonic()-start,'state':p.evaluate('()=>({fixture:window.__widgetFixture,moon:window.SalahMoonRuntime?.state,detail:window.SalahMoonDetail?.state,qa:window.qaState?.()})')})
   p.screenshot(path=str(out/f'{sec}s.png'));dump(out/'result.json',row)
  c.close();b.close()
except Exception:row['exception']=traceback.format_exc()
finally:
 row['serverRequests']=srv.requests;srv.close();dump(out/'result.json',row);(out/'driver.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'samples':[{'t':s['t'],'moon':s['state'].get('moon')} for s in row['samples']],'error':row.get('exception')}),flush=True)
