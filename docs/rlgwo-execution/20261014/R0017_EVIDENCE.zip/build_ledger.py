"""Assemble bounded R0017 evidence indexes without modifying any raw attempt."""
import json,sys,hashlib,re,subprocess,time
from pathlib import Path
B=Path(__file__).resolve().parent;E=B/'evidence';sys.path.insert(0,str(B))
from run_smoke import identity,dump
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ref(p):
 p=E/p
 return {'path':p.relative_to(E).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size}
def read(p):return json.loads((E/p).read_bytes())
native=[]
for parent in ['native','delivery']:
 for p in sorted((E/parent).glob('*/result.json')):
  r=json.loads(p.read_bytes())
  if r.get('schema')!='r0017-native-proof/v1':continue
  s=r.get('smoke') or {};q=s.get('required') or {}
  native.append({**ref(p.relative_to(E)),'engine':r.get('browser',{}).get('family') or ('firefox' if 'firefox' in p.parent.name else 'chromium'),
   'attempt':p.parent.name,'mode':r.get('mode'),'preference':r.get('preference'),'url':r.get('url'),
   'qualificationStatus':r['status'],'instrumentStatus':s.get('status'),'executed':q.get('executed'),'assertionsPassed':s.get('pass'),
   'assertionsFailed':s.get('fail'),'missing':q.get('missing'),'checks':r['checks'],'driverSha256':r['driverSha256'],
   'startedUtc':r.get('startedUtc'),'finishedUtc':r.get('finishedUtc')})
groups=[]
for p in sorted((E/'controls').glob('*/result.json')):
 r=json.loads(p.read_bytes());groups.append({**ref(p.relative_to(E)),'schema':r.get('schema'),'status':r.get('status'),'caseCount':len(r.get('cases',[])),
  'cases':[{'id':x.get('id'),'engine':x.get('engine',r.get('engine')),'status':x.get('status'),'checks':x.get('checks')} for x in r.get('cases',[])]})
spec=(B/'reference/R0017-immutable.md').read_text(encoding='utf-8');issue=(B/'reference/issue23-body.md').read_text(encoding='utf-8')
for name in ['R0017-immutable.md','issue23-body.md','worker-f-assessment.json','comment-6073045151.md','comment-6074577280.md']:
 target=E/'authority'/name;target.parent.mkdir(exist_ok=True);assert not target.exists();target.write_bytes((B/'reference'/name).read_bytes())
current={
 'capturedUtc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
 'issue':json.loads(subprocess.check_output(['gh','api','repos/theislampill/salah_widget/issues/23','--jq','{number,state,state_reason,updated_at,comments,html_url}'],text=True)),
 'remoteMain':subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd='C:/workspace/ai/salah_widget',text=True).strip(),
 'sharedStatus':subprocess.check_output(['git','--no-optional-locks','status','--short','--branch'],cwd='C:/workspace/ai/salah_widget',text=True),
 'sharedHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd='C:/workspace/ai/salah_widget',text=True).strip()}
dump(E/'authority/final-state-readback.json',current)
assessment=json.loads((B/'reference/worker-f-assessment.json').read_bytes())
dispositions={
 '17-01':('REANCHORED','Exact fetched main763a460 includes delivered R000B PR61. Exported source tree and135-file runtime identity preserved; shared historical checkout/untracked files untouched. Fresh10-file public readback and actual Pages index consumer match.'),
 '17-02':('ACCEPTED_CURRENT','35 current source-bound recorder/storage controls pass. Native missing-module/null-frame, failure/exception/timeout and late-callback controls preserve the complete denominator and do not convert missing callbacks into execution.'),
 '17-03':('BLOCKED','Local Chromium both native-preference envelopes reach30/30,141/141. Firefox local reaches27/30,135/141, including standard-server attempt. Public Chromium28/30,138/141; public Firefox27/30,135/141. Original Moon/calendar8s readiness remains unsatisfied; all original names/minima retained.'),
 '17-04':('ACCEPTED_CURRENT','Exact authored/generated config remains current. Original35 controls plus native explicit/default load/resolve, both local/preferLocal edges, original denied methods and throwing default getter preserve existing shapes/precedence.'),
 '17-05':('ACCEPTED_CURRENT','Both browsers retain exact outer valid/malformed/absent config, probe and unrelated bytes with zero outer getter access.12 seed/outcome controls per browser execute original14/8/4 config callbacks. Private save/clear/probe changes are explicitly recorded and distinct from untouched outer bytes.'),
 '17-06':('ACCEPTED_CURRENT','Current wrapper accepts the actual six-script structure without edits.21 source-bound transport controls pass, retaining historical17 plus4 strict controls. Distinct source-anchor/digest negatives reject before private hooks; actual source/script/request identity remains bound.'),
 '17-07':('QUALIFIED_CONTROLLED','Both browsers consume native current/tomorrow Response.json and render Dhuhr, nextAsr15:30,leftMin180 and actual .left text. Wrong current-day/malformed/missing timing/bypassed JSON/duplicate today-for-tomorrow do not acquire the forbidden state. Metadata identity faults and literal old-document/new-attempt controls reject. Fresh actual Pages root consumer matches.'),
 '17-08':('ADVERSE_QUALIFIED_HEALTHY_BLOCKED','Both engines original reject/hang/bootstrap documents terminate INCOMPLETE/INCOMPLETE/FAIL with intended causes; only3 config callbacks/26 assertions execute. Native pending body, missing config/null frame, late callback and literal retained-document controls discriminate. Actual unchanged Pages root loads. Complete healthy positive remains blocked under17-03.'),
 '17-09':('QUALIFIED_CONTROLLED','Both native browser preference envelopes, original explicit reduce/full callbacks and full override discriminate. Ignore-reduction/ignore-full mutants reach and fail intended assertions. Each frame retains the exact native matchMedia after normal, thrown assertion and controlled timeout exception; actual4s pending-tail cases remain missing. Accelerated continuity is not normal-liveM0.'),
 '17-10':('QUALIFIED_CURRENT','Existing README already covers all original smoke-documentation facts and matches freshly read public bytes. Conditional unsupported inline-Moon layouts do not describe the current supported six-script source. No documentation change justified.'),
 '17-11':('NOT_ACCEPTED_FOR_CLOSURE','Independent AstraMax read-only reviewer examines original matrix, raw attempts and pixels; final record is review/final-review.json. Native/public healthy gates fail. No completion certificate, evidence-publication branch, PR, merge, issue comment or closure performed. Issue remainsOPEN.')}
matrix=[]
for row in assessment['requirementMatrix']:
 status,finding=dispositions[row['id']];matrix.append({'id':row['id'],'originalObligation':row['obligation'],'historicalStatus':row['status'],'currentDisposition':status,'finding':finding})
case_source=read('native/chromium-healthy-default-02/result.json')
legacy=json.loads((B/'snapshot/docs/real-sky/evidence/startup-cloud-20261007/final-v49/receipts/historical-failures-v49-final.json').read_bytes())
todos=[]
for n,line in enumerate((B/'snapshot/tests/r000c-weather.test.cjs').read_text(encoding='utf-8').splitlines(),1):
 if line.startswith('test.todo('):todos.append({'file':'tests/r000c-weather.test.cjs','line':n,'literal':line})
ledger={'schema':'r0017-execution-ledger/v1','canonicalId':'R0017','issue':23,'disposition':'BLOCKED_NATIVE_AND_PUBLIC_MOON_READINESS',
 'authority':{'ownerOrder':'Current OWNER EXECUTION ORDER; exactly one RLGWO; no relaxed denominator/deadline; broader owner conflict must be identified.',
  'immutableSpecificationCommit':'21e7a84365fae37a86cae5c7d5e41008c0adc53f','immutableSpecification':ref('authority/R0017-immutable.md'),
  'originalIssueBody':ref('authority/issue23-body.md'),'workerFAssessment':ref('authority/worker-f-assessment.json'),
  'scopeConflict':'Immutable specification sectionE/H and original issue restrict R0017 to instrument/storage/fixture/docs; renderer/terrain expansion needs a bounded amendment. User order permits narrow in-scope repairs but requires identifying another-owner conflicts.'},
 'source':identity(),'sourceChanged':False,'documentationChanged':False,'fixtureChanged':False,'dependenciesInstalled':False,
 'environment':{'os':'Windows','playwright':'1.60.0','python':'3.11.9','chromium':'148.0.7778.96','firefox':'150.0.2','contexts':'Disposable, nonpersistent, serial; no owner browser/profile accessed','viewport':'1100x900 DPR1 instrument;375x800 DPR1 diagnostic;375x800 DPR2 selected prayer/public root captures','preference':'Native Playwright browser preference emulation; no machine preference change'},
 'denominator':case_source['denominator'],'fixedRecipe':{'utc':'2026-09-07T09:30:00.000Z','latitude':24.47,'longitude':39.61,'method':4,'school':0,'timezone':'Asia/Riyadh','days':['07-09-2026','08-09-2026'],'timings':{'Fajr':'05:00','Sunrise':'06:00','Dhuhr':'12:00','Asr':'15:30','Sunset':'18:00','Maghrib':'18:00','Isha':'19:30'},'syntheticHijri':True},
 'limitsMs':{'requiredCallback':4000,'scene':8000,'image':3000,'changed':False},'matrix':matrix,
 'residualMatrix':[
  {'id':'R0017-A01','maps':['17-03'],'status':'BLOCKED','reason':'All30callbacks not executed in required Firefox/local and bothpublic healthy attempts.'},
  {'id':'R0017-A02','maps':['17-07'],'status':'QUALIFIED_CONTROLLED','reason':'Actual JSON, current/tomorrow identity and rendered180minute consumer, stale-document and metadata controls.'},
  {'id':'R0017-A03','maps':['17-08'],'status':'PARTIAL','reason':'Adverse, timeout, null/missing and normal-entry controls qualified; complete healthy prerequisite blocked.'},
  {'id':'R0017-A04','maps':['17-09'],'status':'QUALIFIED_CONTROLLED','reason':'Both browser preference envelopes, per-frame restoration and intended reached mutants.'},
  {'id':'R0017-A05','maps':['17-10'],'status':'QUALIFIED_DOCUMENTATION_AND_SOURCE_DELIVERY','reason':'README/current wrapper facts and10material public bytes match. Public healthy runtime outcome remains separately non-PASS.'},
  {'id':'R0017-A06','maps':['17-11'],'status':'BLOCKED','reason':'Independent full acceptance cannot be issued withoutA01; nocertificate/public evidencepublication/completedclosure.'}],
 'nativeAttempts':native,'controlGroups':groups,'strictTransportReadback':ref('controls/strict-transport-readback.json'),
 'publicMaterialReadback':ref('delivery/source-readback.json'),'normalPublicConsumer':ref('delivery/normal-root-01/result.json'),
 'diagnostic':{'evidence':ref('diagnostic/firefox-moon-default-server-01/result.json'),'scope':'A separate direct fixture diagnostic does not replace the original full instrument. Original8s image has no calendar disc;15s image has one. Assets finished by0.766s; first terrain adoption13.827s afteractual computation; no asset/bootstrap error.',
  'semanticOwner':'moon/src/moon-quality.mjs adaptiveRender -> moon/src/moon-engine.mjs engine.render -> moon/src/moon-native.mjs adoption; actual generated moon/moon-host.js delivered consumer. No renderer edits authorized or performed under this R0017 scope.'},
 'retainedContraryEvidence':[
  {'path':'native/chromium-healthy-default-01/result.json','reason':'Attempt error before browser launch: oldcp9 Playwright expected unavailableChromium1200. Installed matchingR0007 Playwright1.60.0 reused subsequently.'},
  {'paths':['native/chromium-healthy-default-02','native/chromium-healthy-reduce-01','native/firefox-healthy-default-01','native/firefox-healthy-reduce-01'],'reason':'Original driver added Cache-Control:no-store to all responses. Those attempts remain raw; standard-server Firefox stillfails. Header removal does not retroactively alter older receipts.'},
  {'path':'native/firefox-healthy-default-standard-01/result.json','reason':'Faithful standard-server full run remainsINCOMPLETE27/30,135; each8s Moon/calendar gate retained.'},
  {'path':'controls/chromium-supplement-01/result.json','reason':'One auxiliary matching-tomorrow positive sampled JSON invocation before actual tomorrow adoption, so the report isFAIL. Retained intact; onlythat positive rerun with actual tomorrowLoaded readiness underoriginal8s atchromium-matching-tomorrow-02. Other18 controls retained.'},
  {'paths':['delivery/chromium-public-healthy-01/result.json','delivery/firefox-public-healthy-01/result.json'],'reason':'Public native healthy runsINCOMPLETE28/30,138 and27/30,135 respectively. Chromium last Moon surfaces after8s remainmissing; never retroactivePASS.'},
  {'path':'controls/strict-transport-readback.json','reason':'Original aggregate transport checks were initially too generic; independently inspected rawdata supports stricter target-specific checks, without browserreplay.'}],
 'legacyExceptions':{'eightHistoricalFailures':legacy,'fourCurrentTodos':todos,'disposition':'Individually retained historical exceptions/TODOs, no automaticR0017blocker and no freshPASS claim.'},
 'independentReviewer':{'task':'/root/r0017_review','requestedModel':'gpt-6-astra','requestedReasoningEffort':'max','scope':'Read-only independent raw evidence, original pixels and complete matrix; no browser/source/public mutation','routingEvidence':'Observed successful spawn configuration, not hardware/backend attestation','finalRecord':'review/final-review.json'},
 'publicEffects':{'createdPR':False,'createdEvidenceBranch':False,'committed':False,'pushed':False,'merged':False,'postedCertificate':False,'closedIssue':False},
 'finalState':ref('authority/final-state-readback.json'),
 'nextAction':'Owner/source-owner bounded amendment for actual terrain first-publication performance while preservingoriginal8s, V5geometry/opacity/phase/photometry and independent qualification. Then requalify affected original native/fullpublic paths only; preserve accepted nonaffected work. No broadterrain investigation or policy/threshold change is implied.',
 'scopeLimits':['No normal-liveM0 or general appearance certificate from font-suppressed/fixed-clock smoke.','Normal Pages root readback uses controlled preparse ingress with unchanged HTTP product bytes; not live-provider availability.','Positive localChromium cannot substitute for Firefox orpublic full execution.','Local digest manifest is custody only; not immutable public availability or acceptance.']}
dump(E/'ledger.json',ledger)
status='''R0017 / GitHub issue23: BLOCKED; issue remainsOPEN.

Target main763a460e98dc23c7f0e95bf346274f1685b3c654; unchanged30cases/141assertions and4s/8s/3s bounds.

Local Chromium:30/30,141/141 in bothnative preference envelopes.
Local Firefox:27/30,135/141, including the standard-server run.
Public Chromium:28/30,138/141. Public Firefox:27/30,135/141.
Missing Moon/calendar callbacks cannot be converted toPASS by later surfaces.

Both browsers' reject/hang/bootstrap modes, targetedtransport negatives, literal olddocument guards,
native storage-byte controls, motionmutants and exactfunction restoration qualified in their stated scopes.
Ordinary actual Pages entry consumes matching nativeJSON and visibly renders Dhuhr/Asr15:30/180minutes.
Existing README/source/wrapper are current; no in-scope repository edit is demonstrated.

The Firefox directdiagnostic has no calendar disc at8s and firstterrain adoption at13.827s.
Both assets finished by0.766s. This localizes the missed gate to actual terraincomputation/adoption;
it does not establish a specific optimization or replace the original iframe attempt.

The immutable R0017 specification restricts broader Moon/terrain repair to a bounded owner amendment.
Next: authorize/assign that exact first-publication conflict without weakening the8s gate, then
requalify only affected original native/public paths and complete independent acceptance/publication/closure.

No product/docs/wrapper changes, PR, commit, push, merge, certificate orissue closure.
Raw attempts (including driver failures), named denominator, complete17-01..17-11/A01..A06matrix,
source/runtime identities and individual legacyexceptions are inledger.json.
Independent disposition:review/final-review.json. Finalcustody hashes:manifest.json.
'''
(E/'LEDGER.txt').write_text(status,encoding='utf-8')
cp=json.loads((B/'checkpoint.json').read_bytes());cp.update(route='BLOCKED_NATIVE_AND_PUBLIC_MOON_READINESS; no supported R0017 repository change',nativeQueue='All owned browser commands returned; no active browser job',retainedFailure='See evidence/ledger.json retainedContraryEvidence; never replay accepted work',next=ledger['nextAction'],evidenceLedger='evidence/ledger.json',publicEffects=ledger['publicEffects'],issueState=current['issue']);dump(B/'checkpoint.json',cp)
print(json.dumps({'ledgerSha256':sha(E/'ledger.json'),'nativeAttempts':len(native),'controlGroups':len(groups),'issue':current['issue'],'disposition':ledger['disposition']}))
