"""Seal retained original and amendment raw evidence without editing receipts."""
import hashlib,json,pathlib,re,zipfile
B=pathlib.Path(__file__).resolve().parents[1]
W=pathlib.Path(r'C:/Users/theis/.codex/worktrees/r0017-moon-readiness/salah_widget')
D=W/'docs/rlgwo-execution/20261014'
def digest(data):return hashlib.sha256(data).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=True,allow_nan=False)+'\n',encoding='utf-8')
def invalid_constant(v):raise ValueError('Nonfinite JSON constant '+v)
original=json.loads((B/'evidence/manifest.json').read_text(encoding='utf-8-sig'))
for name,f in original['files'].items():
 p=B/'evidence'/name;data=p.read_bytes()
 assert len(data)==f['bytes'] and digest(data)==f['sha256'],name
paths=sorted([p for folder in ['evidence','amendment'] for p in (B/folder).rglob('*') if p.is_file()]+list(B.glob('*.py')),key=lambda p:p.relative_to(B).as_posix())
files=[];json_count=0;findings=[]
for p in paths:
 assert not p.is_symlink() and '__pycache__' not in p.parts and p.suffix!='.pyc'
 data=p.read_bytes();rel=p.relative_to(B).as_posix()
 if p.suffix=='.json':json.loads(data.decode('utf-8-sig'),parse_constant=invalid_constant);json_count+=1
 if p.suffix in ['.json','.py','.txt','.md','.tap','.patch']:
  if re.search(rb'ghp_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|sk-proj-[A-Za-z0-9_-]{20,}|-----BEGIN [A-Z ]*PRIVATE KEY-----',data):findings.append(rel)
 files.append({'path':rel,'bytes':len(data),'sha256':digest(data)})
assert not findings,findings
manifest={'schema':'r0017-public-evidence-manifest/v1','scope':'Original sealed evidence and all amendment raw attempts, controls, diagnostic drivers and reviews. No source snapshot, browser profile or model recording archive. Paths relative to ZIP root.','fileCount':len(files),'totalBytes':sum(f['bytes'] for f in files),'originalEvidenceFilesVerified':len(original['files']),'jsonFilesParsedStrictly':json_count,'files':files}
archive=D/'R0017_EVIDENCE.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in paths:
  i=zipfile.ZipInfo(p.relative_to(B).as_posix(),(2026,10,14,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16
  z.writestr(i,p.read_bytes(),compresslevel=9)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and z.namelist()==[f['path'] for f in files]
 for f in files:
  data=z.read(f['path']);assert digest(data)==f['sha256'] and len(data)==f['bytes']
manifest['archive']={'path':archive.name,'bytes':archive.stat().st_size,'sha256':digest(archive.read_bytes())}
dump(D/'R0017_EVIDENCE_MANIFEST.json',manifest)
pub=B/'publication';pub.mkdir(exist_ok=True)
dump(pub/'packet-check.json',{'schema':'r0017-local-packet-check/v1','status':'PASS','archive':manifest['archive'],'manifestSha256':digest((D/'R0017_EVIDENCE_MANIFEST.json').read_bytes()),'filesVerified':len(files),'strictJsonCount':json_count,'credentialPatternFindings':findings,'limits':'Bounded pattern scan, not a universal secret detector. Records contain task paths and synthetic fixture bytes; no owner profile/storage or auth material was acquired.'})
print(json.dumps({'archive':manifest['archive'],'files':len(files),'uncompressedBytes':manifest['totalBytes'],'jsonParsed':json_count,'originalFilesVerified':len(original['files'])}))
