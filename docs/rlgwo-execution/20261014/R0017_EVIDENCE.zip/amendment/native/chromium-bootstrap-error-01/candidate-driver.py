"""Reuse the original R0017 native driver with an explicit candidate source binding."""
import sys,subprocess
from pathlib import Path
B=Path(__file__).resolve().parents[1];sys.path.insert(0,str(B))
import run_smoke as rs
rs.ROOT=Path(r'C:/Users/theis/.codex/worktrees/r0017-moon-readiness/salah_widget')
original=rs.identity
def identity():
 r=original();r['baseCommit']=r.pop('commit');r['headCommit']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=rs.ROOT,text=True).strip()
 r['dirtyStatus']=subprocess.check_output(['git','status','--porcelain'],cwd=rs.ROOT,text=True)
 r['candidateDiffSha256']=rs.sha(subprocess.check_output(['git','diff','--binary','HEAD'],cwd=rs.ROOT))
 for p in ['moon/src/moon-engine.mjs','moon/src/moon-pool.mjs','moon/src/moon-native.mjs','moon/src/moon-quality.mjs','moon/moon_kernel.wasm','moon/asset-manifest.json']:
  r['files'][p]=rs.sha((rs.ROOT/p).read_bytes())
 r['wrapperSha256']=rs.sha(Path(__file__).read_bytes());return r
rs.identity=identity
if __name__=='__main__':
 out=Path(sys.argv[sys.argv.index('--out')+1]);result=rs.main()
 (out/'candidate-driver.py').write_bytes(Path(__file__).read_bytes())
 raise SystemExit(result)
