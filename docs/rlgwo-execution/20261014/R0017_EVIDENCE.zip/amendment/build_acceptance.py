"""Derive a successor acceptance ledger without rewriting any original receipt."""
import hashlib,json,pathlib,subprocess
B=pathlib.Path(__file__).resolve().parents[1]
W=pathlib.Path(r'C:/Users/theis/.codex/worktrees/r0017-moon-readiness/salah_widget')
A=B/'amendment'
BASE='763a460e98dc23c7f0e95bf346274f1685b3c654'
def read(p): return json.loads((B/p).read_text(encoding='utf-8-sig'))
def sha(b): return hashlib.sha256(b).hexdigest()
def ref(p):
 p=pathlib.Path(p);data=(B/p).read_bytes();return {'path':p.as_posix(),'sha256':sha(data),'bytes':len(data)}
def dump(p,v): p.write_text(json.dumps(v,indent=2,ensure_ascii=True,allow_nan=False)+'\n',encoding='utf-8')
old=read('evidence/ledger.json');pres=read('amendment/preservation.json');runtime=pres['runtime']['treeSha256']
healthy=['firefox-healthy-default-03','firefox-healthy-reduce-01','chromium-healthy-default-01','chromium-healthy-reduce-01']
adverse=[f'{e}-{m}-01' for e in ['chromium','firefox'] for m in ['reject','hang','bootstrap-error']]
rows=[]
for name in healthy+adverse:
 path=f'amendment/native/{name}/result.json';r=read(path);s=r['smoke'];req=s['required']
 assert r['source']['runtime']['treeSha256']==runtime
 assert r['denominator']==old['denominator'] and req['total']==30
 assert r['status']=='PASS' and all(r['checks'].values())
 if name in healthy:
  assert s['status']=='PASS' and req['executed']==30 and not req['missing'] and req['failed']==0
  assert [s[k] for k in ['pass','fail','skip']]==[141,0,0]
  assert [[c['name'],c['expected']] for c in req['cases']]==old['denominator']
  assert all(c['state']=='executed' and c['assertions']>=c['expected'] for c in req['cases'])
 else: assert s['status']==('FAIL' if r['mode']=='bootstrap-error' else 'INCOMPLETE')
 stages=[]
 for a in s['fixture']['attempts']:
  v=a.get('calendarView');o=v.get('readyObservation') if v else None
  if o:
   assert o['elapsedMs']<8000 and o['sameOwner'] and o['current'] and o['composed'] and o['visibleOwner']
   stages.append({'attempt':a['attempt'],'hash':a['hash'],'documentId':a['documentId'],'elapsedMs':o['elapsedMs'],'acceptedIdentity':o['acceptedIdentity'],'source':o['runtimeSource'],'opaqueVisiblePixels':o['opaqueVisiblePixels'],'nonopaqueVisiblePixels':o['nonopaqueVisiblePixels'],'styleRestored':v['styleRestored']})
 rows.append({**ref(path),'engine':r['browser']['family'],'browser':r['browser'],'preference':r['preference'],'mode':r['mode'],'harnessChecks':r['checks'],'observedDisposition':s['status'],'executed':req['executed'],'required':req['total'],'assertionsPassed':s['pass'],'assertionsFailed':s['fail'],'skips':s['skip'],'missing':req['missing'],'namedCaseAccounting':'Exact per-case state and assertion count in referenced raw result; full names/minima reproduced once in denominator.','moonStages':stages,'outerStorage':r['outerStorage'],'summaryPixels':ref(f'amendment/native/{name}/summary.png')})
matrix=[]
updates={
'17-01':('CANDIDATE_REANCHORED_DELIVERY_PENDING','Exact reviewed base includes R000B PR61; candidate authored/generated/runtime identities bound below. Shared checkout and old sealed evidence preserved. Only four runtime files differ. Candidate public runtime delivery remains post-merge.'),
'17-02':('ACCEPTED_CURRENT','Original recorder is byte-identical. Fresh 35 contract controls plus preserved actual native missing/late/failure/exception/timeout controls retain genuine callback accounting. All four final native healthy runs reach every named minimum.'),
'17-03':('LOCAL_QUALIFIED_PUBLIC_PENDING','Four standard-server healthy runs: Chromium and Firefox, each native preference, all original30/30 callbacks and141/141 assertions, zero fail/skip/missing. Moon stages finish inside original8s. Failed original and intermediate runs remain failures; candidate public consumers await approved deployment.'),
'17-04':('ACCEPTED_CURRENT','Authored/generated config unchanged. Reuse source-bound private/default/denied/throwing-storage controls, including both local/preferLocal consumers and original precedence. Fresh source tests and full native callbacks preserve this interface.'),
'17-05':('ACCEPTED_CURRENT','Original12 seed/outcome cases per browser preserve valid/malformed/absent config, probe and unrelated exact bytes on success/failure/exception/timeout. Private fixture operations stay distinct. Every final healthy/adverse document also has exact outer before/after bytes and zero outer getter access. No owner profile was used.'),
'17-06':('ACCEPTED_CURRENT','Smoke/fixture unchanged and accept actual six-script source. Fresh21 transport controls retain original17 plus4 strict controls; reused native source/anchor/digest, request/body and ownership negatives remain current. No parser/body/readiness bypass introduced.'),
'17-07':('QUALIFIED_CONTROLLED','Actual native current and tomorrow Response.json, fixed date/location/method/school, distinct attempt/document/source identity and rendered Dhuhr→Asr15:30/180minutes are exercised by unchanged full instrument and preserved native positive/negative controls. Candidate normal Pages consumer still requires post-merge readback.'),
'17-08':('QUALIFIED_CONTROLLED','Six fresh separate hostile candidate documents terminate with intended INCOMPLETE(reject), INCOMPLETE(hang), FAIL(bootstrap-error), while four fresh healthy documents fully pass. Retained native pending-body, missing/late callback, stale-document and malformed-input controls remain byte-current.'),
'17-09':('QUALIFIED_CONTROLLED','Four final healthy runs exercise both actual browser preference envelopes and original reduced/full/override callbacks. Unchanged semantic owners justify reuse of real --sunpulse, reached ignore-reduction/ignore-full-override mutants and exact matchMedia-object restoration on normal/throw/4s-timeout paths. No accelerated continuity credit is claimed for normal-live M0.'),
'17-10':('DOCUMENTATION_CURRENT_DELIVERY_PENDING','Existing README already satisfies the original safe-origin, four modes,30/141, callback accounting, fixed synthetic inputs, storage, font, identity, supported-anchor and scope facts. README and wrapper remain unchanged. Existing public matching bytes are retained; candidate runtime delivery remains post-merge.'),
'17-11':('AWAITING_FINAL_CANDIDATE_REVIEW_AND_PUBLIC_DELIVERY','Original BLOCKED review remains valid for its source/attempts. Successor candidate review examines the narrow causal repair, complete original matrix, raw results and pixels. Exact-head owner merge approval, Pages/public consumers, certificate acceptance and intentional completed closure remain mandatory and unperformed.')}
for m in old['matrix']:
 status,finding=updates[m['id']]
 matrix.append({'id':m['id'],'originalObligation':m['originalObligation'],'historicalStatus':m['historicalStatus'],'priorDisposition':m['currentDisposition'],'currentDisposition':status,'finding':finding})
residual=[{'id':'R0017-A01','maps':['17-03'],'status':'LOCAL_QUALIFIED_PUBLIC_PENDING'}, {'id':'R0017-A02','maps':['17-07'],'status':'QUALIFIED_CONTROLLED'}, {'id':'R0017-A03','maps':['17-08'],'status':'QUALIFIED_CONTROLLED'}, {'id':'R0017-A04','maps':['17-09'],'status':'QUALIFIED_CONTROLLED'}, {'id':'R0017-A05','maps':['17-10'],'status':'DOCUMENTATION_CURRENT_DELIVERY_PENDING'}, {'id':'R0017-A06','maps':['17-11'],'status':'AWAITING_FINAL_CANDIDATE_REVIEW_AND_PUBLIC_DELIVERY'}]
groups=[]
for group in old['controlGroups']:
 groups.append({**ref('evidence/'+group['path']),'originalStatus':group['status'],'caseCount':group['caseCount'],'reuse':'Unchanged recorder/fixture/config/prayer/motion semantics. Apply original per-case disposition, including the one retained Chromium matching-tomorrow early sample; its narrowly corrected positive is separate.'})
captures=[]
for e in ['chromium','firefox']:
 path=f'amendment/captures/{e}-dpr2/result.json';r=read(path);assert r['source']['runtime']['treeSha256']==runtime and r['status']=='PASS'
 captures.append({**ref(path),'engine':e,'browser':r['browser'],'scenes':[{'name':s['name'],'elapsedSeconds':s['elapsedSeconds'],'withinOriginal8s':s['withinOriginal8s'],'pixels':s['pixels'],'documentId':s['state']['fixture']['documentId']} for s in r['scenes']],'cacheEnvelope':'One fresh disposable context; first new-Moon scene cold, subsequent waxing/waning fresh documents with same context cache. No installed/preaccepted surface.'})
tracked=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=W,text=True).splitlines()
sourcefiles={p:{'sha256':sha((W/p).read_bytes()),'bytes':(W/p).stat().st_size} for p in tracked}
ledger={
'schema':'r0017-amended-acceptance-ledger/v1','canonicalId':'R0017','issue':23,'disposition':'LOCAL_CANDIDATE_QUALIFIED_AWAITING_INDEPENDENT_REVIEW',
'authority':{'originalSpecificationCommit':old['authority']['immutableSpecificationCommit'],'specification':ref('evidence/authority/R0017-immutable.md'),'ownerAmendment':'2026-10-14 explicit bounded Moon/native startup repair; original8s/30/141 unchanged; no source merge authority','permittedPublication':'One narrowly scoped Draft PR with immutable evidence, then exact-head owner merge gate','priorAssessment':ref('evidence/review/final-review.json'),'priorLedger':ref('evidence/ledger.json')},
'source':{'baseCommit':BASE,'baseRuntimeSha256':old['source']['runtime']['treeSha256'],'runtimeSha256':runtime,'runtimeFileCount':len(pres['runtime']['files']),'runtimeManifest':ref('amendment/preservation.json'),'changedFileIdentities':sourcefiles,'runtimeChangedFiles':pres['runtimeChangedFiles'],'byteIdenticalOwners':pres['byteIdenticalOwners'],'candidateCommit':'Bound by the containing Git commit after publication; no self-referential commit hash is claimed here.'},
'environment':{**old['environment'],'viewport':'1100x900 DPR1 unchanged instrument;375x800 DPR2 supplemental actual original fixture Moon captures','hardwareScope':'Recorded Windows AMD64 host with16 logical CPUs; no universal device latency guarantee'},
'denominator':old['denominator'],'expectedRequiredCallbacks':30,'expectedAssertions':141,'fixedRecipe':old['fixedRecipe'],'limitsMs':old['limitsMs'],
'matrix':matrix,'residualMatrix':residual,'finalNativeAttempts':rows,
'retainedControls':groups,'strictTransportReadback':ref('evidence/controls/strict-transport-readback.json'),
'preservation':{'record':ref('amendment/preservation.json'),'deterministicRebuild':pres['deterministicRebuild'],'unchangedSemanticOwners':len(pres['byteIdenticalOwners']),'originalFilesHashVerified':pres['retainedFilesVerified'],'sourceControls':'35contract+21transport allPASS','V1':'PASS unchanged frozen baseline','assetBuildContract':'2PASS','moonComponents':{'receipt':ref('amendment/moon-tests-04/receipt.json'),'tap':ref('amendment/moon-tests-04/moon-node.tap'),'passed':60,'failed':0,'skip':0,'todo':0,'scope':'Real-WASM field/pixel/quality/calendar/count parity across two/four owners, phases/orientations, odd boundaries and sparse seams; invalid owner/fourth reply; old rows zero; actual camera/light cancellation recovery; sibling cancel/partial boot disposal; existing host/currentness gates.'}},
'renderedMoonCaptures':captures,
'primaryPixelAssessment':{'reviewer':'R0017 executor; independent pixel review separately required','examined':'All six DPR2 new/waxing/waning actual widget captures, plus retained original15s near-new reference and candidate near-new first-presentation capture','observations':'Near-new ashen opaque disc remains visible. Waxing lights the right, waning the left; terrain texture and dark-side detail visible, no stars observed through discs. Header/footer and prayer UI remain within the325x530 card. Chromium waning retains truthful Sky preview refining label.','limits':'Fixed clock/font-suppressed controlled fixture is not normal-live M0, provider availability or general appearance qualification.'},
'andon':ref('amendment/ANDON.json'),'andonFollowup':ref('amendment/ANDON-followup.json'),'retainedAmendmentFailures':ref('amendment/RETAINED_FAILURES.txt'),
'retainedOriginalContraryEvidencePathBase':'evidence/','retainedOriginalContraryEvidence':old['retainedContraryEvidence'],'legacyExceptions':old['legacyExceptions'],
'materialLimits':[
'Same final runtime firefox-healthy-default-02 remains INCOMPLETE29/30,137 assertions due live synthetic installation readiness; Moon callbacks executed. Its final qaState is absent, so cause is unproven. Subsequent read-only observed diagnostic and four standard final runs pass; they do not relabel or explain it.',
'Four workers double measured summed WASM linear memory to653262848 bytes at540 receiver raster, versus326631424 for two. These are not total or peak browser memory; asset copies/JavaScript buffers add cost.',
'Cold/warm diagnostics and first pixels are supplemental; original instrument deadlines and actual named callbacks decide acceptance. Failed/incomplete builds and late polls are never successful full qualification.',
'Candidate has no public Pages healthy execution yet. Prior public source and normal consumer evidence belongs to base763a460, not the changed runtime.',
'No merge, certificate or issue closure is authorized by this ledger. Independent exact candidate/head review and reserved owner merge approval precede delivery.'
],
'delivery':{'priorPublicMaterialReadback':ref('evidence/delivery/source-readback.json'),'priorNormalPublicConsumer':ref('evidence/delivery/normal-root-01/result.json'),'candidatePages':'NOT_DEPLOYED','candidatePublicSmokeChromium':'NOT_RUN_PENDING_APPROVED_MERGE','candidatePublicSmokeFirefox':'NOT_RUN_PENDING_APPROVED_MERGE','certificate':'NOT_PUBLISHED','issueState':'OPEN'},
'independentReviewer':{**old['independentReviewer'],'priorFinalRecord':'evidence/review/final-review.json','finalRecord':'amendment/review/candidate-review.json','recordAuthority':'Separate successor disposition; this executor ledger does not imply independent acceptance.'},'nextAction':'Independent complete candidate review, one Draft PR, independent exact-head/base/public evidence readback, reserved owner merge gate.'}
assert len(ledger['denominator'])==30 and sum(x[1] for x in ledger['denominator'])==141
dump(A/'acceptance.json',ledger)
dump(W/'docs/rlgwo-execution/20261014/R0017_ACCEPTANCE.json',ledger)
print(json.dumps({'runtime':runtime,'matrixRows':len(matrix),'nativeRuns':len(rows),'healthy':len(healthy),'controlsReused':len(groups),'ledgerBytes':(A/'acceptance.json').stat().st_size}))
