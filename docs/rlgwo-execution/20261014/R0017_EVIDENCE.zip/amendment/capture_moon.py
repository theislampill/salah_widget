"""Original fixture Moon scenes: fresh documents, actual first surface and pixels."""
import sys,os,time,argparse,json,base64,traceback
from pathlib import Path
B=Path(__file__).resolve().parents[1];sys.path.insert(0,str(B));sys.path.insert(0,str(Path(__file__).resolve().parent))
import run_candidate as candidate
rs=candidate.rs
ap=argparse.ArgumentParser();ap.add_argument('--engine',required=True);ap.add_argument('--out',required=True);ap.add_argument('--dpr',default=2,type=int);a=ap.parse_args();out=Path(a.out);out.mkdir(parents=True,exist_ok=False)
row={'schema':'r0017-first-moon-capture/v1','source':rs.identity(),'engine':a.engine,'scope':'Supplemental original fixture pixels; unchanged full smoke is separate acceptance','scenes':[]}
srv=rs.Server();os.environ['SALAH_BROWSER']=a.engine
try:
 with rs.sync_playwright() as pw:
  family,opts=rs.browser_options();opts['executable_path']=getattr(pw,family).executable_path;b=getattr(pw,family).launch(**opts)
  row['browser']={'version':b.version,'executableSha256':rs.sha(Path(opts['executable_path']).read_bytes()),'headless':opts['headless'],'dpr':a.dpr,'viewport':{'width':375,'height':800}}
  c=b.new_context(viewport={'width':375,'height':800},device_scale_factor=a.dpr,timezone_id='Asia/Riyadh',reduced_motion='no-preference',service_workers='block');p=c.new_page()
  for n,(name,scene) in enumerate([('new','simTime=01:00&simWx=0&simMoon=0.01&simWax=1&simMoonAlt=-20'),('waxing','simTime=02:00&simWx=0&simMoon=0.3&simWax=1&simMoonAlt=55&simMoonH=0'),('waning','simTime=02:00&simWx=0&simMoon=0.3&simWax=0&simMoonAlt=55&simMoonH=0')],1):
   url=f'{srv.origin}/tests/widget-fixture.html?mode=healthy&attempt={n}&run=moon-capture#lat=24.47&lon=39.61&label=Madinah&method=4&{scene}&tz=Asia/Riyadh&qa=1'
   t=time.monotonic();p.goto(url,wait_until='domcontentloaded');s=None
   while time.monotonic()-t<8:
    s=p.evaluate('()=>{const q=window.qaState?.(),m=window.SalahMoonRuntime?.state,b=window.SalahMoonRuntime?.surface(),d=document.querySelector(".moon-detail-canvas");return {time:performance.now(),fixture:window.__widgetFixture,moon:m,qa:q,hasSurface:!!b,composed:document.querySelector(".c")?.classList.contains("real-sky-composed"),detail:window.SalahMoonDetail?.state,card:document.querySelector(".c")?.getBoundingClientRect().toJSON(),ready:!!b&&m?.current&&d?.isConnected&&window.SalahMoonDetail?.state.visible===true&&q?.cache?.prayerLoaded}}')
    if s.get('ready'):break
    p.wait_for_timeout(100)
   elapsed=time.monotonic()-t;passed=bool(s and s.get('ready') and elapsed<8)
   pixels=p.evaluate('()=>({surface:window.SalahMoonRuntime?.surface()?.toDataURL(),detail:document.querySelector(".moon-detail-canvas")?.toDataURL()})')
   files={}
   for k,v in pixels.items():
    if v:
     path=out/(name+'-'+k+'.png');path.write_bytes(base64.b64decode(v.split(',',1)[1]));files[path.name]=rs.sha(path.read_bytes())
   p.locator('.c').screenshot(path=str(out/(name+'-widget.png')))
   files[name+'-widget.png']=rs.sha((out/(name+'-widget.png')).read_bytes())
   row['scenes'].append({'name':name,'url':url,'elapsedSeconds':elapsed,'withinOriginal8s':passed,'state':s,'pixels':files});rs.dump(out/'result.json',row)
  c.close();b.close();row['status']='PASS' if all(x['withinOriginal8s'] for x in row['scenes']) else 'FAIL'
except Exception:row['exception']=traceback.format_exc();row['status']='ERROR'
finally:srv.close();rs.dump(out/'result.json',row);(out/'driver.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'status':row['status'],'scenes':[(x['name'],x['elapsedSeconds']) for x in row['scenes']],'exception':row.get('exception')}),flush=True)
raise SystemExit(0 if row['status']=='PASS' else 1)
