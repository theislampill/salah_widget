"""Bounded R0017 Audit-ANDON cold/warm worker-boundary observation. No source edits."""
import sys, os, time, json, argparse, traceback
from pathlib import Path
B=Path(__file__).resolve().parents[1];sys.path.insert(0,str(B))
import run_smoke as rs
from run_smoke import sync_playwright, browser_options, dump, sha
ap=argparse.ArgumentParser();ap.add_argument('--engine',required=True);ap.add_argument('--root');ap.add_argument('--out',required=True);ap.add_argument('--phase',default='new',choices=['new','waxing','waning']);ap.add_argument('--cold-only',action='store_true');a=ap.parse_args()
if a.root:rs.ROOT=Path(a.root).resolve()
out=Path(a.out);out.mkdir(parents=True,exist_ok=False)
trace=r'''(()=>{const NativeWorker=window.Worker;window.__moonBoundary=[];window.Worker=class extends NativeWorker{
 constructor(...a){super(...a);this.__n=window.__moonBoundary.filter(x=>x.kind==='construct').length;window.__moonBoundary.push({kind:'construct',worker:this.__n,t:performance.now()});this.addEventListener('message',e=>{const m=e.data;if(m&&['ready','preview','result','progress','error','boot-error'].includes(m.kind))window.__moonBoundary.push({kind:'receive',worker:this.__n,t:performance.now(),message:{kind:m.kind,id:m.id,stage:m.stage,row:m.row,total:m.total,sourceSamples:m.sourceSamples,rowOwner:m.rowOwner,diagnostics:m.diagnostics,error:m.error}});});}
 postMessage(m,...rest){window.__moonBoundary.push({kind:'send',worker:this.__n,t:performance.now(),message:{kind:m?.kind,id:m?.id,scene:m?.scene}});return super.postMessage(m,...rest);}
};})();'''
row={'schema':'r0017-andon-startup-diagnostic/v1','engine':a.engine,'root':str(rs.ROOT),'source':rs.identity(),'runs':[],'purpose':'Observe first genuine current surface; diagnostic only, no smoke acceptance'}
srv=rs.Server();os.environ['SALAH_BROWSER']=a.engine
try:
 with sync_playwright() as pw:
  family,opts=browser_options();opts['executable_path']=getattr(pw,family).executable_path
  b=getattr(pw,family).launch(**opts);c=b.new_context(viewport={'width':375,'height':800},device_scale_factor=1,timezone_id='Asia/Riyadh',reduced_motion='no-preference',service_workers='block');c.add_init_script(trace);p=c.new_page()
  url=srv.origin+'/tests/widget-fixture.html?mode=healthy&attempt=1&run=andon#lat=24.47&lon=39.61&label=Madinah&method=4&simTime=01:00&simWx=0&simMoon=0.01&simWax=1&simMoonAlt=-20&tz=Asia/Riyadh&qa=1'
  if a.phase!='new':url=url.replace('simTime=01:00','simTime=02:00').replace('simMoon=0.01','simMoon=0.3').replace('simMoonAlt=-20','simMoonAlt=55&simMoonH=0')
  if a.phase=='waning':url=url.replace('simWax=1','simWax=0')
  for label in (['cold'] if a.cold_only else ['cold','warm']):
   start=time.monotonic()
   if label=='cold':p.goto(url,wait_until='domcontentloaded')
   else:p.reload(wait_until='domcontentloaded')
   observations=[]
   while time.monotonic()-start<22:
    s=p.evaluate('()=>({t:performance.now(),timeOrigin:performance.timeOrigin,documentId:window.__widgetFixture?.documentId,fixture:window.__widgetFixture?.state,moon:window.SalahMoonRuntime?.state,hasSurface:!!window.SalahMoonRuntime?.surface(),visibility:document.visibilityState})');observations.append(s)
    if s.get('hasSurface'):break
    p.wait_for_timeout(150)
   p.screenshot(path=str(out/(label+'.png')))
   row['runs'].append({'label':label,'elapsed':time.monotonic()-start,'observations':observations,'workerEvents':p.evaluate('window.__moonBoundary'),'resources':p.evaluate('performance.getEntriesByType("resource").map(x=>x.toJSON())')});dump(out/'result.json',row)
   print(json.dumps({'label':label,'elapsed':row['runs'][-1]['elapsed'],'moon':s.get('moon')}),flush=True)
  c.close();b.close()
except Exception:row['exception']=traceback.format_exc();print(row['exception'],flush=True)
finally:srv.close();dump(out/'result.json',row);(out/'driver.py').write_bytes(Path(__file__).read_bytes())
