"""Observe actual original smoke readiness without replacing any assertion or predicate."""
import sys,os,time,json,argparse,traceback
from pathlib import Path
B=Path(__file__).resolve().parent;sys.path.insert(0,str(B));import run_candidate as c
rs=c.rs
ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);a=ap.parse_args();out=Path(a.out);out.mkdir(parents=True,exist_ok=False)
row={'schema':'r0017-readiness-observation/v1','source':rs.identity(),'samples':[],'purpose':'Discriminate new attempt7 live-weather readiness timeout; untouched smoke page and fixture'}
srv=rs.Server();os.environ['SALAH_BROWSER']='firefox'
try:
 with rs.sync_playwright() as pw:
  family,opts=rs.browser_options();opts['executable_path']=pw.firefox.executable_path;b=pw.firefox.launch(**opts);ctx=b.new_context(viewport={'width':1100,'height':900},timezone_id='Asia/Riyadh',reduced_motion='no-preference',service_workers='block');p=ctx.new_page();p.goto(srv.origin+'/tests/smoke.html?fixture=healthy',wait_until='domcontentloaded');t=time.monotonic()
  while time.monotonic()-t<120:
   s=p.evaluate('()=>{const w=document.querySelector("#w")?.contentWindow;try{const f=w?.__widgetFixture,q=w?.qaState?.();return {at:performance.now(),done:!!window.__smoke,attempt:f?.attempt,documentId:f?.documentId,hash:f?.hash,fixtureState:f?.state,clock:f?.clockNow,cache:q?.cache,render:q?.render,wxTruth:q?.wxTruth,weatherHeader:q?.weatherHeader,model:w?.model?.(),moon:w?.SalahMoonRuntime?.state,weatherEvents:f?.weatherEvents?.slice(-3)}}catch(e){return {error:String(e)}}}')
   row['samples'].append(s)
   if s.get('done'):break
   p.wait_for_timeout(150)
  row['smoke']=p.evaluate('window.__smoke');row['summary']=p.locator('#sum').inner_text();p.screenshot(path=str(out/'summary.png'),full_page=True);ctx.close();b.close()
except Exception:row['exception']=traceback.format_exc()
finally:srv.close();rs.dump(out/'result.json',row);(out/'driver.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'summary':row.get('summary'),'exception':row.get('exception'),'samples':len(row['samples'])}),flush=True)
