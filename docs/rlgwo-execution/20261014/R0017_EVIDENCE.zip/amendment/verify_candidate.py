"""Currentness, generated-consumer and retained-evidence checks; no native replay."""
import sys,json,subprocess,hashlib,runpy
from pathlib import Path
B=Path(__file__).resolve().parents[1];A=B/'amendment';W=Path(r'C:/Users/theis/.codex/worktrees/r0017-moon-readiness/salah_widget');S=B/'snapshot'
sys.path.insert(0,str(W/'tools/cp9'));from runtime_identity import runtime_identity
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=runtime_identity(W)
build=subprocess.run([sys.executable,'-X','utf8','-I','-S','-B','-c',"import sys,runpy;sys.path.insert(0,"+repr(str(W/'tools'))+");runpy.run_path("+repr(str(W/'tools/build_native.py'))+",run_name='__main__')"],cwd=W,capture_output=True)
(A/'build-determinism.txt').write_bytes(build.stdout+build.stderr);assert build.returncode==0
after=runtime_identity(W);assert before==after,'runtime changed on deterministic rebuild'
preserved=['tests/smoke.html','tests/widget-fixture.html','tests/r0017-contract.cjs','tests/r0017-transport.cjs','src/native/index.html','src/native/config.js','index.html','config.js','README.md','moon/src/moon-native.mjs','moon/src/moon-quality.mjs','moon/src/moon-worker.mjs','moon/src/moon-detail.mjs','moon/src/moon-calendar.mjs','moon/src/surface_v5.mjs','moon/src/moon_kernel.c','moon/moon_kernel.wasm','moon/asset-manifest.json','real-sky/native-host.mjs','real-sky/native-host-hooks.js','real-sky/native-composition.mjs']
same={p:{'base':sha(S/p),'candidate':sha(W/p)} for p in preserved};assert all(x['base']==x['candidate'] for x in same.values())
manifest=json.loads((B/'evidence/manifest.json').read_bytes());fail=[p for p,x in manifest['files'].items() if sha(B/'evidence'/p)!=x['sha256']];assert not fail
commands=[['node','--test','tests/r0017-contract.cjs','tests/r0017-transport.cjs'],[sys.executable,'-I','-S','-B','tools/verify_v1.py'],[sys.executable,'-I','-S','-B','moon/tests/test_build.py']]
receipts=[]
for n,cmd in enumerate(commands):
 p=subprocess.run(cmd,cwd=W,capture_output=True);name=f'preservation-{n}.txt';(A/name).write_bytes(p.stdout+p.stderr);receipts.append({'command':cmd,'exitCode':p.returncode,'output':name,'sha256':sha(A/name)})
 assert p.returncode==0,name
base_runtime=runtime_identity(S)
changed=[p for p in after['files'] if after['files'][p]!=base_runtime['files'].get(p)]
r={'schema':'r0017-candidate-preservation/v1','baseCommit':'763a460e98dc23c7f0e95bf346274f1685b3c654','runtime':after,'deterministicRebuild':True,'byteIdenticalOwners':same,'runtimeChangedFiles':changed,'retainedManifestSha256':sha(B/'evidence/manifest.json'),'retainedFilesVerified':len(manifest['files']),'commands':receipts}
(A/'preservation.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps({'runtimeSha256':after['treeSha256'],'changed':changed,'preserved':len(same),'oldEvidence':len(manifest['files'])}))
