import json,shutil
from pathlib import Path
B=Path(__file__).resolve().parents[1]
p=B/'checkpoint.json';old=B/'amendment/checkpoint-before-amendment.json'
if not old.exists():shutil.copyfile(p,old)
r=json.loads(p.read_bytes());r['route']='OWNER_AMENDMENT_ACTIVE_MOON_ROW_SCHEDULING_REPAIR';r['authorityAmendment']='2026-10-14 explicit bounded adjacent Moon/native repair authorized; original8s/30/141 unchanged; no source merge authority'
r['worktree']='C:/Users/theis/.codex/worktrees/r0017-moon-readiness/salah_widget';r['branch']='codex/r0017-moon-readiness';r['amendmentEvidence']='amendment/'
r['next']='Finish actual native Chromium/Firefox30/141 qualification and preservation; independent exact candidate review; one DraftPR then reserved exact-head owner merge gate.'
r['priorFinalReview']=r.pop('finalReview',r.get('priorFinalReview'));r['priorFinalReview']['preserved']=True
p.write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
