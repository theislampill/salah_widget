"""Association of original frozen native assertions/capture labels; no native/pixel qualification."""
import json
from pathlib import Path
W=Path(__file__).resolve().parent
VALID=['Native valid scene has finite time','Actual valid scene renders six prayer rows','Inner native card is exactly 325 by 530','No withdrawn elements remain after valid recovery']
INVALID=['Gap/fold has no finite time or old numeric anchor','Invalid actual next prayer is an em dash','Actual unavailable message remains visible','Actual explicit scene reports SIM unavailable','Every present clock-dependent output is hidden','Native withdrawal remembers each actual output visibility']
HIDDEN=['.sky','#wxfx','.climate','.arc','.bar','.cn','.times','.d']
STAGES=['matched-warm-same-day']+['native-distinct-day-'+x for x in ['09','10','11','12']]+['native-evicted-first-day-revisit']
BUCKLE='Unchanged explicit embed keeps its existing non-settings buckle behavior'
def require(value,text):
    if not value:raise ValueError(text)
def captures(name,variant):
    if name=='scenes':return ['invalid-consumer-mutant-reached'] if variant=='gap-bypass-mutant' else ['original-native-scene']
    if name=='modes':return ['original-mode-anchor','independent-wall-3600000','independent-wall--3600000']
    if name=='profiles':return ['first-day-actual-callers']+STAGES+['native-unsupported-profile-control']
    if (name,variant)==('recovery','gap'):return ['original-gap-invalid-boot','invalid-boot-settings-open','invalid-boot-settings-closed','actual-first-UTC-recovery','recovered-settings-open','recovered-settings-closed','actual-NY-invalid-again','actual-second-UTC-recovery']
    if (name,variant)==('recovery','provider-zone'):return ['valid-UTC-held-provider','before-provider-invalidation-settings-open','before-provider-invalidation-settings-closed','provider-zone-gap-withdrawal','provider-invalid-settings-open','provider-invalid-settings-closed','provider-actual-UTC-recovery']
    if (name,variant)==('recovery','valid-to-gap'):return ['valid-UTC-initial','valid-initial-settings-open','valid-initial-settings-closed','actual-config-UTC-to-NY-gap','invalid-after-valid-settings-open','invalid-after-valid-settings-closed','actual-config-recovered-UTC']
    raise ValueError('Outside original owned cell')
def settings(stage):return ['Settings buckle remains reachable during '+stage,'Actual settings overlay is visible during '+stage,'Unedited settings open/close does not create a location generation']
def labels(cell,states):
    name,variant=cell['caseName'],cell['variant'];data={s['name']:s['state'] for s in states}
    def restored(prior,current):return ['Native prior inline visibility restored for '+s for s in HIDDEN if data[prior]['geometry'].get(s) and data[current]['geometry'].get(s)]
    if name=='scenes':
        if variant=='gap-bypass-mutant':return ['Disposable bypass reaches actual scene builders while strict native time is invalid','Same healthy invalid-scene oracle rejects reached withdrawal bypass']
        if variant in ['gap','fold-invalid']:return INVALID+['Invalid original boot cannot build a downstream clock scene',BUCKLE]
        return VALID+['Native valid inverse equals literal '+('2026-11-01T08:30:00Z' if variant=='fold-valid' else '2026-03-08T07:30:00Z'),BUCKLE]
    if name=='modes':
        rows=list(VALID)
        for offset in [3600000,-3600000]:rows+=['Actual '+variant+' clock equals independent wall/elapsed literal at '+str(offset),'Actual ordinary/SIM/ADVANCING ownership remains correct','Declared synthetic weather provenance survives clock-only probe']
        return rows
    if (name,variant)==('recovery','gap'):return INVALID+['Original invalid boot postpones scene builders and clock loop']+settings('invalid-boot')+VALID+settings('recovered')+INVALID+VALID+restored('actual-first-UTC-recovery','actual-second-UTC-recovery')+['Native first recovery initializes builders exactly once across repeated recovery']
    if (name,variant)==('recovery','provider-zone'):return ['Native UTC 02:30 is valid before provider adoption']+settings('before-provider-invalidation')+INVALID+['Guarded provider metadata reaches native NY zone before downstream use']+settings('provider-invalid')+VALID+restored('valid-UTC-held-provider','provider-actual-UTC-recovery')+['Successful native builders remain single across provider invalidation/recovery']
    if (name,variant)==('recovery','valid-to-gap'):return VALID+settings('valid-initial')+INVALID+settings('invalid-after-valid')+VALID+restored('valid-UTC-initial','actual-config-recovered-UTC')+['Actual initially valid builders remain single after valid-invalid-valid config']
    if name=='profiles':
        rows=['Actual model/current/hourly callers build the native NY day profile','Actual same-day callers reuse native profile']
        if variant=='instrumented':rows+=['Counted native strict resolver scans exactly 4321 UTC minutes']
        for stage in STAGES:
            if stage=='native-evicted-first-day-revisit':rows+=['Five distinct actual days evict the first day']
            rows+=['Four-profile bound at '+stage,'Actual trusted input reaches native document at '+stage,'Actual native rAF heartbeat returns at '+stage]
        rows+=['Actual caller revisit rebuilds evicted first profile']
        if variant=='instrumented':rows+=['Each supported native build retains exhaustive 4321 scan','Each successful native lookup adds exactly one round-trip projection']
        return rows+['Actual native unsupported profile is cached and reused','Unsupported native profile participates in four-entry cache bound']
    raise ValueError('Outside original result contract')
def validate(cell,row,directory):
    require((row['case'],row['variant'],row['status'])==(cell['caseName'],cell['variant'],cell['expectedNativeStatus']),'Original native scope/status differs; healthy FAIL cannot continue')
    require(row['source']==cell['preparedIdentity'],'Original source/config/script/fixture identity differs')
    require([s['name'] for s in row['states']]==cell['captureBasenames'],'Original native captures differ')
    require(row['checks']==[{'label':s,'result':'PASS'} for s in labels(cell,row['states'])],'Original native assertion outcomes/ordered labels differ')
    if cell['counterfactual']:
        discriminator=json.loads((Path(directory)/'mutant-discriminator.json').read_bytes())
        require(discriminator['sourceMutation']=='invalid-consumer-bypass' and discriminator['healthyOracleRejected'] and all(x in INVALID for x in discriminator['healthyOracleRejected']),'Original reached mutant discriminator missing; no healthy green credit')
    if cell['caseName']=='profiles':
        timings=json.loads((Path(directory)/'profile-timing.json').read_bytes())
        require(timings['schema']=='r0008-native-profiles-cost/1' and timings['variant']==cell['variant'],'Original profile counterpart missing')
        require([m['stage'] for m in timings['matchedInputAndHeartbeat']]==STAGES and timings['independentResponsivenessDisposition']=='PENDING','Original matched timing/input/heartbeat scope differs')
    return {'originalAssertionsExact':True,'rawStatus':row['status'],'checks':row['checks'],'counterfactual':cell['counterfactual'],'pixelDisposition':'PENDING_INDEPENDENT_ORIGINAL_PIXEL_REVIEW','nativeNodeCredit':0}
