"""Root-only proposal. Default is read-only; no native effect without explicit adoption."""
from pathlib import Path
import argparse, copy, datetime as dt, hashlib, importlib.util, json, os
import socket, struct, subprocess, sys, time
from urllib.parse import urlparse

W = Path(__file__).resolve().parent
RUN = W.parent.parent
LEDGER = RUN / 'ACTIVE_LEDGER.json'
EXACT_ORDER = [('chromium', 'recovery', 'provider-zone'), ('chromium', 'recovery', 'valid-to-gap'), ('chromium', 'modes', 'ordinary'), ('chromium', 'modes', 'default'), ('chromium', 'modes', 'scale1'), ('chromium', 'modes', 'scale60'), ('chromium', 'profiles', 'instrumented'), ('chromium', 'profiles', 'uninstrumented'), ('firefox', 'scenes', 'default'), ('firefox', 'scenes', 'gap'), ('firefox', 'scenes', 'fold-invalid'), ('firefox', 'scenes', 'fold-valid'), ('firefox', 'scenes', 'gap-bypass-mutant'), ('firefox', 'recovery', 'gap'), ('firefox', 'recovery', 'provider-zone'), ('firefox', 'recovery', 'valid-to-gap'), ('firefox', 'modes', 'ordinary'), ('firefox', 'modes', 'default'), ('firefox', 'modes', 'scale1'), ('firefox', 'modes', 'scale60'), ('firefox', 'profiles', 'instrumented'), ('firefox', 'profiles', 'uninstrumented')]
TTL = 600

def now(): return dt.datetime.now(dt.timezone.utc)
def iso(value): return value.isoformat()
def load(path): return json.loads(Path(path).read_bytes())
def encode(value): return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()
def save(path, value): Path(path).write_bytes(encode(value))
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def require(value, text):
    if not value: raise ValueError(text)

def sealed(root, expected):
    root = Path(root).resolve()
    require(sha(root/'SEAL.json') == expected, 'seal drift: ' + str(root))
    seal = load(root/'SEAL.json')
    if isinstance(seal.get('files'), dict):
        names = set()
        for relative,pin in seal['files'].items():
            path = (root/relative).resolve()
            require(path.is_relative_to(root) and relative not in names and not path.is_symlink(), 'unsafe weather sealed member')
            names.add(relative)
            require(path.stat().st_size == pin['bytes'] and sha(path) == pin['sha256'], 'weather sealed byte drift: '+relative)
        require(names | {'SEAL.json'} == {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}, 'weather sealed population drift')
        return seal
    if seal.get('schema') == 'timezone-weather-review-seal/1':
        for member,key in [('MANIFEST.json','manifest'),('REPORT.json','report')]:
            path = root/member; pin = seal[key]
            require(Path(pin['path']).resolve() == path and path.stat().st_size == pin['bytes'] and sha(path) == pin['sha256'], 'typed weather review member drift: '+member)
        manifest = load(root/'MANIFEST.json'); names = set()
        require(manifest.get('schema') == 'timezone-weather-review-manifest/1' and len(manifest['files']) == seal['files'], 'typed weather review manifest differs')
        for row in manifest['files']:
            relative = row['relativePath']; path = (root/relative).resolve()
            require(path.is_relative_to(root) and Path(row['path']).resolve() == path and relative not in names and not path.is_symlink(), 'unsafe/duplicate typed weather review member')
            names.add(relative)
            require(path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], 'typed weather review byte drift: '+relative)
        require(names | {'MANIFEST.json','SEAL.json'} == {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}, 'typed weather review population drift')
        require(sha(root.parent/'timezone_weather/SEAL.json') == seal['inputPacketSealSha256'], 'typed weather review input packet drift')
        report = load(root/'REPORT.json')
        require(seal['sourceAdmissionRecommended'] is True and report['sourceAdmissionRecommended'] is True and not report['nativePass'] and not report['pixelPass'] and not report['nodeComplete'], 'typed weather review scope differs')
        check = subprocess.run([sys.executable,'-I','-S','-B',str(root/'verify_seal.py')],capture_output=True,timeout=30)
        require(check.returncode == 0, 'unchanged typed weather source-review verifier refused: '+check.stderr.decode('utf-8',errors='replace')[-1000:])
        return seal
    manifest = load(root/'MANIFEST.json')
    require(sha(root/'MANIFEST.json') == seal['manifestSha256'], 'manifest drift')
    rows = manifest['files']; names = set()
    for row in rows:
        path = (root/row['path']).resolve()
        require(path.is_relative_to(root) and row['path'] not in names, 'unsafe/duplicate sealed path')
        names.add(row['path'])
        require(path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], 'sealed byte drift: ' + row['path'])
    require(names | {'MANIFEST.json', 'SEAL.json'} == {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}, 'sealed population drift')
    tree = hashlib.sha256(''.join(r['sha256']+'  '+r['path']+'\n' for r in rows).encode()).hexdigest()
    require(tree == manifest['treeSha256'] == seal['treeSha256'] and len(rows) == seal['declaredFiles'], 'sealed tree drift')
    return seal

def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value); return value

def bindings(plan):
    for row in plan['inputPins']+list(plan['toolIdentities'].values())+plan['driverSiblingPins']:
        p=Path(row['path']);require(p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],'exact source/input drift: '+str(p))
    module(W/'driver/package_guard.py','timezone_exact_package_guard').guard_selected(plan['sourceRoot'],plan['expectedSourceSha256'])
    rows=load(W/'ORIGINAL_CASE_MANIFEST.json')['variants'];original=next(r for r in rows if (r['case'],r['variant'])==(plan['caseName'],plan['variant']))
    require(original['identity']==plan['preparedIdentity'],'original scene/config/script/fixture identity drift')
    require(plan['counterfactual']==(original['identity']['sourceMutation']=='invalid-consumer-bypass'),'original mutant identity drift')
    return {'preparedIdentity':plan['preparedIdentity'],'runtimeSha256':plan['runtimeSha256'],'runtimeFiles':139,'nativeExtensionsSha256':sha(W/'driver/timezone_extensions.py')}


def command(plan, lease_id):
    return [lease_id if value == '<FRESH_ACTUAL_LEASE_ID>' else value for value in plan['nativeArgvTemplate']]

def free(ledger):
    require(ledger.get('schema') == 'salah-active-execution/1' and Path(ledger.get('runRoot', '')).resolve() == RUN, 'wrong canonical ledger')
    row = ledger['resourceLeases']['heavy-browser']
    require(row.get('capacity') == 1 and row.get('status') == 'FREE' and row.get('holder') is None and not row.get('unknownChildCompletion') and not row.get('attentionRequired'), 'capacity not verified FREE')

def lease(plan, ledger, lease_id, instant):
    free(ledger)
    require(lease_id and lease_id.startswith('root-') and lease_id not in json.dumps(ledger.get('resourceLeaseHistory', [])) and lease_id != ledger['resourceLeases']['heavy-browser'].get('leaseId'), 'fresh root lease identity required')
    return {'capacity': 1, 'holder': 'root', 'status': 'ACTIVE', 'mode': 'ACTUAL', 'leaseId': lease_id,
        'node': 'R0008-NATIVE', 'command': plan['driverEntry'], 'argv': command(plan, lease_id),
        'driverSha256': plan['nativeDriverSha256'], 'sourceReviewSealSha256': plan['reviewSealSha256'],
        'runtimeSha256': plan['runtimeSha256'], 'outputPath': plan['output'], 'scope': plan['scope'],
        'startedAtUtc': iso(instant), 'expiresAtUtc': iso(instant + dt.timedelta(seconds=TTL)),
        'currentCase': plan['caseName']+'/'+plan['variant'], 'totalCases': 1, 'completedCases': 0, 'sessionId': None,
        'unknownChildCompletion': False, 'attentionRequired': False, 'automaticRetries': 0}

def active(plan, row, lease_id, instant):
    require(row.get('holder') == 'root' and row.get('status') == 'ACTIVE' and row.get('mode') == 'ACTUAL' and row.get('capacity') == 1 and row.get('leaseId') == lease_id and row.get('node') == 'R0008-NATIVE', 'exact root WEATHER ACTUAL lease required')
    require(row.get('command') == plan['driverEntry'] and row.get('argv') == command(plan, lease_id) and row.get('driverSha256') == plan['nativeDriverSha256'], 'lease driver/one-case command differs')
    require(row.get('runtimeSha256') == plan['runtimeSha256'] and row.get('sourceReviewSealSha256') == plan['reviewSealSha256'] and row.get('outputPath') == plan['output'] and row.get('totalCases') == 1 and row.get('scope') == plan['scope'], 'lease scope differs')
    start = dt.datetime.fromisoformat(row['startedAtUtc']); expiry = dt.datetime.fromisoformat(row['expiresAtUtc'])
    require(start.tzinfo and expiry.tzinfo and start <= instant < expiry and (expiry-start).total_seconds() == TTL, 'fresh finite lease required')
    require(not row.get('unknownChildCompletion') and not row.get('attentionRequired'), 'lease has unresolved completion')

def compare_write(expected, value):
    require(LEDGER.read_bytes() == expected, 'ledger changed; refusing overwrite')
    LEDGER.write_bytes(encode(value))  # Existing sole root writer; not an OS-level CAS.

def targets(plan):
    root = Path(plan['sourceRoot']).resolve(); outputs = [Path(plan['dispatchDirectory']).resolve(), Path(plan['output']).resolve()]
    for path in outputs:
        require(path.is_relative_to((RUN/'evidence/R0008').resolve()) and not path.is_relative_to(root) and not root.is_relative_to(path), 'effect output escaped exact R0020/source boundary')
        require(not os.path.lexists(path), 'fresh output required; never overwrite or replay')
    require(outputs[0] != outputs[1] and not outputs[0].is_relative_to(outputs[1]) and not outputs[1].is_relative_to(outputs[0]), 'effect outputs overlap')
    return outputs

def census(driver_pid=0, port=0):
    # Read only managed browser/Playwright executables, the exact driver PID and driver command.
    # Nothing is killed: an unexpected process refuses acquisition/release for root diagnosis.
    script = f"$ErrorActionPreference='Stop'; $all=@(Get-CimInstance Win32_Process -ErrorAction Stop); $ids=[System.Collections.Generic.HashSet[int]]::new(); if({int(driver_pid)} -gt 0) {{[void]$ids.Add({int(driver_pid)}); do{{$added=$false; foreach($row in $all){{if($ids.Contains([int]$row.ParentProcessId) -and -not $ids.Contains([int]$row.ProcessId)){{[void]$ids.Add([int]$row.ProcessId);$added=$true}}}}}}while($added)}}; $p=@($all | Where-Object {{($_.ExecutablePath -like '*playwright*') -or ($ids.Contains([int]$_.ProcessId)) -or ({int(driver_pid)} -gt 0 -and $_.ProcessId -eq {int(driver_pid)}) -or ($_.Name -eq 'python.exe' -and $_.CommandLine -like '*rlgwo_timezone_check.py*')}} | Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CreationDate); $l=@(Get-NetTCPConnection -State Listen -ErrorAction Stop | Where-Object {{$_.LocalPort -eq {int(port)}}} | Select-Object LocalAddress,LocalPort,OwningProcess); ConvertTo-Json -InputObject @{{processes=$p;listeners=$l}} -Depth 4 -Compress"
    result = subprocess.run(['powershell.exe', '-NoProfile', '-Command', script], capture_output=True, check=True, creationflags=subprocess.CREATE_NO_WINDOW, timeout=30)
    return json.loads(result.stdout.decode('utf-8-sig'))

def socket_exit(port):
    start = time.monotonic()
    try:
        with socket.create_connection(('127.0.0.1', port), timeout=5): pass
        status = 'CONNECTED'
    except ConnectionRefusedError as error:
        return {'status': 'ConnectionRefusedError', 'error': str(error), 'elapsedSeconds': time.monotonic()-start, 'timeoutSeconds': 5, 'attempts': 1}
    except OSError as error:
        return {'status': type(error).__name__, 'error': str(error), 'elapsedSeconds': time.monotonic()-start, 'timeoutSeconds': 5, 'attempts': 1}
    return {'status': status, 'elapsedSeconds': time.monotonic()-start, 'timeoutSeconds': 5, 'attempts': 1}

def terminal(plan, output, lease_id, binding):
    manifest=load(output/'manifest.json');result=load(output/plan['caseId']/'result.json')
    require(manifest['execution']=='EXECUTED_WITH_LIMITS' and manifest['leaseId']==lease_id,'post-browser-close original native manifest required')
    require(manifest['suite']=='timezone' and manifest['engineRequested']==plan['engine'] and manifest['driverSha256']==plan['nativeDriverSha256'] and manifest['adapterSha256']==plan['adapterSha256'],'original driver/adapter/engine differs')
    require(Path(manifest['root']).resolve()==Path(plan['sourceRoot']).resolve() and len(manifest['inputs'])==len(manifest['results'])==1,'one exact original cell required')
    require(manifest['inputs'][0]['identity']==binding['preparedIdentity'] and result['source']==binding['preparedIdentity'],'original fixture/source identity differs')
    original=next(r for r in load(W/'ORIGINAL_CASE_MANIFEST.json')['variants'] if (r['case'],r['variant'])==(plan['caseName'],plan['variant']))
    require(load(output/plan['caseId']/'input.json')['plan']==original['plan'],'original native recipe changed')
    module(W/'result_contract.py','returned_native_assertions').validate(plan,result,output/plan['caseId'])
    require(manifest['browser']['family']==plan['engine'] and Path(manifest['browser']['executable']).resolve()==Path(plan['toolIdentities'][plan['engine']]['path']).resolve(),'exact native executable identity differs')
    css=plan['structuralCss'];require(any(r['path']=='/'+css['relativePath'] and r['status']==200 and r['bytes']==css['bytes'] and r['sha256']==css['sha256'] for r in result['serverReceipts']),'required original structural CSS was not delivered')
    url=urlparse(result['url']);require(url.scheme=='http' and url.hostname=='127.0.0.1' and url.port,'actual original fixture endpoint absent')
    return manifest,result,url.port


def finish(ledger, lease_id, known, receipt):
    result = copy.deepcopy(ledger); row = result['resourceLeases']['heavy-browser']
    require(row.get('holder') == 'root' and row.get('status') == 'ACTIVE' and row.get('mode') == 'ACTUAL' and row.get('leaseId') == lease_id, 'ownership changed; never free another lease')
    row.update(status='FREE' if known else 'ATTENTION_REQUIRED', holder=None if known else 'root',
        unknownChildCompletion=not known, attentionRequired=not known, finishedAtUtc=iso(now()), lastResult=receipt,
        reason='Known driver/managed-process/socket exit and current source/runtime; independent actual review remains' if known else 'Unknown exit/currentness; preserve output and root ownership, no automatic retry')
    if known: row.update(completedCases=1, currentCase=None)
    result['updatedAtUtc'] = iso(now()); return result

def first_actual_admission(plan):
    require(plan.get('firstActualAdmissionBound') is True,'Exact corrected-first independent image admission is still pending')
    proof=plan['firstActualAdmission'];review_root=Path(proof['reviewRoot']).resolve()
    sealed(review_root,proof['reviewSealSha256'])
    for pin in proof['pins']:
        path=Path(pin['path']);require(path.stat().st_size==pin['bytes'] and sha(path)==pin['sha256'],'first actual admitted evidence drift: '+str(path))
    report=load(review_root/'REPORT.json')
    for key,value in proof['requiredReportProjection'].items():
        actual=report
        for component in key.split('.'):actual=actual[component]
        require(actual==value,'first actual independent review projection differs: '+key)
    dispatch=load(proof['dispatchPath']);manifest=load(proof['manifestPath']);result=load(proof['resultPath'])
    require(dispatch['knownExit'] is True and dispatch['capacityAfter']=='FREE' and dispatch['driverExitObserved'] is True and dispatch['exitCode']==0 and dispatch['originalAssertionsExact'] is True and dispatch['passiveReadbackExit']==0 and not dispatch.get('error') and not dispatch.get('releaseError'),'first corrected actual known/predicate return differs')
    require(dispatch['processesAfter']=={'processes':[],'listeners':[]} and dispatch['socketExit']['status']=='ConnectionRefusedError' and dispatch['socketExit']['timeoutSeconds']==5,'first corrected actual cleanup is not known')
    require(manifest['suite']=='timezone' and manifest['engineRequested']=='chromium' and manifest['driverSha256']==plan['nativeDriverSha256'] and manifest['execution']=='EXECUTED_WITH_LIMITS','first corrected source/engine/post-close receipt differs')
    original=load(W/'ORIGINAL_CASE_MANIFEST.json')['variants'][0]
    require((result['case'],result['variant'],result['status'])==('scenes','default','PARTIAL_NATIVE_SCOPE') and result['source']==original['identity'],'skipped corrected first is not exact original source/case')
    require(result['checks']==proof['originalSixChecks'],'skipped original six predicates differ')
    css=plan['structuralCss'];require(any(r['path']=='/'+css['relativePath'] and r['status']==200 and r['bytes']==css['bytes'] and r['sha256']==css['sha256'] for r in result['serverReceipts']),'skipped corrected first required stylesheet differs')
    return proof['reviewSealSha256']

def first_five_admission(plan):
    require(plan.get('retainedFirstFiveAdmissionBound') is True,'Exact retained first5 independent review remains pending')
    proof=plan['retainedFirstFiveAdmission'];sealed(proof['reviewRoot'],proof['reviewSealSha256'])
    for pin in proof['pins']:
        path=Path(pin['path']);require(path.stat().st_size==pin['bytes'] and sha(path)==pin['sha256'],'retained first5 or failed receipt drift: '+str(path))
    report=load(Path(proof['reviewRoot'])/'REPORT.json')
    for key,value in proof['requiredReportProjection'].items():require(report[key]==value,'retained first5 review projection differs: '+key)
    require(proof['keys']==plan['retainedFirstFiveKeys'],'exact first5 skip authority differs')
    for row in proof['actualPrefix']:
        dispatch=load(row['dispatchPath'])
        require(dispatch['status']=='RETURNED_KNOWN_EXIT_PENDING_INDEPENDENT_ACTUAL_REVIEW' and dispatch['knownExit'] is True and dispatch['capacityAfter']=='FREE' and dispatch['driverExitObserved'] is True and dispatch['exitCode']==0 and dispatch['originalAssertionsExact'] is True and dispatch['passiveReadbackExit']==0 and not dispatch.get('error') and not dispatch.get('releaseError'),'retained first5 is not exact known returned prefix')
    failed=load(proof['failedResultPath']);postflight=load(proof['failedPostflightPath'])
    require(failed['status']=='FAIL' and postflight['rawStatus']=='FAIL' and postflight['resourceCleanupKnown'] is True and postflight['driverExitCode']==1,'original failed provider case/cleanup must remain failed')
    require(postflight['processAndListenerReadback']=={'processes':[],'listeners':[]} and postflight['endpoint']['status']=='ConnectionRefusedError' and postflight['endpoint']['timeoutSeconds']==5,'failed postflight cleanup differs')
    return proof['reviewSealSha256']

def weather_admission(plan, args):
    require(args.admit_review and args.review_root and args.admit_review not in plan['prohibitedCaseReviewSeals'], 'distinct actual WEATHER source/case/carrier admission required')
    review_root = Path(args.review_root).resolve()
    require(review_root.is_relative_to((RUN/'workers').resolve()) and review_root != W, 'distinct private WEATHER reviewer required')
    sealed(review_root, args.admit_review)
    report = load(review_root/'REPORT.json')
    require(isinstance(report.get('reviewer'), str) and report['reviewer'].strip() and report['reviewer'] not in plan['prohibitedReviewerIdentities'], 'independent actual WEATHER reviewer identity required')
    expected = {**plan['weatherAdmissionRequiredFields'], 'carrierSealSha256': args.expected_seal}
    require(report.get('status') == 'PASS_SOURCE_CASE_PREFLIGHT_ONLY' and report.get('admissionBinding') == expected, 'WEATHER source/case/command/carrier admission differs')
    first_actual_admission(plan); first_five_admission(plan)
    admitted = copy.deepcopy(plan); admitted['reviewSealSha256'] = args.admit_review; admitted['authorSealSha256'] = args.expected_seal
    return admitted

def execute(plan, args):
    require(not sys.flags.optimize and sys.flags.isolated and sys.flags.no_site, 'run root wrapper with -I -S -B; assertions must stay enabled')
    require(args.expected_seal and args.admit_review, 'root must adopt WEATHER carrier and admit distinct source/case/carrier review')
    sealed(W, args.expected_seal); plan = weather_admission(plan, args); bound = bindings(plan); dispatch, output = targets(plan)
    sdk = subprocess.run([plan['toolIdentities']['nativePython']['path'], '-I', '-B', str(W/'check_sdk_import.py')], capture_output=True, timeout=30)
    require(sdk.returncode == 0, 'actual WEATHER-path SDK import refused before any lease/evidence/native effects: ' + sdk.stderr.decode('utf-8', errors='replace')[-1000:])
    sdk_before = json.loads(sdk.stdout)
    require(sdk_before.get('status') == 'PASS_IMPORT_ONLY_NO_NATIVE_EFFECT' and sdk_before.get('driverSha256') == plan['nativeDriverSha256'], 'SDK import readback differs')
    before = LEDGER.read_bytes(); ledger = json.loads(before); actual = lease(plan, ledger, args.lease_id, now())
    initial = census(); require(initial['processes'] == [], 'managed browser still present; root recovery required')
    acquired = copy.deepcopy(ledger); acquired.setdefault('resourceLeaseHistory', []).append({'atUtc': iso(now()), 'resource': 'heavy-browser', 'before': ledger['resourceLeases']['heavy-browser']})
    actual['wrapperSealSha256'] = args.expected_seal; actual['wrapperSha256'] = sha(__file__)
    acquired['resourceLeases']['heavy-browser'] = actual; acquired['updatedAtUtc'] = iso(now())
    dispatch.mkdir(parents=True, exist_ok=False); (dispatch/'ACTIVE_LEDGER.before.json').write_bytes(before)
    receipt = {'schema': 'root-day-one-original-case-dispatch/1', 'status': 'PREPARING', 'mode': 'ACTUAL', 'leaseId': args.lease_id,
        'command': actual['argv'], 'authorSealSha256': plan['authorSealSha256'], 'reviewSealSha256': plan['reviewSealSha256'],
        'wrapperSealSha256': args.expected_seal, 'wrapperSha256': sha(__file__), 'sourceBefore': bound, 'sdkImportBefore': sdk_before, 'processesBefore': initial,
        'scope': plan['scope'], 'automaticRetries': 0, 'nodeCredit': 0, 'pixelsQualified': False, 'nativeDriverStarted': False}
    save(dispatch/'dispatch.json', receipt)
    compare_write(before, acquired)
    known = False; process = None
    try:
        readback = LEDGER.read_bytes(); require(json.loads(readback)['resourceLeases']['heavy-browser'] == actual, 'lease acquired readback differs')
        (dispatch/'ACTIVE_LEDGER.acquired.json').write_bytes(readback)
        active(plan, load(LEDGER)['resourceLeases']['heavy-browser'], args.lease_id, now()); bindings(plan)
        env = os.environ.copy(); env['SALAH_BROWSER_EXECUTABLE'] = plan['toolIdentities'][plan['engine']]['path']
        with (dispatch/'stdout.log').open('wb') as stdout, (dispatch/'stderr.log').open('wb') as stderr:
            process = subprocess.Popen(actual['argv'], stdout=stdout, stderr=stderr, env=env, creationflags=subprocess.CREATE_NO_WINDOW)
            receipt.update(nativeDriverStarted=True, driverProcessId=process.pid, startedAtUtc=iso(now())); save(dispatch/'dispatch.json', receipt)
            remaining = (dt.datetime.fromisoformat(actual['expiresAtUtc'])-now()).total_seconds()
            receipt['exitCode'] = process.wait(timeout=max(0, remaining)); receipt['driverExitObserved'] = True
        manifest, result, port = terminal(plan, output, args.lease_id, bound)
        sealed(W, args.expected_seal); receipt['sourceAfter'] = bindings(plan); receipt['actualServerPort'] = port
        receipt['processesAfter'] = census(process.pid, port); receipt['socketExit'] = socket_exit(port)
        known = receipt['processesAfter']['processes'] == [] and receipt['processesAfter']['listeners'] == [] and receipt['socketExit']['status'] == 'ConnectionRefusedError'
        passive = subprocess.run([plan['toolIdentities']['python311']['path'], '-I', '-S', '-B', plan['passiveReadback'], '--result', str(output/plan['caseId']/'result.json'), '--cell', plan['caseId']], capture_output=True, timeout=30)
        (dispatch/'passive.stdout.json').write_bytes(passive.stdout); (dispatch/'passive.stderr.log').write_bytes(passive.stderr)
        receipt['passiveReadbackExit'] = passive.returncode
        receipt['originalCellFullPNGs'] = []
        for name in plan['captureBasenames']:
            path = output/plan['caseId']/f'{name}.png'; raw = path.read_bytes()
            require(raw[:8] == b'\x89PNG\r\n\x1a\n' and raw[12:16] == b'IHDR' and struct.unpack('>II', raw[16:24]) == (325, 530), 'original full PNG missing or dimensions differ')
            receipt['originalCellFullPNGs'].append({'path': str(path), 'bytes': len(raw), 'sha256': sha(path), 'dimensions': [325, 530]})
        receipt['originalAssertionsExact'] = module(W/'result_contract.py','native_assertion_readback').validate(plan,result,output/plan['caseId'])['originalAssertionsExact']
        receipt['originalRCUnchanged'] = sha(plan['originalRC']['path']) == plan['originalRC']['sha256']
        receipt['manifestSha256'] = sha(output/'manifest.json'); receipt['resultSha256'] = sha(output/plan['caseId']/'result.json'); receipt['namedOutputs'] = manifest.get('namedOutputs'); receipt['weatherCanonicalInterfacesConsumable'] = False
        receipt['status'] = 'RETURNED_KNOWN_EXIT_PENDING_INDEPENDENT_ACTUAL_REVIEW' if known else 'ATTENTION_REQUIRED_UNKNOWN_EXIT'
    except BaseException as error:
        receipt.update(status='RETURNED_KNOWN_EXIT_OUTPUT_DIAGNOSIS_REQUIRED' if known else 'ATTENTION_REQUIRED_NO_AUTOMATIC_RETRY', error=type(error).__name__+': '+str(error))
        if not receipt.get('driverExitObserved'): known = False
        if process is not None: receipt['driverPollAtFailure'] = process.poll()
    finally:
        receipt.update(knownExit=known, finishedAtUtc=iso(now()), processCleanupByWrapper=False, automaticRetries=0)
        save(dispatch/'dispatch.json', receipt)
        release_before = LEDGER.read_bytes(); save(dispatch/'lease.after.before-release.json', json.loads(release_before)['resourceLeases']['heavy-browser'])
        try:
            final = finish(json.loads(release_before), args.lease_id, known, str(dispatch/'dispatch.json'))
            compare_write(release_before, final)
            final_bytes = LEDGER.read_bytes(); require(json.loads(final_bytes) == final, 'lease after readback differs')
            (dispatch/'ACTIVE_LEDGER.after.json').write_bytes(final_bytes); receipt['capacityAfter'] = final['resourceLeases']['heavy-browser']['status']
        except BaseException as error:
            receipt.update(capacityAfter='UNKNOWN_OWNERSHIP_OR_WRITE_REQUIRES_ROOT_READBACK', releaseError=type(error).__name__+': '+str(error), status='ATTENTION_REQUIRED_NO_AUTOMATIC_RETRY')
        save(dispatch/'dispatch.json', receipt)
    print(json.dumps({'status': receipt['status'], 'capacityAfter': receipt.get('capacityAfter'), 'receipt': str(dispatch/'dispatch.json'), 'pixelsQualified': False, 'nodeCredit': 0}))
    return 0 if known and receipt.get('capacityAfter') == 'FREE' and receipt.get('exitCode') == 0 and receipt.get('passiveReadbackExit') == 0 and len(receipt.get('originalCellFullPNGs', [])) == len(plan['captureBasenames']) and receipt.get('originalAssertionsExact') and receipt.get('originalRCUnchanged') else 2

def previous_returned(plan, selected_index, args):
    for cell in cell_plans(plan)[:selected_index]:
        dispatch = Path(cell['dispatchDirectory'])
        receipt = load(dispatch/'dispatch.json')
        require(receipt.get('wrapperSealSha256') == args.expected_seal and receipt.get('reviewSealSha256') == args.admit_review and receipt.get('knownExit') is True and receipt.get('capacityAfter') == 'FREE' and receipt.get('driverExitObserved') is True and receipt.get('exitCode') == 0 and receipt.get('status') == 'RETURNED_KNOWN_EXIT_PENDING_INDEPENDENT_ACTUAL_REVIEW' and not receipt.get('error') and not receipt.get('releaseError'), 'prefix cell is not an exact known returned WEATHER receipt; no skip/replay')
        require(receipt.get('manifestSha256') == sha(Path(cell['output'])/'manifest.json') and receipt.get('resultSha256') == sha(Path(cell['output'])/cell['caseId']/'result.json'), 'returned WEATHER prefix outputs changed')
        require(receipt.get('originalAssertionsExact') is True and receipt.get('passiveReadbackExit') == 0 and len(receipt.get('originalCellFullPNGs',[])) == len(cell['captureBasenames']), 'returned WEATHER prefix predicates/captures missing')
        for pin in receipt['originalCellFullPNGs']:
            path=Path(pin['path']); require(path.stat().st_size == pin['bytes'] and sha(path) == pin['sha256'], 'returned WEATHER prefix crop changed')
    return selected_index

def source_admission_required(plan):
    require(plan.get('sourceInputsBound') is True, 'Actual repaired source/fixture pins are not bound')
    require(plan.get('nodeId') == 'R0008-NATIVE' and plan.get('automaticRetries') == 0 and plan.get('pixelsQualified') is False and plan.get('nodeComplete') is False, 'wrong WEATHER carrier scope')


def cell_plans(plan):
    source_admission_required(plan);cells=plan['cells'];rows=load(W/'ORIGINAL_CASE_MANIFEST.json')['variants']
    expected=[(e,r['case'],r['variant']) for e in ['chromium','firefox'] for r in rows if (e,r['case'],r['variant'])!=('chromium','scenes','default')]
    require(plan['retainedFirstFiveKeys']==[e+':'+n+'--'+v for e,n,v in expected[:5]],'exact retained first5 prefix differs')
    expected=expected[5:]
    require(len(rows)==14 and len(cells)==22 and [(c['engine'],c['caseName'],c['variant']) for c in cells]==expected,'exact original remaining22 order/skip differs')
    require(expected==EXACT_ORDER,'sealed command order differs from original source')
    selected=[]
    for c in cells:
        require(c['caseId']==c['caseName']+'--'+c['variant'] and c['cellKey']==c['engine']+':'+c['caseId'],'original cell association differs')
        require(Path(c['output']).resolve()==(RUN/'evidence/R0008/native/original-remaining-providerfix-r1'/c['engine']/c['caseId']).resolve() and Path(c['dispatchDirectory']).resolve()==(RUN/'evidence/R0008/browser/remaining-native-providerfix-dispatch-r1'/c['engine']/c['caseId']).resolve(),'exact fresh per-case output/dispatch differs')
        require(c['captureBasenames']==module(W/'result_contract.py','original_capture_names').captures(c['caseName'],c['variant']),'original capture contract differs')
        require(c['counterfactual']==(c['variant']=='gap-bypass-mutant') and c['expectedNativeStatus']==('MUTANT_DETECTED' if c['counterfactual'] else 'PARTIAL_NATIVE_SCOPE') and c['expectedNativeProcessExit']==0,'original healthy/mutant expectation differs')
        argv=[plan['toolIdentities']['nativePython']['path'],'-I','-B','-X','utf8',plan['driverEntry'],'--root',plan['sourceRoot'],'--engine',c['engine'],'--cases',c['caseName'],'--variants',c['variant'],'--output',c['output'],'--node',plan['toolIdentities']['node']['path'],'--expected-source-sha256',plan['expectedSourceSha256'],'--execute','--lease-id','<FRESH_ACTUAL_LEASE_ID>']
        require(c['nativeArgvTemplate']==argv,'exact original root command differs');selected.append({**plan,**c})
    return selected


def run_cells(plans, args):
    require(args.lease_prefix and args.lease_prefix.startswith('root-') and all(c.isalnum() or c in '-_' for c in args.lease_prefix), 'fresh root lease prefix required')
    for plan in plans:
        selected = copy.copy(args); selected.lease_id = args.lease_prefix+'-'+plan['engine']+'-'+plan['caseId']
        code = execute(plan, selected)
        if code != 0: return code  # First nonzero/missing-output/unknown-cleanup stop; no retry or next case.
        receipt = load(Path(plan['dispatchDirectory'])/'dispatch.json')
        require(receipt.get('status') == 'RETURNED_KNOWN_EXIT_PENDING_INDEPENDENT_ACTUAL_REVIEW' and not receipt.get('error') and not receipt.get('releaseError'), 'returned cell records an exception or diagnosis; stop before any next case')
    print(json.dumps({'status': 'SELECTED_ORIGINAL_WEATHER_CELLS_RETURNED_PENDING_INDEPENDENT_ACTUAL_REVIEW', 'cellCount': len(plans), 'pixelsQualified': False, 'nodeCredit': 0}))
    return 0

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true'); parser.add_argument('--expected-seal'); parser.add_argument('--admit-review'); parser.add_argument('--review-root'); parser.add_argument('--lease-prefix')
    parser.add_argument('--start-at', choices=[e+':'+n+'--'+v for e,n,v in EXACT_ORDER]); parser.add_argument('--first-only',action='store_true')
    args = parser.parse_args(); plan = load(W/'ROOT_COMMAND.json'); all_plans = cell_plans(plan)
    start = next((i for i,c in enumerate(all_plans) if c['cellKey']==args.start_at),0)
    if args.execute:
        require(not sys.flags.optimize and sys.flags.isolated and sys.flags.no_site, 'run root wrapper with -I -S -B')
        sealed(W, args.expected_seal); weather_admission(plan, args); previous_returned(plan,start,args)
    else:
        require(start==0, 'Resuming a returned prefix requires exact adopted seal and admission readback')
    plans = all_plans[start:start+1] if args.first_only else all_plans[start:]
    checks = [bindings(selected) for selected in plans]
    for selected in plans: targets(selected)
    if args.execute: return run_cells(plans, args)
    ledger = load(LEDGER)
    print(json.dumps({'status': 'PASS_SOURCE_PREFLIGHT_NO_NATIVE_EFFECT', 'cells': [{'engine':c['engine'],'case':c['caseName'],'variant':c['variant'],'binding':b,'nativeArgvTemplate':c['nativeArgvTemplate']} for c,b in zip(plans,checks)], 'runtimeFiles':139,'runtimeSha256':plan['runtimeSha256'],'sourceCaseAdmission':'PENDING_NO_EXECUTION_AUTHORITY','ledgerSha256':sha(LEDGER),'heavyBrowserReadback':ledger['resourceLeases']['heavy-browser'],'nativeExecuted':False,'nodeComplete':False}))
    return 0
if __name__ == '__main__': raise SystemExit(main())
