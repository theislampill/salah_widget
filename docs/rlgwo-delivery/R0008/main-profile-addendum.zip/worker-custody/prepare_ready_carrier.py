"""One bounded material-dependency completion; no browser or server import."""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import subprocess
import sys
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
RUN = HERE.parent.parent.parent
W = Path(r'C:\Users\theis\.codex\worktrees\552b\salah_widget')
BASE = '80e703864a74e3f67bc3d9b399fc1bbe64ea93b4'
READY = HERE / 'carrier-ready'
CANDIDATE = HERE / 'candidate-main-runtime'
PRIOR = RUN / 'workers/r0008_provider_zone_fixture_repair_r1'

def sha(data): return hashlib.sha256(data).hexdigest()
def load(path): return json.loads(Path(path).read_bytes())
def pin(path):
    data = Path(path).read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}
def put(path, data):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream: stream.write(data)
def write(path, data): put(path, (json.dumps(data, indent=2, ensure_ascii=False)+'\n').encode('utf-8'))
def git(*args): return subprocess.run(['git', *args], cwd=W, capture_output=True, check=True).stdout

def main():
    assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
    assert not READY.exists()
    assert git('rev-parse', BASE).decode().strip() == BASE
    assert git('diff', '--name-only', '0e3a3ad6', BASE).decode().splitlines() == ['DESIGN.md']
    binding = load(HERE/'INPUT_BINDING.json')
    for name in ['tests/native-inline-runtime.cjs','tests/r0001-browser-fixture.cjs']:
        data = git('show', BASE+':'+name)
        put(CANDIDATE/name, data)
        binding['files'][name] = {'bytes': len(data), 'sha256': sha(data)}
    for name, identity in binding['files'].items():
        data=(CANDIDATE/name).read_bytes()
        assert data == git('show', BASE+':'+name) and sha(data)==identity['sha256']
    inventory=load(HERE/'input/runtime-identity.json')
    for name, identity in inventory['files'].items():
        data=(CANDIDATE/name).read_bytes()
        assert len(data)==identity['bytes'] and sha(data)==identity['sha256']
    binding['head']=BASE
    binding['materialDependencyCompletion']='Two exact main test modules required by actual record-helper imports; no runtime/harness behavior change.'
    write(READY/'INPUT_BINDING.json', binding)
    write(READY/'input/runtime-identity.json', inventory)
    for path in sorted((HERE/'driver').iterdir()): put(READY/'driver'/path.name, path.read_bytes())
    write(READY/'MATERIAL_COMPLETION.json', {
        'schema':'r0008-main-profile-material-completion/1', 'atUtc':datetime.now(timezone.utc).isoformat(),
        'base':BASE, 'previousBase':'0e3a3ad6dc4f8e09ec8e246d12c70b8a996907df', 'changedFiles':['DESIGN.md'],
        'runtimeSha256':binding['candidateRuntimeSha256'], 'all135RuntimeFilesFreshRead':True,
        'materialFiles':binding['files'], 'originalPartialPreparationFailure':pin(HERE/'prepared/chromium/profiles--instrumented/profiles--instrumented/prepare.log'),
        'correction':'Acquire only exact main native-inline-runtime.cjs and r0001-browser-fixture.cjs required by original record() helper; retain partial output.',
        'sevenSharedClockClauses':'Delivered by owner-approved PR46; omit obsolete DESIGN proposal from any new integration.',
        'nativeLaunches':0, 'browserLease':'PENDING_PARENT_QUEUE_HANDOFF'})

    old_plan=load(PRIOR/'ROOT_COMMAND.json'); tools=old_plan['toolIdentities']
    for name, identity in tools.items(): assert pin(identity['path'])==identity,name
    contract_path=RUN/'workers/r0008_passive_binding_repair_r1/result_contract.py'
    spec=importlib.util.spec_from_file_location('original_result_contract',contract_path)
    contract=importlib.util.module_from_spec(spec);spec.loader.exec_module(contract)
    original_profiles=load(RUN/'evidence/R0008/native/profiles.json')
    cells=[]; commands=[]; controls=[]
    for old in old_plan['cells']:
        if old['caseName']!='profiles': continue
        engine,variant=old['engine'],old['variant']; case=old['caseId']
        prepared=READY/'prepared'/engine/case
        cmd=[tools['python311']['path'],'-I','-S','-B','-X','utf8',str(READY/'driver/rlgwo_timezone_check.py'),
             '--root',str(CANDIDATE),'--engine',engine,'--cases','profiles','--variants',variant,
             '--output',str(prepared),'--node',tools['node']['path'],'--expected-source-sha256',binding['candidateIndexSha256']]
        result=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8')
        put(READY/'logs'/(engine+'--'+variant+'.stdout'),result.stdout.encode())
        put(READY/'logs'/(engine+'--'+variant+'.stderr'),result.stderr.encode())
        assert result.returncode==0,result.stderr
        identity=load(prepared/case/'input.json')['identity']
        assert identity['sourceSha256']==binding['candidateIndexSha256']
        assert identity['sourceMutation'] is None and identity['scriptLayout']['id']=='delivered_main_0e3'
        output=HERE/'native'/engine/case
        argv=[tools['nativePython']['path'],'-I','-B','-X','utf8',str(READY/'driver/rlgwo_timezone_check.py'),
              '--root',str(CANDIDATE),'--engine',engine,'--cases','profiles','--variants',variant,
              '--output',str(output),'--node',tools['node']['path'],'--expected-source-sha256',binding['candidateIndexSha256'],
              '--execute','--lease-id','<ROOT_QUEUE_HANDOFF_LEASE_ID>']
        cell={k:copy.deepcopy(old[k]) for k in ['engine','caseName','variant','caseId','cellKey','counterfactual','originalRecipeKey','expectedNativeStatus','expectedNativeProcessExit','captureBasenames']}
        cell.update({'output':str(output),'preparedIdentity':identity,'preparedInput':pin(prepared/case/'input.json'),'nativeArgvTemplate':argv})
        cells.append(cell);commands.append({'argv':cmd,'exitCode':result.returncode,'prepared':cell['preparedInput']})
        # Actual original result consumer control: never substitute old result for new measurement.
        original=next(r for r in original_profiles['rows'] if r['engine']==engine and r['variant']==variant)
        original_row=load(original['result']['path'])
        oldcell=copy.deepcopy(old);oldcell['preparedIdentity']=original_row['source']
        olddirectory=Path(original['result']['path']).parent
        contract.validate(oldcell,original_row,olddirectory)
        controls.append({'cell':cell['cellKey'],'positive':'Original result accepted by unchanged original consumer'})
        bad=copy.deepcopy(original_row);bad['checks']=bad['checks'][:-1]
        try: contract.validate(oldcell,bad,olddirectory)
        except ValueError as e: controls.append({'cell':cell['cellKey'],'negative':'Omitted original assertion rejected','reason':str(e)})
        else: raise AssertionError('Original consumer accepted omitted assertion')
        bad=copy.deepcopy(original_row);bad['source']['sourceSha256']='0'*64
        try: contract.validate(oldcell,bad,olddirectory)
        except ValueError as e: controls.append({'cell':cell['cellKey'],'negative':'Wrong source rejected','reason':str(e)})
        else: raise AssertionError('Original consumer accepted wrong source')

    # Actual producer layout acceptance and negatives run without DOM/browser/server.
    js=r'''const fs=require('node:fs'), vm=require('node:vm');
const fixture=require(process.argv[1]),root=process.argv[2],source=fs.readFileSync(root+'/index.html','utf8');
const graph=fixture.strictNativeRuntime(source);
for(const variant of ['instrumented','uninstrumented']){
 const built=fixture.prepare({root,suite:'timezone',name:'profiles',variant});
 if(built.identity.sourceSha256!==graph.sourceSha256||built.plan.countResolver!==(variant==='instrumented'))throw Error('Wrong counterpart');
 for(const m of built.page.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/g))if(m[2])new vm.Script(m[2]);
}
let negatives=0;
for(const wrong of [source+' ',source.replace('\nboot();','\nboot();\nboot();')]){try{fixture.strictNativeRuntime(wrong)}catch(e){negatives++}}
try{fixture.prepare({root,suite:'timezone',name:'scenes',variant:'default'})}catch(e){negatives++}
if(negatives!==3)throw Error('Layout/scope negative accepted');
console.log(JSON.stringify({status:'PASS_MAIN_PRODUCER_POSITIVE_AND_THREE_NEGATIVES',scriptCount:graph.scripts.length,nativeOrdinal:fixture.SCRIPT_LAYOUTS[graph.layoutId].nativeOrdinal,negatives,browser:false}));'''
    completed=subprocess.run([tools['node']['path'],'-e',js,str(READY/'driver/rlgwo-clock-date-fixture.cjs'),str(CANDIDATE)],capture_output=True,text=True,encoding='utf-8')
    put(READY/'logs/layout-controls.stdout',completed.stdout.encode());put(READY/'logs/layout-controls.stderr',completed.stderr.encode())
    assert completed.returncode==0,completed.stderr
    controls.append(json.loads(completed.stdout))
    write(READY/'CONNECTED_PREFLIGHT.json',{'schema':'r0008-main-original-profile-connected-preflight/1',
        'status':'PASS_PREPARATION_AND_ORIGINAL_CONSUMER_CONTROLS','commands':commands,'controls':controls,
        'originalResultContract':pin(contract_path),'nativeExecuted':False,'independentReview':'PENDING'})
    write(READY/'FOUR_ORIGINAL_PROFILE_CELLS.json', {'schema':'r0008-exact-main-four-original-profile-cells/1',
        'base':BASE,'runtimeSha256':binding['candidateRuntimeSha256'],'indexSha256':binding['candidateIndexSha256'],
        'candidate':str(CANDIDATE),'tools':tools,'cells':cells,'originalPlan':pin(PRIOR/'ROOT_COMMAND.json'),
        'originalResultConsumer':pin(contract_path),'connectedPreflight':pin(READY/'CONNECTED_PREFLIGHT.json'),
        'browserQueueHandoff':'REQUIRED','numericProductionDeadline':None,'nativeExecuted':False,
        'originalCountsPreserved':'28 cases / 426 assertions / 110 captures; original four cost cells are evidence-preserved, fresh main counterparts are additive.'})
    rows=[]
    for path in sorted(READY.rglob('*')):
        if path.is_file(): rows.append({'name':str(path.relative_to(READY)),**pin(path)})
    write(READY/'MANIFEST.json',{'schema':'r0008-main-profile-preparation-manifest/1','files':rows})
    write(READY/'SEAL.json',{'schema':'r0008-main-profile-preparation-seal/1','manifest':pin(READY/'MANIFEST.json'),
        'cells':pin(READY/'FOUR_ORIGINAL_PROFILE_CELLS.json'),'sourceBinding':pin(READY/'INPUT_BINDING.json'),
        'nativeExecuted':False,'costAccepted':False,'rootIndependentReview':'PENDING','nodeCredit':0})
    print(json.dumps({'status':'PASS_FOUR_ORIGINAL_MAIN_PROFILE_CELLS_READY_NOT_EXECUTED','base':BASE,
        'cells':len(cells),'preflight':pin(READY/'CONNECTED_PREFLIGHT.json'),'seal':pin(READY/'SEAL.json')}))

if __name__=='__main__': main()
