"""Read-only original-consumer association, followed by a create-only worker return.

This does not execute, retry, accept cost, write canonical state or close an issue.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import socket
import sys
from datetime import datetime, timezone
from urllib.parse import urlparse

HERE = Path(__file__).resolve().parent
READY = HERE / 'carrier-ready'
RUN = HERE.parent.parent.parent

def load(path): return json.loads(Path(path).read_bytes())
def pin(path):
    data = Path(path).read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value)
    return value
def put(path,value):
    with Path(path).open('xb') as stream:
        stream.write((json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode('utf-8'))

def main():
    assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
    start=datetime.now(timezone.utc).isoformat()
    plan=load(READY/'FOUR_ORIGINAL_PROFILE_CELLS.json')
    admission=RUN/'integration/r0008-whole-delivery-review-20261012-r1/AFFECTED_ADMISSION_R2.json'
    assert pin(admission)['sha256']=='0db81e00156354a80595262cf408331758446596bfa6246f70acb66537420575'
    guard=module('qualified_original_source_guard',READY/'driver/package_guard.py')
    before=guard.guard_selected(Path(plan['candidate']),plan['indexSha256'])
    contract=module('qualified_original_result_consumer',Path(plan['originalResultConsumer']['path']))
    assert pin(Path(plan['originalResultConsumer']['path']))==plan['originalResultConsumer']
    rows=[]; all_pins=[]
    for cell in plan['cells']:
        output=Path(cell['output']);directory=output/cell['caseId']
        manifest=load(output/'manifest.json');result=load(directory/'result.json')
        assert manifest['execution']=='ATTEMPTED' and manifest['engineRequested']==cell['engine']
        assert manifest['root']==plan['candidate'] and manifest['leaseId']
        assert manifest['driverSha256']==pin(READY/'driver/rlgwo_native_checks.py')['sha256']
        assert manifest['adapterSha256']==pin(READY/'driver/rlgwo-clock-date-fixture.cjs')['sha256']
        assert manifest['inputs'][0]['identity']==cell['preparedIdentity']
        actual_input=load(directory/'input.json')
        assert actual_input['identity']==cell['preparedIdentity']
        association=contract.validate(cell,result,directory)
        timing=load(directory/'profile-timing.json')
        assert [s['name'] for s in result['states']]==cell['captureBasenames']
        capture_files=[]
        for name in cell['captureBasenames']:
            capture_files.append(pin(directory/(name+'.png')))
        final=result['states'][-1]['state']
        builds=[e for e in final['trace'] if e['event']=='zoneDay' and not e['hit'] and e['supported']]
        assert len(builds)>=6 and all(math.isfinite(e['durationMs']) and e['durationMs']>=0 for e in builds)
        stages=[]
        for measurement in timing['matchedInputAndHeartbeat']:
            assert all(math.isfinite(measurement[k]) and measurement[k]>=0 for k in ['driverActionMs','trustedKeyCommandReturnMs'])
            trusted=[e for e in measurement['inputEvents'] if e['event']=='keydown' and e['trusted']]
            assert trusted and all(math.isfinite(e['nativePerformance']) for e in trusted)
            heartbeats=measurement['heartbeats']
            assert heartbeats and all(math.isfinite(e['requested']) and math.isfinite(e['fired']) and e['fired']>=e['requested'] for e in heartbeats)
            stages.append({'stage':measurement['stage'],'driverActionMs':measurement['driverActionMs'],
                           'trustedKeyCommandReturnMs':measurement['trustedKeyCommandReturnMs'],
                           'trustedInputNativePerformance':[e['nativePerformance'] for e in trusted],
                           'nativeHeartbeatWaitMs':[e['fired']-e['requested'] for e in heartbeats]})
        endpoint=urlparse(result['url']);assert endpoint.hostname=='127.0.0.1' and endpoint.port
        with socket.socket() as client:
            client.settimeout(3)
            code=client.connect_ex((endpoint.hostname,endpoint.port))
        assert code in [10061,111],('Actual completed server endpoint remains open or status is unknown',code)
        file_pins=[pin(output/'manifest.json'),pin(directory/'result.json'),pin(directory/'profile-timing.json'),
                   pin(directory/'input.json'),pin(directory/'input.html'),pin(directory/'prepare.log'),*capture_files]
        all_pins.extend(file_pins)
        rows.append({'cellKey':cell['cellKey'],'leaseId':manifest['leaseId'],'browser':manifest['browser'],
                     'source':cell['preparedIdentity'],'result':pin(directory/'result.json'),'timing':pin(directory/'profile-timing.json'),
                     'originalAssertionsExact':association['originalAssertionsExact'],
                     'originalChecks':len(result['checks']),'originalCaptures':capture_files,
                     'coldBuildMs':timing['coldMs'],'reusedProfileMs':timing['reuseMs'],
                     'matchedInputHeartbeat':stages,'serverPort':endpoint.port,'endpointConnectEx':code,
                     'nativeStatus':result['status'],'independentCostDisposition':'PENDING_ROOT',
                     'limits':result.get('limitations',result.get('limits'))})
    after=guard.guard_selected(Path(plan['candidate']),plan['indexSha256'])
    assert before==after
    report={'schema':'r0008-four-original-main-profile-actual-worker-return/1',
        'status':'ACTUAL_FOUR_CASES_RETURNED_ORIGINAL_ASSERTIONS_EXACT_INDEPENDENT_COST_REVIEW_PENDING',
        'observationStartUtc':start,'observationEndUtc':datetime.now(timezone.utc).isoformat(),
        'base':plan['base'],'runtimeSha256':plan['runtimeSha256'],'indexSha256':plan['indexSha256'],
        'sourceBeforeEqualsAfter':True,'actualOriginalCells':rows,'actualCaseCount':len(rows),
        'assertions':sum(r['originalChecks'] for r in rows),'captureCount':sum(len(r['originalCaptures']) for r in rows),
        'rootSourceAdmission':pin(admission),'preparationSeal':pin(READY/'SEAL.json'),
        'acceptedOriginalCampaign':'28 cases / 426 assertions / 110 captures retained; these four main applicability cases are additive.',
        'A12':'Scoped original date-only reuse independently accepted by root; no additional A12 run.',
        'A14':'Direct original f443 qualification retained; no renderer campaign.',
        'numericProductionDeadline':None,'independentCostDisposition':'PENDING_ROOT',
        'wholeIssueClosed':False,'canonicalWrites':0,'GitHubEffects':0,'nodeCredit':0,
        'attributionLimits':'Native Intl forwarded unchanged; instrumented strict-resolver counts only. Uninstrumented pair retains observer and driver transport overhead. Input/native callback timestamps are actual observed browser events, not production latency thresholds.',
        'actualFiles':all_pins}
    put(HERE/'ACTUAL_FOUR_CASES_RETURN.json',report)
    put(HERE/'ACTUAL_FOUR_CASES_RETURN_SEAL.json',{'schema':'r0008-four-case-actual-return-seal/1',
        'return':pin(HERE/'ACTUAL_FOUR_CASES_RETURN.json'),'nativeCostAcceptance':'PENDING_ROOT','nodeCredit':0})
    print(json.dumps({'return':pin(HERE/'ACTUAL_FOUR_CASES_RETURN.json'),'seal':pin(HERE/'ACTUAL_FOUR_CASES_RETURN_SEAL.json'),
        'cases':len(rows),'checks':report['assertions'],'captures':report['captureCount'],'costAcceptance':'PENDING_ROOT'}))

if __name__=='__main__': main()
