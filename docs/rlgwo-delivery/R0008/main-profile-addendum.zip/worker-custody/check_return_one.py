"""Per-return use of existing admitted original consumers; no execution or ledger writes."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import sys

HERE=Path(__file__).resolve().parent
RUN=HERE.parent.parent.parent
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value)
    return value
def load(path):return json.loads(Path(path).read_bytes())
def main():
    index=int(sys.argv[1]);assert index in [1,2,3]
    plan=load(HERE/'carrier-ready/FOUR_ORIGINAL_PROFILE_CELLS.json');cell=plan['cells'][index]
    output=Path(cell['output']);directory=output/cell['caseId']
    manifest=load(output/'manifest.json');row=load(directory/'result.json')
    assert manifest['execution']=='EXECUTED_WITH_LIMITS' and manifest['leaseId']=='root-r0008-four-main-profile-cells-f3e5e0a2-aa60-4e4b-9fa1-c60882a918ca'
    assert manifest['inputs'][0]['identity']==cell['preparedIdentity'] and row['source']==cell['preparedIdentity']
    assert manifest['browser']['family']==cell['engine'] and Path(manifest['browser']['executable']).resolve()==Path(plan['tools'][cell['engine']]['path']).resolve()
    consumer=module('qualified_original_consumer',Path(plan['originalResultConsumer']['path']))
    association=consumer.validate(cell,row,directory)
    guard=module('qualified_original_guard',HERE/'carrier-ready/driver/package_guard.py')
    binding=guard.guard_selected(Path(plan['candidate']),plan['indexSha256'])
    qualified=module('qualified_original_custody',RUN/'workers/r0008_provider_zone_fixture_repair_r1/run_remaining_once.py')
    port=qualified.urlparse(row['url']).port
    census=qualified.census(port=port);endpoint=qualified.socket_exit(port)
    assert census['processes']==[] and census['listeners']==[] and endpoint['status']=='ConnectionRefusedError'
    live=load(RUN/'ACTIVE_LEDGER.json')['resourceLeases']['heavy-browser']
    assert live['status']=='ACTIVE' and live['holder']=='root' and live['leaseId']==manifest['leaseId']
    assert datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(live['expiresAtUtc'])
    result={'cell':cell['cellKey'],'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'originalResultConsumer':association,'sourceAfter':binding,'browser':manifest['browser'],
            'qualifiedCensus':census,'qualifiedEndpoint':endpoint,'actualServerPort':port,
            'originalManifestSha256':hashlib.sha256((output/'manifest.json').read_bytes()).hexdigest(),
            'originalResultSha256':hashlib.sha256((directory/'result.json').read_bytes()).hexdigest(),
            'canonicalLeaseUnchanged':True,'costDisposition':'PENDING_ROOT','canonicalWrites':0}
    with (HERE/('native-custody-'+str(index)+'.json')).open('xb') as stream:
        stream.write((json.dumps(result,indent=2,ensure_ascii=False)+'\n').encode('utf-8'))
    print(json.dumps({'status':'KNOWN_ORIGINAL_NATIVE_RETURN_WITH_QUALIFIED_CLEANUP',
        'cell':cell['cellKey'],'assertions':len(row['checks']),'browser':manifest['browser'],'port':port}))
if __name__=='__main__':main()
