"""Create-only, offline whole-issue closure proposal; grants no acceptance/effects."""
import copy
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

RUN = Path(r"C:\Users\theis\Documents\Codex\salah-rlgwo-execution-20261009")
LANE = RUN / "workers/r0008_whole_closure_r1"
ADD = LANE / "addendum-r2"
OUT = ADD / "final-return-r3"
ROOT_REVIEW = RUN / "integration/r0008-whole-delivery-review-20261012-r1"
MAIN = "ba6d15d6f305451a7eccbbd30e2a47138c9a22b3"

def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))

def pin(path, expected=None):
    path = Path(path)
    data = path.read_bytes()
    result = {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    if expected is not None:
        assert result["sha256"] == expected, (str(path), result)
    return result

def write(name, value):
    data = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    path = OUT / name
    with path.open("xb") as stream:
        stream.write(data)
    return pin(path)

def main():
    OUT.mkdir(exist_ok=False)
    original_report = read(LANE / "REPORT.json")
    original = read(LANE / "ROW_DISPOSITIONS.json")
    original_cert = read(LANE / "postimages-final/docs/rlgwo-delivery/R0008/original-candidate-certificate.json")
    old_applicability = read(LANE / "MAIN_APPLICABILITY_PROPOSAL.json")
    actual = read(ADD / "ACTUAL_FOUR_CASES_RETURN.json")
    current = read(ADD / "CURRENT_MAIN_READBACK.json")
    clauses = read(ADD / "CURRENT_MAIN_SEVEN_CLAUSES.json")
    admission = read(ROOT_REVIEW / "AFFECTED_ADMISSION_R2.json")
    release = read(ROOT_REVIEW / "FOUR_CASE_RELEASE.json")
    assert actual["actualCaseCount"] == 4 and actual["assertions"] == 102 and actual["captureCount"] == 32
    assert actual["sourceBeforeEqualsAfter"] is True
    assert current["base"] == MAIN and clauses["main"] == MAIN
    assert current["runtimeSha256"] == actual["runtimeSha256"]
    assert current["changedPathsSinceMeasuredBase"] == ["DESIGN.md", "README.md"]
    assert len(clauses["allSevenDeliveredSharedClausesRetained"]) == 7
    assert all(row["exactOccurrences"] == 1 for row in clauses["allSevenDeliveredSharedClausesRetained"])
    assert release["cleanupAccepted"] is True
    assert len(original["rows"]) == len(original_cert["all16OriginalObligations"]) == 16
    assert original["acceptanceIds"] == original_cert["requiredAcceptanceIds"]
    assert sum(row["originalDispositionPreserved"] == "satisfied" for row in original["rows"]) == 9

    refs = {
        "originalWholeReturn": pin(LANE / "REPORT.json", "a02adcf1cdb7d9ba3b1b50847987615bae8b5b6f952fddde980ca15b770f1200"),
        "originalAll16Certificate": pin(LANE / "postimages-final/docs/rlgwo-delivery/R0008/original-candidate-certificate.json"),
        "originalQualification": old_applicability["originalCanonicalQualification"],
        "originalQualificationRootJoin": old_applicability["originalRootJoin"],
        "originalIndependentQualification": old_applicability["originalIndependentReview"],
        "sourceRegionalTransfer": pin(LANE / "CONSUMER_TRANSFER.json"),
        "mainSourceReadback": pin(ADD / "CURRENT_MAIN_READBACK.json", "ba981f1f84f4e7e3d52e8f7c5661149dab5a57a2d5b43ffb909f3994c0ab701f"),
        "mainSevenClausesReadback": pin(ADD / "CURRENT_MAIN_SEVEN_CLAUSES.json", "b277d7115b66369ce786f3af844b374bbcc2e0e7738898fda08d400417fe6cbd"),
        "A12ReachedConsumerDecision": pin(ADD / "A12_PREDICATE_DECISION.json"),
        "A12PreScriptTransport": pin(ADD / "A12_PRE_SCRIPT_TRANSPORT_PREDICATE.json"),
        "rootA12AcceptanceAndFourCaseAdmission": pin(ROOT_REVIEW / "AFFECTED_ADMISSION_R2.json", "0db81e00156354a80595262cf408331758446596bfa6246f70acb66537420575"),
        "A13AffectedCaseScope": pin(ADD / "A13_APPLICABILITY_GAP.json"),
        "actualFourCaseReturn": pin(ADD / "ACTUAL_FOUR_CASES_RETURN.json", "e94f4631bb817822463b6624502b54e69526d7aa56ae97863adac5c7e2e376e1"),
        "qualifiedCleanupReturn": pin(ADD / "QUALIFIED_CLEANUP_RETURN.json", "c8f251fa9b3a70da062f56c0eb8816d46cc069db05f989e9acf68ae9b0dc73ce"),
        "rootAcceptedCleanupAndRelease": pin(ROOT_REVIEW / "FOUR_CASE_RELEASE.json", "1543add08c8f702ec8b855ed7d285fbbc0b3b0267d02d48119e1f7186957dea6"),
        "A14DirectF443SourceConsumerMap": old_applicability["A14"]["sourceToConsumerMap"],
        "oldPublicEvidenceReconciliation": pin(LANE / "PUBLICATION_RECONCILIATION_FINAL.json"),
    }
    for ref in refs.values():
        assert pin(ref["path"]) == ref, ref
    claims = {
        "A08_A09": {
            "disposition": "RETAIN_ORIGINAL_ACCEPTED_WEATHER18_114_44_AND_REGIONAL_OWNER_EQUIVALENCE",
            "consumer": old_applicability["A08_A09"],
            "basis": ["originalQualification", "originalQualificationRootJoin", "sourceRegionalTransfer"],
            "newWeatherCases": 0,
            "wholeE718RuntimeEqualityClaim": False,
        },
        "A12": {
            "disposition": "ROOT_ACCEPTED_NARROW_ORIGINAL_REACHED_CONSUMER_REUSE",
            "basis": ["rootA12AcceptanceAndFourCaseAdmission", "A12ReachedConsumerDecision", "A12PreScriptTransport"],
            "predicate": "Original pre-script literal coordinates and simWx0 make unknown-location preview and actual weather starts ineligible. Invalid gap/fold boot returns before unequal valid-scene handoff. Actual valid recovery calls unchanged applyConfig/settings/provider/model/render owners directly. Held provider stages claim strict finite clock/settings only; settled valid/mode stages retain actual six rows and independent controlled wall/monotonic clocks. Extra valid-boot preview yields do not change these literal clocks. No pending preview/first-scene pixels or elapsed-cost transfer is credited.",
            "originalCasesPreserved": 24,
            "newA12Cases": 0,
        },
        "A13": {
            "disposition": "FOUR_ORIGINAL_MAIN_F443_NATIVE_CASES_RETURNED_AWAITING_SEPARATE_INDEPENDENT_COST_DISPOSITION",
            "affectedOwner": "Main partsInTz constructs Intl.DateTimeFormat per call; e718 caches it. Pure projection equivalence alone did not bind model/render/input/rAF elapsed cost.",
            "basis": ["A13AffectedCaseScope", "rootA12AcceptanceAndFourCaseAdmission", "actualFourCaseReturn", "qualifiedCleanupReturn", "rootAcceptedCleanupAndRelease"],
            "actualCases": ["chromium/profiles--instrumented", "chromium/profiles--uninstrumented", "firefox/profiles--instrumented", "firefox/profiles--uninstrumented"],
            "cases": 4,
            "assertions": 102,
            "captures": 32,
            "originalDriverAssertionsDeadlineInputHeartbeatUnchanged": True,
            "nativeSourceBeforeEqualsAfter": True,
            "zeroRetries": True,
            "numericProductionDeadline": None,
            "elapsedCostConclusion": "Raw matched cold/reuse durations, actual trusted input and actual native rAF responses are recorded. Acceptance belongs to the separate independent performance reviewer; this worker adds none.",
            "original28_426_110Preserved": True,
        },
        "A14": {
            "disposition": "RETAIN_ACCEPTED_MATCHED_INVALID_RECOVERY_AND_DIRECT_ORIGINAL_F443_NORMAL_RENDERER_PROOF",
            "basis": ["originalQualification", "A14DirectF443SourceConsumerMap"],
            "directOriginalF443Scope": old_applicability["A14"]["proposal"],
            "noA12OrA13AcceptanceFromRendererDonor": True,
            "wallScalarAloneIsNot15SecondMotionProof": True,
            "newRendererCases": 0,
        },
        "A15": {
            "disposition": "SEVEN_SHARED_CLOCK_CLAUSES_ALREADY_DELIVERED_EXACT_ONCE_IN_CURRENT_MAIN",
            "basis": ["originalQualification", "mainSevenClausesReadback"],
            "mergedDocsAuthorityOwner": "root binds existing exact-head owner-approved PR46 and documentation-only PR47 successor; this proposal neither asserts a new owner approval nor requires a duplicate DESIGN merge.",
            "newDESIGNHunks": 0,
            "rawDESIGN": clauses["DESIGN"],
            "remainingPublicPagesDocumentConsumerReadback": "ROOT_DELIVERY_GATE",
        },
        "A16": {
            "disposition": "WHOLE16_SOURCE_EVIDENCE_DELIVERY_AND_CLOSURE_PROPOSAL_RETAINING_REQUIRED_FINAL_EXTERNAL_GATES",
            "basis": ["originalAll16Certificate", "originalQualificationRootJoin", "originalIndependentQualification", "mainSourceReadback", "oldPublicEvidenceReconciliation"],
            "pending": ["separate A13 independent cost disposition", "root whole transfer/publication review", "immutable public evidence and delivered document consumer readback", "reviewed proof comment readback", "root justified authorized manual closure and live closed-state readback"],
            "runtimeOrExistingDocumentationHunks": 0,
        },
    }
    rows = copy.deepcopy(original["rows"])
    cert_by_id = {row["id"]: row for row in original_cert["all16OriginalObligations"]}
    for row in rows:
        row["originalObligation"] = cert_by_id[row["obligationId"]]["obligation"]
        row["deliveryTarget"] = MAIN
        row["acceptedCandidateScopePreserved"] = row.pop("scope")
        row["currentDeliveryDisposition"] = (
            "RETAINED_ACCEPTED_ORIGINAL_SOURCE_SCOPE_WITH_EXACT_MAIN_F443_RUNTIME_EQUIVALENCE"
            if row["originalAcceptanceId"] is None else claims[
                "A08_A09" if row["originalAcceptanceId"] in ("A08", "A09") else row["originalAcceptanceId"]
            ]["disposition"]
        )
        row["noNewCanonicalNodeCredit"] = True
    rows_ref = write("ROW_DISPOSITIONS_FOR_REVIEW.json", {
        "schema": "r0008-whole-original-sixteen-current-main-delivery-dispositions/1",
        "base": MAIN,
        "rows": rows,
        "acceptanceIds": original["acceptanceIds"],
        "originalStatusesRewritten": False,
        "workerIssueClosureCredit": 0,
    })
    proposal = {
        "schema": "r0008-whole-delivery-closure-addendum-for-independent-review/1",
        "atUtc": datetime.now(timezone.utc).isoformat(),
        "worker": "/root/r0008_whole_closure",
        "consumer": "/root",
        "issue": 8,
        "status": "ALL_EXECUTABLE_SCOPE_RETURNED_WITH_A13_INDEPENDENT_COST_REVIEW_PENDING",
        "base": MAIN,
        "runtimeSha256": actual["runtimeSha256"],
        "runtimeFiles": 135,
        "indexSha256": actual["indexSha256"],
        "WHead": original_report["WHead"],
        "literalAuthority": original_report["literalAuthority"],
        "originalIssueBodySha256": original_report["originalIssueBodySha256"],
        "all16Rows": rows_ref,
        "requiredAcceptanceIds": original["acceptanceIds"],
        "references": refs,
        "affectedApplicabilityDecisions": claims,
        "independentReviewScopeRequested": "Only returned four-cell A13 source/input/result/cost/capture applicability. A12 scoped reuse already independently accepted by root; all unchanged rows, original WEATHER18/native28 and narrow A14 original f443 renderer controls remain preserved. No new whole-node credit or external effect requested from this reviewer.",
        "preservedLimits": original_report["preservedLimits"],
        "additionalLimits": [
            "New four cells use the same date-only optional astronomy503/fallback-font limits as original profiles. They qualify actual resolver/model/header/render/input/heartbeat observations, not complete sky or first-scene/native-parent pixels.",
            "Chromium148.0.7778.96 and Firefox150.0.2 on actual Windows AMD64,325x530/DPR1. Managed browser binaries, exact preparation, actual input clocks/provider, source and custody are bound by the native outputs.",
            "Elapsed host command and native frame samples are observations with instrumentation and host attribution limits; no production responsiveness deadline was invented.",
            "Mac owner deferral, PR43/S1/L1, actual parent and other original programme gates remain separate.",
        ],
        "effectAuthority": {"canonicalWriter": "root", "newPrivateFilesOnly": True, "workerCanonicalWrites": 0, "workerGitHubEffects": 0, "workerCommitPushPREffects": 0, "runtimeChanged": False, "DESIGNChangeProposed": False, "rootLeaseReleased": True, "independentAcceptanceGrantedByWorker": False},
        "deliveryRoute": "Create-only evidence publication from the already delivered documentation/runtime; reuse old exact three archive parts and supplement without duplication. Append one bounded new A12/A13 source/return/review archive and complete public closure bindings. Root integrates/publishes/reviews, binds existing approved document authority, performs public readbacks and manually closes only when original delivery gates hold.",
        "nodeCredit": 0,
        "issueClosureClaim": False,
    }
    proposal_ref = write("CLOSURE_ADDENDUM_FOR_REVIEW.json", proposal)
    seal = write("REVIEW_SCOPE_SEAL.json", {"schema": "r0008-private-whole-review-scope-seal/1", "files": [rows_ref, proposal_ref], "nodeCredit": 0, "acceptanceOwner": "independent reviewer then root"})
    print(json.dumps({"proposal": proposal_ref, "rows": rows_ref, "seal": seal}, indent=2))

if __name__ == "__main__":
    main()
