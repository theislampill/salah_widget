"""Bounded R0008 A12/A13 main applicability addendum; no native execution."""
from pathlib import Path
import copy
import difflib
import hashlib
import importlib.util
import json
import re
import subprocess
import sys
from datetime import datetime, timezone

sys.stdout.reconfigure(encoding='utf-8')
HERE = Path(__file__).resolve().parent
LANE = HERE.parent
RUN = LANE.parent.parent
W = Path(r'C:\Users\theis\.codex\worktrees\552b\salah_widget')
MAIN = '0e3a3ad6dc4f8e09ec8e246d12c70b8a996907df'
RUNTIME = 'f443cf0820e6879dfa7c3ce857d6b2baf554b1fdd2f889433d22e2c532cec260'
INDEX = 'ff728552442f4bcce7f213a089bf01d4cf70ea8d74040bdd3323768ca453beee'
PRIOR = RUN / 'workers/r0008_provider_zone_fixture_repair_r1'
CANDIDATE = HERE / 'candidate-main-runtime'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def load(path):
    return json.loads(Path(path).read_bytes())

def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}

def put(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)

def write(path, data):
    put(path, (json.dumps(data, indent=2, ensure_ascii=False) + '\n').encode('utf-8'))

def git(*args):
    result = subprocess.run(['git', *args], cwd=W, capture_output=True, check=True)
    return result.stdout

def exact_region(text, start, end):
    assert text.count(start) == 1 and text.count(end) == 1, (start, end)
    first, last = text.index(start), text.index(end)
    assert first < last
    body = text[first:last].encode('utf-8')
    return {'start': start, 'end': end, 'bytes': len(body), 'sha256': sha(body),
            'firstLine': text[:first].count('\n') + 1}, body

def main():
    assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
    assert git('rev-parse', MAIN).decode().strip() == MAIN
    assert not CANDIDATE.exists(), 'Create-only preparation; never replay or overwrite'
    ledger_path = RUN / 'ACTIVE_LEDGER.json'
    ledger = load(ledger_path)
    write(HERE / 'REANCHOR.json', {
        'schema': 'r0008-bounded-addendum-reanchor/1',
        'atUtc': datetime.now(timezone.utc).isoformat(),
        'parentFinding': 'Only A12 reached-consumer boot applicability and A13 outer-caller cost applicability.',
        'base': MAIN, 'worktreeHead': git('rev-parse', 'HEAD').decode().strip(),
        'worktreeDirtyStatus': git('status', '--short').decode('utf-8'),
        'actualLedger': pin(ledger_path), 'ledgerSpec': ledger['specSha'],
        'recordedBrowser': {k: ledger['resourceLeases']['heavy-browser'].get(k)
                            for k in ['status', 'holder', 'node', 'leaseId']},
        'browserAuthority': 'Parent queue handoff required regardless of recorded FREE.',
        'nodes': [{'id': n['id'], 'state': n.get('progress', {}).get('state')}
                  for n in ledger['nodes'] if n['id'].startswith('R0008-')],
        'sharedWrites': 0, 'nativeLaunches': 0, 'githubEffects': 0})

    original_map = RUN / 'workers/r0020_whole_closure_r1/EXACT_MAIN_RUNTIME.json'
    reference = load(original_map)
    assert reference['treeSha256'] == RUNTIME and len(reference['files']) == 135
    files = {}
    # Exact Git objects, never dirty W or a build/generator.
    for name, expected in sorted(reference['files'].items()):
        data = git('show', MAIN + ':' + name)
        assert len(data) == expected['bytes'] and sha(data) == expected['sha256'], name
        put(CANDIDATE / name, data)
        files[name] = {'bytes': len(data), 'sha256': sha(data)}
    canonical = ''.join(v['sha256'] + '  ' + n + '\n' for n, v in sorted(files.items()))
    assert sha(canonical.encode()) == RUNTIME
    inventory = {'treeSha256': RUNTIME, 'files': files, 'algorithm': reference['algorithm']}
    write(HERE / 'input/runtime-identity.json', inventory)

    old_binding = load(PRIOR / 'INPUT_BINDING.json')
    material = {}
    for name in old_binding['files']:
        data = git('show', MAIN + ':' + name)
        if not (CANDIDATE / name).exists():
            put(CANDIDATE / name, data)
        assert (CANDIDATE / name).read_bytes() == data
        material[name] = {'bytes': len(data), 'sha256': sha(data)}
    assert material['index.html']['sha256'] == INDEX
    write(HERE / 'INPUT_BINDING.json', {
        'schema': 'r0008-native-input-binding/1', 'candidate': str(CANDIDATE),
        'head': MAIN, 'candidateIndexSha256': INDEX, 'candidateRuntimeSha256': RUNTIME,
        'files': material, 'originalRuntimeMap': pin(original_map),
        'all135GitObjectsByteExact': True, 'sourceChanges': 0,
        'scope': 'Main date-only original profile cases; no full renderer/native acceptance granted.'})

    driver_sources = []
    for path in sorted((PRIOR / 'driver').iterdir()):
        assert path.is_file()
        data = path.read_bytes()
        if path.name != 'rlgwo-clock-date-fixture.cjs':
            put(HERE / 'driver' / path.name, data)
            driver_sources.append({'original': pin(path), 'private': pin(HERE / 'driver' / path.name),
                                   'byteExact': True})
    fixture = PRIOR / 'driver/rlgwo-clock-date-fixture.cjs'
    assert sha(fixture.read_bytes()) == '59ed45375131bdc5209473d09cac02eede611ffc547efcb613705c25aaace4ab'
    source = (CANDIDATE / 'index.html').read_text(encoding='utf-8')
    scripts = list(re.finditer(r'<script\b([^>]*)>([\s\S]*?)</script>', source))
    boot = [i for i, m in enumerate(scripts) if '\nboot();' in m[2]]
    assert len(boot) == 1
    profile = {'sourceSha256': INDEX, 'nativeOrdinal': boot[0],
               'scripts': [[m[1], sha(m[2].encode()), m[2].count('\nboot();')] for m in scripts]}
    text = fixture.read_text(encoding='utf-8')
    marker = 'const SCRIPT_LAYOUTS={\n'
    assert text.count(marker) == 1
    changed = text.replace(marker, marker + '  delivered_main_0e3:' + json.dumps(profile, separators=(',', ':')) + ',\n')
    marker2 = "const layoutId=sha(source)===SCRIPT_LAYOUTS.weather_info_01.sourceSha256?"
    assert changed.count(marker2) == 1
    changed = changed.replace(marker2, "const layoutId=sha(source)===SCRIPT_LAYOUTS.delivered_main_0e3.sourceSha256?'delivered_main_0e3':sha(source)===SCRIPT_LAYOUTS.weather_info_01.sourceSha256?")
    marker3 = "  if(admission.layoutId==='font_intermediate_01'"
    assert changed.count(marker3) == 1
    changed = changed.replace(marker3, "  if(admission.layoutId==='delivered_main_0e3'&&(suite!=='timezone'||name!=='profiles'))throw Error('Main layout admitted only for original R0008 profiles pairs');\n" + marker3)
    put(HERE / 'driver/rlgwo-clock-date-fixture.cjs', changed.encode('utf-8'))
    put(HERE / 'fixture-layout-only.patch', ''.join(difflib.unified_diff(text.splitlines(True), changed.splitlines(True),
         fromfile='original-qualified-fixture.cjs', tofile='private-main-profile-fixture.cjs')).encode('utf-8'))
    driver_sources.append({'original': pin(fixture), 'private': pin(HERE / 'driver/rlgwo-clock-date-fixture.cjs'),
                           'change': 'Add exact main script graph; retain strict roles/digests/boot count/whole entry, admit profiles only.'})
    write(HERE / 'SOURCE_ADAPTATION.json', {'sources': driver_sources, 'scriptLayout': profile,
        'allOriginalProfileActionsAndTimingObserversByteExact': True,
        'allOriginalAssertionAndCaptureContractsByteExact': True,
        'originalResultContract': pin(RUN / 'workers/r0008_passive_binding_repair_r1/result_contract.py')})

    # A12 transfer is not whole-entry equality: bind each reached original stage
    # to the guard/model/config/provider/mode consumer and its applicable delta boundary.
    e718 = (RUN / 'candidates/rlgwo-weather-info-01/src/native/index.html').read_text(encoding='utf-8')
    main_text = (CANDIDATE / 'src/native/index.html').read_text(encoding='utf-8')
    regions = []
    for start, end in [
        ('// Strict Gregorian coordinate,', 'function initSim(){'),
        ('function initSim(){', '// current wall-clock in the configured timezone'),
        ('async function loadPrayerData(){', '// Invalid explicit boot postpones'),
        ('let _sceneBuilt=false;', '// Diagnostic control of the EXISTING native clock'),
        ('function _enableSettingsAffordance(){', 'function _settingsFormToConfig(){'),
        ('async function boot(){', '  if(lat==null||lon==null){')]:
        a, ab = exact_region(main_text, start, end)
        b, bb = exact_region(e718, start, end)
        assert ab == bb, start
        regions.append({'main': a, 'e718': b, 'byteExact': True})
    # The scheduler body is exact independently of the changed pre-loop boot handoff.
    loop_main = main_text[main_text.index('function startRenderLoop(){'):]
    loop_e718 = e718[e718.index('function startRenderLoop(){'):]
    next_main = loop_main.index('\nfunction ', 1)
    next_e718 = loop_e718.index('\nfunction ', 1)
    assert loop_main[:next_main] == loop_e718[:next_e718]
    regions.append({'name': 'startRenderLoop', 'bytes': len(loop_main[:next_main].encode()),
                    'sha256': sha(loop_main[:next_main].encode()), 'byteExact': True})
    scenes = load(RUN / 'evidence/R0008/native/scenes.json')
    stage_rows = []
    for row in scenes['rows']:
        result = Path(row['result']['path'])
        assert pin(result) == row['result']
        data = load(result)
        assert data['source']['sourceSha256'] == '14e1d92101dad56f1352a2b4a85a460067361ecdfca62093f9f9d1286b991fad'
        stages = []
        for observed in data['states']:
            state = observed['state']
            trace = state['trace']
            assert trace[0]['event'] == 'pre-script-installed' and trace[1]['event'] == 'readonly-hooks-installed'
            events = []
            for index, event in enumerate(trace):
                if event.get('event') in ['epochForTzTime', 'buildStars', 'buildWeather', 'adoptPrayerBundle']:
                    events.append({'ordinal': index, **{k: event[k] for k in ['event', 'args', 'finite', 'requestedDay', 'payloadDay', 'value'] if k in event}})
            stages.append({'name': observed['name'], **{k: state.get(k) for k in ['valid', 'now', 'nowFinite', 'anchorFinite', 'day', 'zone', 'sceneBuilds', 'loopStarted', 'clockMode']},
                'wallAndMonotonic': state['clock'], 'rows': state['dom']['rows'],
                'buckleInteractive': state['dom']['buckleInteractive'], 'buckleRole': state['dom']['buckleRole'],
                'hiddenOutputs': len(state['hiddenEntries']), 'reachedTrace': events[:24]})
        stage_rows.append({'engine': row.get('engine'), 'case': data['case'], 'variant': data['variant'],
                           'result': row['result'], 'stages': stages})
    write(HERE / 'A12_REACHED_CONSUMER_APPLICABILITY.json', {
        'schema': 'r0008-a12-main-reached-consumer-applicability-proposal/1',
        'base': MAIN, 'runtimeSha256': RUNTIME, 'originalScenes': pin(RUN / 'evidence/R0008/native/scenes.json'),
        'exactReachedOwners': regions, 'originalStageReadbacks': stage_rows,
        'deltaDisposition': [
            {'delta': 'Unknown-location optional preview start', 'reason': 'All original scenes carry literal coordinates; branch unreached.'},
            {'delta': 'Weather starts immediately on main versus after e718 two-rAF/MessageChannel boundary',
             'reason': 'A12 scenes/recovery/modes use declared simWx=0, so actual fresh weather transport is ineligible. Retained weather/init path and literal clock are unchanged. A13 ordinary model/current/hourly cases will measure the main reached path separately.'},
            {'delta': 'Extra first-preview creation and two-rAF/MessageChannel task',
             'reason': 'Invalid boot returns at exact simulationReady guard before any changed block. Recovery config/apply and guarded provider adoption are exact; valid/modes assertions observe settled model with actual loopStarted, six rows and literal independently controlled wall/elapsed state. No first-scene time/order/preview pixels are inferred.'},
            {'delta': 'e718 pending !M paintCelestialWithoutTimetable call absent on main',
             'reason': 'Pending preview pixels are outside A12. Valid original captures reached admitted M and six rows; invalid captures use simulationReady withdrawal before that render branch; provider-held pre-adoption stage claims finite strict clock and settings, not a prayer-backed celestial frame.'},
            {'delta': 'partsInTz cached formatter on e718 versus native allocation on main',
             'reason': 'Pure projection equivalence supports finite/value assertions only. No A12 elapsed-cost claim. A13 requires four exact-main timing counterparts and independent cost review.'}],
        'mainA12NewNativeCasesProposed': [], 'independentRootAcceptance': 'PENDING',
        'preserveCanonicalAccepted28NativeCases426Assertions110Captures': True,
        'preserve18WeatherCases': True, 'preserveDirectF443A14': True,
        'claimLimits': 'Date-only original controlled providers, optional astronomy503 and fallback fonts; no startup presentation/whole-renderer/Mac/actual-parent/PR43S1/L1 credit.'})

    # No applicable original f443 profile pairs were acquired: bounded original donor inventory.
    donor_dir = W / 'docs/real-sky/evidence/startup-cloud-20261007/final-v49'
    donor_search = []
    for path in sorted(donor_dir.rglob('results.json')):
        donor = path.read_text(encoding='utf-8')
        donor_search.append({'file': pin(path), 'matchedProfileStage': donor.count('matched-warm-same-day'),
            'resolverBuildEvents': donor.count('zoneDay'), 'profileCostOutput': donor.count('profile-timing'),
            'trustedProfileKeyReturn': donor.count('trustedKeyCommandReturnMs')})
    assert donor_search and all(not any(x[k] for k in ['matchedProfileStage', 'resolverBuildEvents', 'profileCostOutput', 'trustedProfileKeyReturn']) for x in donor_search)
    write(HERE / 'A13_APPLICABILITY_GAP.json', {'schema': 'r0008-a13-main-cost-applicability-gap/1',
        'base': MAIN, 'runtimeSha256': RUNTIME, 'originalCostDisposition': pin(RUN / 'workers/r0008_native_actual_exit_review_r1/node-exit/PROFILE_COST_DISPOSITION.json'),
        'allFourAcceptedProfilePairsMeasured': 'e718fe9e58f37535de4dc496a2da3bf2b05808153287e1fe328398ea59c0df53',
        'originalDonorInspection': donor_search,
        'affectedOriginalCases': ['chromium:profiles--instrumented', 'chromium:profiles--uninstrumented', 'firefox:profiles--instrumented', 'firefox:profiles--uninstrumented'],
        'reason': 'Outer model/render partsInTz native formatter allocation differs. Exact inverse/profile bodies and pure225 projection values do not bind input/rAF elapsed cost.',
        'noFullCampaignInvalidation': True, 'numericProductionDeadline': None,
        'originalAssertionsAndAdverseControlsRetained': True, 'independentCostDisposition': 'PENDING_EXACT_MAIN_NATIVE_PAIRS'})

    old_plan = load(PRIOR / 'ROOT_COMMAND.json')
    tools = old_plan['toolIdentities']
    for name, identity in tools.items():
        assert pin(identity['path']) == identity, name
    cells = []
    commands = []
    for old in old_plan['cells']:
        if old['caseName'] != 'profiles':
            continue
        engine, variant = old['engine'], old['variant']
        output = HERE / 'native' / engine / ('profiles--' + variant)
        prepared = HERE / 'prepared' / engine / ('profiles--' + variant)
        command = [tools['python311']['path'], '-I', '-S', '-B', '-X', 'utf8',
                   str(HERE / 'driver/rlgwo_timezone_check.py'), '--root', str(CANDIDATE),
                   '--engine', engine, '--cases', 'profiles', '--variants', variant,
                   '--output', str(prepared), '--node', tools['node']['path'], '--expected-source-sha256', INDEX]
        completed = subprocess.run(command, capture_output=True, text=True, encoding='utf-8')
        put(HERE / 'logs' / (engine + '--' + variant + '.stdout'), completed.stdout.encode())
        put(HERE / 'logs' / (engine + '--' + variant + '.stderr'), completed.stderr.encode())
        assert completed.returncode == 0, completed.stderr
        input_path = prepared / ('profiles--' + variant) / 'input.json'
        prepared_identity = load(input_path)['identity']
        assert prepared_identity['sourceSha256'] == INDEX
        native_argv = [tools['nativePython']['path'], '-I', '-B', '-X', 'utf8',
                       str(HERE / 'driver/rlgwo_timezone_check.py'), '--root', str(CANDIDATE),
                       '--engine', engine, '--cases', 'profiles', '--variants', variant,
                       '--output', str(output), '--node', tools['node']['path'], '--expected-source-sha256', INDEX,
                       '--execute', '--lease-id', '<ROOT_QUEUE_HANDOFF_LEASE_ID>']
        cell = {k: copy.deepcopy(old[k]) for k in ['engine', 'caseName', 'variant', 'caseId', 'cellKey', 'counterfactual', 'originalRecipeKey', 'expectedNativeStatus', 'expectedNativeProcessExit', 'captureBasenames']}
        cell.update({'output': str(output), 'preparedIdentity': prepared_identity,
                     'preparedInput': pin(input_path), 'nativeArgvTemplate': native_argv})
        cells.append(cell)
        commands.append({'argv': command, 'exitCode': completed.returncode, 'preparedInput': pin(input_path)})
    assert len(cells) == 4
    write(HERE / 'FOUR_ORIGINAL_PROFILE_CELLS.json', {'schema': 'r0008-exact-main-four-original-profile-cells/1',
        'base': MAIN, 'runtimeSha256': RUNTIME, 'indexSha256': INDEX, 'candidate': str(CANDIDATE),
        'originalPlan': pin(PRIOR / 'ROOT_COMMAND.json'), 'tools': tools, 'cells': cells,
        'sdkImported': False, 'nativeExecuted': False, 'connectedPreparationCommands': commands,
        'rootBrowserQueueHandoff': 'REQUIRED', 'originalResultConsumer': pin(RUN / 'workers/r0008_passive_binding_repair_r1/result_contract.py')})
    print(json.dumps({'status': 'FOUR_ORIGINAL_PROFILE_CELLS_PREPARED_NOT_EXECUTED', 'base': MAIN,
        'runtimeSha256': RUNTIME, 'cells': [c['cellKey'] for c in cells], 'a12Addendum': str(HERE / 'A12_REACHED_CONSUMER_APPLICABILITY.json')}))

if __name__ == '__main__':
    main()
