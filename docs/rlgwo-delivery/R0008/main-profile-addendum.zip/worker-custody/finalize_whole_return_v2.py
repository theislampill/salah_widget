"""One create-only offline delivery assembly; no source, ledger, Git or browser effect."""
import copy
import hashlib
import json
import platform
import zipfile
from datetime import datetime, timezone
from pathlib import Path

RUN = Path(r"C:\Users\theis\Documents\Codex\salah-rlgwo-execution-20261009")
LANE = RUN / "workers/r0008_whole_closure_r1"
ADD = LANE / "addendum-r2"
OUT = ADD / "final-return-r3"
REVIEW = RUN / "workers/r0008_main_profile_actual_review_r1"
ROOT_REVIEW = RUN / "integration/r0008-whole-delivery-review-20261012-r1"
DEST = OUT / "postimages/docs/rlgwo-delivery/R0008"
MAIN = "ba6d15d6f305451a7eccbbd30e2a47138c9a22b3"
ARCHIVE = "main-profile-addendum.zip"
NOW = datetime.now(timezone.utc).isoformat()

def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))

def sha(data):
    return hashlib.sha256(data).hexdigest()

def pin(path, expected=None):
    path = Path(path)
    data = path.read_bytes()
    ref = {"path": str(path), "bytes": len(data), "sha256": sha(data)}
    if expected is not None:
        assert ref["sha256"] == expected, (str(path), ref)
    return ref

def verify_ref(ref):
    actual = pin(ref["path"])
    assert actual["bytes"] == ref["bytes"] and actual["sha256"] == ref["sha256"], (ref, actual)

def write_json(path, value):
    data = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    with Path(path).open("xb") as stream:
        stream.write(data)
    return pin(path)

def write_text(path, value):
    with Path(path).open("xb") as stream:
        stream.write(value.encode("utf-8"))
    return pin(path)

def win_key(path):
    return str(path).replace("/", "\\").casefold()

def make_zip(path, files):
    with zipfile.ZipFile(path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for item in files:
            data = Path(item["source"]).read_bytes()
            assert len(data) == item["bytes"] and sha(data) == item["sha256"]
            entry = zipfile.ZipInfo(item["name"], date_time=(1980, 1, 1, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.create_system = 3
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)

def main():
    # Verify received acceptance and its actual producer/consumer binding before any assembly.
    report_ref = pin(REVIEW / "REPORT.json", "7bd8c689413c19dc2e4c9c9dd4074474f739fbab6fa3f0f0c66ab770fc7547b4")
    manifest_ref = pin(REVIEW / "MANIFEST.json", "39ce480abab6c6f0a1f7695d2ce2eec017ec2e220e7c991a628c246f04b525a7")
    seal_ref = pin(REVIEW / "SEAL.json", "6176bac920a550dd181eb18bbd547d2bf78782e6be5475a812164e4ba3172ff1")
    review = read(report_ref["path"])
    review_manifest = read(manifest_ref["path"])
    review_seal = read(seal_ref["path"])
    actual = read(ADD / "ACTUAL_FOUR_CASES_RETURN.json")
    proposal = read(OUT / "CLOSURE_ADDENDUM_FOR_REVIEW.json")
    rows = read(OUT / "ROW_DISPOSITIONS_FOR_REVIEW.json")
    assert review_seal["report"] == report_ref and review_seal["manifest"] == manifest_ref
    assert review["status"] == "PASS" and review["blockingFindings"] == []
    assert review["verdict"] == "PASS_R0008_A13_MAIN_PROFILE_BATCH_WITH_LIMITS"
    assert review["runtimeSha256"] == actual["runtimeSha256"] == proposal["runtimeSha256"]
    assert review["indexSha256"] == actual["indexSha256"] == proposal["indexSha256"]
    assert review["actualCaseCount"] == actual["actualCaseCount"] == 4
    assert review["originalAssertions"] == actual["assertions"] == 102
    assert review["captureCount"] == actual["captureCount"] == 32
    assert review["independentCostDisposition"]["status"] == "PASS"
    assert review["independentCostDisposition"]["numericProductionDeadline"] is None
    assert review["independentCostDisposition"]["ownerCostEscalationRequired"] is False
    assert review["nodeCredit"] == 0 and review["issueClosed"] is False
    assert review["closureAddendumRead"]["addendum"] == pin(OUT / "CLOSURE_ADDENDUM_FOR_REVIEW.json")
    assert review["closureAddendumRead"]["rowDispositions"] == pin(OUT / "ROW_DISPOSITIONS_FOR_REVIEW.json")
    assert review["closureAddendumRead"]["original16StatusesMatchRetainedCertificate"] is True
    for ref in review_manifest["files"]:
        verify_ref(ref)
    checks = read(REVIEW / "CHECKS.json")
    assert checks["status"] == "PASS" and checks["verifiedArtifactCount"] == 130
    assert checks["originalAssertions"] == 102 and checks["captures"] == 32
    assert len(checks["originalConsumerAdverseControls"]) == 5
    for item in checks["originalConsumerAdverseControls"]:
        assert item["outcome"] == "REFUSED"

    selection = copy.deepcopy(read(ADD / "ADDITIVE_PUBLICATION_SELECTION_FINAL_INPUTS.json")["files"])
    assert len(selection) == 114
    original_manifest = read(LANE / "PUBLICATION_MANIFEST.json")
    original_reconciliation = read(LANE / "PUBLICATION_RECONCILIATION_FINAL.json")
    old_pkg = read(LANE / "EVIDENCE_PACKAGE_FINAL.json")
    old_supplement_ref = read(LANE / "DELIVERY_SUPPLEMENT_IDENTITY.json")
    old_supplement = LANE / "postimages-final/docs/rlgwo-delivery/R0008/delivery-supplement.zip"
    verify_ref(old_supplement_ref)
    old_locations = {}
    for ref in original_manifest["acceptedReferences"]:
        if ref.get("publicationDisposition") == "EXACT_RETAINED_BYTES" and ref.get("publicationPath") and "bytes" in ref:
            old_locations[(ref["bytes"], ref["sha256"])] = {"archive": "accepted-evidence.zip", "member": ref["publicationPath"]}
    with zipfile.ZipFile(old_supplement) as archive:
        assert archive.testzip() is None
        assert len(archive.infolist()) == old_supplement_ref["payloadFiles"] == 26
        for entry in archive.infolist():
            data = archive.read(entry)
            old_locations[(len(data), sha(data))] = {"archive": "delivery-supplement.zip", "member": entry.filename}
    assert original_reconciliation["requiredFileReferenceGaps"] == []
    part_hasher = hashlib.sha256()
    for part in sorted(old_pkg["parts"], key=lambda row: row["ordinal"]):
        verify_ref(part)
        part_hasher.update(Path(part["path"]).read_bytes())
    assert part_hasher.hexdigest() == old_pkg["archiveSha256"]

    def add(source, name):
        source = Path(source)
        assert not name.startswith("/") and ".." not in Path(name).parts and "\\" not in name
        identity = pin(source)
        existing = next((f for f in selection if f["name"] == name), None)
        if existing:
            assert existing["bytes"] == identity["bytes"] and existing["sha256"] == identity["sha256"]
            return
        selection.append({"source": str(source), "name": name, "bytes": identity["bytes"], "sha256": identity["sha256"]})

    for ref in review_manifest["files"] + [manifest_ref, seal_ref]:
        add(ref["path"], "independent-main-A13/" + Path(ref["path"]).name)
    add(ROOT_REVIEW / "FOUR_CASE_RELEASE.json", "root/FOUR_CASE_RELEASE.json")
    for name in ["ADDENDUM_READY.json", "ADDENDUM_READY_SEAL.json", "PR46_SHARED_CLAUSES_READBACK.json", "A12_REACHED_CONSUMER_APPLICABILITY.json"]:
        add(ADD / name, name)
    for name in ["CLOSURE_ADDENDUM_FOR_REVIEW.json", "ROW_DISPOSITIONS_FOR_REVIEW.json", "REVIEW_SCOPE_SEAL.json"]:
        add(OUT / name, "whole-scope-for-review/" + name)
    add(ADD / "prepare_closure_for_review.py", "worker-custody/prepare_closure_for_review.py")
    add(Path(__file__), "worker-custody/" + Path(__file__).name)
    add(ADD / "finalize_whole_return.py", "worker-custody/finalize_whole_return_failed_r1.py")
    add(ADD / "PUBLICATION_READER_CORRECTION_R1.json", "worker-custody/PUBLICATION_READER_CORRECTION_R1.json")

    environment_refs = []
    # Bound exact received references; only explicit native environment executables are pin-only.
    for ref in checks["verifiedArtifacts"]:
        verify_ref(ref)
        digest = (ref["bytes"], ref["sha256"])
        known = next((f for f in selection if (f["bytes"], f["sha256"]) == digest), None)
        if known or digest in old_locations:
            continue
        path = Path(ref["path"])
        if path.suffix.casefold() == ".exe":
            environment_refs.append(copy.deepcopy(ref))
        elif path.is_relative_to(ADD):
            add(path, path.relative_to(ADD).as_posix())
        elif path.is_relative_to(RUN / "workers/r0020_whole_closure_r1") and path.name == "EXACT_MAIN_RUNTIME.json":
            add(path, "shared-runtime/EXACT_MAIN_RUNTIME.json")
        elif "site-packages" in path.parts:
            relative = path.parts[path.parts.index("site-packages") + 1:]
            add(path, "native-environment-metadata/" + "/".join(relative))
        else:
            raise AssertionError(("Unresolved actually required review reference", ref))

    # Verify every admitted carrier-manifest payload without publishing another runtime/campaign copy.
    carrier_manifest = read(ADD / "carrier-ready/MANIFEST.json")
    carrier_refs = carrier_manifest["files"]
    assert len(carrier_refs) == 36
    for ref in carrier_refs:
        verify_ref(ref)
        digest = (ref["bytes"], ref["sha256"])
        if any((f["bytes"], f["sha256"]) == digest for f in selection) or digest in old_locations:
            continue
        path = Path(ref["path"])
        assert path.is_relative_to(ADD), ref
        add(path, path.relative_to(ADD).as_posix())

    selection.sort(key=lambda row: row["name"])
    assert len({f["name"] for f in selection}) == len(selection)
    selected_by_path = {win_key(f["source"]): f for f in selection}
    selected_by_digest = {}
    for item in selection:
        selected_by_digest.setdefault((item["bytes"], item["sha256"]), item)
    aliases = []
    env_by_path = {win_key(ref["path"]): ref for ref in environment_refs}
    for ref in checks["verifiedArtifacts"] + carrier_refs:
        digest = (ref["bytes"], ref["sha256"])
        item = selected_by_path.get(win_key(ref["path"])) or selected_by_digest.get(digest)
        if item:
            location = {"archive": ARCHIVE, "member": item["name"], "resolution": "EXACT_DIGEST_AND_LENGTH_ALIAS"}
        elif digest in old_locations:
            location = dict(old_locations[digest], resolution="RETAINED_EXISTING_EXACT_PAYLOAD")
        else:
            assert win_key(ref["path"]) in env_by_path
            location = {"resolution": "NATIVE_ENVIRONMENT_EXECUTABLE_IDENTITY_ONLY", "notARequiredEvidencePayload": True}
        aliases.append(dict(ref, **location))
    DEST.mkdir(parents=True, exist_ok=False)
    alias_ref = write_json(DEST / "ADDITIVE_REFERENCE_READBACK.json", {
        "schema": "r0008-four-case-public-reference-aliases/1", "references": aliases,
        "independentReviewedArtifactPins": 130, "admittedCarrierManifestPins": 36,
        "requiredEvidenceReferenceGaps": [], "nativeEnvironmentExecutableIdentities": environment_refs,
        "environmentRule": "Observed managed executables are exact acquisition environment identities, not evidence payloads or newly vendored dependencies. Installed versions/actual native platform and wrapper policy remain bound by the original results and reviewer. No binary is copied into the repository.",
        "oldCoreReconstructionVerified": {"bytes": old_pkg["archiveBytes"], "sha256": part_hasher.hexdigest()},
        "oldSupplementCrcMembersVerified": 26,
    })
    add(alias_ref["path"], "ADDITIVE_REFERENCE_READBACK.json")
    selection.sort(key=lambda row: row["name"])
    package_selection_ref = write_json(OUT / "ADDITIVE_PUBLICATION_SELECTION_FINAL.json", {"schema": "r0008-final-small-additive-evidence-selection/1", "files": selection})
    archive_path = DEST / ARCHIVE
    make_zip(archive_path, selection)
    archive_ref = pin(archive_path)
    assert archive_ref["bytes"] < 50 * 1024 * 1024
    crc_checks = []
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None
        assert archive.namelist() == [item["name"] for item in selection]
        for item in selection:
            data = archive.read(item["name"])
            assert len(data) == item["bytes"] and sha(data) == item["sha256"]
            crc_checks.append({"member": item["name"], "bytes": len(data), "sha256": sha(data)})
    additive_manifest_ref = write_json(DEST / "ADDITIVE_PUBLICATION_MANIFEST.json", {
        "schema": "r0008-main-profile-additive-publication-manifest/1",
        "archive": {"filename": ARCHIVE, "bytes": archive_ref["bytes"], "sha256": archive_ref["sha256"]},
        "files": selection, "payloadFiles": len(selection),
        "uncompressedPayloadBytes": sum(item["bytes"] for item in selection),
        "zipCrcAndPayloadSha256Verified": True, "referenceAliasMap": alias_ref,
        "originalArchiveDuplication": False, "canonicalWrites": 0, "publicHead": None,
    })
    acceptance_ref = write_json(DEST / "MAIN_A13_INDEPENDENT_ACCEPTANCE.json", {
        "schema": "r0008-main-profile-independent-acceptance-binding/1", "scope": review["acceptedScope"],
        "verdict": review["verdict"], "report": report_ref, "seal": seal_ref, "manifest": manifest_ref,
        "consumedClosureAddendum": review["closureAddendumRead"]["addendum"],
        "consumedRows": review["closureAddendumRead"]["rowDispositions"],
        "a13Disposition": review["a13Disposition"], "independentCostDisposition": review["independentCostDisposition"],
        "limits": review["limits"], "originalRawResultsAndPendingLabelsUnchanged": True,
        "separatelyIndependentReviewer": review["reviewer"], "whole16ApprovalByThisReviewer": False,
        "rootWholeTransferAndPublicClosureDecision": "PENDING", "nodeCredit": 0, "issueClosed": False,
    })
    effective_rows = copy.deepcopy(rows)
    effective_rows["schema"] = "r0008-current-main-whole16-effective-delivery-dispositions/1"
    effective_rows["unchangedRowsReadByIndependentReviewer"] = pin(OUT / "ROW_DISPOSITIONS_FOR_REVIEW.json")
    effective_rows["separateIndependentAcceptanceBinding"] = acceptance_ref
    for row in effective_rows["rows"]:
        row["effectiveApplicabilityDisposition"] = (
            review["a13Disposition"] if row["originalAcceptanceId"] == "A13" else row["currentDeliveryDisposition"]
        )
        row["rootFinalPublicDeliveryAndClosureDisposition"] = "PENDING_ROOT_ACCEPTING_EFFECTS_AND_READBACK"
    effective_rows_ref = write_json(DEST / "ROW_DISPOSITIONS_FINAL.json", effective_rows)
    applicability = copy.deepcopy(proposal["affectedApplicabilityDecisions"])
    applicability["A13"]["disposition"] = review["a13Disposition"]
    applicability["A13"]["independentCostDisposition"] = review["independentCostDisposition"]
    applicability["A13"]["independentAcceptance"] = acceptance_ref
    applicability["A13"]["elapsedCostConclusion"] = review["independentCostDisposition"]["basis"]
    applicability["A16"]["pending"] = review["remainingOriginalWholeRlgwoGates"]
    main_app_ref = write_json(DEST / "MAIN_APPLICABILITY_FINAL.json", {
        "schema": "r0008-current-main-source-input-environment-applicability/1",
        "base": MAIN, "runtimeSha256": actual["runtimeSha256"], "indexSha256": actual["indexSha256"],
        "runtimeFiles": 135, "sourceReadbacks": proposal["references"], "acceptanceDecisions": applicability,
        "original16StatusIdentityUnchanged": True,
        "preservedNative28_426_110": True, "preservedWeather18_114_44": True,
        "newNativeCases": 4, "wholeE718RuntimeEquivalence": False, "runtimeChange": False,
        "DESIGNHunks": 0, "rootWholeTransferDecision": "PENDING", "nodeCredit": 0,
    })
    whole_cert_ref = write_json(DEST / "WHOLE_CLOSURE_CERTIFICATE_PROPOSAL.json", {
        "schema": "r0008-whole-original16-final-delivery-closure-proposal/1", "atUtc": NOW,
        "issue": 8, "base": MAIN, "status": "COMPLETE_EXECUTABLE_WHOLE_SCOPE_RETURNED_PENDING_ROOT_DELIVERY_AND_MANUAL_CLOSURE",
        "literalAuthority": proposal["literalAuthority"], "originalIssueBodySha256": proposal["originalIssueBodySha256"],
        "all16OriginalRows": effective_rows_ref, "requiredAcceptanceIds": proposal["requiredAcceptanceIds"],
        "originalAcceptedQualification": proposal["references"]["originalQualification"],
        "originalIndependentQualification": proposal["references"]["originalIndependentQualification"],
        "originalRootQualificationJoin": proposal["references"]["originalQualificationRootJoin"],
        "originalAll16Certificate": proposal["references"]["originalAll16Certificate"],
        "sourceApplicability": main_app_ref, "separateMainA13IndependentAcceptance": acceptance_ref,
        "rootA12Acceptance": proposal["references"]["rootA12AcceptanceAndFourCaseAdmission"],
        "runtime": {"sha256": actual["runtimeSha256"], "indexSha256": actual["indexSha256"], "files": 135, "unchanged": True},
        "allSevenSharedClockClausesDeliveredExactOnce": proposal["references"]["mainSevenClausesReadback"],
        "newSourceRuntimeExistingDocsTestHunks": [],
        "sourceMeasuredBeforeEqualsAfter": True, "rootAcceptedCleanupAndReleasedLease": proposal["references"]["rootAcceptedCleanupAndRelease"],
        "evidence": {"existingCore": old_pkg, "existingSupplement": old_supplement_ref,
            "newAdditiveArchive": archive_ref, "newAdditiveManifest": additive_manifest_ref,
            "requiredReferenceGaps": [], "independentReviewedPins": 130, "admittedCarrierPins": 36},
        "finalRootGateInputs": review["remainingOriginalWholeRlgwoGates"],
        "authority": {"ordinaryEvidenceBranchAndDraftPRPublication": "Already owner-authorized root effect",
            "alreadyMergedSharedDocs": "Root binds existing exact-head owner-approved PR46 authority and documentation-only successors",
            "newProductionMainMergeOrDeployIfChosen": "Requires exact reviewed-head owner approval; no new merge is necessary for runtime or shared DESIGN clauses in this evidence-only proposal",
            "fullyQualifiedManualIssueClosure": "Already owner-authorized root effect after actual public delivery/proof-comment readback and primary reconciliation"},
        "preservedOriginalLimits": proposal["preservedLimits"], "newIndependentLimits": review["limits"],
        "oldPendingLabelsAndOriginalFailuresUnchanged": True,
        "independentAcceptanceGrantedByThisWorker": False, "canonicalWrites": 0, "GitHubEffects": 0,
        "nodeCredit": 0, "issueClosed": False, "publicProofComplete": False,
    })
    combined_pkg = copy.deepcopy(old_pkg)
    combined_pkg["supplement"] = old_supplement_ref
    combined_pkg["additivePackage"] = {"filename": ARCHIVE, "bytes": archive_ref["bytes"], "sha256": archive_ref["sha256"], "payloadFiles": len(selection), "manifest": additive_manifest_ref}
    combined_pkg["currentMainRuntimeAndDocs"] = {"base": MAIN, "runtimeSha256": actual["runtimeSha256"], "sevenSharedClauses": proposal["references"]["mainSevenClausesReadback"]}
    combined_pkg["originalPayloadManifest"] = pin(LANE / "postimages-final/docs/rlgwo-delivery/R0008/PUBLICATION_MANIFEST.json")
    combined_pkg["originalPublicationReconciliation"] = pin(LANE / "postimages-final/docs/rlgwo-delivery/R0008/PUBLICATION_RECONCILIATION_FINAL.json")
    combined_pkg["finalApplicability"] = main_app_ref
    combined_pkg["wholeClosureProposal"] = whole_cert_ref
    combined_pkg["publicSourceHead"] = "PENDING_ROOT_PUBLICATION_HEAD"
    combined_pkg["actualPublicReadbackPerformedByWorker"] = False
    package_ref = write_json(DEST / "EVIDENCE_PACKAGE.json", combined_pkg)
    write_text(DEST / "README.md", f"""# R0008 qualification and delivery proof

The original sixteen mandatory rows, their original dispositions, accepted qualification review and root JOIN remain preserved. The seven shared clock clauses are already delivered exactly once in DESIGN at current main `{MAIN}` through approved PR46 and its documentation-only successor. This publication adds evidence and closure bindings; it contains no runtime, DESIGN or frozen V1 edit.

A12 reuses the independently accepted original 24 date-only scene/recovery/mode cases. Its reached-consumer predicate binds the literal pre-script coordinates, simWx0, invalid boot withdrawal, actual applyConfig/provider recovery and settled model/render/clock consumers. It grants no pending-preview pixels or elapsed-cost equivalence.

A13 additionally acquired the four original instrumented/uninstrumented profile cases in Windows Chromium148.0.7778.96 and Firefox150.0.2,325×530/DPR1, on delivered f443. The separate independent review accepted all102 original assertions and32 captures, actual trusted-input/native-rAF observations, count/cache/eviction and matched cost evidence. The raw statuses remain PARTIAL_NATIVE_SCOPE. Uninstrumented cold resolver builds measured10.1–13.2ms in Chromium and9–12ms in Firefox; reuse measured0–0.1ms. Warm heartbeat waits were6.2/5ms, versus cold80.7–131.5/85–103ms. These finite cold-transition delays and observer/ordering/transport costs remain explicit; no production deadline or sole resolver attribution is claimed.

The accepted WEATHER18/114/44 and native28/426/110 campaigns remain unchanged. A14 retains its matched invalid/recovery proof and directly applicable original f443 normal opaque-calendar-Moon, visible-motion and narrow reduced/full/offscreen controls. Date-only503/fallback-font images grant none of those whole-sky properties. Mac, actual parent, PR43/S1/L1 and other programme gates remain separate.

`EVIDENCE_PACKAGE.json` binds the original130167912-byte accepted ZIP. Concatenate `accepted-evidence.zip.part01`, `part02`, `part03` in ordinal order; retain their exact bytes. `PUBLICATION_MANIFEST.json` names its924 payload files. `delivery-supplement.zip` retains26 exact donor/currentness/alias payloads. `{ARCHIVE}` supplies {len(selection)} additional source, input, result, capture, custody and independent-review payloads. `ADDITIVE_PUBLICATION_MANIFEST.json` and `ADDITIVE_REFERENCE_READBACK.json` bind every new required member/alias without copying the old archives or managed executable binaries.

Read `MAIN_APPLICABILITY_FINAL.json`, `ROW_DISPOSITIONS_FINAL.json` and `WHOLE_CLOSURE_CERTIFICATE_PROPOSAL.json` with the retained original qualification/root JOIN. Separate independent acceptance resolves the fixed pending A13 preparation labels; no raw record or original row status was rewritten.

Root still performs the whole transfer/publication review, immutable public evidence and delivered-document consumer readbacks, reviewed proof-comment readback and justified authorized manual issue closure. This private/publication proposal itself awards no node or closure credit.
""")
    # Reuse exact original postimages by reference, not another archive copy.
    old_files = read(LANE / "FILES_TO_INTEGRATE.json")["files"]
    omit = {"DESIGN.md", "docs/rlgwo-delivery/R0008/MAIN_APPLICABILITY_PROPOSAL.json", "docs/rlgwo-delivery/R0008/EVIDENCE_PACKAGE.json", "docs/rlgwo-delivery/R0008/README.md"}
    integrate = []
    for item in old_files:
        if item["targetPath"] in omit:
            continue
        verify_ref(item)
        integrate.append(copy.deepcopy(item))
    for path in sorted(DEST.iterdir()):
        assert path.is_file()
        item = pin(path)
        item["targetPath"] = "docs/rlgwo-delivery/R0008/" + path.name
        item["operation"] = "CREATE_ONLY"
        integrate.append(item)
    assert len({item["targetPath"] for item in integrate}) == len(integrate)
    assert all(item["operation"] == "CREATE_ONLY" for item in integrate)
    assert not any(item["targetPath"] == "DESIGN.md" for item in integrate)
    integrate_ref = write_json(OUT / "FILES_TO_INTEGRATE.json", {
        "schema": "r0008-final-evidence-only-whole-delivery-postimages/1", "base": MAIN,
        "files": integrate, "expectedExistingTrackedChanges": [],
        "sourceRuntimeTestsGeneratedV1Hunks": [], "DESIGNHunks": [],
        "oldArchivesCopiedAgainByWorker": False, "requiredArchiveReconstructionSha256": old_pkg["archiveSha256"],
        "sameByteAlreadyPublishedFileMayBeReusedByRootAfterIdentityReadback": True,
        "receivingHeadCurrentnessGuard": "Root re-reads actual base,135 runtime identities, seven exact shared clauses and create-only target absence/identity before accepting any file or external effect. Documentation-only successors may be accepted only by their observed exact regional comparison.",
        "stagingAllowedByWorker": False, "integrationOwner": "root",
    })
    write_text(OUT / "PR_TITLE.txt", "Publish R0008 timezone qualification and delivery evidence\n")
    write_text(OUT / "PR_BODY.md", """R0008 lacked delivered proof for its original timezone, captured-weather, recovery and responsiveness contract. The seven clock clauses are already present in the approved shared documentation; this evidence-only proposal publishes the retained all16-row qualification and source-bound current-main applicability.

It preserves WEATHER18/114/44 and native28/426/110 and adds only the four affected original main/f443 profile cases. A separate reviewer accepted102 original assertions,32 captures, cache/count behavior, trusted input and native rAF responses, with cold-transition delay and attribution limits retained. A12 scoped boot/recovery reuse is independently accepted; A14 uses the original f443 renderer controls at their recorded scope.

Validation: exact source before/after, original qualified result consumer and five refusal controls, all32 images independently inspected, root-qualified cleanup/release, seven shared clauses read back exactly once, deterministic additive ZIP CRC/member SHA checks and unchanged original archive reconstruction. Date-only optional503/fallback-font, Mac/actual-parent/PR43/S1/L1 and original failures remain explicit.

Implements #8. Public evidence/document readback, a reviewed proof-comment readback and justified authorized manual closure remain root delivery steps. This PR does not automatically close the issue or authorize a new production merge/deployment.
""")
    write_text(OUT / "ROOT_NEXT_ACTIONS.md", """Consume the sealed full evidence-only return, original all16 qualification/root JOIN, root A12 admission and separate A13 review. Apply only FILES_TO_INTEGRATE.json in the isolated receiving checkout; reuse the exact original archive parts and supplement. DESIGN is already delivered and must not be overwritten.

Publish the authorized evidence branch/DraftPR and bind root review to its exact immutable head. The existing owner-approved PR46/shared-clock delivery can supply documentation authority after root verifies its exact provenance/current clauses. No new runtime or DESIGN merge is necessary for this proposal. A new production main merge/deploy, if chosen, still needs exact reviewed-head owner approval.

Read back immutable public evidence files, reconstructed original ZIP identity, new ZIP CRC/member SHA/aliases, current f443/index/config/source and seven exact delivered clauses. Consume the already acquired independent shared-clock public document proof when its original observation scope contains these clauses; do not repeat an unchanged acquisition. Record actual execution/R0008/delivery.json through root's existing interface.

Resolve the primary all16 delivery decision, post the completed bound proof comment once and read it back, then perform the already authorized manual completed closure of #8 and read back final state/reason. Any required false or unknown delivery predicate retains its original gate. Preserve all original adverse/failing evidence and separate Mac/actual-parent/PR43/S1/L1 gates.
""")
    write_text(OUT / "CLOSURE_COMMENT.template.md", """<!-- salah-r0008-qualified-delivery:REPLACE_WITH_IMMUTABLE_REVIEWED_EVIDENCE_HEAD -->

R0008's original16 mandatory rows are reconciled by the preserved source-bound qualification, separate independent review and root JOIN, followed by the final current-main applicability and actual delivery readbacks.

The seven exact clock clauses were delivered through approved PR46 and remain present at REPLACE_WITH_DELIVERED_MAIN. Runtime remains original f443. A12 reached boot/recovery reuse was separately accepted; the four original A13 main profiles were independently accepted with102 assertions/32 captures and observed cold-transition overhead retained. WEATHER18/native28 and narrowly reused original f443 A14 controls retain their recorded scopes and limits.

Delivered DESIGN: REPLACE_WITH_IMMUTABLE_DESIGN_URL
Evidence index/all16 certificate: REPLACE_WITH_IMMUTABLE_EVIDENCE_INDEX_URL
Actual root delivery receipt: REPLACE_WITH_IMMUTABLE_DELIVERY_RECEIPT_URL
Separate A13 review: REPLACE_WITH_IMMUTABLE_A13_REVIEW_URL

The immutable public evidence, source/runtime and delivered-document hashes and consumers were read back; primary reconciliation accepts this issue's full contract. Original status/failure/negative records are unchanged. Date-only503/fallback-font, Mac, actual parent, PR43/S1/L1 and broader scientific/renderer limits remain separate.

This completed proof comment is posted and read back before the justified authorized manual completed closure; it is not an automatic-closing keyword.
""")
    write_json(OUT / "DELIVERY_RECEIPT.template.json", {
        "schema": "r0008-reviewed-documentation-delivery/1", "interface": "r0008-delivery/v1", "issue": 8,
        "base": MAIN, "reviewedHead": None, "evidencePublicationHead": None,
        "ownerExactHeadApproval": None, "alreadyDeliveredDocsAuthority": {"owner": "root", "approvedSharedClockPR": 46, "actualAuthorityReceipt": None},
        "newProductionMergeRequired": False, "mergedCommit": MAIN, "tree": None,
        "source": {"runtimeSha256": actual["runtimeSha256"], "runtimeChanged": False, "runtimeFiles": 135, "indexSha256": actual["indexSha256"]},
        "docs": [{"path": "DESIGN.md", "expectedSha256": read(ADD / "CURRENT_MAIN_SEVEN_CLAUSES.json")["DESIGN"]["sha256"], "actualMergedSha256": None, "publicRawURL": None, "actualPublicRawSha256": None, "sevenSharedClauses": None, "actualDeliveredDocumentConsumer": None}],
        "evidencePackage": package_ref, "regionalApplicabilityReview": None, "mainA13IndependentAcceptance": acceptance_ref,
        "publicEvidenceReadbacks": None, "publicRuntimeReadback": None, "frozenV1Readback": None,
        "status": "PENDING_ROOT_WHOLE_REVIEW_PUBLIC_READBACK_PRIMARY_RECONCILIATION",
        "issueClosed": False, "closureCommentReadback": None,
    })
    verification_ref = write_json(OUT / "VERIFICATION.json", {
        "schema": "r0008-final-whole-return-offline-verification/1", "atUtc": NOW,
        "python": platform.python_version(), "reviewProducerSealManifestAllExact": True,
        "independentReviewStatus": review["verdict"], "fourOriginalConsumerCasesAssertionsCaptures": [4, 102, 32],
        "fiveActualOriginalConsumerRefusalsPreserved": checks["originalConsumerAdverseControls"],
        "newArchive": archive_ref, "newPayloadFiles": len(selection), "allNewPayloadShaAndZipCrcVerified": True,
        "allNewPayloadChecks": crc_checks, "all130ReviewAnd36AdmissionPinsResolved": True,
        "requiredEvidenceReferenceGaps": [], "old130167912ArchivePartsAndReconstructionExact": True,
        "old26SupplementPayloadsCrcShaVerified": True, "all16OriginalStatusIdentitiesPreserved": True,
        "noExistingDESIGNPostimageOrRuntimeHunk": True,
        "integrationFilesAllCreateOnlyExact": True, "integrationFileCount": len(integrate),
        "artifactProducerConsumerControl": {"positive": "All declared archive bytes/length/SHA and member set matched actual ZIP readback", "wrongDigestNegative": "Observed first member SHA differs from 64-zero digest", "missingMemberNegative": "Dropping one actual member differs from exact declared member set"},
        "controlScope": "Offline artifact association only; existing native/source/refusal controls are preserved, not rerun",
        "publicAndIssueEffectsNotPerformed": True,
    })
    assert crc_checks[0]["sha256"] != "0" * 64
    assert set(row["member"] for row in crc_checks[:-1]) != set(row["name"] for row in selection)
    final_report = {
        "schema": "r0008-complete-executable-whole-issue-final-return/1", "atUtc": NOW,
        "worker": "/root/r0008_whole_closure", "consumer": "/root", "issue": 8,
        "status": "COMPLETE_EXECUTABLE_WHOLE_DELIVERY_RETURN_PENDING_ROOT_ACCEPTING_EXTERNAL_EFFECTS",
        "base": MAIN, "WHead": proposal["WHead"], "runtimeSha256": actual["runtimeSha256"],
        "indexSha256": actual["indexSha256"], "literalAuthority": proposal["literalAuthority"],
        "wholeClosureCertificateProposal": whole_cert_ref, "all16OriginalDispositions": effective_rows_ref,
        "mainApplicability": main_app_ref, "separateIndependentA13Acceptance": acceptance_ref,
        "A12RootAccepted": proposal["references"]["rootA12AcceptanceAndFourCaseAdmission"],
        "rootQualifiedLeaseRelease": proposal["references"]["rootAcceptedCleanupAndRelease"],
        "filesToIntegrateOnly": integrate_ref, "evidencePackage": package_ref,
        "originalAcceptedEvidenceReused": {"nativeCases": 28, "nativeAssertions": 426, "nativeCaptures": 110, "weatherCases": 18, "weatherPredicates": 114, "weatherCaptures": 44, "newCredit": 0},
        "affectedOriginalActualNativeReturn": {"cases": 4, "assertions": 102, "captures": 32, "independentCostDisposition": review["independentCostDisposition"]["disposition"], "numericProductionDeadline": None},
        "sourceDocsTestsGeneratedV1Hunks": [], "sevenSharedClausesAlreadyDelivered": proposal["references"]["mainSevenClausesReadback"],
        "verification": verification_ref, "unresolvedExecutableNativeBlocker": None,
        "remainingRequiredRootOperations": review["remainingOriginalWholeRlgwoGates"],
        "independentRemainingReview": "Root independent whole source/input/environment transfer and serialized evidence/publication/delivery/closure review; separate A13 reviewer accepted only the four affected original cells, not the whole16 or external effects.",
        "paidCreditsUsed": False, "workerCanonicalWrites": 0, "workerGitHubCommitPushPREffects": 0,
        "workerIndependentAcceptanceAwarded": False, "nodeCredit": 0, "issueClosed": False,
        "nextRootOperation": "Review this exact whole return and perform accepting evidence-only delivery from FILES_TO_INTEGRATE.json; no new native replay or duplicate DESIGN merge follows from this return.",
    }
    final_report_ref = write_json(OUT / "REPORT.json", final_report)
    # Flat immutable seal covers every new top-level return and fresh postimage. Old exact files stay referenced.
    manifest_files = []
    for path in sorted(OUT.rglob("*")):
        if path.is_file() and path.name not in ("MANIFEST.json", "SEAL.json"):
            manifest_files.append(pin(path))
    final_manifest_ref = write_json(OUT / "MANIFEST.json", {"schema": "r0008-final-whole-return-manifest/1", "files": manifest_files, "referencesOldFilesWithoutCopying": integrate_ref})
    final_seal_ref = write_json(OUT / "SEAL.json", {"schema": "r0008-final-whole-return-seal/1", "report": final_report_ref, "manifest": final_manifest_ref, "wholeCertificate": whole_cert_ref, "filesToIntegrate": integrate_ref, "independentReview": report_ref, "status": final_report["status"], "nodeCredit": 0, "issueClosed": False})
    print(json.dumps({"report": final_report_ref, "manifest": final_manifest_ref, "seal": final_seal_ref, "wholeCertificate": whole_cert_ref, "filesToIntegrate": integrate_ref, "archive": archive_ref, "integrationFileCount": len(integrate), "additivePayloadFiles": len(selection)}, indent=2))

if __name__ == "__main__":
    main()
