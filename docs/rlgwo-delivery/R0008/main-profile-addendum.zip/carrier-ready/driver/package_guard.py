"""Fail before native launch when any selected source/input/runtime binding drifts."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def guard_selected(root, expected):
    binding = json.loads((HERE/'INPUT_BINDING.json').read_text(encoding='utf-8'))
    root = Path(root).resolve()
    if root != Path(binding['candidate']).resolve() or expected != binding['candidateIndexSha256']:
        raise RuntimeError('Selected root/entry differs from sealed e718 candidate')
    for name, identity in binding['files'].items():
        path = root/name
        if not path.resolve().is_relative_to(root) or sha(path) != identity['sha256']:
            raise RuntimeError('Selected material preimage drift: '+name)
    inventory = json.loads((HERE/'input/runtime-identity.json').read_text(encoding='utf-8'))
    canonical = ''
    for name, identity in sorted(inventory['files'].items()):
        path = root/name
        if not path.resolve().is_relative_to(root) or path.stat().st_size != identity['bytes'] or sha(path) != identity['sha256']:
            raise RuntimeError('Selected runtime preimage drift: '+name)
        canonical += identity['sha256']+'  '+name+'\n'
    if hashlib.sha256(canonical.encode('utf-8')).hexdigest() != binding['candidateRuntimeSha256']:
        raise RuntimeError('Selected canonical runtime differs from sealed e718')
    return binding
