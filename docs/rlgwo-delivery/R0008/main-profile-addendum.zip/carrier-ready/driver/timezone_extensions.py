"""Assigned native actions atop the retained driver. Not executed during prep."""
import json
import time

HIDDEN = ['.sky', '#wxfx', '.climate', '.arc', '.bar', '.cn', '.times', '.d']

def valid_checks(state):
    card = state['geometry']['.c']
    return [(state['valid'] and state['nowFinite'] and state['anchorFinite'] if not state['clockMode']['followWall'] else state['valid'] and state['nowFinite'], 'Native valid scene has finite time'),
        (state['dom']['rows'] == 6, 'Actual valid scene renders six prayer rows'),
        (card['width'] == 325 and card['height'] == 530, 'Inner native card is exactly 325 by 530'),
        (not state['hiddenEntries'], 'No withdrawn elements remain after valid recovery')]

def invalid_checks(state):
    present = [state['geometry'][selector] for selector in HIDDEN if state['geometry'][selector] is not None]
    return [(not state['valid'] and not state['nowFinite'] and not state['anchorFinite'], 'Gap/fold has no finite time or old numeric anchor'),
        (state['dom']['next'] == '—', 'Invalid actual next prayer is an em dash'),
        (state['dom']['countdown'] == 'Simulation time unavailable', 'Actual unavailable message remains visible'),
        (state['dom']['sim'] == 'SIM unavailable', 'Actual explicit scene reports SIM unavailable'),
        (bool(present) and all(g['visibility'] == 'hidden' for g in present), 'Every present clock-dependent output is hidden'),
        (len(state['hiddenEntries']) == len(present), 'Native withdrawal remembers each actual output visibility')]

def native_owned_case(page, name, variant, metadata, out, retained):
    capture, wait, check = retained['capture'], retained['wait_ready'], retained['check']
    states, checks = [], []
    def require(rows):
        for condition, label in rows:
            checks.append(check(condition, label))
    def settings(stage):
        before = page.evaluate(retained['READ'])
        checks.append(check(before['dom']['buckleInteractive'] and before['dom']['buckleRole'] == 'button', 'Settings buckle remains reachable during '+stage))
        page.locator('.buckle').focus()
        page.keyboard.press('Enter')
        page.wait_for_function("document.querySelector('.c').classList.contains('settings-open')")
        opened = capture(page, out, stage+'-settings-open', states)
        checks.append(check(opened['geometry']['#settings']['visibility'] == 'visible', 'Actual settings overlay is visible during '+stage))
        page.locator('#setClose').click()
        page.wait_for_function("!document.querySelector('.c').classList.contains('settings-open')")
        closed = capture(page, out, stage+'-settings-closed', states)
        checks.append(check(closed['generation'] == before['generation'], 'Unedited settings open/close does not create a location generation'))
        return closed
    def apply_zone(zone):
        cfg = page.evaluate('__rlgwo.read().config')
        cfg['tz'] = zone
        # Declared provider input changes before the actual config loader starts.
        page.evaluate('(zone)=>Object.values(__rlgwo.fixture.records).forEach(r=>r.meta.timezone=zone)', zone)
        page.evaluate('(cfg)=>{window.__timezoneNativeApply=__rlgwo.apply(cfg)}', cfg)
    def restored(prior, current):
        for selector in HIDDEN:
            if prior['geometry'].get(selector) and current['geometry'].get(selector):
                checks.append(check(current['geometry'][selector]['inlineVisibility'] == prior['geometry'][selector]['inlineVisibility'], 'Native prior inline visibility restored for '+selector))
    if name == 'profiles':
        return profiles_case(page, variant, out, retained)
    if name == 'scenes' and variant == 'gap-bypass-mutant':
        wait(page, True)
        mutant = capture(page, out, 'invalid-consumer-mutant-reached', states)
        rows = invalid_checks(mutant)
        failures = [label for condition, label in rows if not condition]
        checks.append(check(not mutant['valid'] and mutant['sceneBuilds']['stars'] == 1 and mutant['sceneBuilds']['weather'] == 1, 'Disposable bypass reaches actual scene builders while strict native time is invalid'))
        checks.append(check(bool(failures) and not mutant['hiddenEntries'], 'Same healthy invalid-scene oracle rejects reached withdrawal bypass'))
        retained['write'](out/'mutant-discriminator.json', {'sourceMutation':metadata['identity']['sourceMutation'], 'healthyOracleRejected':failures, 'scope':'Disposable counterfactual source; not the original product runtime.'})
        return states, checks, 'MUTANT_DETECTED', ['Separate original-source gap/fold controls and independent crop review required.']
    if name == 'recovery' and variant == 'provider-zone':
        prayer = retained['wait_pending'](page, 'prayer', '08-03-2026')
        before = capture(page, out, 'valid-UTC-held-provider', states)
        checks.append(check(before['valid'] and before['now'] == 1772937000000, 'Native UTC 02:30 is valid before provider adoption'))
        settings('before-provider-invalidation')
        changed = json.loads(json.dumps(metadata['plan']['records']['08-03-2026']))
        changed['meta']['timezone'] = 'America/New_York'
        retained['release'](page, prayer, changed)
        wait(page, True)
        withdrawn = capture(page, out, 'provider-zone-gap-withdrawal', states)
        require(invalid_checks(withdrawn))
        checks.append(check(withdrawn['zone'] == 'America/New_York', 'Guarded provider metadata reaches native NY zone before downstream use'))
        settings('provider-invalid')
        page.evaluate("(key)=>__rlgwo.policy(key,'release')", metadata['plan']['hold'][0])
        apply_zone('UTC')
        wait(page)
        retained['settle_prayers'](page)
        recovered = capture(page, out, 'provider-actual-UTC-recovery', states)
        require(valid_checks(recovered))
        restored(before, recovered)
        checks.append(check(recovered['sceneBuilds'] == before['sceneBuilds'] == {'stars':1,'weather':1}, 'Successful native builders remain single across provider invalidation/recovery'))
    elif name == 'recovery' and variant == 'valid-to-gap':
        wait(page)
        before = capture(page, out, 'valid-UTC-initial', states)
        require(valid_checks(before))
        settings('valid-initial')
        apply_zone('America/New_York')
        wait(page, True)
        invalid = capture(page, out, 'actual-config-UTC-to-NY-gap', states)
        require(invalid_checks(invalid))
        settings('invalid-after-valid')
        apply_zone('UTC')
        wait(page)
        recovered = capture(page, out, 'actual-config-recovered-UTC', states)
        require(valid_checks(recovered))
        restored(before, recovered)
        checks.append(check(recovered['sceneBuilds'] == before['sceneBuilds'] == {'stars':1,'weather':1}, 'Actual initially valid builders remain single after valid-invalid-valid config'))
    elif name == 'recovery':
        wait(page, True)
        initial = capture(page, out, 'original-gap-invalid-boot', states)
        require(invalid_checks(initial))
        checks.append(check(initial['sceneBuilds'] == {'stars':0,'weather':0} and not initial['loopStarted'], 'Original invalid boot postpones scene builders and clock loop'))
        settings('invalid-boot')
        apply_zone('UTC')
        wait(page)
        valid = capture(page, out, 'actual-first-UTC-recovery', states)
        require(valid_checks(valid))
        settings('recovered')
        apply_zone('America/New_York')
        wait(page, True)
        again = capture(page, out, 'actual-NY-invalid-again', states)
        require(invalid_checks(again))
        apply_zone('UTC')
        wait(page)
        recovered = capture(page, out, 'actual-second-UTC-recovery', states)
        require(valid_checks(recovered))
        restored(valid, recovered)
        checks.append(check(recovered['sceneBuilds'] == valid['sceneBuilds'] == {'stars':1,'weather':1}, 'Native first recovery initializes builders exactly once across repeated recovery'))
    elif name == 'scenes':
        invalid = variant in {'gap','fold-invalid'}
        wait(page, invalid)
        initial = capture(page, out, 'original-native-scene', states)
        if invalid:
            require(invalid_checks(initial))
            checks.append(check(initial['sceneBuilds'] == {'stars':0,'weather':0}, 'Invalid original boot cannot build a downstream clock scene'))
        else:
            require(valid_checks(initial))
            wanted = 1793521800000 if variant == 'fold-valid' else 1772955000000
            checks.append(check(initial['now'] == wanted, 'Native valid inverse equals literal '+('2026-11-01T08:30:00Z' if variant == 'fold-valid' else '2026-03-08T07:30:00Z')))
        checks.append(check(not initial['dom']['buckleInteractive'], 'Unchanged explicit embed keeps its existing non-settings buckle behavior'))
    elif name == 'modes':
        wait(page)
        initial = capture(page, out, 'original-mode-anchor', states)
        require(valid_checks(initial))
        rate = 0 if variant == 'default' else 60 if variant == 'scale60' else 1
        anchor = initial['now']
        page.evaluate('__rlgwo.setMono(1000)')
        for offset in [3600000,-3600000]:
            page.evaluate('(wall)=>__rlgwo.setWall(wall)', initial['clock']['wall']+offset)
            page.evaluate('__rlgwo.waitFrames(4)')
            current = capture(page, out, 'independent-wall-'+str(offset), states)
            wanted = current['clock']['wall'] if variant == 'ordinary' else anchor+1000*rate
            checks.append(check(current['now'] == wanted, 'Actual '+variant+' clock equals independent wall/elapsed literal at '+str(offset)))
            checks.append(check(current['clockMode']['followWall'] == (variant == 'ordinary') and current['clockMode']['advancing'] == (variant != 'ordinary' and rate > 0), 'Actual ordinary/SIM/ADVANCING ownership remains correct'))
            checks.append(check(current['weather']['src'] == initial['weather']['src'] == 'sim', 'Declared synthetic weather provenance survives clock-only probe'))
    else:
        raise RuntimeError('Outside owned native action partition: '+name)
    return states, checks, 'PARTIAL_NATIVE_SCOPE', ['Controlled wall/elapsed clocks and complete declared prayer inputs; actual config/boot/provider/model/native scheduler. Date-only optional astronomy/fonts are explicit 503. Independent crops and full affected regression remain pending.']

def profiles_case(page, variant, out, retained):
    capture, check = retained['capture'], retained['check']
    states, checks, measurements = [], [], []
    retained['wait_ready'](page)
    retained['settle_prayers'](page)
    first = capture(page, out, 'first-day-actual-callers', states)
    actual = [x for x in first['trace'] if x['event'] == 'zoneDay']
    checks.append(check(any(x['args'][3] == 'America/New_York' and not x['hit'] for x in actual), 'Actual model/current/hourly callers build the native NY day profile'))
    checks.append(check(any(x['hit'] for x in actual), 'Actual same-day callers reuse native profile'))
    if variant == 'instrumented':
        checks.append(check(any(x['supported'] and not x['hit'] and x['projections'] == 4321 for x in actual), 'Counted native strict resolver scans exactly 4321 UTC minutes'))
    def transition(stage, wall, day):
        start = time.perf_counter()
        previous = page.evaluate("__rlgwo.trace.filter(x=>x.event==='actual-render').length")
        page.evaluate('([stage,wall])=>{__rlgwo.profileStage=stage;__rlgwo.scheduleHeartbeat(stage);__rlgwo.setWall(wall)}', [stage,wall])
        key_start = time.perf_counter()
        page.keyboard.press('Tab')
        key_return = time.perf_counter()
        page.wait_for_function("([count,day])=>__rlgwo.trace.filter(x=>x.event==='actual-render').length>count && __rlgwo.read().day===day", arg=[previous,day])
        retained['settle_prayers'](page)
        page.evaluate('__rlgwo.waitFrames(3)')
        state = capture(page, out, stage, states)
        measurements.append({'stage':stage,'wall':wall,'driverActionMs':(time.perf_counter()-start)*1000,
            'trustedKeyCommandReturnMs':(key_return-key_start)*1000,
            'inputEvents':[x for x in state['inputEvents'] if x.get('profileStage') == stage],
            'heartbeats':[x for x in state['heartbeat'] if x['stage'] == stage],
            'scope':'Actual trusted input and native callback observed around this transition; ordering is in raw native timestamps. Host-command duration includes driver/transport overhead; no inferred production threshold.'})
        checks.append(check(len(state['profileKeys']) <= 4, 'Four-profile bound at '+stage))
        checks.append(check(any(x['event'] == 'keydown' and x['trusted'] and x.get('profileStage') == stage for x in state['inputEvents']), 'Actual trusted input reaches native document at '+stage))
        checks.append(check(any(x['stage'] == stage for x in state['heartbeat']), 'Actual native rAF heartbeat returns at '+stage))
        return state
    transition('matched-warm-same-day', '2026-03-08T12:00:01Z', '08-03-2026')
    for day in ['09','10','11','12']:
        fifth = transition('native-distinct-day-'+day, '2026-03-'+day+'T12:00:00Z', day+'-03-2026')
    key = '["America/New_York",2026,3,8]'
    checks.append(check(key not in fifth['profileKeys'], 'Five distinct actual days evict the first day'))
    revisit = transition('native-evicted-first-day-revisit', '2026-03-08T12:00:02Z', '08-03-2026')
    builds = [x for x in revisit['trace'] if x['event'] == 'zoneDay' and not x['hit'] and x['supported']]
    checks.append(check(len([x for x in builds if x['args'][:3] == [2026,3,8]]) >= 2, 'Actual caller revisit rebuilds evicted first profile'))
    if variant == 'instrumented':
        checks.append(check(all(x['projections'] == 4321 for x in builds), 'Each supported native build retains exhaustive 4321 scan'))
        successful = [x for x in revisit['trace'] if x['event'] == 'epochForTzTime' and x['finite']]
        checks.append(check(bool(successful) and all(x['roundTripProjections'] == 1 for x in successful), 'Each successful native lookup adds exactly one round-trip projection'))
    # Separate direct diagnostic uses actual native Intl failure, not a synthetic offset table.
    unsupported = 'Invalid/RLGWO_Native_Control'
    prior = page.evaluate('__rlgwo.trace.length')
    page.evaluate('(zone)=>{__rlgwo.profileProbe(2026,3,8,3,30,zone);__rlgwo.profileProbe(2026,3,8,3,30,zone)}', unsupported)
    diagnostic = capture(page, out, 'native-unsupported-profile-control', states)
    unsupported_events = [x for x in diagnostic['trace'][prior:] if x['event'] == 'zoneDay']
    checks.append(check(len(unsupported_events) == 2 and not unsupported_events[0]['hit'] and unsupported_events[1]['hit'] and all(not x['supported'] for x in unsupported_events), 'Actual native unsupported profile is cached and reused'))
    checks.append(check(len(diagnostic['profileKeys']) <= 4 and any(not x['supported'] and unsupported in x['key'] for x in diagnostic['profileEntries']), 'Unsupported native profile participates in four-entry cache bound'))
    timings = {'schema':'r0008-native-profiles-cost/1','variant':variant,
        'coldMs':[x['durationMs'] for x in builds],
        'reuseMs':[x['durationMs'] for x in diagnostic['trace'] if x['event'] == 'zoneDay' and x['hit']],
        'matchedInputAndHeartbeat':measurements,'independentResponsivenessDisposition':'PENDING',
        'scope':'Native Intl forwarded unchanged. Only instrumented variant counts strict Gregorian/Latin/h23 formatToParts; uninstrumented counterpart excludes that wrapper. Observer/driver overhead retained. No numeric production deadline. Synthetic second/>24h profiles retain source-only admitted credit.'}
    retained['write'](out/'profile-timing.json', timings)
    return states, checks, 'PARTIAL_NATIVE_SCOPE', ['Both engine pairs and independent cost/input/heartbeat attribution remain required; no production deadline or native PASS follows from recorded return. Direct unsupported-zone diagnostic is distinct from model/weather caller credit.']
