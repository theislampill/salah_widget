"""ROOT ONLY: inert by default; exact R0020 QUALIFY JOIN after actual final review."""
import argparse
import ast
import collections
import copy
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import sys

RUN = Path('C:/Users/theis/Documents/Codex/salah-rlgwo-execution-20261009')
HERE = Path(__file__).resolve().parent
GRAPH = Path('C:/Users/theis/Documents/Codex/celestial-startup-repair-20261008/planning-original-21e7a843/docs/rlgwo-execution/20261008/CLOSURE_DAG.json')
GRAPH_SHA = '9ac372cfcce4df94ee0e678b907e66c131fe49f72cc55106143aa35dbdb0a6e7'
DAY_HELPER = RUN / 'integration/join_r0020_day_exit_r1.py'
DAY_HELPER_SHA = '535b09b064799d0b1d63177e348c9669bb97442a4bb44b504daeef83ce81f5b1'
ASSEMBLED = RUN / 'workers/r0020_qualify_final_join_r1/assembled-actual-r1'
ASSEMBLED_SEAL_SHA = '16f16716c0f5ed203fd574a40b979fe347a0ad49842f3accd92102ccbbd54f45'
ASSEMBLED_REPORT_SHA = '09beefd940a8fdbfd606bc1d3844ec49c9c5eb69802d79e7f1855bb6fa8efe02'
FREEZE = RUN / 'workers/r0020_qualify_exit_preparation_r1/FINAL_SOURCE_FREEZE.json'
FREEZE_SHA = '1aa43fa3b25a84be56d7a6b6e3677f0809c3dcf9a7093dd7b92369a933658b52'
JOIN = RUN / 'integration/r0020-qualify-final-join-r1'
NODE = 'R0020-QUALIFY'
REVIEWER = '/root/diagnostic_qualification_exit'
CRITERIA = [
    'Every mapped residual has actual source/config/input/environment-bound required outputs and independent disposition.',
    'Preserve healthy/mutant/failing receipts; do not infer defect or pass from missing evidence.',
    'Independently reviewed pre-delivery candidate certificate with all retained/new rows and exact final source/docs/input hashes; list downstream delivery/comment/closure gates PENDING. Qualification can finish before merge/public delivery and does not close the issue.',
]
ROWS = ['R0020-O%02d' % i for i in range(1, 17)]
OUTPUTS = [
    ('R0020-QUALIFY-OUTPUT-1', 'evidence/R0020/native/boundary-modes.json', 7107602,
     'e1ca8aab6be37d5889e56b77258688020da78533c2fca0e15c3a03e94d2086f3'),
    ('R0020-QUALIFY-OUTPUT-2', 'evidence/R0020/regression/reuse-and-crops.json', 344648,
     '8eec735ad68e5ffc8bb80592498e53292372d5ed3a256994e6e8d7fad5db11fd'),
    ('R0020-QUALIFY-OUTPUT-3', 'evidence/R0020/closure-certificate.json', 158585,
     '84918a6216e15d1b09b5664e0bf297ea8d8c8cd11ba37b1c7535c594ac959a45'),
]
DOWNSTREAM = {name: 'PENDING' for name in ('R0020-DELIVERY-RECEIPT', 'merge',
    'publicDocumentationEvidenceDelivery', 'proofCommentAndReadback', 'manualIssueClosure')}


def require(ok, reason):
    if not ok:
        raise ValueError(reason)


def safe_helpers():
    """Copy only inspected pure/custody functions; execute no DAY/WALL main or globals."""
    raw = DAY_HELPER.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == DAY_HELPER_SHA, 'DAY safe-helper source drift')
    tree = ast.parse(raw)
    wanted = {'sha', 'read', 'enc', 'save', 'pin', 'sealed'}
    selected = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in wanted]
    require({n.name for n in selected} == wanted, 'safe-helper inventory changed')
    namespace = {'hashlib': hashlib, 'json': json, 'Path': Path}
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(DAY_HELPER), 'exec'), namespace)
    return namespace


def exact_ref(h, ref):
    require(h['pin'](Path(ref['path'])) == {k: ref[k] for k in ('path', 'bytes', 'sha256')},
            'exact reference drift: ' + ref['path'])


def validate_decision(d, proposals, h):
    require(d.get('status') == 'PASS_R0020_QUALIFY_PRE_DELIVERY_CANDIDATE' and
            d.get('reviewer') == REVIEWER and d.get('ownNodeExitSatisfied') is True,
            'actual independent own-exit approval missing')
    row_records = d.get('rowDispositions', [])
    require([r.get('obligationId', r.get('id')) for r in row_records] == ROWS and
            all(r.get('id') in (expected, expected.removeprefix('R0020-'))
                for r, expected in zip(row_records, ROWS)) and
            all(r.get('candidateDisposition') == 'ACCEPTED' for r in d['rowDispositions']),
            'actual16-row candidate review missing')
    exits = d.get('ownExitDispositions', [])
    require([x.get('literal') for x in exits] == CRITERIA and
            all(x.get('disposition') == 'SATISFIED' and x.get('supportingArtifactRefs') for x in exits),
            'literal three DAG exit criteria not independently satisfied')
    require(d.get('downstream') == DOWNSTREAM, 'downstream PENDING boundaries changed')
    require(d.get('assembledSeal', {}).get('sha256') == ASSEMBLED_SEAL_SHA and
            d.get('assembledReport', {}).get('sha256') == ASSEMBLED_REPORT_SHA and
            d.get('sourceFreeze', {}).get('sha256') == FREEZE_SHA, 'wrong source/assembled identities')
    for key in ('assembledSeal', 'assembledReport', 'sourceFreeze'):
        exact_ref(h, d[key])
    output = d.get('outputDispositions', [])
    require(len(output) == 3, 'exact three approved canonical outputs required')
    for a, proposal, (ident, relative, size, digest) in zip(output, proposals, OUTPUTS):
        expected = {'path': str((ASSEMBLED / 'proposed' / relative).resolve()),
                    'bytes': size, 'sha256': digest}
        require(a.get('id') == ident and a.get('canonicalRelativePath') == relative and
                {k: a.get('proposal', {}).get(k) for k in ('path', 'bytes', 'sha256')} == expected and
                a.get('currentCanonicalPreimage') is None and
                a.get('postimage') == {'bytes': size, 'sha256': digest} and
                a.get('disposition') == 'APPROVED_PRE_DELIVERY_CANDIDATE_OUTPUT',
                'wrong/rejected output disposition: ' + ident)
        require({k: proposal[k] for k in ('path', 'bytes', 'sha256')} == expected,
                'assembled output/report mismatch')
        if 'canonicalTarget' in a:
            require(Path(a['canonicalTarget']).resolve() == (RUN / relative).resolve(),
                    'wrong canonical target')
    require(isinstance(d.get('atUtc'), str), 'actual review timestamp missing')


def validate_state(l, index, graph):
    require(l.get('graphSha256') == GRAPH_SHA and len(graph['nodes']) == 213 and
            len(graph['edges']) == 409 and len(l['nodes']) == 213, 'immutable213/409 graph mismatch')
    defs = {n['id']: n for n in graph['nodes']}
    nodes = {n['id']: n for n in l['nodes']}
    require(len(defs) == 213 and len(nodes) == 213 and set(defs) == set(nodes), 'wrong graph/ledger node identity')
    require(defs[NODE]['exitCriteria'] == CRITERIA and
            [(x['id'], x['artifact']) for x in defs[NODE]['outputs']] ==
            [(x[0], x[1]) for x in OUTPUTS], 'literal DAG criteria/output identity changed')
    lease = l['resourceLeases']['heavy-browser']
    require(lease['capacity'] == 1 and lease['status'] == 'FREE' and lease['holder'] is None and
            not lease.get('unknownChildCompletion') and not lease.get('attentionRequired'),
            'heavy-browser lease not known FREE')
    node = nodes[NODE]
    require(node['progress']['state'] == 'EXECUTING' and
            node['progress']['exitCriteriaVerified'] is False and
            not node['progress']['unmetPredecessors'], 'wrong/non-ready QUALIFY state')
    require({x['id'] for x in node['inputs']} == {x['id'] for x in defs[NODE]['inputs']} and
            all(x.get('status') == 'SATISFIED' for x in node['inputs']), 'named QUALIFY input missing')
    incoming = {e['from'] for e in graph['edges'] if e['to'] == NODE}
    require(all(nodes[k]['progress']['state'] == 'COMPLETE' for k in incoming), 'actual predecessor incomplete')
    bundles = l['executionGovernance']['closureBoundAutoLoom']['activeBundles']
    require(sum(b['node'] == NODE for b in bundles) == 1 and len(bundles) <= 2,
            'active CBAL bundle identity/capacity mismatch')
    complete = sum(n['progress']['state'] == 'COMPLETE' for n in l['nodes'])
    require(index['currentExecutionProjection']['completeNodes'] == complete and
            index['currentExecutionProjection']['totalNodes'] == 213, 'index/ledger count drift')
    return defs, nodes, complete


def criterion_evidence(d, review_report_path):
    return [{'criterion': x['literal'], 'disposition': 'SATISFIED',
             'evidence': [review_report_path] + [r['path'] for r in x['supportingArtifactRefs']]}
            for x in d['ownExitDispositions']]


def project(l, index, graph, d, canonical, receipt_ref, now, review_report_path):
    """Pure projection, also exercised on explicitly synthetic disposable fixtures."""
    l = copy.deepcopy(l)
    index = copy.deepcopy(index)
    defs, nodes, before_count = validate_state(l, index, graph)
    n = nodes[NODE]
    criteria = criterion_evidence(d, review_report_path)
    n.update(executionStatus='COMPLETE_EXIT_VERIFIED', lastUpdatedAtUtc=now,
             independentReviewer=REVIEWER,
             nextAction='Exact pre-delivery candidate qualified; actual R0020 delivery/comment/readback and authorized closure remain PENDING.')
    n['outputReceipts'] += [x['path'] for x in canonical] + [receipt_ref['path']]
    n['progress']['evidence'] += [x['path'] for x in canonical] + [receipt_ref['path']]
    n['progress'].update(state='COMPLETE', exitCriteriaVerified=True, completedAtUtc=now,
        runtime='12d2b12fc7751ad2f5356cf7ed5f6e96635c18aee9de86a69c488c6e4ea2fec2',
        reason='All three literal QUALIFY exits and16 candidate rows independently accepted; exact three outputs joined. Downstream delivery/closure remains separate.',
        exitCriteriaDisposition=criteria, owners=['root', REVIEWER])
    successors = sorted({e['to'] for e in graph['edges'] if e['from'] == NODE})
    successor_projection = []
    for ident in successors:
        successor = nodes[ident]
        for inp in successor['inputs']:
            for output in canonical:
                if inp.get('id') == output['id']:
                    inp.update(status='SATISFIED', evidence=[output['path'], receipt_ref['path']],
                               stage='PRE_DELIVERY_CANDIDATE', delivered=False)
        unmet = sorted({e['from'] for e in graph['edges'] if e['to'] == ident and
                        nodes[e['from']]['progress']['state'] != 'COMPLETE'})
        successor['progress']['unmetPredecessors'] = unmet
        input_gaps = [x['id'] for x in successor['inputs'] if x.get('status') != 'SATISFIED']
        if not unmet and not input_gaps and successor['progress']['state'] in ('NOT_STARTED', 'BLOCKED'):
            successor['progress']['state'] = 'READY'
            successor['executionStatus'] = 'READY_FOR_SEPARATE_ADMISSION'
        successor_projection.append({'node': ident, 'unmetPredecessors': unmet,
                                     'namedInputGaps': input_gaps, 'state': successor['progress']['state']})
    complete = sum(x['progress']['state'] == 'COMPLETE' for x in l['nodes'])
    require(complete == before_count + 1, 'completion delta must be exactly1')
    cb = l['executionGovernance']['closureBoundAutoLoom']
    finished = [b for b in cb['activeBundles'] if b['node'] == NODE][0]
    cb['activeBundles'] = [b for b in cb['activeBundles'] if b['node'] != NODE]
    cb.setdefault('completedBundles', []).append(dict(finished, completedAtUtc=now,
        receipt=receipt_ref['path'], status='COMPLETE_OWN_EXITS_ONLY'))
    throughput = l['closureDirectedProgress']['throughput']
    throughput['completionReceipts'].append(receipt_ref['path'])
    require(NODE not in throughput['newVerifiedExits'], 'duplicate checkpoint exit')
    throughput['newVerifiedExits'].append(NODE)
    elapsed = (dt.datetime.fromisoformat(now) - dt.datetime.fromisoformat(d['atUtc'])).total_seconds()
    require(elapsed >= 0, 'future final-review time')
    l['closureDirectedProgress']['reviewJoinQueueMetrics']['consumedReviews'].append({
        'review': 'r0020_qualify_final_exit_review_r1', 'timestampKind': 'reportAtUtc',
        'recordedAtUtc': d['atUtc'], 'rootConsumedAtUtc': now,
        'elapsedToRootConsumptionMinutes': elapsed / 60,
        'scope': 'Exact independent final decision-to-root JOIN; not transport or queue age'})
    l['updatedAtUtc'] = now
    l['nextAction'] = 'R0020-QUALIFY exact own exits completed. Preserve remaining CBAL bundle; admit successors only after their actual remaining inputs and separate authority.'
    projection = index['currentExecutionProjection']
    projection.update(atUtc=now, completeNodes=complete,
                      observedIntervalExits=projection['observedIntervalExits'] + 1)
    if 'activeClosureNextGates' in projection:
        require(isinstance(projection['activeClosureNextGates'], list), 'next-gates schema changed')
        projection['activeClosureNextGates'] = [g for g in projection['activeClosureNextGates']
                                               if g['node'] != NODE]
    projection['retainedRootExitReceipts'].append({'node': NODE, 'atUtc': now,
        'receipt': receipt_ref, 'independentReviewer': REVIEWER,
        'sourceManifest': {'path': str(FREEZE), 'sha256': FREEZE_SHA, 'bytes': 11394},
        'nativeQualified': False,
        'nativeScope': 'Exact scoped dual-engine O14 and retained accepted evidence qualified PRE_DELIVERY_CANDIDATE; whole-programme native/startup gates separate.',
        'delivered': False})
    index['updatedAtUtc'] = now
    return l, index, successor_projection, complete


def cas(lp, lb, ip, ib):
    require(lp.read_bytes() == lb and ip.read_bytes() == ib, 'ledger/index CAS drift')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute-root-join', action='store_true')
    parser.add_argument('--consumer')
    parser.add_argument('--review-dir', type=Path)
    parser.add_argument('--review-seal-sha256')
    parser.add_argument('--review-report-sha256')
    parser.add_argument('--ledger-before-sha256')
    parser.add_argument('--index-before-sha256')
    args = parser.parse_args()
    if not args.execute_root_join:
        print(json.dumps({'status': 'INERT_ROOT_ONLY_PREPARATION', 'liveLedgerReads': 0,
                          'canonicalLedgerIndexWrites': 0, 'actualFinalReviewRequired': True}))
        return
    require(args.consumer == 'root' and sys.flags.optimize == 0, 'root consumer/unoptimised checks required')
    require(all((args.review_dir, args.review_seal_sha256, args.review_report_sha256,
                 args.ledger_before_sha256, args.index_before_sha256)), 'actual final-review and fresh CAS pins required')
    h = safe_helpers()
    review_dir = args.review_dir.resolve()
    require(review_dir.is_relative_to((RUN / 'workers').resolve()), 'wrong final review owner/path')
    h['sealed'](review_dir, args.review_seal_sha256)
    require(h['sha'](review_dir / 'REPORT.json') == args.review_report_sha256, 'final report drift')
    report = h['read'](review_dir / 'REPORT.json')
    require(report.get('reviewer') == REVIEWER, 'wrong independent final reviewer')
    decision_path = review_dir / 'ROOT_JOIN_DECISION.json'
    d = h['read'](decision_path) if decision_path.exists() else report.get('rootJoinDecision', report)
    require(h['sha'](ASSEMBLED / 'SEAL.json') == ASSEMBLED_SEAL_SHA and
            h['sha'](ASSEMBLED / 'REPORT.json') == ASSEMBLED_REPORT_SHA and
            h['sha'](FREEZE) == FREEZE_SHA and h['sha'](GRAPH) == GRAPH_SHA, 'fixed source/proposal/graph drift')
    assembled = h['read'](ASSEMBLED / 'REPORT.json')
    assembled_seal = h['read'](ASSEMBLED / 'SEAL.json')
    require(h['sha'](ASSEMBLED / 'MANIFEST.json') == assembled_seal['manifestSha256'],
            'assembled manifest drift')
    validate_decision(d, assembled['outputs'], h)
    require(assembled['downstream'] == DOWNSTREAM, 'assembled downstream boundaries changed')
    source_refs = assembled['currentSourcePinsVerified']
    require(len(source_refs) == 15, 'selected final source-pin scope changed')
    for ref in source_refs:
        exact_ref(h, ref)
    for ident, relative, size, digest in OUTPUTS:
        exact_ref(h, {'path': str((ASSEMBLED / 'proposed' / relative).resolve()), 'bytes': size, 'sha256': digest})
        require(not (RUN / relative).exists(), 'canonical preimage is not absent: ' + relative)
    cert = h['read'](ASSEMBLED / 'proposed' / OUTPUTS[2][1])
    require(cert['stage'] == 'PRE_DELIVERY_CANDIDATE' and cert['downstream'] == DOWNSTREAM and
            [r['id'] for r in cert['rows']] == ROWS and cert['rowCount'] == 16 and
            cert['allOriginalRowsRetained'] is True and cert['issueClosureAuthorized'] is False,
            'wrong16-row/nonclosing certificate')
    lp, ip = RUN / 'ACTIVE_LEDGER.json', RUN / 'FINAL_REVIEW_INDEX.json'
    lb, ib = lp.read_bytes(), ip.read_bytes()
    require(hashlib.sha256(lb).hexdigest() == args.ledger_before_sha256 and
            hashlib.sha256(ib).hexdigest() == args.index_before_sha256, 'fresh root CAS pins mismatch')
    l, index, graph = json.loads(lb), json.loads(ib), h['read'](GRAPH)
    _, _, before_count = validate_state(l, index, graph)
    require(not JOIN.exists(), 'immutable JOIN receipt path already exists; no automatic retry')
    now = dt.datetime.now(dt.timezone.utc).isoformat()
    canonical = [{'id': ident, 'path': str((RUN / relative).resolve()), 'bytes': size,
                  'sha256': digest} for ident, relative, size, digest in OUTPUTS]
    receipt = {'schema': 'root-reviewed-node-exit-join/1', 'node': NODE, 'atUtc': now,
        'status': 'COMPLETE_OWN_EXITS_ONLY', 'stage': 'PRE_DELIVERY_CANDIDATE',
        'independentReviewer': REVIEWER, 'independentReview': h['pin'](review_dir / 'REPORT.json'),
        'joinScript': h['pin'](Path(__file__)), 'safeDayHelperSource': h['pin'](DAY_HELPER),
        'independentReviewSeal': h['pin'](review_dir / 'SEAL.json'),
        'independentRootJoinDecision': h['pin'](decision_path) if decision_path.exists() else None,
        'assembledSeal': h['pin'](ASSEMBLED / 'SEAL.json'), 'sourceFreeze': h['pin'](FREEZE),
        'requiredOutputs': canonical, 'requiredOutputReadbackExact': True,
        'criterionDispositions': criterion_evidence(d, str(review_dir / 'REPORT.json')),
        'rowDispositions': d['rowDispositions'],
        'downstream': DOWNSTREAM, 'sourceCurrentnessPins': source_refs,
        'newNativeExecutionByJoin': False, 'inherited535ReferencesReevaluated': False,
        'issueClosed': False, 'mergeDeploymentAuthorized': False, 'wholeRendererStartupPass': False,
        'ledgerBeforeSha256': args.ledger_before_sha256, 'indexBeforeSha256': args.index_before_sha256,
        'beforeCompleteCount': before_count, 'afterCompleteCount': before_count + 1,
        'completionDelta': 1, 'ledgerIndexPostStateReadbackExact': True}
    receipt_raw = h['enc'](receipt)
    receipt_ref = {'path': str(JOIN / 'receipt.json'), 'bytes': len(receipt_raw),
                   'sha256': hashlib.sha256(receipt_raw).hexdigest()}
    after_l, after_i, successors, complete = project(l, index, graph, d, canonical, receipt_ref,
                                                   now, str(review_dir / 'REPORT.json'))
    la, ia = h['enc'](after_l), h['enc'](after_i)
    cas(lp, lb, ip, ib)
    JOIN.mkdir()
    h['save'](JOIN / 'JOIN_PLAN.json', {'status': 'PROSPECTIVE_NOT_COMPLETION_EVIDENCE',
        'intendedReceipt': receipt, 'intendedReceiptPin': receipt_ref,
        'immediateSuccessorsAfterIntendedJOIN': successors, 'automaticRetry': False})
    (JOIN / 'ACTIVE_LEDGER.before.json').write_bytes(lb)
    (JOIN / 'FINAL_REVIEW_INDEX.before.json').write_bytes(ib)
    (JOIN / 'ACTIVE_LEDGER.after.json').write_bytes(la)
    (JOIN / 'FINAL_REVIEW_INDEX.after.json').write_bytes(ia)
    effects = []
    try:
        for _, relative, size, digest in OUTPUTS:
            cas(lp, lb, ip, ib)
            target = RUN / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream:
                stream.write((ASSEMBLED / 'proposed' / relative).read_bytes())
            exact_ref(h, {'path': str(target.resolve()), 'bytes': size, 'sha256': digest})
            effects.append(str(target))
        for ref in source_refs:
            exact_ref(h, ref)
        cas(lp, lb, ip, ib)
        for dest, preimage, body in ((lp, lb, la), (ip, ib, ia)):
            require(dest.read_bytes() == preimage, 'individual ledger/index CAS drift')
            if dest == ip:
                require(lp.read_bytes() == la, 'ledger postimage changed before index commit')
            temp = dest.with_suffix('.r0020-qualify-join.tmp')
            require(not temp.exists(), 'stale temporary state; no automatic retry')
            temp.write_bytes(body)
            require(dest.read_bytes() == preimage, 'pre-replace CAS drift')
            os.replace(temp, dest)
            require(dest.read_bytes() == body, 'ledger/index postimage readback mismatch')
            effects.append(str(dest))
        cas(lp, la, ip, ia)
        for ref in source_refs:
            exact_ref(h, ref)
        require(h['sha'](FREEZE) == FREEZE_SHA and
                h['sha'](review_dir / 'SEAL.json') == args.review_seal_sha256 and
                h['sha'](review_dir / 'REPORT.json') == args.review_report_sha256,
                'post-JOIN source/review identity drift')
        for ref in canonical:
            exact_ref(h, {k: ref[k] for k in ('path', 'bytes', 'sha256')})
        # Actual completion receipt is written only after both CAS postimages/readbacks exist.
        with (JOIN / 'receipt.json').open('xb') as stream:
            stream.write(receipt_raw)
        exact_ref(h, receipt_ref)
        h['save'](JOIN / 'READBACK.json', {'receipt': receipt_ref, 'ledger': h['pin'](lp),
            'index': h['pin'](ip), 'canonicalOutputs': canonical,
            'counts': dict(collections.Counter(n['progress']['state'] for n in after_l['nodes'])),
            'immediateSuccessors': successors, 'completionDelta': 1,
            'onlyRetiredBundle': NODE, 'downstream': DOWNSTREAM})
    except Exception as error:
        h['save'](JOIN / 'ATTENTION_REQUIRED.json', {'status': 'PARTIAL_JOIN_REQUIRES_ROOT_RECONCILIATION',
            'error': str(error), 'knownWrites': effects, 'actualCompletionReceiptExists':
            (JOIN / 'receipt.json').exists(), 'automaticRetry': False,
            'compensation': 'Preserve canonical artifacts and before/after snapshots; root must reconcile exact live pins before any guarded repair. No automatic rollback/delete or completion inference.'})
        raise
    print(json.dumps({'receipt': receipt_ref, 'completeNodes': complete, 'totalNodes': 213,
                      'completionDelta': 1, 'immediateSuccessors': successors}))


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError, AssertionError) as error:
        print('REFUSED: ' + str(error), file=sys.stderr)
        sys.exit(2)
