const _RAFNOW = ()=> (typeof performance!=='undefined' && performance.now) ? performance.now() : Date.now();
const _tsParam=q.get("timeScale");
let TIMESCALE = _tsParam!=null ? Math.max(0,+_tsParam||0) : (SIM.time!=null ? 0 : 1);
let ADVANCING = _tsParam!=null && TIMESCALE>0;          // a running fast-forward → show the sim clock
let FOLLOW_WALL_CLOCK = _tsParam==null && SIM.time==null && TIMESCALE===1;
let _clockPreview=false; // explicit runtime clock control retains forecast provenance while paused
let _rafT0=_RAFNOW(), _simBase=null, _simTz=null, _simValid=true, _simInvalidTz=null;
// Formatter construction appeared on the first-scene critical path dozens of
// times. Reuse only its immutable zone/options; every call still projects the
// supplied current UTC, including DST, seek and configuration changes.
let _partsFormatter=null,_partsFormatterZone=null;
function partsInTz(ms){
  try{
    if(!_partsFormatter||_partsFormatterZone!==tz){
      _partsFormatter=new Intl.DateTimeFormat("en-CA",{timeZone:tz,year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:false});_partsFormatterZone=tz;
    }
    const f=_partsFormatter;
    const p={}; for(const part of f.formatToParts(new Date(ms))) p[part.type]=part.value;
    return {y:+p.year,mo:+p.month,d:+p.day,h:(+p.hour)%24,mi:+p.minute,s:+p.second,dateStr:`${p.day}-${p.month}-${p.year}`};
  }catch(e){
    const d=new Date(ms);
    return {y:d.getFullYear(),mo:d.getMonth()+1,d:d.getDate(),h:d.getHours(),mi:d.getMinutes(),s:d.getSeconds(),dateStr:`${pad(d.getDate())}-${pad(d.getMonth()+1)}-${d.getFullYear()}`};
  }
}
// Strict Gregorian coordinate, including years 1–99 (Date.UTC would reinterpret those as 1901–1999).
// Projection may cross the BCE boundary; callers of the inverse require a positive requested year.
function utcFields(y,mo,d,h=0,mi=0,s=0){
  if(![y,mo,d,h,mi,s].every(Number.isInteger) || mo<1 || mo>12 || d<1 || d>31 || h<0 || h>23 || mi<0 || mi>59 || s<0 || s>59) return NaN;
  const date=new Date(0); date.setUTCFullYear(y,mo-1,d); date.setUTCHours(h,mi,s,0);
  const ms=date.getTime();
  return Number.isFinite(ms) && date.getUTCFullYear()===y && date.getUTCMonth()+1===mo && date.getUTCDate()===d ? ms : NaN;
}
function zoneFormatter(zone){
  return new Intl.DateTimeFormat("en-US-u-ca-gregory-nu-latn",{timeZone:zone,calendar:"gregory",numberingSystem:"latn",era:"short",year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit",hourCycle:"h23"});
}
function projectInZone(formatter,ms){
  try{
    const p={}; for(const part of formatter.formatToParts(new Date(ms))) p[part.type]=part.value;
    if(p.era!=="AD" && p.era!=="BC") return null;
    const y=p.era==="BC" ? 1-(+p.year) : +p.year, mo=+p.month, d=+p.day, h=+p.hour, mi=+p.minute, s=+p.second;
    if(!Number.isFinite(utcFields(y,mo,d,h,mi,s))) return null;
    return {y,mo,d,h,mi,s};
  }catch(e){ return null; }
}
// Minute-precision inverse, fail-closed for gaps, folds and unsupported offsets. One day profile searches
// all 4,321 UTC minutes in the ±24h offset window; reuse it across model/hourly callers, never each frame.
// This deliberately does not certify historical second-resolution offsets or arbitrary IANA history.
const _zoneDays=new Map();
function zoneDay(y,mo,d,zone){
  const key=JSON.stringify([zone,y,mo,d]);
  if(_zoneDays.has(key)) return _zoneDays.get(key);
  const profile={formatter:null,minutes:null};
  _zoneDays.set(key,profile); if(_zoneDays.size>4) _zoneDays.delete(_zoneDays.keys().next().value);
  try{
    const f=zoneFormatter(zone), u=utcFields(y,mo,d), minutes=Array.from({length:1440},()=>[]);
    for(let ms=u-86400000;ms<=u+172800000;ms+=60000){
      const p=projectInZone(f,ms);
      if(!p) return profile;
      const offset=(utcFields(p.y,p.mo,p.d,p.h,p.mi,p.s)-ms)/60000;
      if(!Number.isInteger(offset) || Math.abs(offset)>1440) return profile;
      if(p.y===y && p.mo===mo && p.d===d && p.s===0){
        const entry=minutes[p.h*60+p.mi]; if(!entry.includes(ms)) entry.push(ms);
      }
    }
    profile.formatter=f; profile.minutes=minutes;
  }catch(e){}
  return profile;
}
function epochForTzTime(y,mo,d,h,mi,zone=tz){
  if(y<=0 || typeof zone!=="string" || !zone || !Number.isFinite(utcFields(y,mo,d,h,mi))) return NaN;
  const profile=zoneDay(y,mo,d,zone), entry=profile.minutes && profile.minutes[h*60+mi];
  if(!entry || entry.length!==1) return NaN;
  const ms=entry[0], p=projectInZone(profile.formatter,ms);
  return p && p.y===y && p.mo===mo && p.d===d && p.h===h && p.mi===mi && p.s===0 ? ms : NaN;
}
function initSim(){
  const now=Date.now(); let base=now;
  if(SIM.time!=null){
    let real=null; try{ real=projectInZone(zoneFormatter(tz),now); }catch(e){}
    const t=String(SIM.time).split(":");
    base=real ? epochForTzTime(real.y,real.mo,real.d,((+t[0]%24)+24)%24,(+t[1]||0),tz) : NaN;
  }
  if(!Number.isFinite(base)){ _simBase=null; _simValid=false; _simInvalidTz=tz; return false; }
  _simBase=base; _rafT0=_RAFNOW(); _simTz=tz; _simValid=true; _simInvalidTz=null;
  return true;
}
// re-anchor when the timezone settles (it loads from the location AFTER boot — only changes once, near t0)
function simNow(){
  if(FOLLOW_WALL_CLOCK) return Date.now();
  if(!_simValid && _simInvalidTz===tz) return NaN;
  if((_simBase==null || _simTz!==tz) && !initSim()) return NaN;
  return _simBase + (_RAFNOW()-_rafT0)*TIMESCALE;
}
function simDate(){ return new Date(simNow()); }
// An unresolved explicit scene has no celestial/prayer clock. Hide its retained outputs without changing
// geometry or settings access, and restore each element's prior visibility when a valid scene recovers.
const _simHidden=new Map(); let _simClockDisplay=null;
function simulationReady(){
  const valid=SIM.time==null || Number.isFinite(simNow()), sc=$(".simclock");
  if(!valid){
    for(const selector of [".sky","#wxfx",".climate",".arc",".bar",".cn",".times",".d"]){
      const el=$(selector); if(el && !_simHidden.has(el)){ _simHidden.set(el,el.style.visibility); el.style.visibility="hidden"; }
    }
    showError("Simulation time unavailable");
    if(sc){ if(_simClockDisplay===null) _simClockDisplay=sc.style.display; sc.textContent="SIM unavailable"; sc.style.display="block"; }
    return false;
  }
  for(const [el,visibility] of _simHidden) el.style.visibility=visibility;
  _simHidden.clear();
  if(sc && _simClockDisplay!==null){ sc.style.display=_simClockDisplay; _simClockDisplay=null; }
  return true;
}
// current wall-clock in the configured timezone, derived from simTime (not the browser clock)
function nowParts(){ return partsInTz(simNow()); }
function tomorrowStr(){
  const n=nowParts();
  const d=new Date(Date.UTC(n.y,n.mo-1,n.d));
  d.setUTCDate(d.getUTCDate()+1);
  return `${pad(d.getUTCDate())}-${pad(d.getUTCMonth()+1)}-${d.getUTCFullYear()}`;
}

