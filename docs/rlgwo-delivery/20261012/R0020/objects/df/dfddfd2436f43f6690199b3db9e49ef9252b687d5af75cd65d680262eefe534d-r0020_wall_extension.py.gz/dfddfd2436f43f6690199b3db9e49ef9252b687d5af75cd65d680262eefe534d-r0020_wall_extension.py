"""Missing wall-only admissions/readbacks; existing native helpers remain owners."""
from datetime import datetime
import hashlib,importlib.util,json,math,sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
BINDING=HERE/'WALL_TARGET_BINDING.json'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 b=Path(p).read_bytes();return {'path':str(Path(p).resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def receipt_json(value):
 if isinstance(value,float) and not math.isfinite(value):return {'$nonfinite':'NaN' if math.isnan(value) else 'Infinity' if value>0 else '-Infinity'}
 if isinstance(value,dict):return {k:receipt_json(v) for k,v in value.items()}
 if isinstance(value,(list,tuple)):return [receipt_json(v) for v in value]
 return value
def actual_runtime(root,binding):
 owner=Path(root)/'tools/cp9/runtime_identity.py';assert pin(owner)['sha256']==binding['runtimeOwner']['sha256'],'Runtime identity owner changed'
 spec=importlib.util.spec_from_file_location('wall_source_runtime',owner);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod.runtime_identity(root)
def assert_current(value):
 binding=read(BINDING);root=Path(binding['candidate'])
 for key in ['index','config','authored']:
  assert pin(binding[key]['path'])==binding[key],key+' input identity differs'
 for row in binding['helpers']:assert pin(row['path'])==row,'Relevant helper differs'
 assert actual_runtime(root,binding)==binding['runtime'],'Full current generated runtime differs'
 return True
def require_root_lease(args,here=HERE,ledger=None):
 binding=read(BINDING);run=Path(binding['runRoot']).resolve()
 path=run/'ACTIVE_LEDGER.json';value=read(path) if ledger is None else ledger
 assert value.get('schema')=='salah-active-execution/1' and Path(value.get('runRoot','')).resolve()==run,'Wrong root lease ledger'
 row=value.get('resourceLeases',{}).get('heavy-browser',{})
 assert args.lease_id and row.get('leaseId')==args.lease_id and row.get('holder')=='root' and row.get('status')=='ACTIVE' and row.get('capacity')==1,'Root ACTIVE capacity-one exact lease required'
 assert Path(row.get('command','')).resolve()==(Path(here)/'rlgwo_wall_clock_check.py').resolve() and isinstance(row.get('scope'),str) and row['scope'].strip(),'Root lease command/scope differs'
 return {'ledger':pin(path) if ledger is None else None,'lease':dict(row)}
def preflight(args,suite,here,fixture):
 if sys.flags.optimize:raise ValueError('Optimized Python cannot prepare or execute the assertion-guarded wall proposal')
 binding=read(BINDING);root=args.root.resolve();out=args.output.resolve();run=Path(binding['runRoot']).resolve()
 assert suite=='wall','This private proposal admits R0020-WALL only'
 assert root==Path(binding['candidate']).resolve(),'Only exact current generated weather-info-01 is admitted'
 assert args.expected_source_sha256==binding['index']['sha256'],'Only exact approved generated entry identity is admitted'
 assert out.is_relative_to(run) and not out.is_relative_to(root) and not root.is_relative_to(out),'Output must stay within RUN and outside served input'
 assert not out.exists(),'Fresh output required; retain previous receipts'
 assert args.node and pin(args.node)==binding['node'],'Exact existing Node22 required'
 assert_current(binding)
 lease=require_root_lease(args,here) if args.execute else {'admitted':False,'scope':'Preparation only; no native lease or effect claimed'}
 return {'schema':'r0020-wall-driver-admission/1','targetBinding':pin(BINDING),'root':str(root),'generatedEntry':binding['index'],'authoredOwner':binding['authored'],'config':binding['config'],'runtimeSha256':binding['runtime']['treeSha256'],'runtimeFiles':len(binding['runtime']['files']),'node':binding['node'],'driverEntry':pin(Path(here)/'rlgwo_wall_clock_check.py'),'nativeDriver':pin(Path(here)/'rlgwo_native_checks.py'),'extension':pin(__file__),'adapter':pin(fixture),'lease':lease,'nativeExecuted':False,'actualHealthyReadback':None}
def epoch(s):return int(datetime.fromisoformat(s.replace('Z','+00:00')).timestamp()*1000)
def action_watermark(page):
 return page.evaluate('() => ({trace:window.__rlgwo.trace.length,frames:window.__rlgwo.frames.length})')
def action_rows(s,key,watermark):
 rows=s[key]
 if watermark is None:return rows
 offset=watermark[key]
 assert type(offset) is int and 0<=offset<=len(rows),'Invalid action '+key+' watermark'
 return rows[offset:]
def clock_frames(s,watermark=None,wall=None):return [x for x in action_rows(s,'frames',watermark) if x.get('event')=='fired' and x.get('clockLoop') is True and (wall is None or x.get('wall')==wall)]
def actual_clock_render(s,wall=None,day=None,watermark=None):
 frames={(x['id'],x['ownerId']) for x in clock_frames(s,watermark,wall=wall)}
 for row in reversed(action_rows(s,'trace',watermark)):
  callback=row.get('callback') or {};state=row.get('state') or {}
  if row.get('event')=='actual-render' and callback.get('clockLoop') is True and (callback.get('id'),callback.get('ownerId')) in frames and (wall is None or row.get('wall')==wall) and (day is None or state.get('day')==day):return row
 return None
def setup_checks(s,d):
 tags=[x['event'] for x in s['trace']]
 out=[d.check(tags.index('pre-script-installed')<tags.index('readonly-hooks-installed')<tags.index('beginRequest'),'Pre-script precedes source hooks and actual request owner'),d.check(s['loopStarted'] and s['dom']['rows']==6,'Actual boot starts loop with six prayer rows'),d.check(s['prayerRecordsGeneration']==s['generation'],'Admitted prayer record belongs to actual generation'),d.check(actual_clock_render(s) is not None,'Actual source render carries a delegated native clock callback'),d.check(len(s['activeClockFrames'])==1,'One active exact clock-loop callback'),d.check(s['limits']['prayerAttempt']==10000 and s['limits']['rolloverRetry']==60000,'Original prayer deadline/cooldown remain unchanged'),d.check(s['geometry']['.c']['width']==325 and s['geometry']['.c']['height']==530,'Actual protected325x530 card geometry')]
 return out
def ready(page,d):
 d.wait_ready(page);d.settle_prayers(page)
 page.wait_for_function("__rlgwo.trace.some(x=>x.event==='actual-render'&&x.callback?.clockLoop===true)")
def cache_identity(s):
 rows=dict(s['effects']['storage']);key=s.get('cacheKey');value=rows.get(key)
 if not isinstance(key,str) or not isinstance(value,str):return None
 try:envelope=json.loads(value)
 except (ValueError,TypeError):return None
 return {'key':key,'raw':value,'sha256':hashlib.sha256(value.encode()).hexdigest(),'date':envelope.get('date'),'dataDay':envelope.get('data',{}).get('date',{}).get('gregorian',{}).get('date'),'timezone':envelope.get('data',{}).get('meta',{}).get('timezone')}
def warm_witness(s):
 cache=cache_identity(s)
 return bool(s.get('loopStarted') and s.get('prayerRecordsGeneration')==s.get('generation') and s.get('day')=='07-09-2026' and (s.get('today') or {}).get('date',{}).get('gregorian',{}).get('date')=='07-09-2026' and cache and cache['date']==cache['dataDay']=='07-09-2026' and cache['timezone']=='UTC' and actual_clock_render(s,day='07-09-2026') and len(s.get('activeClockFrames',[]))==1)
def prayer_assertions(s,d,wall,current,next_key,next_time,left,until,watermark=None):
 model=s['model'];row=actual_clock_render(s,wall=wall,day='07-09-2026',watermark=watermark)
 return [d.check(row is not None,'Scheduled native render at literal wall '+str(wall)),d.check(model['nowEpoch']==s['now']==s['clock']['wall']==wall,'Actual model/temporal API use corrected wall'),d.check(model['currentKey']==s['dom']['current']==current,'Current prayer literal '+current),d.check(model['nextKey']==s['dom']['nextPrayer']==next_key and model['nextTime']==s['dom']['next']==next_time,'Next prayer/time literal '+next_key+'/'+next_time),d.check(model['leftMin']==left and s['dom']['untilTime']==until,'Actual finite countdown and DOM literal '+until),d.check(s['date']['requestedGregorianDay']=='07-09-2026','Actual selected date stays within requested day')]
def prayer_case(page,metadata,out,d):
 states=[];checks=[];ready(page,d);initial=d.capture(page,out,'prayer-before-Asr',states);checks+=setup_checks(initial,d)
 checks+=prayer_assertions(initial,d,epoch('2026-09-07T15:29:59Z'),'Dhuhr','Asr','15:30',1/60,'1s')
 forward_watermark=action_watermark(page)
 d.step(page,'2026-09-07T15:30:01Z');forward=d.capture(page,out,'prayer-forward-Asr',states);states[-1]['actionWatermark']=forward_watermark
 checks+=prayer_assertions(forward,d,epoch('2026-09-07T15:30:01Z'),'Asr','Maghrib','18:00',8999000/60000,'2h 29m',watermark=forward_watermark)
 reverse_watermark=action_watermark(page)
 d.step(page,'2026-09-07T15:29:59Z');back=d.capture(page,out,'prayer-reverse-Dhuhr',states);states[-1]['actionWatermark']=reverse_watermark
 checks+=prayer_assertions(back,d,epoch('2026-09-07T15:29:59Z'),'Dhuhr','Asr','15:30',1/60,'1s',watermark=reverse_watermark)
 checks.append(d.check(back['clock']['mono']==forward['clock']['mono']==initial['clock']['mono']==0,'Wall correction leaves independent monotonic source unchanged'))
 return states,checks,'PARTIAL_NATIVE_SCOPE',['Actual scheduled date/prayer scope; injected clocks/providers/storage; full renderer/font/timing/public qualification separate.']
def held_case(page,metadata,out,d):
 states=[];checks=[];ready(page,d);warm=d.capture(page,out,'warm-completed-day7-cache-native-loop',states);checks+=setup_checks(warm,d)
 checks.append(d.check(warm_witness(warm),'Healthy settled day7 cache/native-callback prerequisite'))
 cache7=cache_identity(warm);loop_owners={x['ownerId'] for x in clock_frames(warm)}
 for day in ['07','08','09']:d.policy(page,'prayer:'+day+'-09-2026','hold')
 cfg=dict(warm['config']);cfg['label']='Madinah refreshed';page.evaluate('(cfg)=>{window.__heldApply=__rlgwo.apply(cfg)}',cfg)
 current=d.wait_pending(page,'prayer','07-09-2026');next8=d.wait_pending(page,'prayer','08-09-2026');refresh=d.capture(page,out,'actual-label-only-refresh-current7-prefetch8',states)
 keys=['lat','lon','tz','method','school','units']
 checks += [d.check(all(refresh['config'][k]==warm['config'][k] for k in keys),'Actual label-only refresh preserves coordinates/zone/method/school/units'),d.check(refresh['generation']==warm['generation']+1 and refresh['loopStarted'],'New generation retains running native loop'),d.check(cache_identity(refresh)==cache7 and refresh['day']=='07-09-2026' and refresh['prayerRecordsGeneration']==refresh['generation'],'Exact persisted cache7 envelope re-admitted; no JavaScript reference-equality claim'),d.check(current['owner']['kind']=='current' and next8['owner']['kind']=='prefetch' and current['owner']['generation']==next8['owner']['generation']==refresh['generation'],'Distinct real current7/prefetch8 owners in new generation'),d.check(next8.get('callback',{}).get('clockLoop') is True and next8['callback']['ownerId'] in loop_owners,'Existing native callback causes new prefetch8')]
 d.step(page,'2026-09-08T00:00:01Z');d.release(page,next8);page.wait_for_function("__rlgwo.read().day==='08-09-2026'")
 next9=d.wait_pending(page,'prayer','09-09-2026');page.wait_for_function("__rlgwo.trace.some(x=>x.event==='actual-render'&&x.callback?.clockLoop&&x.state?.day==='08-09-2026')")
 successor=d.capture(page,out,'prefetch9-owns-before-current7-finally',states)
 checks += [d.check(successor['slots']['current']['operationId']==current['owner']['operationId'] and successor['slots']['prefetch']['operationId']==next9['owner']['operationId'],'Current7 still owns while successor prefetch9 already owns'),d.check(next9.get('callback',{}).get('clockLoop') is True and next9['callback']['ownerId'] in loop_owners,'Existing native callback causes prefetch9'),d.check(successor['today']['date']['gregorian']['date']=='08-09-2026' and cache_identity(successor)['date']=='08-09-2026','Actual day8 adoption/persistence before current7 release')]
 d.release(page,current);corrected=d.wait_pending(page,'prayer','08-09-2026');correction=d.capture(page,out,'late-current7-issues-one-corrected8',states)
 checks += [d.check(corrected['owner']['operationId']==current['owner']['operationId'] and corrected['owner']['kind']=='current' and corrected['owner']['prayerAttempts']==2,'Same operation makes one corrected-day request within three-attempt budget'),d.check(correction['day']=='08-09-2026' and correction['today']['date']['gregorian']['date']=='08-09-2026','Late7 never relabeled/adopted as current8'),d.check(corrected['owner']['attempt']['attemptId']!=current['owner']['attempt']['attemptId'] and corrected['owner']['attempt']['deadlineAt']==10000,'Correction owns fresh actual attempt/deadline without wall-consuming it')]
 d.release(page,corrected);page.wait_for_function('__rlgwo.read().slots.current===null');after=d.capture(page,out,'current-finally-preserves-owning-prefetch9',states)
 requests=[r for r in after['requests'] if r.get('kind')=='prayer' and r.get('owner',{}).get('operationId')==current['owner']['operationId']]
 checks += [d.check([r['day'] for r in requests]==['07-09-2026','08-09-2026'] and len(requests)<=3,'Shared operation has only late7 and one correction8'),d.check(after['slots']['prefetch']['operationId']==next9['owner']['operationId'] and after['slots']['current'] is None,'Current finally clears only own slot'),d.check(all(not r['aborted'] and r['mono']<r['owner']['attempt']['deadlineAt'] for r in requests),'Release path retains existing absolute attempt eligibility')]
 d.release(page,next9);d.settle_prayers(page);page.evaluate('__rlgwo.waitFrames(2)');settled=d.capture(page,out,'actual-day8-next9-settled',states)
 checks += [d.check(settled['day']=='08-09-2026' and settled['tomorrow']['date']['gregorian']['date']=='09-09-2026','Actual current8/next9 final consumer'),d.check(len(settled['activeClockFrames'])==1 and {x['ownerId'] for x in clock_frames(settled)}==loop_owners,'Retained source callback owner through label refresh/releases')]
 return states,checks,'PARTIAL_NATIVE_SCOPE',['Warm cache key/date/envelope identity, not object-reference identity. Every held body uses original native timers/10000ms attempt/three-attempt budget. DAY/QUALIFY/public/whole-renderer gates separate.']
def owned_local_frame(host,origin,entry_hash):
 assert host.url==origin+'/offscreen-host.html','Unexpected local parent URL'
 elements=host.query_selector_all('iframe');assert len(elements)==1,'Exactly one local parent iframe required'
 element=elements[0];expected='/index.html'+entry_hash;assert element.get_attribute('src')==expected,'Declared child source differs'
 frame=element.content_frame();assert frame is not None and frame.parent_frame is host.main_frame,'Missing/foreign child owner'
 initial=frame.url;assert initial in ['', 'about:blank',origin+expected],'Unexpected initial child URL: '+repr(initial)
 return frame,element,{'parent':host.url,'source':expected,'initialUrl':initial}
def verify_local_frame(host,frame,element,bound):
 assert host.url==bound['parent'] and frame.parent_frame is host.main_frame and element.content_frame() is frame,'Local parent/child owner changed'
 assert len(host.query_selector_all('iframe'))==1 and element.get_attribute('src')==bound['source'] and frame.url==bound['parent'].removesuffix('/offscreen-host.html')+bound['source'],'Ready local source/URL/cardinality differs'
def visibility_case(page,metadata,out,environment,d):
 states=[];checks=[];ready(page,d);before=d.capture(page,out,'visible-before-injected-hidden',states);checks+=setup_checks(before,d)
 page.evaluate('__rlgwo.injectVisibility("hidden")');page.evaluate('__rlgwo.waitFrames(2)');hidden=d.capture(page,out,'injected-hidden-cancelled',states)
 checks.append(d.check(hidden['activeClockFrames']==[],'Injected hidden cancels actual exact clock owner'))
 page.evaluate('__rlgwo.setWall("2026-09-08T00:00:01Z")');page.evaluate('__rlgwo.waitFrames(4)');quiet=d.capture(page,out,'injected-hidden-day-step-no-catchup',states)
 checks += [d.check(len(clock_frames(quiet))==len(clock_frames(hidden)),'No source clock callbacks during controlled hidden interval'),d.check(len(quiet['requests'])==len(hidden['requests']),'Hidden step creates no per-missed-day request storm')]
 page.evaluate('__rlgwo.injectVisibility("visible")');page.wait_for_function("__rlgwo.read().day==='08-09-2026'");d.settle_prayers(page);page.evaluate('__rlgwo.waitFrames(3)');resumed=d.capture(page,out,'injected-visible-current-day8',states)
 checks += [d.check(len(resumed['activeClockFrames'])==1 and resumed['now']==resumed['clock']['wall'],'Resume owns one callback at present wall instant'),d.check(actual_clock_render(resumed,day='08-09-2026') is not None,'Resumed day8 is actual scheduled consumer')]
 host=page.context.new_page();origin=environment['server'].origin
 try:
  host.goto(origin+'/offscreen-host.html',wait_until='domcontentloaded');widget,element,bound=owned_local_frame(host,origin,metadata['plan']['hash']);ready(widget,d);verify_local_frame(host,widget,element,bound)
  native_before=d.capture(widget,out,'local-parent-native-visible',states);checks+=setup_checks(native_before,d)
  host.mouse.wheel(0,900);widget.wait_for_function('__rlgwo.activeClockFrames().length===0');cancelled=d.capture(widget,out,'local-parent-actual-IO-cancelled',states)
  widget.evaluate('__rlgwo.setWall("2026-09-08T00:00:01Z")');widget.evaluate('__rlgwo.waitFrames(3)');offscreen=d.capture(widget,out,'local-parent-actual-IO-hidden-day-step',states)
  checks.append(d.check(offscreen['activeClockFrames']==[] and len(clock_frames(offscreen))==len(clock_frames(cancelled)) and len(offscreen['requests'])==len(cancelled['requests']),'After observed actual IO cancellation, day step causes no callback/request backlog'))
  host.mouse.wheel(0,-1200);widget.wait_for_function("__rlgwo.read().day==='08-09-2026'");d.settle_prayers(widget);widget.evaluate('__rlgwo.waitFrames(3)');verify_local_frame(host,widget,element,bound);returned=d.capture(widget,out,'local-parent-actual-IO-resumed-day8',states)
  checks += [d.check(len(returned['activeClockFrames'])==1 and returned['now']==returned['clock']['wall'],'Actual IO reveal resumes one present-instant owner'),d.check(actual_clock_render(returned,day='08-09-2026') is not None,'Actual offscreen/reveal reaches scheduled day8 consumer')]
  d.write(out/'LOCAL_PARENT_BINDING.json',{'binding':bound,'finalUrl':widget.url,'scope':'Local fixture parent/actual IntersectionObserver only; no real new-tab parent or native sleep.'})
 finally:host.close()
 return states,checks,'PARTIAL_NATIVE_SCOPE',['Injected visibility is not native sleep. Local same-origin parent/actual IntersectionObserver is not real new-tab/Tabliss admission. Screenshots stay passive page captures while offscreen.']
def modes_case(page,variant,metadata,out,d):
 states=[];checks=[];ready(page,d);initial=d.capture(page,out,'mode-initial-'+variant,states);checks+=setup_checks(initial,d)
 anchor=epoch('2026-09-07T03:30:00Z') if variant in {'frozen','sim1','sim60'} else epoch('2026-09-07T12:00:00Z')
 rate=0 if variant=='frozen' else 60 if variant in {'scale60','sim60'} else 1
 checks += [d.check(initial['now']==anchor,'Literal independently specified initial anchor'),d.check(initial['clockMode']=={'followWall':variant=='ordinary','rate':rate,'advancing':variant!='ordinary' and rate>0},'Actual explicit/default parser authority and ADVANCING flags')]
 page.evaluate('__rlgwo.setMono(1000)')
 for offset in [3600000,-3600000,7200000,-7200000]:
  page.evaluate('(v)=>__rlgwo.setWall(v)',initial['clock']['wall']+offset);page.evaluate('__rlgwo.waitFrames(4)');state=d.capture(page,out,'mode-'+variant+'-wall-'+str(offset),states)
  wanted=state['clock']['wall'] if variant=='ordinary' else anchor+1000*rate
  checks += [d.check(state['now']==wanted and state['model']['nowEpoch']==wanted,'Actual temporal/model consumer retains literal authority after '+str(offset)),d.check(state['clock']['mono']==1000,'Wall does not alter independent elapsed input'),d.check(len(state['activeClockFrames'])==1 and len(clock_frames(state))>len(clock_frames(initial)),'Existing actual scheduled callback remains sole owner'),d.check(state['clockMode']==initial['clockMode'],'Explicit rate/ADVANCING intent unchanged')]
 return states,checks,'PARTIAL_NATIVE_SCOPE',['Native positive ordinary/explicit1/60/frozen/sim1/sim60 only. Retained36 alias source cases supply unchanged0/empty/invalid/negative parsing; no fallback monotonic host/first-scene/performance claim.']
def mutant_case(page,name,variant,metadata,out,d):
 states=[];checks=[];ready(page,d);initial=d.capture(page,out,'counterfactual-initial-'+variant,states);checks+=setup_checks(initial,d)
 checks.append(d.check(metadata['identity']['counterfactual'] and metadata['identity']['sourceMutation']==variant,'Separately bound exact original source discriminator'))
 if variant=='broad-default':
  checks.append(d.check(initial['now']!=epoch('2026-09-07T03:30:00Z') and initial['clockMode']['followWall'] is True,'Broad default contradicts independent explicit frozen anchor'))
  page.evaluate('__rlgwo.setMono(1000)');page.evaluate('__rlgwo.setWall("2026-09-07T13:00:00Z")');page.evaluate('__rlgwo.waitFrames(4)');after=d.capture(page,out,'counterfactual-broad-default-follows-wall',states)
  checks.append(d.check(after['now']==after['clock']['wall'] and after['now']!=epoch('2026-09-07T03:30:00Z') and len(clock_frames(after))>len(clock_frames(initial)),'Actual native callback frozen-control contradiction reached'))
 else:
  if variant=='increasing-only':
   forward_watermark=action_watermark(page)
   d.step(page,'2026-09-07T15:30:01Z');initial=d.capture(page,out,'counterfactual-positive-forward-Asr',states);states[-1]['actionWatermark']=forward_watermark
   checks.append(d.check(initial['dom']['current']=='Asr' and actual_clock_render(initial,wall=epoch('2026-09-07T15:30:01Z'),day='07-09-2026',watermark=forward_watermark) is not None,'Increasing-only positive forward path remains healthy'))
  wall='2026-09-07T15:29:59Z' if variant=='increasing-only' else '2026-09-07T15:30:01Z'
  watermark=action_watermark(page)
  page.evaluate('(v)=>__rlgwo.setWall(v)',epoch(wall));page.evaluate('__rlgwo.waitFrames(4)');after=d.capture(page,out,'counterfactual-'+variant+'-contradiction',states);states[-1]['actionWatermark']=watermark
  checks.append(d.check(bool(clock_frames(after,watermark,wall=epoch(wall))) and after['clock']['wall']==epoch(wall),'Real scheduled callback observes changed fixture input'))
  if variant=='anchor-only':checks.append(d.check(after['now']!=after['clock']['wall'] and after['dom']['current']=='Dhuhr','Anchor-only contradicts healthy forward Asr model/DOM oracle'))
  else:checks.append(d.check(after['now']==after['clock']['wall'] and after['dom']['current']=='Asr' and actual_clock_render(after,wall=epoch(wall),watermark=watermark) is None,'Increasing-only contradicts healthy backward scheduled Dhuhr render oracle'))
 return states,checks,'MUTANT_DETECTED',['Counterfactual fixture native source, not original product runtime. Requires paired healthy default prayer or frozen result on identical declared inputs.']
def native_case(page,name,variant,metadata,out,environment,d):
 if metadata['identity'].get('counterfactual'):return mutant_case(page,name,variant,metadata,out,d)
 if name=='prayer':return prayer_case(page,metadata,out,d)
 if name=='held':return held_case(page,metadata,out,d)
 if name=='visibility':return visibility_case(page,metadata,out,environment,d)
 if name=='modes':return modes_case(page,variant,metadata,out,d)
 raise ValueError('Unassigned native wall case: '+name)
def publish_outputs(out,manifest,rows):
 """Root native return only; preparation must never produce an acquired interface."""
 if manifest.get('execution')!='EXECUTED_WITH_LIMITS':return {'status':'NO_NATIVE_INTERFACE_FROM_PREPARATION','outputs':[]}
 out=Path(out);refs=[]
 for row in rows:
  target=out/(row['case']+'--'+row['variant']);result=target/'result.json'
  refs.append({'case':row['case'],'variant':row['variant'],'status':row['status'],'result':pin(result),'images':[pin(p) for p in sorted(target.glob('*.png'))],'counterfactual':bool(row['source'].get('counterfactual'))})
 common={'schema':'r0020-wall-native-interface-return/1','sourceBinding':manifest['wallBinding'],'browser':manifest.get('browser'),'executionEnvironment':manifest.get('executionEnvironment'),'scope':manifest['scope'],'inputAndResultBindings':refs,'independentDisposition':'PENDING_ROOT_NATIVE_REVIEW','nodeComplete':False,'fullRendererQualified':False,'realParentQualified':False,'performanceQualified':False,'serialization':'Actual nonfinite readbacks use explicit $nonfinite tags; finite consumers unchanged.'}
 names=[]
 def emit(name,value):
  path=out/name;path.write_text(json.dumps(receipt_json(value),indent=2,allow_nan=False)+'\n',encoding='utf-8');names.append(pin(path))
 held=next((r for r in rows if r['case']=='held' and r['variant']=='default'),None)
 if held and held['status']=='PARTIAL_NATIVE_SCOPE' and not held.get('pageErrors'):
  warm=next((s for s in held['states'] if s['name']=='warm-completed-day7-cache-native-loop'),None)
  if warm and warm_witness(warm['state']):emit('wall-fixture-contract.json',{**common,'outputId':'R0020-WALL-OUTPUT-1','status':'RETURNED_PENDING_NATIVE_FIXTURE_REVIEW','healthyInitialNativeConsumerReadback':warm,'warmHeldSequence':held['states'],'cacheIdentityMeaning':'Actual key/date/serialized envelope and current-generation admission, not retained JavaScript pointer.','consumableByDAY':False,'reason':'Independent native fixture disposition still required before the hard interface is consumed.'})
 emit('setup-and-consumers.json',{**common,'outputId':'R0020-WALL-OUTPUT-2','status':'RETURNED_WITH_SCOPED_CASES_REQUIRES_REVIEW','cases':[{'case':r['case'],'variant':r['variant'],'states':r.get('states'),'failedState':r.get('failedState'),'pageErrors':r.get('pageErrors')} for r in rows]})
 emit('wall-boundaries-modes.json',{**common,'outputId':'R0020-WALL-OUTPUT-3','status':'RETURNED_SCOPED_ONLY_QUALIFY_JOINS_DAY','cases':[r for r in refs if r['case'] in {'prayer','visibility','modes'}],'missingOrUnqualifiedScope':['DAY broader promotion/back-late/retry output','QUALIFY combined boundary report','Independent pixel/caller disposition','Actual real-parent/performance/full-scene qualification']})
 return {'status':'NAMED_RETURNS_PENDING_INDEPENDENT_REVIEW','outputs':names}
