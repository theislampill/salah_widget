"""Root-only exact reviewed DAY evidence JOIN. No product/public mutation or replay."""
import collections, datetime as dt, hashlib, json, os
from pathlib import Path
RUN=Path('C:/Users/theis/Documents/Codex/salah-rlgwo-execution-20261009')
PLAN=Path('C:/Users/theis/Documents/Codex/celestial-startup-repair-20261008/planning-original-21e7a843/docs/rlgwo-execution/20261008')
W=RUN/'workers/r0020_day_node_exit_join_r1'
R=RUN/'workers/r0020_day_actual_exit_review_r1'
O=RUN/'integration/r0020-day-exit-join-r1'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(Path(p).read_bytes())
def enc(v): return (json.dumps(v,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode()
def save(p,v): Path(p).write_bytes(enc(v))
def pin(p): return {'path':str(p),'bytes':Path(p).stat().st_size,'sha256':sha(p)}
def sealed(folder,expected):
    assert sha(folder/'SEAL.json')==expected
    s=read(folder/'SEAL.json');m=read(folder/'MANIFEST.json');assert sha(folder/'MANIFEST.json')==s['manifestSha256']
    rows=m['files']; names=set()
    for row in rows:
        p=(folder/row['path']).resolve();assert p.is_relative_to(folder.resolve()) and row['path'] not in names
        names.add(row['path']);assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],str(p)
    assert names|{'MANIFEST.json','SEAL.json'}=={p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file()}
    assert hashlib.sha256(''.join(x['sha256']+'  '+x['path']+'\n' for x in rows).encode()).hexdigest()==s['treeSha256']==m['treeSha256']
    assert len(rows)==s['declaredFiles'];return len(rows)
def check_refs(value,seen):
    if isinstance(value,dict):
        if isinstance(value.get('path'),str) and 'sha256' in value and 'bytes' in value:
            p=Path(value['path'])
            if p.is_absolute():
                k=(str(p),value['sha256']);
                if k not in seen: assert p.stat().st_size==value['bytes'] and sha(p)==value['sha256'],str(p);seen.add(k)
        for x in value.values(): check_refs(x,seen)
    elif isinstance(value,list):
        for x in value: check_refs(x,seen)
def main():
    lp=RUN/'ACTIVE_LEDGER.json';ip=RUN/'FINAL_REVIEW_INDEX.json';lb=lp.read_bytes();ib=ip.read_bytes();l=json.loads(lb);index=json.loads(ib)
    lease=l['resourceLeases']['heavy-browser'];assert lease['status']=='FREE' and lease['holder'] is None and not lease.get('unknownChildCompletion') and not lease.get('attentionRequired')
    assert not O.exists();producer_members=sealed(W,'d53660efd710f92d63e6184c034d342b13bc2c81d79a6a4f022a1c41e0c2339c');review_members=sealed(R,'fb924ae5c5ec73f8b0d828bcede52e6e0ef30620a1eca8e5591ad8b0ad1bf344')
    review=read(R/'REPORT.json');assert sha(R/'REPORT.json')=='e8fb8106bf485ea5288a286859c9fd18784b55225c3cbb58d06f69dc370d45ee'
    assert review['status']=='PASS_R0020_DAY_NODE_LOCAL_EXIT_WITH_LIMITS' and review['reviewer']=='/root/day_source_carrier_review_r1' and review['nodeLocalEvidenceExitSatisfied'] is True and review['nodeLocalDisposition']=='PASS'
    assert sha(PLAN/'CLOSURE_DAG.json')==l['graphSha256']=='9ac372cfcce4df94ee0e678b907e66c131fe49f72cc55106143aa35dbdb0a6e7'
    graph=read(PLAN/'CLOSURE_DAG.json');assert len(graph['nodes'])==213 and len(graph['edges'])==409
    defs={n['id']:n for n in graph['nodes']};nodes={n['id']:n for n in l['nodes']};n=nodes['R0020-DAY'];assert n['progress']['state']=='EXECUTING' and not n['progress']['exitCriteriaVerified'] and not n['progress']['unmetPredecessors']
    assert [x['literal'] for x in review['ownExitDispositions']]==defs[n['id']]['exitCriteria'] and all(x['disposition']=='SATISFIED' for x in review['ownExitDispositions'])
    refs=set();check_refs(review,refs)
    binding=read(RUN/'workers/r0020_day_dispatch_repair_r1/proposed/tools/cp9/WALL_TARGET_BINDING.json');runtime=binding['runtime'];source=Path(review['reviewBinding']['sourceRoot']);assert len(runtime['files'])==139
    for relative,value in runtime['files'].items(): assert (source/relative).stat().st_size==value['bytes'] and sha(source/relative)==value['sha256'],relative
    assert hashlib.sha256(''.join(v['sha256']+'  '+k+'\n' for k,v in sorted(runtime['files'].items())).encode()).hexdigest()==runtime['treeSha256']=='e718fe9e58f37535de4dc496a2da3bf2b05808153287e1fe328398ea59c0df53'
    outputs=review['outputDispositions'];assert len(outputs)==3
    for a,b in zip(outputs,defs[n['id']]['outputs']):
        target=Path(a['canonicalTarget']);assert target.resolve()==(RUN/b['artifact']).resolve() and target.resolve().is_relative_to((RUN/'evidence/R0020/native').resolve())
        assert a['id']==b['id'] and a['canonicalRelativePath']==b['artifact'] and a['currentCanonicalPreimage'] is None and not target.exists()
        assert a['disposition']=='PASS_NODE_LOCAL_NATIVE_OUTPUT_WITH_RETAINED_VISUAL_LIMITS' and pin(Path(a['proposal']['path']))==a['proposal'] and a['postimage']=={k:a['proposal'][k] for k in ['bytes','sha256']}
    assert sha(RUN/'evidence/R0020/native/wall-fixture-contract.json')=='cdaafb8a5f3cb6ccec1776f49ef5ed8226d08477a6ab20569db0936b520eeb63'
    assert lp.read_bytes()==lb and ip.read_bytes()==ib
    O.mkdir();(O/'ACTIVE_LEDGER.before.json').write_bytes(lb);(O/'FINAL_REVIEW_INDEX.before.json').write_bytes(ib)
    canonical=[]
    for a in outputs:
        target=Path(a['canonicalTarget'])
        with target.open('xb') as f:f.write(Path(a['proposal']['path']).read_bytes())
        assert sha(target)==a['postimage']['sha256'];canonical.append(dict(id=a['id'],**pin(target)))
    now=dt.datetime.now(dt.timezone.utc).isoformat();receipt_path=O/'receipt.json'
    criteria=[{'criterion':x['literal'],'disposition':'SATISFIED','evidence':[str(R/'REPORT.json')]+[p['path'] for p in x['supportingArtifactRefs']]} for x in review['ownExitDispositions']]
    receipt={'schema':'root-reviewed-node-exit-join/1','atUtc':now,'node':n['id'],'status':'COMPLETE_OWN_EXITS_ONLY','independentReviewer':review['reviewer'],'independentReview':pin(R/'REPORT.json'),'independentReviewSeal':pin(R/'SEAL.json'),'producerSeal':pin(W/'SEAL.json'),'sourceRuntimeSha256':runtime['treeSha256'],'requiredOutputs':canonical,'requiredOutputReadbackExact':True,'criterionDispositions':criteria,'originalNativeCases':12,'originalPredicates':48,'originalPNGsReviewed':50,'heldReuseCases':2,'heldReusePredicates':48,'heldReusePNGs':12,'newNativeExecutionByJoin':False,'reviewReportToJoinSeconds':(dt.datetime.fromisoformat(now)-dt.datetime.fromisoformat(review['atUtc'])).total_seconds(),'sourceAndReviewPinsVerified':len(refs),'producerMembers':producer_members,'reviewMembers':review_members,'residualGates':review['residualGates'],'visualLimits':review['visualLimits'],'historicalFailureEvidencePreserved':True,'issueClosed':False,'mergeDeploymentAuthorized':False,'fullRuntimeEquivalenceToCurrent07':False}
    save(receipt_path,receipt)
    n['executionStatus']='COMPLETE_EXIT_VERIFIED';n['lastUpdatedAtUtc']=now;n['independentReviewer']=review['reviewer'];n['nextAction']='Consume these exact DAY outputs in separate R0020-QUALIFY; broader renderer, current07 equivalence, public delivery and issue closure remain separate.'
    n['outputReceipts']+=[x['path'] for x in canonical]+[str(receipt_path)];n['progress']['evidence']+=[x['path'] for x in canonical]+[str(R/'REPORT.json'),str(receipt_path)]
    n['progress'].update(state='COMPLETE',exitCriteriaVerified=True,completedAtUtc=now,runtime=runtime['treeSha256'],reason='Both literal DAY exits independently satisfied: actual promotion/back-late/cooldown states, 48 predicates and 50 inspected crops plus exact held reuse. Three canonical outputs joined and read back; transient visual limits and downstream qualification preserved.',exitCriteriaDisposition=criteria,owners=['root',review['reviewer']])
    for other in l['nodes']:
        other['progress']['unmetPredecessors']=[k for k in other['progress'].get('unmetPredecessors',[]) if nodes[k]['progress']['state']!='COMPLETE']
        for inp in other.get('inputs',[]):
            for c in canonical:
                if inp.get('id')==c['id'] and inp.get('producerNode')==n['id']:inp.update(status='SATISFIED',evidence=[c['path'],str(receipt_path),str(R/'REPORT.json')],sourceRuntimeSha256=runtime['treeSha256'])
    q=nodes['R0020-QUALIFY']
    if q['progress']['state']=='NOT_STARTED' and not q['progress']['unmetPredecessors']:
        q['progress'].update(state='READY',reason='All named WALL and DAY outputs independently accepted and canonically joined; exact qualification/reuse/certificate preparation may be admitted under CBAL.');q['executionStatus']='READY_FOR_INDEPENDENT_CANDIDATE_REVIEW'
    complete=sum(x['progress']['state']=='COMPLETE' for x in l['nodes']);assert complete==52
    c=l['closureDirectedProgress'];c['throughput']['completionReceipts'].append(str(receipt_path));c['throughput']['newVerifiedExits']=[n['id']]
    c['reviewJoinQueueMetrics']['consumedReviews'].append({'review':'r0020_day_actual_exit_review_r1','timestampKind':'reportAtUtc','recordedAtUtc':review['atUtc'],'rootConsumedAtUtc':now,'elapsedToRootConsumptionMinutes':receipt['reviewReportToJoinSeconds']/60,'scope':'Exact report-to-root JOIN, not transport delay or node queue age.'})
    cb=l['executionGovernance']['closureBoundAutoLoom'];finished=[b for b in cb['activeBundles'] if b['node']==n['id']];assert len(finished)==1;cb['activeBundles']=[b for b in cb['activeBundles'] if b['node']!=n['id']];cb.setdefault('completedBundles',[]).append({**finished[0],'completedAtUtc':now,'receipt':str(receipt_path),'status':'COMPLETE_OWN_EXITS_ONLY'})
    l['updatedAtUtc']=now;l['nextAction']='Consume final WALL actual/own-exit review; then admit the shortest qualifying successor within two bundles.'
    proj=index['currentExecutionProjection'];proj.update(atUtc=now,completeNodes=complete,observedIntervalExits=complete-34);proj['retainedRootExitReceipts'].append({'node':n['id'],'atUtc':now,'receipt':pin(receipt_path),'independentReviewer':review['reviewer'],'sourceManifest':runtime['treeSha256'],'nativeQualified':False,'nativeScope':'DAY exact scoped actual evidence and held reuse accepted; whole-programme native qualification remains open.','delivered':False});index['updatedAtUtc']=now
    la=enc(l);ia=enc(index);(O/'ACTIVE_LEDGER.after.json').write_bytes(la);(O/'FINAL_REVIEW_INDEX.after.json').write_bytes(ia)
    assert lp.read_bytes()==lb and ip.read_bytes()==ib
    for dest,raw in [(lp,la),(ip,ia)]:
        tmp=dest.with_suffix('.day-join.tmp');assert not tmp.exists();tmp.write_bytes(raw);os.replace(tmp,dest);assert dest.read_bytes()==raw
    save(O/'READBACK.json',{'receipt':pin(receipt_path),'ledger':pin(lp),'index':pin(ip),'canonicalOutputs':canonical,'counts':dict(collections.Counter(x['progress']['state'] for x in l['nodes']))})
    print(json.dumps({'receipt':pin(receipt_path),'counts':dict(collections.Counter(x['progress']['state'] for x in l['nodes'])),'completePercent':round(complete/213*100,2),'reviewToJoinSeconds':receipt['reviewReportToJoinSeconds']}))
if __name__=='__main__':main()
