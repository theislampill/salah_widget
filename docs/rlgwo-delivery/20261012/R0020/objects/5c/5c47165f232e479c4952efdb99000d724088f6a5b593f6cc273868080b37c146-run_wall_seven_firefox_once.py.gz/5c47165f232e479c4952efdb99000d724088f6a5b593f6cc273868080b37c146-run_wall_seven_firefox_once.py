"""Root-only proposal. Default is read-only; no native effect without explicit adoption."""
from pathlib import Path
import argparse, copy, datetime as dt, hashlib, importlib.util, json, os
import socket, struct, subprocess, sys, time
from urllib.parse import urlparse

W = Path(__file__).resolve().parent
RUN = W.parent.parent
LEDGER = RUN / 'ACTIVE_LEDGER.json'
EXACT_CELLS = [('modes', 'ordinary'), ('modes', 'scale1'), ('modes', 'scale60'), ('modes', 'frozen'), ('modes', 'sim1'), ('modes', 'sim60'), ('modes', 'broad-default')]
TTL = 600

def now(): return dt.datetime.now(dt.timezone.utc)
def iso(value): return value.isoformat()
def load(path): return json.loads(Path(path).read_bytes())
def encode(value): return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()
def save(path, value): Path(path).write_bytes(encode(value))
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def require(value, text):
    if not value: raise ValueError(text)

def sealed(root, expected):
    root = Path(root).resolve()
    require(sha(root/'SEAL.json') == expected, 'seal drift: ' + str(root))
    seal = load(root/'SEAL.json'); manifest = load(root/'MANIFEST.json')
    require(sha(root/'MANIFEST.json') == seal['manifestSha256'], 'manifest drift')
    rows = manifest['files']; names = set()
    for row in rows:
        path = (root/row['path']).resolve()
        require(path.is_relative_to(root) and row['path'] not in names, 'unsafe/duplicate sealed path')
        names.add(row['path'])
        require(path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], 'sealed byte drift: ' + row['path'])
    require(names | {'MANIFEST.json', 'SEAL.json'} == {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}, 'sealed population drift')
    tree = hashlib.sha256(''.join(r['sha256']+'  '+r['path']+'\n' for r in rows).encode()).hexdigest()
    require(tree == manifest['treeSha256'] == seal['treeSha256'] and len(rows) == seal['declaredFiles'], 'sealed tree drift')
    return seal

def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value); return value

def bindings(plan):
    for pin in plan['packets']: sealed(pin['root'], pin['sealSha256'])
    for pin in plan['toolIdentities'].values():
        path = Path(pin['path'])
        require(path.stat().st_size == pin['bytes'] and sha(path) == pin['sha256'], 'tool drift: ' + str(path))
    require(sha(plan['originalRC']['path']) == plan['originalRC']['sha256'], 'original RC drift')
    entry = Path(plan['nativeDriver'])
    require(sha(entry) == plan['nativeDriverSha256'], 'corrected native driver drift')
    extension = module(entry.parent/'r0020_wall_extension.py', 'wall_preflight_extension')
    extension.assert_current({})
    binding = load(entry.parent/'WALL_TARGET_BINDING.json')
    require(Path(binding['runRoot']).resolve() == RUN and Path(binding['candidate']).resolve() == Path(plan['sourceRoot']).resolve(), 'wrong target/root binding')
    require(len(binding['runtime']['files']) == 139 and binding['runtime']['treeSha256'] == plan['runtimeSha256'], 'runtime scope drift')
    metadata = load(plan['originalCaseMetadata'])
    require(sha(plan['originalCaseMetadata']) == plan['originalCaseMetadataSha256'] and sha(plan['originalCaseMetadataSource']['path']) == plan['originalCaseMetadataSha256'], 'original remaining-cell metadata differs')
    require(metadata['plan']['suite'] == 'wall' and metadata['plan']['name'] == plan['caseName'] and metadata['plan']['variant'] == plan['variant'] and metadata['identity'].get('counterfactual') is plan['counterfactual'], 'exact original healthy or counterfactual remaining cell required')
    require(sha(plan['originalFixture']['path']) == metadata['identity']['fixtureSha256'] == plan['originalFixture']['sha256'], 'original remaining-cell fixture differs')
    assertion = load(plan['originalAssertions'])['cells'][plan['caseId']]
    require(assertion['captureBasenames'] == plan['captureBasenames'] and sha(assertion['originalResult']['path']) == assertion['originalResult']['sha256'], 'retained original assertion/capture source differs')
    require(load(assertion['originalResult']['path'])[assertion['originalChecksField']] == assertion['expectedChecks'], 'original checks differ')
    return {'runtimeSha256': binding['runtime']['treeSha256'], 'runtimeFiles': 139, 'preparedIdentity': metadata['identity']}

def command(plan, lease_id):
    return [lease_id if value == '<FRESH_ACTUAL_LEASE_ID>' else value for value in plan['nativeArgvTemplate']]

def free(ledger):
    require(ledger.get('schema') == 'salah-active-execution/1' and Path(ledger.get('runRoot', '')).resolve() == RUN, 'wrong canonical ledger')
    row = ledger['resourceLeases']['heavy-browser']
    require(row.get('capacity') == 1 and row.get('status') == 'FREE' and row.get('holder') is None and not row.get('unknownChildCompletion') and not row.get('attentionRequired'), 'capacity not verified FREE')

def lease(plan, ledger, lease_id, instant):
    free(ledger)
    require(lease_id and lease_id.startswith('root-') and lease_id not in json.dumps(ledger.get('resourceLeaseHistory', [])) and lease_id != ledger['resourceLeases']['heavy-browser'].get('leaseId'), 'fresh root lease identity required')
    return {'capacity': 1, 'holder': 'root', 'status': 'ACTIVE', 'mode': 'ACTUAL', 'leaseId': lease_id,
        'node': 'R0020-WALL', 'command': plan['driverEntry'], 'argv': command(plan, lease_id),
        'driverSha256': plan['nativeDriverSha256'], 'sourceReviewSealSha256': plan['reviewSealSha256'],
        'runtimeSha256': plan['runtimeSha256'], 'outputPath': plan['output'], 'scope': plan['scope'],
        'startedAtUtc': iso(instant), 'expiresAtUtc': iso(instant + dt.timedelta(seconds=TTL)),
        'currentCase': plan['caseName']+'/'+plan['variant'], 'totalCases': 1, 'completedCases': 0, 'sessionId': None,
        'unknownChildCompletion': False, 'attentionRequired': False, 'automaticRetries': 0}

def active(plan, row, lease_id, instant):
    require(row.get('holder') == 'root' and row.get('status') == 'ACTIVE' and row.get('mode') == 'ACTUAL' and row.get('capacity') == 1 and row.get('leaseId') == lease_id, 'exact root ACTUAL lease required')
    require(row.get('command') == plan['driverEntry'] and row.get('argv') == command(plan, lease_id) and row.get('driverSha256') == plan['nativeDriverSha256'], 'lease driver/one-case command differs')
    require(row.get('runtimeSha256') == plan['runtimeSha256'] and row.get('sourceReviewSealSha256') == plan['reviewSealSha256'] and row.get('outputPath') == plan['output'] and row.get('totalCases') == 1 and row.get('scope') == plan['scope'], 'lease scope differs')
    start = dt.datetime.fromisoformat(row['startedAtUtc']); expiry = dt.datetime.fromisoformat(row['expiresAtUtc'])
    require(start.tzinfo and expiry.tzinfo and start <= instant < expiry and (expiry-start).total_seconds() == TTL, 'fresh finite lease required')
    require(not row.get('unknownChildCompletion') and not row.get('attentionRequired'), 'lease has unresolved completion')

def compare_write(expected, value):
    require(LEDGER.read_bytes() == expected, 'ledger changed; refusing overwrite')
    LEDGER.write_bytes(encode(value))  # Existing sole root writer; not an OS-level CAS.

def targets(plan):
    root = Path(plan['sourceRoot']).resolve(); outputs = [Path(plan['dispatchDirectory']).resolve(), Path(plan['output']).resolve()]
    for path in outputs:
        require(path.is_relative_to((RUN/'evidence/R0020').resolve()) and not path.is_relative_to(root) and not root.is_relative_to(path), 'effect output escaped exact R0020/source boundary')
        require(not os.path.lexists(path), 'fresh output required; never overwrite or replay')
    require(outputs[0] != outputs[1] and not outputs[0].is_relative_to(outputs[1]) and not outputs[1].is_relative_to(outputs[0]), 'effect outputs overlap')
    return outputs

def census(driver_pid=0, port=0):
    # Read only managed browser/Playwright executables, the exact driver PID and driver command.
    # Nothing is killed: an unexpected process refuses acquisition/release for root diagnosis.
    script = f"$ErrorActionPreference='Stop'; $p=@(Get-CimInstance Win32_Process -ErrorAction Stop | Where-Object {{($_.ExecutablePath -like '*playwright*') -or ({int(driver_pid)} -gt 0 -and $_.ProcessId -eq {int(driver_pid)}) -or ($_.Name -eq 'python.exe' -and $_.CommandLine -like '*rlgwo_wall_clock_check.py*')}} | Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CreationDate); $l=@(Get-NetTCPConnection -State Listen -ErrorAction Stop | Where-Object {{$_.LocalPort -eq {int(port)}}} | Select-Object LocalAddress,LocalPort,OwningProcess); ConvertTo-Json -InputObject @{{processes=$p;listeners=$l}} -Depth 4 -Compress"
    result = subprocess.run(['powershell.exe', '-NoProfile', '-Command', script], capture_output=True, check=True, creationflags=subprocess.CREATE_NO_WINDOW, timeout=30)
    return json.loads(result.stdout.decode('utf-8-sig'))

def socket_exit(port):
    start = time.monotonic()
    try:
        with socket.create_connection(('127.0.0.1', port), timeout=5): pass
        status = 'CONNECTED'
    except ConnectionRefusedError as error:
        return {'status': 'ConnectionRefusedError', 'error': str(error), 'elapsedSeconds': time.monotonic()-start, 'timeoutSeconds': 5, 'attempts': 1}
    except OSError as error:
        return {'status': type(error).__name__, 'error': str(error), 'elapsedSeconds': time.monotonic()-start, 'timeoutSeconds': 5, 'attempts': 1}
    return {'status': status, 'elapsedSeconds': time.monotonic()-start, 'timeoutSeconds': 5, 'attempts': 1}

def terminal(plan, output, lease_id, binding):
    manifest = load(output/'manifest.json'); result = load(output/plan['caseId']/'result.json')
    require(manifest['execution'] == 'EXECUTED_WITH_LIMITS' and manifest.get('runtimeAfterVerified') is True and manifest['leaseId'] == lease_id, 'missing exact post-finally terminal')
    require(manifest['suite'] == 'wall' and manifest['engineRequested'] == 'firefox' and manifest['driverSha256'] == plan['nativeDriverSha256'], 'terminal engine/driver differs')
    require(len(manifest['inputs']) == len(manifest['results']) == 1 and manifest['inputs'][0]['case'] == plan['caseName'] and manifest['inputs'][0]['variant'] == plan['variant'] and manifest['inputs'][0]['identity'] == binding['preparedIdentity'] and result.get('source') == binding['preparedIdentity'], 'one original input identity differs')
    require(manifest['results'] == [{'case': plan['caseName'], 'variant': plan['variant'], 'status': result['status']}] and result['case'] == plan['caseName'] and result['variant'] == plan['variant'], 'exact one-case terminal/result differs')
    require(result.get('status') == plan['expectedNativeStatus'], 'original per-cell healthy/mutant disposition differs; never normalize an unexpected negative or failure')
    require(manifest['wallBinding']['runtimeSha256'] == plan['runtimeSha256'] and manifest['wallBinding']['runtimeFiles'] == 139, 'terminal runtime differs')
    require(Path(manifest['browser']['executable']).resolve() == Path(plan['toolIdentities']['firefox']['path']).resolve() and manifest['browser']['family'] == 'firefox', 'terminal browser differs')
    require(manifest['executionEnvironment']['python'] == plan['toolIdentities']['nativePython'] and manifest['executionEnvironment']['playwrightVersion'] == plan['observedAdapterVersion'], 'actual native Python/SDK identity differs from explicit pair')
    url = urlparse(result['url'])
    require(url.scheme == 'http' and url.hostname == '127.0.0.1' and url.port and url.path == '/index.html', 'actual served origin missing')
    return manifest, result, url.port

def finish(ledger, lease_id, known, receipt):
    result = copy.deepcopy(ledger); row = result['resourceLeases']['heavy-browser']
    require(row.get('holder') == 'root' and row.get('status') == 'ACTIVE' and row.get('mode') == 'ACTUAL' and row.get('leaseId') == lease_id, 'ownership changed; never free another lease')
    row.update(status='FREE' if known else 'ATTENTION_REQUIRED', holder=None if known else 'root',
        unknownChildCompletion=not known, attentionRequired=not known, finishedAtUtc=iso(now()), lastResult=receipt,
        reason='Known driver/managed-process/socket exit and current source/runtime; independent actual review remains' if known else 'Unknown exit/currentness; preserve output and root ownership, no automatic retry')
    if known: row.update(completedCases=1, currentCase=None)
    result['updatedAtUtc'] = iso(now()); return result

def firefox_admission(plan, args):
    require(args.admit_review and args.admit_review not in plan['prohibitedCaseReviewSeals'], 'distinct remaining-Firefox source/case review required; prior singleton/Chromium authority cannot be reused')
    review_root = Path(plan['firefoxCaseReviewRoot']).resolve()
    sealed(review_root, args.admit_review)
    report = load(review_root/'REPORT.json')
    expected = {**plan['firefoxAdmissionRequiredFields'], 'carrierSealSha256': args.expected_seal, 'firstActualBinding': first_actual(plan, args.first_dispatch_sha256), 'rootRecoveryBinding': root_recovery(plan)}
    require(report.get('status') == 'PASS_SOURCE_CASE_PREFLIGHT_ONLY' and report.get('admissionBinding') == expected, 'remaining-Firefox source/case/command/first-actual admission differs')
    admitted = copy.deepcopy(plan); admitted['reviewSealSha256'] = args.admit_review
    return admitted

def execute(plan, args):
    require(not sys.flags.optimize and sys.flags.isolated and sys.flags.no_site, 'run root wrapper with -I -S -B; assertions must stay enabled')
    require(args.expected_seal and args.admit_review, 'root must adopt first-Firefox carrier and admit distinct source/case review')
    sealed(W, args.expected_seal); plan = firefox_admission(plan, args); bound = bindings(plan); dispatch, output = targets(plan)
    sdk = subprocess.run([plan['toolIdentities']['nativePython']['path'], '-I', '-B', str(W/'check_sdk_import.py')], capture_output=True, timeout=30)
    require(sdk.returncode == 0, 'actual wall-path SDK import refused before any lease/evidence/native effects: ' + sdk.stderr.decode('utf-8', errors='replace')[-1000:])
    sdk_before = json.loads(sdk.stdout)
    require(sdk_before.get('status') == 'PASS_IMPORT_ONLY_NO_NATIVE_EFFECT' and sdk_before.get('driverSha256') == plan['nativeDriverSha256'], 'SDK import readback differs')
    before = LEDGER.read_bytes(); ledger = json.loads(before); actual = lease(plan, ledger, args.lease_id, now())
    initial = census(); require(initial['processes'] == [], 'managed browser still present; root recovery required')
    acquired = copy.deepcopy(ledger); acquired.setdefault('resourceLeaseHistory', []).append({'atUtc': iso(now()), 'resource': 'heavy-browser', 'before': ledger['resourceLeases']['heavy-browser']})
    actual['wrapperSealSha256'] = args.expected_seal; actual['wrapperSha256'] = sha(__file__)
    acquired['resourceLeases']['heavy-browser'] = actual; acquired['updatedAtUtc'] = iso(now())
    dispatch.mkdir(parents=True, exist_ok=False); (dispatch/'ACTIVE_LEDGER.before.json').write_bytes(before)
    receipt = {'schema': 'root-wall-css-one-original-case-dispatch/1', 'status': 'PREPARING', 'mode': 'ACTUAL', 'leaseId': args.lease_id,
        'command': actual['argv'], 'authorSealSha256': plan['authorSealSha256'], 'reviewSealSha256': plan['reviewSealSha256'],
        'wrapperSealSha256': args.expected_seal, 'wrapperSha256': sha(__file__), 'sourceBefore': bound, 'sdkImportBefore': sdk_before, 'processesBefore': initial,
        'scope': plan['scope'], 'automaticRetries': 0, 'nodeCredit': 0, 'pixelsQualified': False, 'nativeDriverStarted': False}
    save(dispatch/'dispatch.json', receipt)
    compare_write(before, acquired)
    known = False; process = None
    try:
        readback = LEDGER.read_bytes(); require(json.loads(readback)['resourceLeases']['heavy-browser'] == actual, 'lease acquired readback differs')
        (dispatch/'ACTIVE_LEDGER.acquired.json').write_bytes(readback)
        active(plan, load(LEDGER)['resourceLeases']['heavy-browser'], args.lease_id, now()); bindings(plan)
        env = os.environ.copy(); env['SALAH_BROWSER_EXECUTABLE'] = plan['toolIdentities']['firefox']['path']
        with (dispatch/'stdout.log').open('wb') as stdout, (dispatch/'stderr.log').open('wb') as stderr:
            process = subprocess.Popen(actual['argv'], stdout=stdout, stderr=stderr, env=env, creationflags=subprocess.CREATE_NO_WINDOW)
            receipt.update(nativeDriverStarted=True, driverProcessId=process.pid, startedAtUtc=iso(now())); save(dispatch/'dispatch.json', receipt)
            remaining = (dt.datetime.fromisoformat(actual['expiresAtUtc'])-now()).total_seconds()
            receipt['exitCode'] = process.wait(timeout=max(0, remaining)); receipt['driverExitObserved'] = True
        manifest, result, port = terminal(plan, output, args.lease_id, bound)
        sealed(W, args.expected_seal); receipt['sourceAfter'] = bindings(plan); receipt['actualServerPort'] = port
        receipt['processesAfter'] = census(process.pid, port); receipt['socketExit'] = socket_exit(port)
        known = receipt['processesAfter']['processes'] == [] and receipt['processesAfter']['listeners'] == [] and receipt['socketExit']['status'] == 'ConnectionRefusedError'
        passive = subprocess.run([plan['toolIdentities']['python311']['path'], '-I', '-S', '-B', plan['passiveReadback'], '--result', str(output/plan['caseId']/'result.json'), '--cell', plan['caseId']], capture_output=True, timeout=30)
        (dispatch/'passive.stdout.json').write_bytes(passive.stdout); (dispatch/'passive.stderr.log').write_bytes(passive.stderr)
        receipt['passiveReadbackExit'] = passive.returncode
        receipt['originalCellFullPNGs'] = []
        for name in plan['captureBasenames']:
            path = output/plan['caseId']/f'{name}.png'; raw = path.read_bytes()
            require(raw[:8] == b'\x89PNG\r\n\x1a\n' and raw[12:16] == b'IHDR' and struct.unpack('>II', raw[16:24]) == (325, 530), 'original full PNG missing or dimensions differ')
            receipt['originalCellFullPNGs'].append({'path': str(path), 'bytes': len(raw), 'sha256': sha(path), 'dimensions': [325, 530]})
        receipt['originalAssertionsExact'] = result.get('checks') == load(plan['originalAssertions'])['cells'][plan['caseId']]['expectedChecks']
        receipt['originalRCUnchanged'] = sha(plan['originalRC']['path']) == plan['originalRC']['sha256']
        receipt['manifestSha256'] = sha(output/'manifest.json'); receipt['resultSha256'] = sha(output/plan['caseId']/'result.json'); receipt['namedOutputs'] = manifest.get('namedOutputs'); receipt['earlyDAYInterfaceConsumable'] = False
        receipt['status'] = 'RETURNED_KNOWN_EXIT_PENDING_INDEPENDENT_ACTUAL_REVIEW' if known else 'ATTENTION_REQUIRED_UNKNOWN_EXIT'
    except BaseException as error:
        receipt.update(status='RETURNED_KNOWN_EXIT_OUTPUT_DIAGNOSIS_REQUIRED' if known else 'ATTENTION_REQUIRED_NO_AUTOMATIC_RETRY', error=type(error).__name__+': '+str(error))
        if not receipt.get('driverExitObserved'): known = False
        if process is not None: receipt['driverPollAtFailure'] = process.poll()
    finally:
        receipt.update(knownExit=known, finishedAtUtc=iso(now()), processCleanupByWrapper=False, automaticRetries=0)
        save(dispatch/'dispatch.json', receipt)
        release_before = LEDGER.read_bytes(); save(dispatch/'lease.after.before-release.json', json.loads(release_before)['resourceLeases']['heavy-browser'])
        try:
            final = finish(json.loads(release_before), args.lease_id, known, str(dispatch/'dispatch.json'))
            compare_write(release_before, final)
            final_bytes = LEDGER.read_bytes(); require(json.loads(final_bytes) == final, 'lease after readback differs')
            (dispatch/'ACTIVE_LEDGER.after.json').write_bytes(final_bytes); receipt['capacityAfter'] = final['resourceLeases']['heavy-browser']['status']
        except BaseException as error:
            receipt.update(capacityAfter='UNKNOWN_OWNERSHIP_OR_WRITE_REQUIRES_ROOT_READBACK', releaseError=type(error).__name__+': '+str(error), status='ATTENTION_REQUIRED_NO_AUTOMATIC_RETRY')
        save(dispatch/'dispatch.json', receipt)
    print(json.dumps({'status': receipt['status'], 'capacityAfter': receipt.get('capacityAfter'), 'receipt': str(dispatch/'dispatch.json'), 'pixelsQualified': False, 'nodeCredit': 0}))
    return 0 if known and receipt.get('capacityAfter') == 'FREE' and receipt.get('exitCode') == 0 and receipt.get('passiveReadbackExit') == 0 and len(receipt.get('originalCellFullPNGs', [])) == len(plan['captureBasenames']) and receipt.get('originalAssertionsExact') and receipt.get('originalRCUnchanged') else 2

def first_actual(plan, expected_dispatch_sha256):
    gate = module(W/'first_firefox_gate.py', 'remaining_firefox_first_gate')
    return gate.bind(plan, expected_dispatch_sha256)

def root_recovery(plan):
    contract = plan.get('rootAdministrativeRecovery')
    require(contract and contract.get('receipt'), 'actual root administrative recovery receipt required before new admission; failed visibility cannot advance automatically')
    proof = contract['receipt']; path = Path(proof['path'])
    require(path.stat().st_size == proof['bytes'] and sha(path) == proof['sha256'], 'root administrative recovery receipt drift')
    failed = plan['priorR6FailedVisibilityDispatch']
    require(Path(failed['path']).stat().st_size == failed['bytes'] and sha(failed['path']) == failed['sha256'], 'preserved R6 visibility failure drift')
    return contract


def cell_plans(plan):
    cells = plan['cells']
    require([(c['caseName'], c['variant']) for c in cells] == EXACT_CELLS, 'only exact seven unrun original Firefox modes allowed')
    result = []
    for cell in cells:
        require(cell['caseId'] == cell['caseName']+'--'+cell['variant'], 'cell identity differs')
        selected = {**plan, **cell}
        expected = [plan['toolIdentities']['nativePython']['path'], '-I', '-B', plan['driverEntry'], '--root', plan['sourceRoot'], '--engine', 'firefox', '--cases', cell['caseName'], '--variants', cell['variant'], '--expected-source-sha256', plan['expectedSourceSha256'], '--node', plan['toolIdentities']['node']['path'], '--output', cell['output'], '--execute', '--lease-id', '<FRESH_ACTUAL_LEASE_ID>']
        require(cell['nativeArgvTemplate'] == expected, 'exact original scalar case/variant command differs')
        result.append(selected)
    require(len({c['dispatchDirectory'] for c in cells}) == len({c['output'] for c in cells}) == 7, 'seven distinct fresh original Firefox mode outputs required')
    return result

def run_cells(plans, args):
    require(args.lease_prefix and args.lease_prefix.startswith('root-') and all(c.isalnum() or c in '-_' for c in args.lease_prefix), 'fresh root lease prefix required')
    for plan in plans:
        selected = copy.copy(args); selected.lease_id = args.lease_prefix+'-'+plan['caseId']
        code = execute(plan, selected)
        if code != 0: return code  # First nonzero/missing-output/unknown-cleanup stop; no retry or next case.
        receipt = load(Path(plan['dispatchDirectory'])/'dispatch.json')
        require(receipt.get('status') == 'RETURNED_KNOWN_EXIT_PENDING_INDEPENDENT_ACTUAL_REVIEW' and not receipt.get('error') and not receipt.get('releaseError'), 'returned cell records an exception or diagnosis; stop before any next case')
    print(json.dumps({'status': 'SEVEN_ORIGINAL_FIREFOX_MODE_CELLS_RETURNED_PENDING_INDEPENDENT_ACTUAL_REVIEW', 'cellCount': 7, 'pixelsQualified': False, 'nodeCredit': 0}))
    return 0

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true'); parser.add_argument('--expected-seal'); parser.add_argument('--admit-review'); parser.add_argument('--lease-prefix'); parser.add_argument('--first-dispatch-sha256')
    args = parser.parse_args(); plan = load(W/'ROOT_COMMAND.json'); plans = cell_plans(plan)
    if args.execute:
        require(not sys.flags.optimize and sys.flags.isolated and sys.flags.no_site, 'run root wrapper with -I -S -B')
        sealed(W, args.expected_seal); firefox_admission(plan, args)
    checks = [bindings(selected) for selected in plans]
    for selected in plans: targets(selected)  # Refuse every partial/consumed batch before its first effect.
    if args.execute: return run_cells(plans, args)
    first_binding = first_actual(plan, args.first_dispatch_sha256) if args.first_dispatch_sha256 else None
    ledger = load(LEDGER)
    print(json.dumps({'status': 'PASS_SOURCE_PREFLIGHT_NO_NATIVE_EFFECT', 'cells': [{'case': c['caseName'], 'variant': c['variant'], 'binding': b, 'nativeArgvTemplate': c['nativeArgvTemplate']} for c,b in zip(plans, checks)], 'runtimeFiles': 139, 'runtimeSha256': plan['runtimeSha256'], 'firstActualBinding': first_binding, 'firstActualGate': 'SATISFIED_RAW_PREREQUISITE_ONLY' if first_binding else 'PENDING_UNASSERTED_NO_EXECUTION_ADMISSION', 'ledgerSha256': sha(LEDGER), 'heavyBrowserReadback': ledger['resourceLeases']['heavy-browser'], 'nativeExecuted': False, 'nodeComplete': False}))
    return 0
if __name__ == '__main__': raise SystemExit(main())
