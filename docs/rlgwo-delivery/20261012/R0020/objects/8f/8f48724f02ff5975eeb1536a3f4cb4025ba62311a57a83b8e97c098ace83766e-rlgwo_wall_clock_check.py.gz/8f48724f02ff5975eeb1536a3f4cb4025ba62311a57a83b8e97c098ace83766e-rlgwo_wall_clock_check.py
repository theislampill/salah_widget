from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from rlgwo_native_checks import main
if __name__=='__main__':main('wall')
