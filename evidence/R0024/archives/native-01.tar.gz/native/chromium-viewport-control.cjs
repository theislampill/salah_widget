const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto');
const core='C:/Users/theis/AppData/Local/Microsoft/WinGet/Packages/OpenJS.NodeJS.LTS_Microsoft.Winget.Source_8wekyb3d8bbwe/node-v24.15.0-win-x64/node_modules/playwright/node_modules/playwright-core';
const {chromium}=require(core),root=__dirname,out=path.join(root,'chromium-viewport-control-r1');
const exe='C:/Users/theis/AppData/Local/ms-playwright/chromium-1223/chrome-win64/chrome.exe',sleep=ms=>new Promise(r=>setTimeout(r,ms));
const r={schema:'r0024-native-viewport-control/v1',scope:'Owned blank static control only; no product credit',observerSha256:crypto.createHash('sha256').update(fs.readFileSync(__filename)).digest('hex'),steps:[]};
(async()=>{fs.mkdirSync(out);const lock=path.join(root,'native-resource.lock');fs.writeFileSync(lock,JSON.stringify({pid:process.pid,kind:'serial blank Chrome viewport discriminator'}),{flag:'wx'});let child,browser;
try{
 const profile=path.join(out,'profile');fs.mkdirSync(profile);const log=fs.openSync(path.join(out,'browser.log'),'w');child=cp.spawn(exe,['--headless','--no-first-run','--no-default-browser-check','--remote-debugging-port=0','--user-data-dir='+profile,'about:blank'],{windowsHide:true,stdio:['ignore',log,log]});
 const active=path.join(profile,'DevToolsActivePort');for(let i=0;i<100&&!fs.existsSync(active);i++)await sleep(100);const lines=fs.readFileSync(active,'utf8').trim().split('\n');browser=await chromium.connectOverCDP('ws://127.0.0.1:'+lines[0]+lines[1],{noDefaults:true});
 const context=browser.contexts()[0],page=await context.newPage(),session=await context.newCDPSession(page);
 await session.send('Emulation.setDeviceMetricsOverride',{width:390,height:600,deviceScaleFactor:1,mobile:false});
 await page.setContent('<style>body{margin:0}.c{width:325px;height:530px;background:#173f22;color:white;box-sizing:border-box;border-bottom:12px solid red}</style><div class="c">Owned static control<br>Visible bottom is red</div>');
 const shot=async name=>{const metrics=await session.send('Page.getLayoutMetrics');const env=await page.evaluate(()=>({width:innerWidth,height:innerHeight,dpr:devicePixelRatio,visual:{width:visualViewport.width,height:visualViewport.height}}));await page.locator('.c').screenshot({path:path.join(out,name+'.png')});r.steps.push({name,metrics,env});};
 await shot('manual-metrics');await page.setViewportSize({width:390,height:600});await shot('driver-viewport');r.status='OBSERVED';
}catch(e){r.status='FAILED';r.exception=e.stack;}
finally{if(browser)try{await browser.close();}catch{}if(child&&!child.killed)child.kill();fs.writeFileSync(path.join(out,'receipt.json'),JSON.stringify(r,null,2));fs.unlinkSync(lock);console.log(JSON.stringify(r));}})();
