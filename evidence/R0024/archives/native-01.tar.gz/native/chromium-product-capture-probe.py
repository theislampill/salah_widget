"""Bounded original-product capture discriminator. No qualification credit."""
import argparse,hashlib,json,sys,traceback
from pathlib import Path
ROOT=Path(r'C:\Users\theis\.codex\worktrees\r0024-execution\salah_widget')
sys.path.insert(0,str(ROOT/'tools/qa'))
import run_r0024_native as native
import run_r0024_resume as resume

def probe(page,context,base,spec,engine,out):
    session=page.context.new_cdp_session(page);browser=page.context.browser.new_browser_cdp_session()
    target=session.send('Target.getTargetInfo')['targetInfo']['targetId'];r={'schema':'r0024-product-capture-discriminator/v1','observerSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'fixture':page.evaluate('()=>__weatherCases.identity()'),'steps':[]}
    def capture(name):
        x={'name':name,'layout':session.send('Page.getLayoutMetrics'),'ownWindow':browser.send('Browser.getWindowForTarget',{'targetId':target}),'state':native.observation(page)}
        page.locator('.c').screenshot(path=str(out/(name+'.png')));r['steps'].append(x)
    capture('manual-metrics-first')
    page.set_viewport_size({'width':390,'height':600})
    capture('driver-viewport-next')
    page.screenshot(path=str(out/'whole-viewport.png'));page.screenshot(path=str(out/'whole-page.png'),full_page=True)
    native.write_json(out/'capture-discriminator.json',r)
    raise RuntimeError('Intentional capture-only diagnostic stop: no lifecycle qualification claim')

if __name__=='__main__':
    native.suspension=probe
    raise SystemExit(resume.main())
