"""Index retained native evidence without converting execution into qualification."""
import hashlib,json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
SOURCE=Path(r'C:\Users\theis\.codex\worktrees\r0024-execution\salah_widget')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))

registry=read(SOURCE/'tests/weather-native/cases.json')
entry=sha(SOURCE/'index.html')
report={'schema':'r0024-native-retained-index/v1','entrySha256':entry,
        'claim':'Native execution predicates only; pixels, accessibility scope, motion and whole-obligation review remain independent gates',
        'engines':{},'retainedFailures':[]}
for engine in ['chromium','firefox']:
    declared=[r['id'] for r in registry if engine in r.get('engines',['chromium','firefox'])]
    by_id={};phases=[]
    for path in sorted((ROOT/engine).glob('*/results.json')):
        data=read(path);phase={'path':str(path.relative_to(ROOT)), 'sha256':sha(path),
             'status':data['status'],'inputSha256':data['admissionSha256'],
             'runtimeSha256':data['preflight']['runtimeSha256'],
             'postflightMatched':data.get('sourcePostflight')==data['preflight']}
        phases.append(phase)
        for row in data['cases']:
            record={'id':row['id'],'phase':path.parent.name,'status':row['status'],
                    'sameRuntime':row.get('fixtureIdentity',{}).get('sourceSha256')==entry,
                    'receipt':str((path.parent/row['id']/'receipt.json').relative_to(ROOT)),
                    'failedChecks':[k for k,v in row.get('checks',{}).items() if v is False]}
            receipt=ROOT/record['receipt']
            record['receiptSha256']=sha(receipt) if receipt.exists() else None
            if row['status']=='EXECUTED_PENDING_PIXEL_AND_INDEPENDENT_REVIEW' and record['sameRuntime'] and phase['postflightMatched']:
                by_id[row['id']]=record
            else:report['retainedFailures'].append({'engine':engine,**record})
    report['engines'][engine]={'declared':len(declared),'executedCurrent':len(by_id),
        'missing':[c for c in declared if c not in by_id], 'cases':[by_id[c] for c in declared if c in by_id], 'phases':phases}
out=ROOT/'retained-index.json'
out.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({e:{k:v for k,v in x.items() if k in ['declared','executedCurrent','missing']} for e,x in report['engines'].items()},indent=2))
