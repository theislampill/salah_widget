"""Bounded blank-page native focus-reset capability; not product qualification."""
import hashlib,json,os,socket,subprocess,time,traceback
from pathlib import Path

ROOT=Path(__file__).resolve().parent
EXE=Path(r'C:\Users\theis\AppData\Local\ms-playwright\firefox-1522\firefox\firefox.exe')
RESET="const d=window.docShell; const before={force:d.forceActiveState,focus:d.overrideHasFocus}; d.forceActiveState=false; d.overrideHasFocus=false; return {before,after:{force:d.forceActiveState,focus:d.overrideHasFocus},visibility:document.visibilityState};"
READ="return {visibility:document.visibilityState,focus:document.hasFocus(),events:window.__r24capabilityEvents};"
class Marionette:
 def __init__(self,sock):self.sock=sock;self.serial=0;self.commands=[];self.hello=self.receive()
 def receive(self):
  length=b''
  while not length.endswith(b':'):
   part=self.sock.recv(1)
   if not part:raise EOFError('Native socket closed')
   length+=part
  size=int(length[:-1]);data=b''
  while len(data)<size:
   part=self.sock.recv(size-len(data))
   if not part:raise EOFError('Native socket closed')
   data+=part
  return json.loads(data)
 def call(self,name,params):
  self.serial+=1;wire=json.dumps([0,self.serial,name,params]).encode();start=time.monotonic();self.sock.sendall(str(len(wire)).encode()+b':'+wire);response=self.receive()
  self.commands.append({'name':name,'params':params,'response':response,'elapsedMs':(time.monotonic()-start)*1000})
  if response[0]!=1 or response[1]!=self.serial or response[2] is not None:raise RuntimeError(str(response))
  return response[3]
 def script(self,script,system=False):return self.call('WebDriver:ExecuteScript',{'script':script,'args':[],'newSandbox':True,'sandbox':'system' if system else None})

def main():
 out=ROOT/'firefox-focus-capability-r1';out.mkdir();lock=ROOT/'native-resource.lock'
 with lock.open('x',encoding='utf8') as f:json.dump({'pid':os.getpid(),'kind':'serial blank Firefox native focus capability','out':str(out)},f)
 result={'schema':'r0024-firefox-native-focus-capability/v1','scope':'Blank owned disposable browser only; no product credit','observerSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'executable':str(EXE),'executableSha256':hashlib.sha256(EXE.read_bytes()).hexdigest(),'steps':[]};p=None;sock=None;client=None
 try:
  profile=out/'profile';profile.mkdir();port_socket=socket.socket();port_socket.bind(('127.0.0.1',0));port=port_socket.getsockname()[1];port_socket.close()
  prefs={'marionette.port':port,'browser.shell.checkDefaultBrowser':False,'browser.startup.homepage':'about:blank','datareporting.policy.dataSubmissionEnabled':False,'toolkit.telemetry.enabled':False,'app.update.auto':False,'network.captive-portal-service.enabled':False,'network.connectivity-service.enabled':False}
  (profile/'user.js').write_text('\n'.join('user_pref('+json.dumps(k)+','+json.dumps(v)+');' for k,v in prefs.items()),encoding='utf8')
  command=[str(EXE),'-headless','-no-remote','-profile',str(profile),'--marionette','--remote-allow-system-access','about:blank'];result['launch']=command;result['preferences']=prefs
  with (out/'browser.log').open('w',encoding='utf8') as log:
   p=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
   end=time.monotonic()+20
   while time.monotonic()<end:
    if p.poll() is not None:raise RuntimeError('Owned browser exited')
    try:sock=socket.create_connection(('127.0.0.1',port),timeout=1);break
    except OSError:time.sleep(.1)
   if sock is None:raise RuntimeError('Owned Marionette endpoint unavailable')
   sock.settimeout(20);client=Marionette(sock);result['hello']=client.hello;result['session']=client.call('WebDriver:NewSession',{'capabilities':{'alwaysMatch':{}}})
   subject=client.call('WebDriver:GetWindowHandle',{})['value'];result['subject']=subject
   client.script("window.__r24capabilityEvents=[];document.addEventListener('visibilitychange',e=>window.__r24capabilityEvents.push({type:e.type,trusted:e.isTrusted,visibility:document.visibilityState,monotonic:performance.now()}));")
   result['steps'].append({'name':'before-reset','value':client.script(READ)})
   result['steps'].append({'name':'native-override-reset','value':client.script(RESET,True)})
   helper=client.call('WebDriver:NewWindow',{'type':'tab','focus':True});result['helper']=helper
   time.sleep(.5);result['steps'].append({'name':'helper-activated-subject-still-selected-for-script','value':client.script(READ)})
   client.call('WebDriver:SwitchToWindow',{'handle':subject,'focus':True});time.sleep(.5);result['steps'].append({'name':'subject-reactivated','value':client.script(READ)})
   result['status']='OBSERVED'
 except Exception:result['status']='FAILED';result['exception']=traceback.format_exc()
 finally:
  if client:
   result['commands']=client.commands
   try:client.call('Marionette:Quit',{'flags':['eForceQuit']})
   except Exception:pass
  if sock:sock.close()
  if p:
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=5)
  (out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');lock.unlink();print(json.dumps(result))
if __name__=='__main__':main()
