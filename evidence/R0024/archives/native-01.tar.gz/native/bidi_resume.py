"""Three owned Firefox tab-resume controls through its existing native BiDi agent.
No Juggler, privileged script, synthetic event, host UI, or new recorder.
"""
import argparse,base64,hashlib,importlib.util,json,os,socket,subprocess,time,traceback
from pathlib import Path
from urllib.parse import urlencode
from websockets.sync.client import connect

ROOT=Path(r'C:\Users\theis\.codex\worktrees\r0024-execution\salah_widget')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def require(ok,why):
    if not ok:raise AssertionError(why)
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
native=load('r24_native',ROOT/'tools/qa/run_r0024_native.py')

class Client:
    def __init__(self,ws):self.ws=ws;self.serial=0;self.events=[];self.commands=[]
    def call(self,method,params):
        self.serial+=1;number=self.serial;self.ws.send(json.dumps({'id':number,'method':method,'params':params}));start=time.monotonic()
        while True:
            response=json.loads(self.ws.recv(timeout=40))
            if response.get('id')!=number:self.events.append(response);continue
            self.commands.append({'id':number,'method':method,'params':params,'elapsedMs':(time.monotonic()-start)*1000,'responseType':response.get('type'),'responseSha256':hashlib.sha256(json.dumps(response,sort_keys=True).encode()).hexdigest()})
            require(response.get('type')!='error',str(response));return response['result']
    def evaluate(self,context,fn,arg=None):
        result=self.call('script.callFunction',{'target':{'context':context},'awaitPromise':True,'functionDeclaration':'async () => JSON.stringify(await ('+fn+')('+json.dumps(arg,ensure_ascii=True)+'))'})
        require(result['type']=='success',str(result));value=result['result'];require(value['type']=='string',str(value));return json.loads(value['value'])
    def wait(self,context,fn,timeout=10):
        end=time.monotonic()+timeout
        while time.monotonic()<end:
            if self.evaluate(context,fn):return
            time.sleep(.1)
        raise TimeoutError('Actual native predicate timeout: '+fn)
    def shot(self,context,path):
        result=self.call('browsingContext.captureScreenshot',{'context':context,'origin':'viewport','format':{'type':'image/png'},'clip':{'type':'box','x':0,'y':0,'width':325,'height':530}})
        path.write_bytes(base64.b64decode(result['data']))

def case_run(args,server,spec,attempt,out):
    profile=out/'disposable-profile';profile.mkdir();port_socket=socket.socket();port_socket.bind(('127.0.0.1',0));port=port_socket.getsockname()[1];port_socket.close()
    preferences={'browser.startup.homepage':'about:blank','browser.shell.checkDefaultBrowser':False,'browser.startup.homepage_override.mstone':'ignore','datareporting.policy.dataSubmissionEnabled':False,'toolkit.telemetry.enabled':False,'app.update.auto':False,'network.captive-portal-service.enabled':False,'network.connectivity-service.enabled':False}
    (profile/'user.js').write_text('\n'.join('user_pref('+json.dumps(k)+','+json.dumps(v)+');' for k,v in preferences.items()),encoding='utf-8')
    command=[str(args.executable),'-headless','-no-remote','-profile',str(profile),'--remote-debugging-port',str(port),'about:blank']
    row={'id':spec['id'],'input':spec,'status':'NOT_RUN','driver':'Firefox built-in WebDriver BiDi; no -juggler-pipe','observerSha256':sha(Path(__file__)),'profilePreferences':preferences,'launch':command,'checks':{}}
    log=(out/'browser.log').open('w',encoding='utf-8');process=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW);ws=None;client=None;subject=None
    try:
        end=time.monotonic()+20
        while time.monotonic()<end:
            require(process.poll() is None,'Browser exited before BiDi')
            try:ws=connect('ws://127.0.0.1:'+str(port)+'/session',open_timeout=1,max_size=None);break
            except (OSError,TimeoutError):time.sleep(.1)
        require(ws is not None,'BiDi endpoint unavailable');client=Client(ws)
        row['session']=client.call('session.new',{'capabilities':{'alwaysMatch':{'acceptInsecureCerts':False}}})
        client.call('session.subscribe',{'events':['log.entryAdded']})
        subject=client.call('browsingContext.getTree',{})['contexts'][0]['context']
        client.call('browsingContext.setViewport',{'context':subject,'viewport':{'width':390,'height':600},'devicePixelRatio':1})
        client.call('emulation.setTimezoneOverride',{'contexts':[subject],'timezone':'Asia/Riyadh'})
        cfg={'lat':24.47,'lon':39.61,'tz':'Asia/Riyadh','label':'Weather fixture','method':4,'school':0,'units':'c','seed':1}
        if spec.get('preview'):cfg['timeScale']=1
        if spec.get('local'):cfg['local']=1
        url=server.origin+'/fixture.html?'+urlencode({'case':spec['id'],'attempt':attempt,'run':args.run,'mode':'healthy','source':sha(ROOT/'index.html')})+'#'+urlencode(cfg);row['url']=url
        client.call('browsingContext.navigate',{'context':subject,'url':url,'wait':'interactive'})
        client.wait(subject,"()=>window.__widgetFixture?.state==='ready'||window.__widgetFixture?.state==='error'")
        require(client.evaluate(subject,"()=>__widgetFixture.state")=='ready','Fixture failed')
        client.wait(subject,"()=>{const s=__weatherCases.read(__weatherCases.identity());return s.qa.cache.prayerLoaded&&!s.wxBusy&&!s.radarBusy&&!!s.information.header;}")
        row['environment']=client.evaluate(subject,"()=>({width:innerWidth,height:innerHeight,dpr:devicePixelRatio,zone:Intl.DateTimeFormat().resolvedOptions().timeZone,reduced:matchMedia('(prefers-reduced-motion:reduce)').matches,agent:navigator.userAgent})")
        row['checks']['exactEnvironment']=row['environment']['width']==390 and row['environment']['height']==600 and row['environment']['dpr']==1 and row['environment']['zone']=='Asia/Riyadh' and not row['environment']['reduced']
        row['seedDescriptions']=client.evaluate(subject,native.approved_seed());row['fixtureIdentity']=client.evaluate(subject,'()=>__weatherCases.identity()');row['actionReceipts']=[]
        for i,value in enumerate(spec.get('actions',[])):row['actionReceipts'].append(client.evaluate(subject,'i=>__weatherCases.step(__weatherCases.identity(),i)',i))
        client.wait(subject,"()=>{const s=__weatherCases.read(__weatherCases.identity());return s.precip==='on'&&s.visibleParticles>0;}")
        observe='()=>__r24NativeControl.read(__r24NativeControl.identity())';particles="()=>[...document.querySelectorAll('.drop,.flake')].map(e=>({class:e.className,left:e.style.left,delay:e.style.animationDelay}))"
        before=client.evaluate(subject,observe);history=client.evaluate(subject,particles);client.shot(subject,out/'before-suspension.png');row['before']=before
        helper=client.call('browsingContext.create',{'type':'tab','referenceContext':subject,'background':False})['context'];client.call('browsingContext.activate',{'context':helper})
        client.wait(subject,"()=>document.visibilityState==='hidden'&&document.querySelector('.c').classList.contains('paused')",3);row['hidden']=client.evaluate(subject,observe)
        time.sleep(spec['suspend']['seconds']);client.call('browsingContext.activate',{'context':subject})
        client.wait(subject,"()=>document.visibilityState==='visible'&&!document.querySelector('.c').classList.contains('paused')",3)
        client.wait(subject,"()=>{const s=__weatherCases.read(__weatherCases.identity());return s.precip==='off'&&s.visibleParticles===0&&s.information.description===s.information.header.information.summary;}")
        after=client.evaluate(subject,observe);row['after']=after;client.shot(subject,out/'expired-after-resume.png')
        checks=row['checks'];events=after['nativeEvents']
        checks.update(actualTrustedHiddenAndVisible=all(any(e['type']=='visibilitychange' and e['trusted'] is True and e['visibility']==v for e in events) for v in ['hidden','visible']),expiredWetWithdrawn=after['state']['precip']=='off' and after['state']['visibleParticles']==0 and after['state']['lightning']=='off',cloudPopulationRetained=before['cloud']['motion']['key']==after['cloud']['motion']['key'] and before['cloud']['motion']['population']==after['cloud']['motion']['population'] and before['cloud']['fieldSeed']==after['cloud']['fieldSeed'],particleHistoryRetained=history==client.evaluate(subject,particles),sameDocument=client.evaluate(subject,'()=>__weatherCases.identity()')==row['fixtureIdentity'])
        if spec['suspend'].get('recover'):
            row['recoveryKick']=client.evaluate(subject,'()=>__r24NativeControl.recovery(__r24NativeControl.identity())')
            client.wait(subject,"()=>{const r=__r24NativeControl.read(__r24NativeControl.identity());return !r.state.wxBusy&&r.eligibility.eligible&&r.state.precip==='on'&&r.state.visibleParticles>0;}",12)
            fresh=client.evaluate(subject,observe);row['recovered']=fresh;checks['freshAcquisitionRestoresModelOnly']=fresh['state']['raw']['retrievedAt']>before['state']['raw']['retrievedAt'] and fresh['state']['qa']['wxTruth']['observedPresent'] is False and fresh['state']['lightning']=='off';client.shot(subject,out/'fresh-model-restored.png')
        expected={**spec['expect'],'group':'R0024'}
        if spec['suspend'].get('recover'):expected.update(wet=True,modelEstimate=True)
        checks.update(client.evaluate(subject,'e=>__weatherCases.checks(__weatherCases.read(__weatherCases.identity()),e)',expected))
        state=client.evaluate(subject,'()=>__weatherCases.read(__weatherCases.identity())');row['state']=state;row['accessibility']={'scope':'Actual BiDi computed role/name with matching DOM node; full computed description unavailable','nodes':{}}
        for selector,name,role in [('#wi',state['information']['name'],'img')]+([('.buckle',state['information']['buckle']['name'],'button')] if spec.get('local') else []):
            css=client.call('browsingContext.locateNodes',{'context':subject,'locator':{'type':'css','value':selector}})
            accessible=client.call('browsingContext.locateNodes',{'context':subject,'locator':{'type':'accessibility','value':{'name':name,'role':role}}})
            row['accessibility']['nodes'][selector]={'css':css,'accessible':accessible};checks['computedAccessibleIdentity:'+selector]=len(css['nodes'])==1 and any(n['sharedId']==css['nodes'][0]['sharedId'] for n in accessible['nodes'])
        checks['sameSnapshotDescription']=state['information']['sinkExposed'] and state['information']['description']==state['information']['header']['information']['summary'] and state['information']['describedBy'].split().count('weather-information')==1
        row['providerLedger']=client.evaluate(subject,'()=>__widgetFixture.ledger');row['nativeObservation']=client.evaluate(subject,observe);client.shot(subject,out/'card.png')
        row['status']='EXECUTED_PENDING_PIXEL_AND_INDEPENDENT_REVIEW' if all(checks.values()) else 'FAIL'
    except Exception:
        row['status']='FAILED_CONSUMER_OR_HARNESS';row['exception']=traceback.format_exc()
        if client and subject:
            try:row['failureObservation']=client.evaluate(subject,'()=>({visibility:document.visibilityState,paused:document.querySelector(".c")?.classList.contains("paused"),fixture:window.__widgetFixture,state:window.__r24NativeControl?__r24NativeControl.read(__r24NativeControl.identity()):null})');client.shot(subject,out/'failure-card.png')
            except Exception:row['failureCaptureException']=traceback.format_exc()
    finally:
        if client:
            row['protocolCommands']=client.commands;row['protocolEvents']=client.events
            try:client.call('browser.close',{})
            except Exception:pass
        if ws:ws.close()
        try:process.wait(timeout=5)
        except subprocess.TimeoutExpired:process.terminate();process.wait(timeout=5)
        log.close()
    write(out/'receipt.json',row);return row

def main():
    p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True);p.add_argument('--input-sha',required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--executable',type=Path,required=True);p.add_argument('--run',default='r0024-execution-20261015');a=p.parse_args()
    require(not a.out.exists(),'New output required');require(sha(a.input)==a.input_sha,'Input digest changed');native.BINDING=a.input;pre=native.source_preflight(ROOT)
    lock=a.out.parent.parent/'native-resource.lock'
    with lock.open('x',encoding='utf-8') as f:json.dump({'pid':os.getpid(),'kind':'serial Firefox BiDi resume','out':str(a.out)},f)
    report={'schema':'r0024-native-bidi-resume/v1','preflight':pre,'admissionSha256':a.input_sha,'capability':{'engine':'firefox','driver':'built-in BiDi','executable':str(a.executable),'executableSha256':sha(a.executable),'headless':True},'cases':[],'status':'RUNNING','limitations':['No continuous recording or motion credit','Full computed AX description unavailable; native name/role and exposed description association retained','Distinct Firefox driver preferences; not identical Juggler environment']}
    try:
        a.out.mkdir(parents=True);base=native.helper_module();specs=[x for x in native.cases() if x.get('suspend',{}).get('kind')=='tab']
        with base.FixtureServer(ROOT) as server:
            for attempt,spec in enumerate(specs,1):
                out=a.out/spec['id'];out.mkdir();row=case_run(a,server,spec,attempt,out);report['cases'].append(row);write(a.out/'results.json',report);print(json.dumps({'case':row['id'],'status':row['status']}),flush=True)
                if row['status']!='EXECUTED_PENDING_PIXEL_AND_INDEPENDENT_REVIEW':break
            report['httpLedger']=server.ledger
        report['sourcePostflight']=native.source_preflight(ROOT);report['status']='EXECUTED_PENDING_PIXEL_AND_INDEPENDENT_REVIEW' if len(report['cases'])==3 and all(x['status']=='EXECUTED_PENDING_PIXEL_AND_INDEPENDENT_REVIEW' for x in report['cases']) else 'FAIL';write(a.out/'results.json',report);print(report['status']);return 0 if report['status'].startswith('EXECUTED') else 1
    finally:lock.unlink()
if __name__=='__main__':raise SystemExit(main())
