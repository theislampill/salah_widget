// Bounded capability control: owned headless browser, fresh profile, blank pages.
// The installed driver's noDefaults option avoids its default focus override.
const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto');
const core='C:/Users/theis/AppData/Local/Microsoft/WinGet/Packages/OpenJS.NodeJS.LTS_Microsoft.Winget.Source_8wekyb3d8bbwe/node-v24.15.0-win-x64/node_modules/playwright/node_modules/playwright-core';
const {chromium}=require(core),root=__dirname,out=path.join(root,'chromium-default-context-probe-r1');
const exe='C:/Users/theis/AppData/Local/ms-playwright/chromium-1223/chrome-win64/chrome.exe';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const result={schema:'r0024-native-visibility-capability/v1',source:'blank capability only; no product qualification',driverVersion:require(core+'/package.json').version,executable:exe,executableSha256:sha(exe),observerSha256:sha(__filename),steps:[]};
(async()=>{fs.mkdirSync(out);const lock=path.join(root,'native-resource.lock');fs.writeFileSync(lock,JSON.stringify({pid:process.pid,out,kind:'serial blank Chrome capability'}),{flag:'wx'});let child,browser;
try{
 const profile=path.join(out,'profile');fs.mkdirSync(profile);const log=fs.openSync(path.join(out,'browser.log'),'w');
 child=cp.spawn(exe,['--headless','--no-first-run','--no-default-browser-check','--remote-debugging-port=0','--user-data-dir='+profile,'about:blank'],{windowsHide:true,stdio:['ignore',log,log]});
 const active=path.join(profile,'DevToolsActivePort');for(let i=0;i<100&&!fs.existsSync(active);i++)await sleep(100);
 const lines=fs.readFileSync(active,'utf8').trim().split('\n');browser=await chromium.connectOverCDP('ws://127.0.0.1:'+lines[0]+lines[1],{noDefaults:true});
 const context=browser.contexts()[0],subject=await context.newPage();await subject.setContent('<title>Owned visibility subject</title><p>Capability only</p>');
 await subject.evaluate(()=>{window.events=[];for(const type of ['visibilitychange','freeze','resume'])document.addEventListener(type,e=>events.push({type:e.type,trusted:e.isTrusted,visibility:document.visibilityState,monotonic:performance.now()}));});
 const read=async name=>result.steps.push({name,...await subject.evaluate(()=>({visibility:document.visibilityState,focus:document.hasFocus(),events}))});
 await read('initial');const helper=await context.newPage();await helper.bringToFront();await sleep(500);await read('helper-activated');await subject.bringToFront();await sleep(500);await read('subject-reactivated');
 const session=await context.newCDPSession(subject);await session.send('Page.setWebLifecycleState',{state:'frozen'});await sleep(500);await session.send('Page.setWebLifecycleState',{state:'active'});await sleep(500);await read('native-freeze-resume');
 result.status='OBSERVED';
}catch(e){result.status='FAILED';result.exception=e.stack;}
finally{if(browser)try{await browser.close();}catch{}if(child&&!child.killed)child.kill();fs.writeFileSync(path.join(out,'receipt.json'),JSON.stringify(result,null,2));fs.unlinkSync(lock);console.log(JSON.stringify(result));}})();
