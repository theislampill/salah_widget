"""Lossless raw evidence bundles, with explicit immutable reuse and local-only profiles."""
from pathlib import Path
import collections,datetime,gzip,hashlib,io,json,re,subprocess,tarfile
OUT=Path(__file__).resolve().parent
ROOT=Path(r'C:\Users\theis\.codex\worktrees\r0024-execution\salah_widget')
PUB=OUT/'publication'
HEAD='57a41486b171ec5c8040a3f8285053bfb273e62a'
BASE='ae24fec477eba0280ea513ad57b3947a4c66dda0'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert not git('status','--porcelain')
assert not PUB.exists(),'Retain sealed publication; do not overwrite'
PUB.mkdir();(PUB/'archives').mkdir()
trees={}
for ref in [HEAD,BASE]:
 rows=git('ls-tree','-r','-z',ref).split(b'\0')
 trees[ref]={r.split(b'\t')[1].decode():r.split(b'\t')[0].decode().split()[2]for r in rows if r}
copies=['baseline','resource/baseline','resource/information','source/build-snow-r1']
profileNames={'profile','private-profile','disposable-profile'}
selected=[];reuse=[];omitted=collections.defaultdict(lambda:{'files':0,'bytes':0});secretHits=[]
for p in sorted(OUT.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(OUT);name=rel.as_posix()
 if rel.parts[0]in {'publication','review'} or name=='execution.json':continue
 if '__pycache__'in rel.parts or name.endswith('.pyc'):continue
 if any(x in profileNames for x in rel.parts):
  i=next(i for i,x in enumerate(rel.parts)if x in profileNames);key='/'.join(rel.parts[:i+1]);omitted[key]['files']+=1;omitted[key]['bytes']+=p.stat().st_size;continue
 if name in {'source/production-pathspec.bin'}:continue
 data=p.read_bytes();row={'original':name,'bytes':len(data),'sha256':sha(data)}
 clone=next((x for x in copies if name.startswith(x+'/')),None)
 if clone:
  repoPath=name[len(clone)+1:];blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
  match=next((ref for ref,tree in trees.items()if tree.get(repoPath)==blob),None)
  if match:
   reuse.append({**row,'gitCommit':match,'gitPath':repoPath,'gitBlobSha':blob,'disposition':'Exact redundant source/runtime bytes; retained locally and available at immutable source commit'});continue
 if p.suffix.lower() in {'.json','.py','.cjs','.js','.mjs','.md','.txt','.log','.stderr','.stdout','.tap','.html','.patch'}:
  for pattern in [rb'gh[pousr]_[A-Za-z0-9]{30,}',rb'github_pat_[A-Za-z0-9_]{40,}',rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',rb'ya29\.[A-Za-z0-9_-]{30,}']:
   if re.search(pattern,data):secretHits.append(name)
 selected.append((p,row))
assert not secretHits,'Potential secret literal found; inspect filenames before publication: '+str(secretHits)
groups=collections.defaultdict(list)
for p,row in selected:
 parts=Path(row['original']).parts
 group='native-'+parts[1] if parts[0]=='native'and len(parts)>1 and parts[1]in {'chromium','firefox'} else parts[0] if len(parts)>1 else 'tools'
 groups[group].append((p,row))
archives=[]
for group,items in sorted(groups.items()):
 chunks=[];chunk=[];size=0
 for item in items:
  if chunk and size+item[1]['bytes']>40_000_000:chunks.append(chunk);chunk=[];size=0
  chunk.append(item);size+=item[1]['bytes']
 if chunk:chunks.append(chunk)
 for i,chunk in enumerate(chunks,1):
  name=f'archives/{group}-{i:02d}.tar.gz';path=PUB/name
  with path.open('wb')as target:
   with gzip.GzipFile(filename='',mode='wb',fileobj=target,mtime=0,compresslevel=6)as gz:
    with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT)as tf:
     for p,row in chunk:
      data=p.read_bytes();assert sha(data)==row['sha256'];info=tarfile.TarInfo(row['original']);info.size=len(data);info.mode=0o644;info.mtime=0;tf.addfile(info,io.BytesIO(data))
  actual=path.read_bytes();assert len(actual)<90_000_000
  with tarfile.open(path,'r:gz')as tf:
   members=tf.getmembers();assert [m.name for m in members]==[row['original']for _,row in chunk]
   for m,(_,row)in zip(members,chunk):assert sha(tf.extractfile(m).read())==row['sha256']
  archives.append({'path':name,'bytes':len(actual),'sha256':sha(actual),'files':[row for _,row in chunk]})
manifest={'schema':'r0024-lossless-evidence-custody/v1','createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidateHead':HEAD,'base':BASE,'claim':'Custody only. Includes raw failures and execution-only receipts; does not upgrade native qualification or resource raw status.','archives':archives,'immutableSourceReuse':reuse,'localOnlyDisposableProfiles':[{'path':p,**v,'reason':'Disposable controlled browser profile contents retained locally, not needed or published as acceptance evidence'}for p,v in sorted(omitted.items())],'bytecodeExcluded':'Derived __pycache__ files excluded','secretLiteralScan':{'patterns':'GitHub token, Google OAuth token and PEM private-key signatures','matches':[],'limit':'Bounded literal scan; no claim of a general privacy/security audit'},'reviewAndCurrentMetadata':'Published separately after independent final disposition; not inside these frozen raw bundles'}
(PUB/'payload-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'archives':len(archives),'files':sum(len(x['files'])for x in archives),'publishedBytes':sum(x['bytes']for x in archives),'exactReferencedCopies':len(reuse),'profileDirectoriesExcluded':len(omitted),'manifestSha256':sha((PUB/'payload-manifest.json').read_bytes())}))
