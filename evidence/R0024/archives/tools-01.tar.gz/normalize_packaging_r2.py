"""Finish full-commit whitespace validation, retaining the original four files."""
from pathlib import Path
import ast,datetime,hashlib,json,subprocess
ROOT=Path(r'C:\Users\theis\.codex\worktrees\r0024-execution\salah_widget')
OUT=Path(__file__).resolve().parent
BASE='ae24fec477eba0280ea513ad57b3947a4c66dda0'
NODE=Path(r'C:\Users\theis\AppData\Local\Microsoft\WinGet\Packages\OpenJS.NodeJS.LTS_Microsoft.Winget.Source_8wekyb3d8bbwe\node-v24.15.0-win-x64\node.exe')
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
before=git('rev-parse','HEAD').decode().strip();assert before=='9fc1df04c34e8a27fe3dc6f1909cb2dbd2407f85'
p=subprocess.run(['git','diff','--check',BASE,'HEAD'],cwd=ROOT,capture_output=True)
assert p.returncode==2
(OUT/'source/full-commit-whitespace-failure.stdout').write_bytes(p.stdout)
(OUT/'source/full-commit-whitespace-failure.stderr').write_bytes(p.stderr)
seed=ROOT/'tests/weather-native/description-seed.js';raw=seed.read_bytes();assert raw.endswith(b'};} \n')
seed.write_bytes(raw[:-2]+b'\n')
info=ROOT/'tools/qa/info_contract.py';raw=info.read_bytes();fixed=raw.rstrip(b'\n')+b'\n';assert ast.dump(ast.parse(raw))==ast.dump(ast.parse(fixed));info.write_bytes(fixed)
subprocess.run([str(NODE),'--check',str(seed)],cwd=ROOT,check=True)
# Check the entire base-to-working-tree diff, including the already committed files.
subprocess.run(['git','diff','--check',BASE],cwd=ROOT,check=True)
subprocess.run(['git','add','--','tests/weather-native/description-seed.js','tools/qa/info_contract.py'],cwd=ROOT,check=True)
subprocess.run(['git','diff','--cached','--check',BASE],cwd=ROOT,check=True)
subprocess.run(['git','commit','--amend','--no-edit'],cwd=ROOT,check=True)
head=git('rev-parse','HEAD').decode().strip();subprocess.run(['git','diff','--check',BASE,head],cwd=ROOT,check=True)
assert not git('status','--porcelain')
rows=[]
for rel in ['tests/weather-native/cases.json','tools/qa/run_r0024_native.py','tests/weather-native/description-seed.js','tools/qa/info_contract.py']:
 a=(OUT/'review/executed-fixtures-input-r15'/rel).read_bytes();b=(ROOT/rel).read_bytes()
 assert a.replace(b'\r\n',b'\n').rstrip().splitlines()==b.rstrip().splitlines() or rel.endswith('description-seed.js')
 if rel.endswith('description-seed.js'):assert a[:-2]+b'\n'==b
 elif rel.endswith('.py'):assert ast.dump(ast.parse(a))==ast.dump(ast.parse(b))
 else:assert json.loads(a)==json.loads(b)
 rows.append({'path':rel,'executedSha256':sha(a),'finalSha256':sha(b),'oldBytes':len(a),'newBytes':len(b),'onlyChange':'CRLF to LF, one trailing space, or final blank line; no tokens or values changed'})
receipt={'schema':'r0024-final-fixture-whitespace-reconciliation/v1','atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'retainedLocalCommit':before,'finalHead':head,'base':BASE,'changes':rows,'executedSnapshot':'review/executed-fixtures-input-r15','originalFailure':'Full base-to-commit check additionally found one trailing space in description-seed.js and one final blank line in info_contract.py; prior staged-only correction had omitted these already-committed files.','correctiveAction':'Check entire candidate against base before and after amend; exact executed bytes retained; values/AST or exact single trailing space equality verified.','fullCommitDiffCheckExitCode':0,'productRuntimeChanged':False,'browserFixtureTokenChanges':False,'frozenResourcePackageChanged':False,'nativeRerun':'Not claimed; same compiled tokens and JSON values independently reconcilable.'}
(OUT/'source/final-fixture-whitespace-reconciliation.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'head':head,'clean':True,'fullCommitDiffCheckExitCode':0}))
