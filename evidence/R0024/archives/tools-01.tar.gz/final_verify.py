"""Bind the completed source/build checks to the final candidate; no Git effects."""
from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys

OUT=Path(__file__).resolve().parent
ROOT=Path(r'C:\Users\theis\.codex\worktrees\r0024-execution\salah_widget')
BASE='ae24fec477eba0280ea513ad57b3947a4c66dda0'
NODE=Path(r'C:\Users\theis\AppData\Local\Microsoft\WinGet\Packages\OpenJS.NodeJS.LTS_Microsoft.Winget.Source_8wekyb3d8bbwe\node-v24.15.0-win-x64\node.exe')
sys.path.insert(0,str(ROOT/'tools/cp9'))
from runtime_identity import runtime_identity

def sha(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def write(name,value):
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():raise RuntimeError('Retain existing receipt; no overwrite: '+name)
 p.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def run(name,args,env=None):
 p=subprocess.run(args,cwd=ROOT,capture_output=True,env=env)
 for suffix,data in [('stdout',p.stdout),('stderr',p.stderr)]:
  path=OUT/'source'/(name+'.'+suffix)
  if path.exists():raise RuntimeError('Retain existing command output')
  path.write_bytes(data)
 value={'command':[str(x) for x in args],'cwd':str(ROOT),'exitCode':p.returncode,
        'stdoutSha256':sha(p.stdout),'stderrSha256':sha(p.stderr),
        'stdout':'source/'+name+'.stdout','stderr':'source/'+name+'.stderr'}
 write('source/'+name+'.json',value)
 if p.returncode:raise RuntimeError(value)
 return value

assert git('rev-parse','HEAD').decode().strip()==BASE
live=json.loads(subprocess.check_output(['gh','api','repos/theislampill/salah_widget/git/ref/heads/main']))
assert live['object']['sha']==BASE
before=runtime_identity(ROOT)
assert before['treeSha256']=='33ce3ee48c2bb2037a4073d3090f40c4892560721d10fcead0a4dda00b36ce93'
build=OUT/'source/build-snow-r1'
same=runtime_identity(build)
assert before==same,'Previously successful canonical build no longer matches candidate'
for rel in ['src/native/index.html','tools/build_native.py','tools/build_moon.py','tools/native_core_horizon.py']:
 assert (build/rel).read_bytes()==(ROOT/rel).read_bytes(),rel
paths=git('ls-tree','-r','--name-only',BASE).decode().splitlines()
protected=[p for p in paths if p.startswith(('v1/','real-sky/','moon/','presets/')) or p in ['AGENTS.md','config.js','src/native/config.js','builder.html','src/native/builder.html','install.ps1','install.sh','tools/build_native.py','tools/build_moon.py','tools/native_core_horizon.py','_config.yml']]
interfaces=[]
for rel in protected:
 data=(ROOT/rel).read_bytes();assert data==git('show',BASE+':'+rel),rel
 interfaces.append({'path':rel,'bytes':len(data),'sha256':sha(data)})
env=os.environ.copy();env.update(SALAH_WEATHER_SOURCE=str(ROOT/'index.html'),SALAH_CONFIG_SOURCE=str(ROOT/'config.js'),SALAH_HOTFIX_SOURCE=str(ROOT/'src/native/index.html'))
checks=[run('final-information',[str(NODE),'--test','tests/r0024-information.test.cjs','tests/r0024-particle-origin.test.cjs'],env),
 run('final-affected-weather',[str(NODE),'--test',*['tests/'+x for x in ['r000c-weather.test.cjs','r000d-weather.test.cjs','r0024-weather.test.cjs','r0024-response-zone.test.cjs','r0024-cloud-expiry.test.cjs','hotfix-prayer-weather.test.cjs']]],env),
 run('final-diff-check',['git','diff','--check'])]
after=runtime_identity(ROOT);assert before==after
modified=git('diff','--name-only').decode().splitlines()+git('ls-files','--others','--exclude-standard').decode().splitlines()
assert len(modified)==len(set(modified))
files=[{'path':rel,'bytes':(ROOT/rel).stat().st_size,'sha256':sha((ROOT/rel).read_bytes())}for rel in sorted(modified)]
write('source/final-candidate-identity.json',{'schema':'r0024-final-precommit-source/v1','atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':BASE,'liveMain':live['object']['sha'],'runtime':after,'files':files,'protectedInterfaces':interfaces,'canonicalBuild':{'receipt':'source/canonical-build-recovery.json','receiptSha256':sha((OUT/'source/canonical-build-recovery.json').read_bytes()),'successfulBuildExactMatch':True,'rerunRequired':False,'limit':'Existing successful canonical build re-read and matched; no second build invocation or invented recovery cause.'},'checks':checks,'claim':'Source/build/interface checks only. Native whole-obligation, delivery and closure remain separate.'})
print(json.dumps({'runtime':after['treeSha256'],'files':len(files),'protectedInterfaces':len(interfaces),'checks':len(checks)}))
