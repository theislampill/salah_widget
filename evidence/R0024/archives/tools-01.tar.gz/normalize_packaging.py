"""Retain executed fixture bytes and correct two CRLF packaging defects only."""
from pathlib import Path
import ast,datetime,hashlib,json,subprocess
ROOT=Path(r'C:\Users\theis\.codex\worktrees\r0024-execution\salah_widget')
OUT=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
bound=json.loads((OUT/'native/input-r15.json').read_bytes())
before=git('rev-parse','HEAD').decode().strip()
assert before.startswith('70db95a0')
snapshot=OUT/'review/executed-fixtures-input-r15'
assert not snapshot.exists()
for rel,row in bound['fixtures'].items():
 data=(ROOT/rel).read_bytes();assert sha(data)==row['sha256'],rel
 p=snapshot/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
rows=[]
for rel in ['tests/weather-native/cases.json','tools/qa/run_r0024_native.py']:
 path=ROOT/rel;raw=path.read_bytes();assert b'\r\n' in raw
 fixed=raw.replace(b'\r\n',b'\n');assert b'\r' not in fixed
 if rel.endswith('.json'):assert json.loads(raw)==json.loads(fixed);parsed='JSON exact value equality'
 else:assert ast.dump(ast.parse(raw))==ast.dump(ast.parse(fixed));parsed='Python AST exact equality'
 path.write_bytes(fixed)
 rows.append({'path':rel,'executedSha256':sha(raw),'finalSha256':sha(fixed),'oldBytes':len(raw),'newBytes':len(fixed),'proof':parsed,'onlyChange':'CRLF to LF'})
subprocess.run(['git','add','--',*[x['path'] for x in rows]],cwd=ROOT,check=True)
p=subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,capture_output=True)
(OUT/'source/packaging-diff-check.stdout').write_bytes(p.stdout);(OUT/'source/packaging-diff-check.stderr').write_bytes(p.stderr)
assert p.returncode==0
subprocess.run(['git','commit','--amend','--no-edit'],cwd=ROOT,check=True)
head=git('rev-parse','HEAD').decode().strip();assert not git('status','--porcelain')
assert git('rev-parse','HEAD^').decode().strip()=='ae24fec477eba0280ea513ad57b3947a4c66dda0'
receipt={'schema':'r0024-packaging-newline-reconciliation/v1','atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'retainedLocalCommit':before,'finalHead':head,'base':'ae24fec477eba0280ea513ad57b3947a4c66dda0','executedInput':'native/input-r15.json','executedFixtureSnapshot':'review/executed-fixtures-input-r15','changes':rows,'originalFailure':'git diff --cached --check reported CRLF as trailing whitespace after the earlier check omitted untracked files. A local-only commit proceeded despite that failed check; it was never pushed.','correctiveAction':'Exact executed bytes retained; only two files normalized; JSON/Python AST equality; staged whitespace check now exit0; unpublished commit amended.','productRuntimeChanged':False,'browserServedFixtureScriptsChanged':False,'frozenResourcePackageChanged':False,'nativeRerun':'Not claimed; independent scope reconciliation required.'}
(OUT/'source/packaging-newline-reconciliation.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'head':head,'changes':rows,'clean':True}))
