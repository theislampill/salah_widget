"""Matched current-renderer decision-tape comparison; replay grants resource evidence only.

Acquire actual tape/equivalence/capability before independent input qualification.
Measurement requires that exact input digest and the independent disposition.
Historical failures stay separate; exceeding registered variance is never automatic PASS.
"""
import argparse,copy,hashlib,importlib.util,json,os,statistics,time,traceback
from pathlib import Path
from urllib.parse import unquote,urlsplit

ROOT=Path(__file__).resolve().parents[2]
ASSETS=ROOT/'tests/weather-native'
def sha(data):return hashlib.sha256(data).hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def write(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8',newline='\n')
def require(ok,message):
    if not ok:raise ValueError(message)
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
BASE=load('r24_resource_transport',ROOT/'tools/qa/legacy_weather_helpers.py')
class Server(BASE.FixtureServer):
    def __init__(self,root):
        super().__init__(root);handler=self.server.RequestHandlerClass;parent=self
        class Handler(handler):
            def do_GET(self):
                if unquote(urlsplit(self.path).path)=='/native-controls.js':
                    data=(ASSETS/'native-controls.js').read_bytes();parent.ledger.append({'path':'/native-controls.js','bytes':len(data),'sha256':sha(data)})
                    self.send_response(200);self.send_header('Content-Type','text/javascript');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
                else:super().do_GET()
        self.server.RequestHandlerClass=Handler

def projection(text):
    start=text.index('// Information is downstream of one admitted decision:');end=text.index('let _lastWeatherHeader=null;',start)
    text=text[:start]+text[end:]
    changes=[('  <span class="weather-information" id="weather-information"></span>\n',''),
      ('.weather-information{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);clip-path:inset(50%);white-space:nowrap;border:0}\n',''),
      ('  const information=weatherInformation(decision,day);\n  return {...info,label:info.label+"; "+information.summary,information,temperature:','  return {...info,temperature:'),
      ('  const information=$("#weather-information");if(information)information.textContent=value.information?.summary||"";\n  describeWeatherInformation(wi);\n  if(_cfgMode==="local")describeWeatherInformation($(".buckle"));\n','')]
    for old,new in changes:
        require(text.count(old)==1,'Exact INFO inverse anchor missing');text=text.replace(old,new)
    return text

def identities(args):
    runtimes={};sources={}
    for label,root in [('baseline',args.baseline),('information',args.candidate)]:
        runtimes[label]=load('identity_'+label,root/'tools/cp9/runtime_identity.py').runtime_identity(root)
        sources[label]=sha((root/'src/native/index.html').read_bytes())
    for rel in ['src/native/index.html','index.html','offline.html']:
        require(projection((args.candidate/rel).read_text(encoding='utf-8'))==(args.baseline/rel).read_text(encoding='utf-8'),'Not an exact INFO-only pair: '+rel)
    files=runtimes['baseline']['files'];other=runtimes['information']['files']
    require(set(files)==set(other),'Runtime inventory mismatch')
    require(all(value==other[name]for name,value in files.items()if name not in ['index.html','offline.html']),'Non-entry renderer/asset drift')
    observer={p.relative_to(ROOT).as_posix():sha(p.read_bytes())for p in ROOT.rglob('*')if p.is_file()and '__pycache__'not in p.parts}
    return {'runtimes':runtimes,'sources':sources,'observer':observer,'executable':str(args.executable.resolve()),'executableSha256':sha(args.executable.read_bytes()),'scope':'Same current renderer including snow repair in all arms; full scaffold versus old-selection replay, then INFO-only delta. No whole historical-versus-current renderer comparison.'}

def tape_content(tape):
    value=copy.deepcopy(tape);value.pop('sourceSha256',None);return value
def counters(page):return page.evaluate('()=>__weatherCases.resourceCounters(__weatherCases.identity())')
def state(page):return page.evaluate('()=>__weatherCases.resourceRead(__weatherCases.identity())')
def ledger(page):return page.evaluate('()=>__widgetFixture.ledger.filter(x=>!x.url.includes("/product/"))')
def stage(page,name):return page.evaluate('name=>__weatherCases.resourceStage(__weatherCases.identity(),name)',name)
def install(page,arm,tape,index):
    bound=copy.deepcopy(tape);bound['sourceSha256']=index
    receipt=page.evaluate('v=>__weatherCases.resourceArm(__weatherCases.identity(),v.arm,v.tape)',{'arm':arm,'tape':bound})
    return {'receipt':receipt,'tape':bound,'logicalTapeSha256':sha(json.dumps(tape_content(bound),sort_keys=True).encode())}

class Metrics:
    def __init__(self,page):
        self.session=page.context.new_cdp_session(page);self.errors=[];self.domain='threadTicks'
        self.enable=self.session.send('Performance.enable',{'timeDomain':self.domain})
    def read(self):return self.session.send('Performance.getMetrics')
    def gc(self):return self.session.send('HeapProfiler.collectGarbage')
    def close(self):self.session.detach()
    def measure(self,page,body,profile=False):
        gc_before=self.gc();before=self.read();counts_before=counters(page);start=time.monotonic()
        sampling_start=self.session.send('HeapProfiler.startSampling',{'samplingInterval':32768})
        if profile:self.session.send('Profiler.enable');self.session.send('Profiler.setSamplingInterval',{'interval':10000});self.session.send('Profiler.start')
        value=body();after=self.read();elapsed=time.monotonic()-start
        cpu_profile=self.session.send('Profiler.stop')if profile else None
        allocations=self.session.send('HeapProfiler.stopSampling')
        counts_after=counters(page);gc_after=self.gc();retained=self.read()
        def values(raw):return {r['name']:r['value']for r in raw['metrics']}
        b,a,r=values(before),values(after),values(retained)
        def delta(k,last):return None if k not in b or k not in last else last[k]-b[k]
        def total(node):return node.get('selfSize',0)+sum(total(c)for c in node.get('children',[]))
        sampled=total(allocations['profile']['head'])if allocations.get('profile')else None
        cpu=delta('TaskDuration',a)
        return {'wallSeconds':elapsed,'cpuMs':None if cpu is None else cpu*1000,'heapUsedDeltaBytes':delta('JSHeapUsedSize',a),'retainedHeapDeltaBytes':delta('JSHeapUsedSize',r),'sampledLiveAllocationBytes':sampled,
          'rawBefore':before,'rawAfter':after,'rawRetained':retained,'gcBefore':gc_before,'gcAfter':gc_after,'samplingStart':sampling_start,'allocation':allocations,'cpuProfile':cpu_profile,
          'countsBefore':counts_before,'countsAfter':counts_after,'value':value,'metricScope':'Chromium page task CPU with threadTicks; heap after explicit GC; sampled live V8 allocation. CPU profile signed deltas retained as diagnostics, never independently summed as CPU.','workerCpuMs':None,'collectedAllocationBytes':None}

def open_arm(browser,server,index,args,number):
    spec=BASE.load_cases()[0];return BASE.open_case(browser,server,spec,index,args.run,number)
def acquire(args,pins):
    from playwright.sync_api import sync_playwright
    report={'schema':'r0024-scaffold-resource-baseline/v1','status':'ACQUIRED_PENDING_INDEPENDENT_INPUT_REVIEW','pins':pins,'arms':{},'metrics':{'available':[],'unavailable':{'workerCpuMs':None,'collectedAllocationBytes':None,'uiCallback250ms':None}},'measurementRun':False}
    with Server(args.baseline)as baseline,Server(args.candidate)as candidate,sync_playwright()as pw:
        browser=pw.chromium.launch(headless=True,executable_path=str(args.executable),chromium_sandbox=True,args=['--disable-dev-shm-usage'])
        try:
            report['browser']={'family':'chromium','version':browser.version,'executable':str(args.executable),'headless':True,'chromiumSandbox':True}
            index=pins['runtimes']['baseline']['files']['index.html']['sha256']
            context,page,*_=open_arm(browser,baseline,index,args,1)
            try:tape=page.evaluate('()=>__weatherCases.resourcePrecompute(__weatherCases.identity())')
            finally:context.close()
            report['decisionTape']=tape;report['decisionTapeSha256']=sha(json.dumps(tape_content(tape),sort_keys=True).encode())
            for number,(label,server,arm,source)in enumerate([('baselineReplay',baseline,'replay','baseline'),('baselineFull',baseline,'full','baseline'),('informationFull',candidate,'full','information')],2):
                index=pins['runtimes'][source]['files']['index.html']['sha256'];context,page,errors,network,url=open_arm(browser,server,index,args,number);metrics=None
                try:
                    bound=install(page,arm,tape,index);rows=[]
                    for entry in tape['entries']:
                        value=stage(page,entry['stage']);observed=state(page)
                        require(value['information']['decision']==entry['decision']and observed['inputSignature']==entry['signature'],'Acquisition epoch equivalence failed')
                        rows.append({'stage':entry['stage'],'state':value,'observed':observed,'counters':counters(page)})
                    metrics=Metrics(page);raw=metrics.read();require(any(x['name']=='TaskDuration'for x in raw['metrics']),'Thread CPU metric unavailable')
                    metrics.gc();metrics.session.send('HeapProfiler.startSampling',{'samplingInterval':32768});sample=metrics.session.send('HeapProfiler.stopSampling')
                    report['arms'][label]={'installed':bound,'epochs':rows,'provider':ledger(page),'errors':errors,'rawMetricCapability':raw,'rawAllocationCapability':sample,'timeDomain':metrics.domain}
                    require(not errors,'Acquisition page errors')
                finally:
                    if metrics:metrics.close()
                    context.close()
            report['metrics']['available']=['pageTaskThreadCpuMs','heapUsedBytes','postGcRetainedHeapBytes','sampledLiveAllocationBytes']
        finally:browser.close()
    report['pinsPostflight']=identities(args);require(report['pinsPostflight']==pins,'Acquisition input drift');return report

def trial(browser,server,index,arm,tape,args,label,number):
    context,page,errors,network,url=open_arm(browser,server,index,args,number);metrics=Metrics(page)
    try:
        installed=install(page,arm,tape,index);result={'label':label,'repeat':number,'installed':installed,'metrics':{},'checks':{},'providerBefore':ledger(page)}
        for name in ['cold','wet']:result['metrics'][name]=metrics.measure(page,lambda name=name:stage(page,name))
        page.wait_for_timeout(2000)
        result['metrics']['warm60s']=metrics.measure(page,lambda:page.wait_for_timeout(60000),profile=True)
        for phase,kind in [('cached1000','cached'),('information1000','information'),('lookupObserverTare1000','tare'),('oldSelectionTare1000','legacy')]:
            result['metrics'][phase]=metrics.measure(page,lambda kind=kind:page.evaluate('kind=>__weatherCases.resourceProbe(__weatherCases.identity(),1000,kind)',kind))
        for name in ['dry','expiry','new-generation']:result['metrics'][name]=metrics.measure(page,lambda name=name:stage(page,name))
        result.update(consumer=state(page),providerAfter=ledger(page),network=network,pageErrors=errors,metricErrors=metrics.errors)
        result['checks']['noAddedProviderRequestsOrBytes']=result['providerBefore']==result['providerAfter']
        result['checks']['sameEpochDecisions']=all(result['metrics'][e['stage']]['value']['information']['decision']==e['decision']for e in tape['entries'])
        result['checks']['noPageErrors']=not errors
        result['checks']['replaySkippedScaffold']=arm!='replay'or all(result['consumer']['counts'][k]==0 for k in ['reconcile','forecast'])
        for phase in ['warm60s','cached1000','information1000']:
            row=result['metrics'][phase];b,a=row['countsBefore'],row['countsAfter']
            result['checks'][phase+'NoReconcile']=b['reconcile']==a['reconcile']and b['forecast']==a['forecast']
            result['checks'][phase+'NoFormatterRebuild']=b['informationMisses']==a['informationMisses']
        return result
    finally:metrics.close();context.close()

def variance(rows):
    output={}
    for phase in rows[0]['metrics']:
        output[phase]={}
        for metric in ['cpuMs','heapUsedDeltaBytes','retainedHeapDeltaBytes','sampledLiveAllocationBytes']:
            values=[r['metrics'][phase][metric]for r in rows]
            output[phase][metric]=None if None in values else {'values':values,'mean':statistics.mean(values),'min':min(values),'max':max(values),'range':max(values)-min(values)}
    return output

def measure(args,pins,acquired):
    from playwright.sync_api import sync_playwright
    groups={};report={'schema':'r0024-resource-output/v1','status':'MEASURING','inputSha256':sha(args.input.read_bytes()),'reviewSha256':sha(args.review.read_bytes()),'pins':pins,'trials':groups,'preregistered':{},'comparisons':{},'metricLimits':acquired['metrics']['unavailable']}
    with Server(args.baseline)as baseline,Server(args.candidate)as candidate,sync_playwright()as pw:
        browser=pw.chromium.launch(headless=True,executable_path=str(args.executable),chromium_sandbox=True,args=['--disable-dev-shm-usage'])
        try:
            require(browser.version==acquired['browser']['version'],'Browser version changed')
            for label,server,arm,source in [('baselineReplay',baseline,'replay','baseline'),('baselineFull',baseline,'full','baseline'),('informationFull',candidate,'full','information')]:
                groups[label]=[];index=pins['runtimes'][source]['files']['index.html']['sha256']
                for number in range(1,4):
                    row=trial(browser,server,index,arm,acquired['decisionTape'],args,label,number);groups[label].append(row);write(args.out/label/(str(number)+'.json'),row)
                    write(args.out/'receipt.json',report);print(json.dumps({'arm':label,'repeat':number,'checks':row['checks']}),flush=True)
                    require(all(row['checks'].values()),'Paired consumer/cache equivalence failed; retain and stop')
                if label!='informationFull':
                    prereg={'basis':'Three actual baseline repeats before comparison arm','rule':'Any mean increment greater than measured baseline max-minus-min range requires diagnosis and an explicit concrete primary disposition; no automatic PASS','ranges':variance(groups[label])}
                    write(args.out/('preregistered-'+label+'.json'),prereg);report['preregistered'][label]=prereg
            for label,baseline_label in [('baselineFull','baselineReplay'),('informationFull','baselineFull')]:
                values=variance(groups[label]);over=[]
                for phase,items in report['preregistered'][baseline_label]['ranges'].items():
                    for metric,b in items.items():
                        v=values[phase][metric]
                        if b is not None and v is not None and v['mean']-b['mean']>b['range']:over.append({'phase':phase,'metric':metric,'increment':v['mean']-b['mean'],'registeredRange':b['range']})
                report['comparisons'][label]={'baseline':baseline_label,'ranges':values,'exceedances':over}
            report['status']='FAIL_REQUIRES_PRIMARY_DISPOSITION'if any(c['exceedances']for c in report['comparisons'].values())else'EXECUTED_PENDING_INDEPENDENT_REVIEW'
        except Exception:report.update(status='FAILED_OR_UNVERIFIED',exception=traceback.format_exc())
        finally:browser.close()
    report['pinsPostflight']=identities(args);require(report['pinsPostflight']==pins,'Measured input drift');write(args.out/'receipt.json',report);return report

def main():
    p=argparse.ArgumentParser();p.add_argument('--baseline',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True);p.add_argument('--executable',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--input',type=Path);p.add_argument('--review',type=Path);p.add_argument('--lock',type=Path,required=True);p.add_argument('--acquire',action='store_true');p.add_argument('--run',default='r0024-resource-current');a=p.parse_args()
    require(not a.out.exists(),'New evidence output required');pins=identities(a)
    if not a.acquire:
        acquired=read(a.input);review=read(a.review);require(acquired['pins']==pins,'Reviewed input changed')
        require(review.get('disposition')=='QUALIFIED_SCOPED_INPUT'and review.get('inputSha256')==sha(a.input.read_bytes()),'Independent exact-input qualification required')
    a.out.mkdir(parents=True);lock=a.lock
    with lock.open('x',encoding='utf-8')as f:json.dump({'pid':os.getpid(),'run':a.run,'out':str(a.out),'started':time.time()},f)
    try:
        result=acquire(a,pins)if a.acquire else measure(a,pins,acquired)
        write(a.out/'receipt.json',result);print(json.dumps({'status':result['status'],'out':str(a.out)}));return 0 if result['status'].startswith(('ACQUIRED','EXECUTED'))else 1
    finally:lock.unlink()
if __name__=='__main__':raise SystemExit(main())
