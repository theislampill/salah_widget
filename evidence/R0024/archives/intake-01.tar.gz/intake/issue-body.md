# R0024 — Separate current precipitation evidence from nearby, approaching and forecast states

Canonical identity: **theislampill/salah_widget R0024**. Baseline `fd2972ba64225fe9d6848e92497e6d0ed20ea624`. This work order defines a bounded evidence/classification implementation. It does not select or certify a radar arrival engine, add a provider, authorize production deployment or promise forecast accuracy.

The current WMO/amount gate cannot represent dry-at-point with rain nearby, uncertain current evidence, or forecast rain later. It uses a confirm-only `max(current, radar proxy)` for precip-coded weather. The product needs separate current, spatial and short-horizon concepts so the renderer cannot turn a nearby or future cell into local falling rain.

## Actual baseline and why existing repairs are insufficient

[fetchWeather](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/index.html#L771) requests Open-Meteo current plus hourly values; [syncWeather](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/index.html#L859) uses hourly only in accelerated preview. That current/preview separation must survive. Open-Meteo current is a weather-model product; minutely timestamps outside native domains may be interpolated hourly output. [provider contract](https://open-meteo.com/en/docs).

[Radar](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/index.html#L803) samples one latest zoom6 tile's clipped7×7 alpha neighbourhood. At latitude24.47°, pixel pitch is about2.226km and full sample width15.584km; at52.52°,1.488km and10.418km. Three full-alpha returns/49 give a0.545 “mm” proxy even if the centre is dry. [R000E](https://github.com/theislampill/salah_widget/issues/14) already owns withdrawing that unsupported quantitative authority and explicitly permits a separately qualified categorical alternative, including dry-centre negative controls. Do not reopen or duplicate it.

[The gate](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/index.html#L1435) keeps raw clear/model0/radar1 clear, keeps model rain1/radar0 rainy, and can keep a rain code wet using only nearby radar proxy. [wxTruth](https://github.com/theislampill/salah_widget/blob/fd2972ba64225fe9d6848e92497e6d0ed20ea624/index.html#L2052) lacks explicit nearby/approach/forecast/unknown state. Fixing finite values, stale clocks or radar units does not by itself supply this product distinction.

Fresh research on2026-09-08 found RainViewer future radar discontinued, history limited to2h/10min, max zoom7; live manifest had13 past frames and an empty nowcast array. [current transition](https://www.rainviewer.com/api/transition-faq.html). A MET Norway browser probe succeeded for Oslo with radar quality metadata, but a regional adapter and empirical skill remain later work. This issue must remain useful without either source enhancement.

## Selected bounded contract

Implement a small pure reconciliation over admitted evidence, separate from rendering. Preserve WMO as one provider input, not the sole atmosphere authority. Return independently:

- **Current:** supported wet, supported dry, model-estimated wet, model-estimated dry, conflicting or unknown.
- **Spatial:** nearby precipitation evidence, observed-area no nearby echo, or unavailable.
- **Short horizon:** approaching with supported arrival interval, nearby without supported arrival, numerical forecast only, none supported or unknown. Imminent is a horizon-qualified approach; it is never current wet.
- **Forecast:** source/product, valid interval, amount with units and optional probability with its event/window.
- **Renderer permissions:** local rain/snow and lightning permissions derived from admitted present evidence, with reason and expiry.

These are conceptual data states, not predetermined UI wording. Current and approaching may coexist. Unknown/no evidence is not dry; a missing probability is not0%; a nonzero forecast amount is not an observed rate. Avoid an arbitrary weighted confidence score or numerical probability labels without calibration.

For this first implementation, existing Open-Meteo current maps to **model-estimated** wet/dry after R000C/B admission. The withdrawn alpha proxy supplies no evidence. Nearby/approach remain **unavailable** until an adapter is independently qualified. Do not invent approach from hourly weather, current surface wind, proximity alone, an empty future-frame array or15-minute interpolation. This explicit unavailable state is a successful outcome of this bounded state/renderer work order, not delivery of the separately requested useful local rain-arrival capability. A later bounded source-qualification increment must establish which present/nearby/approach claims an actual provider supports in a declared geography; that increment is not selected or implemented by this issue. Do not synthesize an ETA to disguise the distinction.

Local falling precipitation requires separately admitted present-condition evidence at the selected target with source/time/location quality adequate for that claim. This stage therefore suppresses strong local rain/lightning effects where the only live evidence is a coarse/model estimate; it preserves useful model temperature/cloud/visibility and describes its uncertainty. That behaviour change is intentional under the owner's stronger truthfulness requirement. It must not be labelled “confirmed dry.” Synthetic renderer QA can explicitly grant positive evidence in a marked simulation lane; production cannot inherit that permission.

The source-adapter interface must not be a free boolean `trusted:true`. An admitted record identifies provider/product, target generation, measurement/valid interval, frame/issue/receipt times as available, units, spatial footprint/coverage, documented quality status and a versioned admission-policy reason. Existing sources in this stage cannot self-upgrade to strong current wet. A later provider-specific implementation must supply positive/negative fixtures and source-quality rules before that category can be emitted live. Consume the existing R000B/R000C/R000E contracts explicitly: a RainViewer composite-generation time is not a per-radar observation time, and nominal coverage does not establish operational negative evidence. Preserve unknown local observation age/health. Retain quantity kind and units: a preceding-15-minute amount at16:30 spans16:15–16:30; converting0.4mm to1.6mm/h gives an interval average, not instantaneous rain or onset. These are source-admission refinements, not a new provider or weather repair owner. [RainViewer contract](https://www.rainviewer.com/api/weather-maps-api.html), [Open-Meteo variables](https://open-meteo.com/en/docs).

## Dependency-ordered implementation

1. Re-anchor current source and existing repairs. Consume [R0003](https://github.com/theislampill/salah_widget/issues/3) request/target ownership, [R000C](https://github.com/theislampill/salah_widget/issues/12) finite admission, [R000B](https://github.com/theislampill/salah_widget/issues/11) freshness and R000E radar authority. They remain separately owned; do not call their future contracts already implemented. Their relevant consumer interfaces are qualification prerequisites.
2. Consume [R0023](https://github.com/theislampill/salah_widget/issues/35) location target/intent/accuracy/acquisition-age contract. A fixed site is not necessarily a device fix; unknown IP accuracy is not a made-up radius. Model-grid spatial support remains separate from coordinate precision.
3. Add a compact evidence record and pure reconciliation with explicit availability/rejection reasons. Use physical units and time intervals; retain nulls. Preserve source time versus receipt time and source generation. A source gap cannot extend an old wet lease by resetting receipt time.
4. Connect current live inputs to model-estimated/unknown categories. Maintain accelerated preview in its explicit synthetic/forecast mode. Add structural nearby/approach/forecast fields without new network calls; unavailable is the default until a qualified source exists.
5. Derive renderer permissions and a concise truthful information state. No falling rain, snow or bolt from approaching/forecast/unknown alone. Do not replace all atmosphere with a blank scene: admitted present/model cloud, temperature, visibility and humidity still supply appropriately described atmosphere. A forecast-like thunder code and rain amount are not a lightning observation.
6. Make `qaState().wxTruth` explain the consumed decision: target/source/accuracy/fix age, source valid/receipt ages, coverage/quality, point versus surrounding evidence, classifications, source rejection/unavailability, renderer permissions/reason/expiry and arrival derivation only when present. Omit full tiles and redundant forecast arrays. No remote telemetry or continuous location tracking.
7. Update actual public weather semantics, source attribution and supported diagnostic documentation. No field-study export, sample-collection programme or general telemetry/harness framework is required or in scope.

## Decision fixtures A–G and controls

Use deterministic admitted-evidence records, not the owner looking outside. Preserve each source's provenance and reject undefined “high confidence” shortcuts.

| Fixture | Required result |
|---|---|
| A: qualified current wet evidence at precise target, model dry | Current supported wet with disagreement recorded; original clear WMO cannot veto independently admitted current evidence. In the initial implementation this is a synthetic adapter-contract fixture, not a live RainViewer claim. |
| B: qualified usable negative evidence, model rain | Current supported dry or conflicting according to the adapter's explicit negative-evidence policy; never universal radar-always-wins. Model estimate remains inspectable. |
| C: dry point, nearby echo with qualified movement/arrival | Current dry/uncertain remains separate; nearby/approach has its own interval; local particles stay off. Unqualified movement yields nearby only or unavailable. |
| D: radar absent/outside coverage, model rain | Model-estimated wet plus observation unavailable; neither confirmed dry nor strong local rain. |
| E: radar18min old, fresh model | Evaluate source-time policy; fresh download does not rejuvenate old evidence. No tight ETA from old/missing trajectory. |
| F: coarse-IP/unknown accuracy versus precise target | Spatial/point claim admission differs when warranted; do not assert viewer precipitation from a centroid. Preserve evidence at the configured site separately. |
| G: weak/interpolated/ambiguous returns | Uncertain/unavailable categorical evidence, never mm or calibrated drizzle from alpha. |

Additional controls: null versus zero; current rate versus prior15-minute amount; future interval labelled current; model native versus interpolated minutely metadata; probability versus amount; empty radar under no coverage; dry centre/three wet neighbours; stale after tab resume; changed location with old response/history; rain-end clearing and source outage; simulated positive rain/thunder versus identical live forecast-only input; current rain plus later approaching cell simultaneously; a fresh composite with stale/unknown underlying local observation age; nominal coverage with absent/unknown operational health. The latter cases must not acquire strong negative/current evidence merely from fresh transport and a covered pixel.

Render those decisions in the actual325×530 card. Positive synthetic current rain retains cloud-linked particles; dry/nearby/approach/forecast/unknown controls do not emit them. Do not hide uncertainty by showing a clear-weather icon that implies confirmed dry. Preserve existing sun/moon/cloud quality, header/footer/prayer information, reduced motion and readable status. UI wording may be compact, but the information needed to distinguish current from predicted/unknown cannot exist only in a debug object.

## Arrival and source boundaries

No production motion estimator, minutely fetch, regional provider or predicted cloud direction is included here. RainViewer's historical map pixels can support later motion research, but radar returns aloft are not guaranteed ground rain. Regional nowcasts may be stronger when quality flags are usable. Numerical15-minute fields can corroborate prediction; they do not observe approach. A future adapter must document coverage, update/valid/receipt clocks, CORS/deployment origin, limits, attribution, bytes/cache/battery and graceful degradation before granting live evidence.

A demonstrative motion calculation is not validation: at1km/pixel,4px per10min implies24km/h; a10km leading edge would arrive in25min under unchanged translation, while20km location uncertainty alone adds about±50min. Turning, growth, decay, new convection, gaps and frame latency require wider intervals or abstention. No exact17:40 claim follows from an hourly forecast.

## Acceptance, evidence limits and rollback

Pass when all states remain distinct through acquisition→reconciliation→diagnostics→visible renderer, A–G behave as above, no unsupported source grants current particles, positive synthetic current evidence still exercises the renderer, and existing interface/clock/expiry tests pass on the integrated candidate. Measure extra CPU/memory/network against baseline: this stage adds no provider requests and needs no per-frame inference; reconcile when evidence/time eligibility changes.

No field-study programme, owner weather observations, sample/event collection or periodic taste check-ins are required. Qualification uses automated decision fixtures, lawfully available recorded provider responses, synthetic conflict/motion cases and bounded API/browser contract checks. Real-world predictive skill remains unestablished where it has not been measured; neither arithmetic controls nor an all-dry API smoke certify it. Do not turn that evidence limit into an unrequested study deliverable or claim this state scaffold delivers an arrival service.

[R000D](https://github.com/theislampill/salah_widget/issues/13) remains source-body/image lifetime owner; [R001E](https://github.com/theislampill/salah_widget/issues/30) owns zero-axis queries; [R001B](https://github.com/theislampill/salah_widget/issues/27) owns network-recipient disclosure. Existing radar/current correctness issues are unchanged, not absorbed. New renderer richness consumes this state and must not drive it. Shared `index.html` weather/atmosphere/diagnostic writers require one integrator; serialize with location and lunar/entry work at their interfaces.

Rollback a new evidence source/approach classifier to explicit unavailable/model-estimated states if validation fails. Never restore alpha-mm authority, convert unknown to dry or retain local rain merely to keep a dramatic scene. Stop and narrow if implementation needs paid infrastructure, continuous GPS, a general state framework or an unvalidated ETA to close this issue. Done is the honest state/renderer contract with exact-candidate evidence; arrival accuracy and future provider qualification remain separate work.
