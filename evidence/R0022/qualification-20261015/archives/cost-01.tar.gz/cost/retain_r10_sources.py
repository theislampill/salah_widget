from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent;R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget');packet=json.loads((D/'PREMEASUREMENT_PINS_R10.json').read_bytes());target=D/'setup-chromium-dpr1-r10/observer-source';target.mkdir()
for group,base in [('files',D),('repositoryFiles',R)]:
 for name,digest in packet[group].items():
  data=(base/name).read_bytes();assert hashlib.sha256(data).hexdigest()==digest
  p=target/group/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
print('R10 exact preimages retained')
