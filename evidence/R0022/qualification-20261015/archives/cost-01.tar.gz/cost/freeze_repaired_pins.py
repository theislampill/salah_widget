from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent;R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((D/'PREMEASUREMENT_PINS_R9.json').read_bytes())
record={'files':{name:sha(D/name)for name in [*old['files'],'preflight_controls.mjs','prepare_repaired_fixture.py']},'repositoryFiles':{name:sha(R/name)for name in old['repositoryFiles']},'runtime':json.loads((D.parent/'selected-r2/RUNTIME.json').read_bytes())['treeSha256'],'sourceRepair':{name:sha(R/name)for name in ['real-sky/native-preview.mjs','real-sky/native-host.mjs','tests/real-sky/native-lunar-display.test.mjs','tests/real-sky/native-host-composition.test.mjs']},'scope':'Repaired H1 source and canonical-phase fixture. No approval or timing; exact source plus observed native setup requires independent review.'}
p=D/'PREMEASUREMENT_PINS_R12.json';assert not p.exists();p.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');print(json.dumps({'packet':sha(p),'driver':record['files']['run_native_cost.py'],'runtime':record['runtime']}))
