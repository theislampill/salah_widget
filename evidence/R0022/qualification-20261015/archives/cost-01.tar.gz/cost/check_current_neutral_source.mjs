import fs from 'node:fs';import crypto from 'node:crypto';
import {nativeAtmosphereFields} from 'file:///C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget/real-sky/native-preview.mjs';
const C='C:/Users/theis/.codex/work-products/r0022-execution-20261015/cost';
const sh=b=>crypto.createHash('sha256').update(b).digest('hex');
const path=C+'/admission-diagnostic-r3/quiescence-all.json',data=fs.readFileSync(path),rows=JSON.parse(data);
const raw=rows.find(r=>r.side==='candidate').actualAfterQuiescence.raw,{view,backgroundStepCss:step,diffuse}=raw.request.options;
const fields=nativeAtmosphereFields(raw.result.physicalState,raw.result.atmosphere,view,diffuse.residualNight,Math.ceil(325/step),Math.ceil(530/step));
const source=fields.background,actualHash=sh(Buffer.from(source.buffer,source.byteOffset,source.byteLength)),expected=raw.result.arrays.skyBackgroundLinear.sha256;
let neutral=0,positive=0;
for(let i=0;i<source.length;i+=3){if(Object.is(source[i],source[i+1])&&Object.is(source[i],source[i+2]))neutral++;if(source[i]>0)positive++;}
const out={schema:'r0022-current-neutral-source-discriminator/v1',inputSha256:sh(data),sourceOwnerSha256:sh(fs.readFileSync('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget/real-sky/native-preview.mjs')),node:process.version,expectedNativeSha256:expected,reconstructedSha256:actualHash,byteIdentity:actualHash===expected,pixels:source.length/3,neutralPixels:neutral,positivePixels:positive,scope:'One offline use of current native field owner with actual captured physical state/atmosphere/grid. Only exact SHA equality can associate reconstructed bytes with the current native raw field. No native cost, output change or new physical calibration claim.'};
fs.writeFileSync(C+'/admission-diagnostic-r3/neutral-source.json',JSON.stringify(out,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(out));
