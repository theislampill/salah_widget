from pathlib import Path
import hashlib,json,shutil,subprocess,sys
D=Path(__file__).resolve().parent;O=D.parent;R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
assert read(O/'browser-lease.json')['status']=='FREE'and not(O/'native-resource.lock').exists()
assert (O/'selected-r5/RUNTIME.json').exists()
retained=D/'retained-fixture-r15';assert not retained.exists();retained.mkdir()
old=read(D/'SOURCE_FIXTURE.json')
for row in old['files']:
 p=D/row['side']/row['path'];assert sha(p)==row['fixtureSha256'];q=retained/row['side']/row['path'];q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
shutil.copyfile(D/'SOURCE_FIXTURE.json',retained/'SOURCE_FIXTURE.json')
s=(D/'prepare_sources_r15.py').read_text(encoding='utf-8').replace('selected-r4','selected-r5')
anchor="    insert(b'let nativeDisplayEncodeCache=null;',b'\\nwindow.__r0022CostObserver.caches.push({get value(){return nativeDisplayEncodeCache;}});')"
extra="""
    insert(b'let client,lifecycle,frame=null,job=null,disposed=false,paintedFrame=null,paintedJob=null,previousPresentation=null,previousSolarMask=null,previousMoonBottom=0,lastCompose=-Infinity,animationId=null,workerUrl=null;',b'\\n window.__r0022CostObserver.caches.push({kind:"solar-mask",get value(){return previousSolarMask;},get rows(){return previousPresentation?.rows??0;}});')"""
assert s.count(anchor)==1;s=s.replace(anchor,anchor+extra)
(D/'prepare_sources_r16.py').write_text(s,encoding='utf-8')
subprocess.run([sys.executable,'-I','-S','-B',str(D/'prepare_sources_r16.py')],check=True)
s=(D/'counter_probe_r15.js').read_text(encoding='utf-8')
needle='directions:v.directions.length,typedBytes:';assert s.count(needle)==1
s=s.replace(needle,'directions:v.directions.length,vectors:v.vectors?.filter(Boolean).length??0,finiteVectors:v.vectors?v.vectors.filter(Boolean).every(a=>Array.isArray(a)&&a.length===3&&a.every(Number.isFinite)):true,typedBytes:')
needle="}:{kind:'encoder',initialized:!!c.value,";assert s.count(needle)==1
s=s.replace(needle,"}:c.kind==='solar-mask'?{kind:'solar-mask',initialized:c.value!==null,urlLength:c.value?.length??0,rows:c.rows}:{kind:'encoder',initialized:!!c.value,")
(D/'counter_probe_r16.js').write_text(s,encoding='utf-8')
s=(D/'receiver.mjs').read_text(encoding='utf-8')
start=s.index(" const scopes=[{name:'nativeAdmission'");end=s.index('\n',start)
s=s[:start]+" const scopes=[{name:'nativeAdmission',A:admission(windows.baseline),B:admission(windows.candidate)}];"+s[end:]
s=s.replace("raw.status='RAW_BATCHES_RETURNED';", "raw.status='PARTIAL_SELECTED_SCOPE_RETURNED';raw.unmeasuredScopes=['atmosphere','paint','renderMoon','nativePreview','nativeFastPreview'];")
# Guard against any future receiver shape change silently keeping a full verdict.
assert "PARTIAL_SELECTED_SCOPE_RETURNED" in s
(D/'receiver_r16.mjs').write_text(s,encoding='utf-8')
s=(D/'run_native_cost_r15.py').read_text(encoding='utf-8').replace('selected-r4','selected-r5').replace('counter_probe_r15.js','counter_probe_r16.js').replace("D/'receiver.mjs'","D/'receiver_r16.mjs'").replace("review['files']['receiver.mjs']","review['files']['receiver_r16.mjs']")
s=s.replace("'scope':'One serial cost setup and six predeclared ABBA function scopes'","'scope':'R5 exact setup then ONLY changed admission scope, same full5s/fourABBA policy; other scopes unmeasured'")
s=s.replace(' raw=None;admission=',' clean=False;raw=None;admission=')
s=s.replace("await ctx.close();await browser.close();return","await ctx.close();await browser.close();clean=True;return")
start=s.index('   raw=await page.evaluate("async b=>{const m=await import(\'/receiver.mjs\');return m.measure(')
end=s.index("   ctx,page,frames=await setup('display'",start)
s=s[:start]+"   raw={**binding,'schema':'r0022-paint-cost/v1','measurementKind':'actual-browser','status':'ACQUIRING','scopes':[]}\n   save(a.out/'raw.json',raw);await ctx.close()\n"+s[end:]
s=s.replace("'adapter':sha((D/'receiver.mjs').read_bytes())","'adapter':sha((D/'receiver_r16.mjs').read_bytes())")
s=s.replace("save(a.out/'raw.json',raw);await ctx.close();await browser.close()","save(a.out/'raw.json',raw);await ctx.close();await browser.close();clean=True")
s=s.replace("'finishedAtUtc':now(),'errors':errors","'finishedAtUtc':now(),'ownedNativeCleanupEstablished':clean,'errors':errors")
needle="  lease.update(status='FREE',owner=None,finishedAtUtc=now());save(O/'browser-lease.json',lease);assert(O/'native-resource.lock').read_text()==a.out.name;(O/'native-resource.lock').unlink()"
assert s.count(needle)==1
s=s.replace(needle,"""  if clean:
   lease.update(status='FREE',owner=None,finishedAtUtc=now());save(O/'browser-lease.json',lease);assert(O/'native-resource.lock').read_text()==a.out.name;(O/'native-resource.lock').unlink()
  else:
   lease.update(status='RECOVERY_REQUIRED',owner='R0022 root',reason='Native cost closure not established');save(O/'browser-lease.json',lease)""")
(D/'run_native_cost_r16.py').write_text(s,encoding='utf-8')
p=read(D/'PREMEASUREMENT_PINS_R15.json');p['files']={n:sha(D/n)for n in p['files']}
for n in ['prepare_r16.py','prepare_sources_r16.py','receiver_r16.mjs','counter_probe_r16.js','run_native_cost_r16.py']:p['files'][n]=sha(D/n)
p['runtime']=read(O/'selected-r5/RUNTIME.json')['treeSha256'];p['sourceRepair']={n:sha(R/n)for n in p['sourceRepair']}
for n in ['tests/real-sky/native-lunar-boundaries.test.mjs','tests/real-sky/native-lunar-cache.test.mjs']:p['sourceRepair'][n]=sha(R/n)
p['scope']='Selected-r5, only changed nativeAdmission four fullABBA rounds after5s warmups. Other five scopes explicitly unmeasured in this artifact. Fixed budget/noise unchanged. Actual rigid vectors and single solar-mask URL inventory; setup only until independent actual preflight review. This is a source-change comparison, not a noise retry.'
save(D/'PREMEASUREMENT_PINS_R16.json',p)
print(json.dumps({'packet':sha(D/'PREMEASUREMENT_PINS_R16.json'),'adapter':sha(D/'run_native_cost_r16.py'),'receiver':sha(D/'receiver_r16.mjs'),'runtime':p['runtime'],'fixture':sha(D/'SOURCE_FIXTURE.json')}))
