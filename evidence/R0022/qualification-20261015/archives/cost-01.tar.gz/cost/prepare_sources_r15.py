from pathlib import Path
import hashlib,importlib.util,json,subprocess
O=Path(__file__).resolve().parent.parent;D=O/'cost';R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget')
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,o):p.write_text(json.dumps(o,indent=2)+'\n',encoding='utf-8')
original='fd2972ba64225fe9d6848e92497e6d0ed20ea624'
for name in ['index.html','config.js']:
 p=D/'original'/name;p.parent.mkdir(exist_ok=True);b=subprocess.check_output(['git','show',original+':'+name],cwd=R);p.write_bytes(b)
spec=importlib.util.spec_from_file_location('cost',R/'tests/r0022-paint-cost.py');cost=importlib.util.module_from_spec(spec);spec.loader.exec_module(cost)
manifest={'schema':'r0022-cost-source-fixture/v1','originalCommit':original,'baselineCommit':'fc8d13338f9274a768580cda5a805492f80c510d','candidateRuntime':json.loads((O/'selected-r4/RUNTIME.json').read_bytes())['treeSha256'],'files':[]}
for name in ['index.html','config.js']:
 b=(D/'original'/name).read_bytes();manifest['files'].append({'side':'original','path':name,'sourceSha256':sha(b),'fixtureSha256':sha(b),'inserts':[]})
for side,root in [('baseline',O/'qualification/baseline-current'),('candidate',R)]:
 for name in ['index.html','real-sky/native-sky.js']:
  source=(root/name).read_bytes();b=source;inserts=[]
  def insert(anchor,extra):
   global b
   assert b.count(anchor)==1,(side,name,anchor,b.count(anchor))
   b=b.replace(anchor,anchor+extra,1);inserts.append(extra)
  insert(b'const displayGeometryCache=new Map();',b'\nwindow.__r0022CostObserver.caches.push(displayGeometryCache);')
  if side=='candidate':
   insert(b'const lunarGeometryCache=new Map();',b'\nwindow.__r0022CostObserver.caches.push(lunarGeometryCache);')
   if name.endswith('native-sky.js'):
    insert(b'let nativeDisplayEncodeCache=null;',b'\nwindow.__r0022CostObserver.caches.push({get value(){return nativeDisplayEncodeCache;}});')
  # Expose the actual retained rigid-geometry arrays, otherwise hidden in method
  # closures. This finite observer-only property is created during warmup.
  anchor=b'const value={mapping,scale(x,y)';extra=b'__costBuffers:[rays,scales,ready],'
  assert b.count(anchor)==1;b=b.replace(anchor,b'const value={'+extra+b'mapping,scale(x,y)',1);inserts.append(extra)
  # Hoisted actual compiled function, not an imported duplicate or mirrored body.
  anchor=b'function renderNativeBackgroundPreview(snapshot){';extra=b'window.__r0022CostPreview=renderNativeBackgroundPreview;\n'
  assert b.count(anchor)==1;b=b.replace(anchor,extra+anchor,1);inserts.append(extra)
  if name.endswith('native-sky.js'):
   patched=cost.prepare_host_owner(b,sha(b))
   inserts += [b'\n  if(window.__r0022CostProbe?.captureRaw)window.__r0022CostProbe.captureRaw(result,request);',b'\n if(window.__r0022CostProbe?.bind)window.__r0022CostProbe.bind({accept,current:request=>lifecycle.current(request,snapshot()),readState});']
   b=patched
  recovered=b
  for marker in inserts:assert recovered.count(marker)==1;recovered=recovered.replace(marker,b'',1)
  assert recovered==source,'Guarded removal must recover original bytes exactly'
  p=D/side/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
  manifest['files'].append({'side':side,'path':name,'sourceSha256':sha(source),'fixtureSha256':sha(b),'inserts':[i.decode()for i in inserts]})
save(D/'SOURCE_FIXTURE.json',manifest)
print(json.dumps({'status':'DISPOSABLE_FIXTURES_ONLY','files':len(manifest['files']),'manifest':sha((D/'SOURCE_FIXTURE.json').read_bytes())}))
