from pathlib import Path
import hashlib,json,subprocess
D=Path(__file__).resolve().parent;O=D.parent;R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
old=json.loads((D/'PREMEASUREMENT_PINS_R9.json').read_bytes());archive=D/'measure-chromium-dpr1-r9/observer-source';archive.mkdir()
for name,digest in old['files'].items():
 p=D/name;data=p.read_bytes()
 if name=='receiver.mjs':
  # New preflight was inserted between the unchanged import and measure export.
  # Recover and verify the R9 source by its already published pre-run digest.
  start=data.index(b'export async function proveOriginalQuiescence(');end=data.index(b'export async function measure(')
  data=data[:start]+data[end:]
 assert hashlib.sha256(data).hexdigest()==digest,(name,'R9 custody drift')
 target=archive/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
for row in json.loads((D/'SOURCE_FIXTURE.json').read_bytes())['files']:
 p=D/row['side']/row['path'];assert sha(p)==row['fixtureSha256'];target=archive/'fixture'/row['side']/row['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
# Source-derived fixture phase is independent of timings. The actual setup must
# prove this prediction equals the current accepted fraction at the same footprint.
node='C:/workspace/ai/cp9-integration-20261005/toolchain/node-v22.16.0-win-x64/node.exe'
code="const fs=require('fs'),vm=require('vm');const c={};vm.createContext(c);vm.runInContext(fs.readFileSync(process.argv[1],'utf8'),c);console.log(JSON.stringify([109,217].map(d=>({diameter:d,phase:c.canonicalFraction(.92,d),idempotent:c.canonicalFraction(c.canonicalFraction(.92,d),d)}))));"
phases=json.loads(subprocess.check_output([node,'-e',code,str(R/'moon/src/moon-precision.mjs')],text=True))
assert all(x['phase']==x['idempotent']for x in phases)
scene=json.loads((D/'SCENES.json').read_bytes());scene['original']['phase']='source-canonical gibbous; exact per-cell value below';scene['original']['originalFailurePhase']=.92
scene['original']['canonicalPhaseByCell']={key:{**value,'source':str(R/'moon/src/moon-precision.mjs'),'sourceSha256':sha(R/'moon/src/moon-precision.mjs')}for key,value in zip(['chromium-dpr1','firefox-dpr2'],phases)}
scene['original']['phaseDerivation']='Unchanged actual native canonicalFraction(.92, footprint), not timing selection.109px comes from R9 actual original candidate;217px from ordinary Firefox DPR2 layout. Setup must independently confirm actual fixed-scene footprint, accepted fraction and idempotence before measurement; mismatch fails closed.'
scene['status']='SOURCE_REPAIR_NEW_FIXTURE_REQUIRES_OBSERVED_SETUP_REVIEW';save(D/'SCENES.json',scene)
p=D/'prepare_sources.py';s=p.read_text();s=s.replace("'candidateRuntime':'fe73f4796bdc9e4292e20b48bde69b839cf6cda87cf768c53d53be4191a47953'","'candidateRuntime':json.loads((O/'selected-r2/RUNTIME.json').read_bytes())['treeSha256']");p.write_text(s,encoding='utf-8',newline='')
p=D/'run_native_cost.py';s=p.read_text();s=s.replace("selected-r1/RUNTIME.json","selected-r2/RUNTIME.json")
s=s.replace("fragment='lat=24.47", "phase_fixture=read(D/'SCENES.json')['original']['canonicalPhaseByCell'].get(a.engine+'-dpr'+str(a.dpr))\n    assert phase_fixture is not None\n    fragment='lat=24.47")
s=s.replace("simMoon=.92&simWax", "simMoon='+str(phase_fixture['phase'])+'&simWax")
anchor="    await page.screenshot(path=str(a.out/(kind+'-quiescent.png')))"
assert s.count(anchor)==1
s=s.replace(anchor,"    if kind=='original':\n     proof=await page.evaluate(\"async v=>{const m=await import('/receiver.mjs');return m.proveOriginalQuiescence({windows:{original:document.querySelector('#a').contentWindow,candidate:document.querySelector('#b').contentWindow},fixture:v});}\",phase_fixture)\n     save(a.out/'original-repeated-quiescence.json',proof)\n     if proof['status']!='QUIESCENT':raise RuntimeError('Repeated native calls are not quiescent; retained')\n"+anchor)
p.write_text(s,encoding='utf-8',newline='')
p=D/'counter_probe.js';s=p.read_text().replace('let serial=0,','let renderRequests=0,serial=0,');s=s.replace("if(m?.kind==='render')record.pending.add(m.id);","if(m?.kind==='render'){renderRequests++;record.pending.add(m.id);}");s=s.replace('function live(){return {pendingJobs:', 'function live(){return {renderRequests,pendingJobs:');p.write_text(s,encoding='utf-8',newline='')
print(json.dumps({'phaseFixtures':phases,'retainedR9Files':len(old['files'])}))
