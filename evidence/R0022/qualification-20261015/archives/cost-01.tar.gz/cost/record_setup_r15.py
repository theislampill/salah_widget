from pathlib import Path
import json,hashlib,datetime
D=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
packet=D/'PREMEASUREMENT_PINS_R15.json';assert sha(packet)=='702792ba51192b22a9294691f230bf78a0b2475c01840905edd38e4a768b737e'
for cell,name in [('CHROMIUM','run_native_cost_r15.py'),('FIREFOX','run_native_cost_firefox_r15.py')]:
 p=json.loads(packet.read_bytes());p.update(status='APPROVED_FOR_SETUP_ONLY',adapterSha256=sha(D/name),packetSha256=sha(packet),reviewer='/root/r0022_independent_review',recordedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),provenance='Executor transcription of actual independent reviewer return before native setup; no signature or formal lifecycle receipt.',verdict='33 packet pins,135 runtime hashes,six fixture reconstructions,retained R14 originals and18case bridge verified. Serial C1/F2 setup only. Atomic actual cache inventory stability required. No warmup or timing approved.')
 (D/('SETUP_REVIEW_R15_'+cell+'.json')).write_text(json.dumps(p,indent=2)+'\n',encoding='utf-8')
