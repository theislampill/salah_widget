"""Report only the retained admission scope; never manufacture the missing full A03 result."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,math,statistics
D=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(D/'evaluate_noise.py')=='e1af979731738bd2252102fa3da402a3ded45cfd073e1ff750431e4ba973bf70'
assert sha(D/'NOISE_POLICY.json')=='7ebff50f1d329b04e6f6004909c88faff702579d63dd474fbebdf7732f9142c9'
spec=importlib.util.spec_from_file_location('fixed_noise',D/'evaluate_noise.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def p95(v):return sorted(v)[math.ceil(.95*len(v))-1]
def valid_warm(w):return isinstance(w,dict)and set(w)=={'A','B'}and all(isinstance(v,(int,float))and not isinstance(v,bool)and math.isfinite(v)and v>=5000 for v in w.values())
assert valid_warm({'A':5000,'B':5001})and not any(valid_warm(w)for w in [{},{'A':5000},{'A':5000,'B':4999},{'A':5000,'B':5000,'C':5000},{'A':5000,'B':float('nan')}])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('run',type=Path);a=p.parse_args()
 raw=json.loads((a.run/'raw.json').read_bytes())
 assert raw['status']=='PARTIAL_SELECTED_SCOPE_RETURNED'and len(raw['scopes'])==1
 s=raw['scopes'][0];assert s['name']=='nativeAdmission'and s['status']=='RAW_BATCHES_RETURNED'
 assert raw['unmeasuredScopes']==['atmosphere','paint','renderMoon','nativePreview','nativeFastPreview']
 assert all(r['elapsedMs']>=5000 and not r['exceptions']and len(r['durationsMs'])>0 for r in s['slots'])
 assert valid_warm(s['warmMs'])
 assert all(isinstance(v,(int,float))and math.isfinite(v)and v>=0 for r in s['slots']for v in r['durationsMs'])
 noise=m.noise_scope(s);vals={side:[v for r in s['slots']if r['side']==side for v in r['durationsMs']]for side in 'AB'}
 stats={side:{'calls':len(v),'medianMs':statistics.median(v),'p95Ms':p95(v)}for side,v in vals.items()}
 limits={k:stats['A'][k]+max(.25,.1*stats['A'][k])for k in ['medianMs','p95Ms']}
 within=all(stats['B'][k]<=limits[k]for k in limits)
 report={'schema':'r0022-admission-only-cost-readback/v1','rawSha256':sha(a.run/'raw.json'),'evaluatorSha256':sha(Path(__file__)),'noisePolicySha256':sha(D/'NOISE_POLICY.json'),'status':'PASS_SCOPE_ONLY'if within and noise['status']=='CONTROLLED'else'INCONCLUSIVE_NOISE'if noise['status']!='CONTROLLED'else'FAIL_SCOPE','budgetWithin':within,'baseline':stats['A'],'candidate':stats['B'],'limits':limits,'noise':noise,'blocks':4,'slots':len(s['slots']),'candidateRoundMediansMs':[statistics.median([v for r in s['slots']if r['side']=='B'and r['block']==b for v in r['durationsMs']])for b in range(4)],'A03':'INCOMPLETE: five other scopes unmeasured in this artifact; actual input/resource provenance still requires independent review.','scope':'All retained calls, fixed median/nearest-rank p95 and predeclared noise policy. No filtering or threshold change.'}
 out=a.run/'admission-scope-assessment.json';assert not out.exists();out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps(report))
