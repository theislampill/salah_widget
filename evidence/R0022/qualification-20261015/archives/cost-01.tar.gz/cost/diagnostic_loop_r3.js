async ({side,durationMs})=>{
 const w=document.querySelector(side==='baseline'?'#a':'#b').contentWindow;
 const adapter=w.__r0022DiagnosticAdapter;
 // Same parent-frame pulse and awaited phase ordering as collectCostScope.
 // This is diagnostic custody, not a replacement qualifying collector.
 const pulse=()=>new Promise((resolve,reject)=>{
  let frame,timer;
  const finish=error=>{cancelAnimationFrame(frame);clearTimeout(timer);error?reject(error):resolve();};
  timer=setTimeout(()=>finish(new Error('No native animation frame within the finite cost fixture watchdog')),10000);
  frame=requestAnimationFrame(()=>finish());
 });
 const record=window.__r0022DiagInProgress={status:'ACQUIRING',side,timeOrigin:performance.timeOrigin,startMs:performance.now(),calls:[],errors:[]};
 try{
  while(performance.now()-record.startMs<durationMs){
   await pulse();
   const call={index:record.calls.length,stage:'prepare',startMs:performance.now(),prepareMs:null,runMs:null,verifyMs:null,completed:false};
   record.calls.push(call);
   try{
    await adapter.prepare();call.prepareEndMs=performance.now();call.prepareMs=call.prepareEndMs-call.startMs;
    call.stage='run';call.runStartMs=performance.now();
    try{
     const value=adapter.run();
     if(value&&typeof value.then==='function')throw new TypeError('Asynchronous work is outside synchronous self-time scope');
    }finally{call.runEndMs=performance.now();call.runMs=call.runEndMs-call.runStartMs;}
    call.stage='verify';call.verifyStartMs=performance.now();
    try{await adapter.verify();}finally{call.verifyEndMs=performance.now();call.verifyMs=call.verifyEndMs-call.verifyStartMs;}
    call.stage='complete';call.completed=true;
   }catch(error){call.error=String(error?.stack??error);record.errors.push(call.error);}
   finally{call.endMs=performance.now();}
   if(record.errors.length)break;
  }
 }catch(error){record.errors.push(String(error?.stack??error));}
 finally{record.elapsedMs=performance.now()-record.startMs;record.status=record.errors.length?'INCOMPLETE':'DIAGNOSTIC_CALLS_RETURNED';}
 return record;
}
