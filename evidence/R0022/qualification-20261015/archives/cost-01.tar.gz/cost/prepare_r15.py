from pathlib import Path
import hashlib,json,shutil,subprocess,sys
D=Path(__file__).resolve().parent;O=D.parent;R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
assert read(O/'browser-lease.json')['status']=='FREE'and not(O/'native-resource.lock').exists()
retained=D/'retained-fixture-r14';retained.mkdir()
old=read(D/'SOURCE_FIXTURE.json')
for row in old['files']:
 p=D/row['side']/row['path'];assert sha(p)==row['fixtureSha256']
 q=retained/row['side']/row['path'];q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
shutil.copyfile(D/'SOURCE_FIXTURE.json',retained/'SOURCE_FIXTURE.json')
source=(D/'prepare_sources_r14.py').read_text().replace('selected-r3','selected-r4')
anchor="  # Expose the actual retained rigid-geometry arrays"
extra="""  if side=='candidate':
   insert(b'const lunarGeometryCache=new Map();',b'\\nwindow.__r0022CostObserver.caches.push(lunarGeometryCache);')
   if name.endswith('native-sky.js'):
    insert(b'let nativeDisplayEncodeCache=null;',b'\\nwindow.__r0022CostObserver.caches.push({get value(){return nativeDisplayEncodeCache;}});')
"""
assert source.count(anchor)==1;source=source.replace(anchor,extra+anchor)
(D/'prepare_sources_r15.py').write_text(source,encoding='utf-8')
subprocess.run([sys.executable,'-I','-S','-B',str(D/'prepare_sources_r15.py')],check=True)
for name in ['run_native_cost_r14.py','run_native_cost_firefox_r14.py']:
 s=(D/name).read_text().replace('selected-r3','selected-r4').replace('counter_probe.js','counter_probe_r15.js')
 (D/name.replace('r14','r15')).write_text(s,encoding='utf-8')
s=(D/'counter_probe.js').read_text()
anchor='return {retainedArrays:arrays.size,retainedBytes:[...buffers].reduce((n,b)=>n+b.byteLength,0)};'
extra="""return {retainedArrays:arrays.size,retainedBytes:[...buffers].reduce((n,b)=>n+b.byteLength,0),cacheInventory:caches.map(c=>c instanceof Map?{kind:'map',entries:c.size,geometries:[...c.values()].filter(v=>v.directions).map(v=>({width:v.width,height:v.height,gx:v.gx,gy:v.gy,directions:v.directions.length,typedBytes:['omega','above','ix','tx','iy','ty'].reduce((n,k)=>n+v[k].byteLength,0)}))}:{kind:'encoder',initialized:!!c.value,typedBytes:c.value?['edges','low','high'].reduce((n,k)=>n+c.value[k].byteLength,0):0})};"""
assert s.count(anchor)==1;s=s.replace(anchor,extra);(D/'counter_probe_r15.js').write_text(s,encoding='utf-8')
p=read(D/'PREMEASUREMENT_PINS_R14.json');p['files']={n:sha(D/n)for n in p['files']}
for n in ['prepare_r15.py','prepare_sources_r15.py','run_native_cost_r15.py','run_native_cost_firefox_r15.py','counter_probe_r15.js']:p['files'][n]=sha(D/n)
p['runtime']=read(O/'selected-r4/RUNTIME.json')['treeSha256']
for n in ['tests/real-sky/native-host-encoding.test.mjs','tests/real-sky/native-lunar-fused.test.mjs']:p['sourceRepair'][n]=sha(R/n)
p['sourceRepair']={n:sha(R/n)for n in p['sourceRepair']}
p['scope']='Selected-r4 canonical H1. Same six actual scopes, matched inputs, fixed budget, noise policy and full admission. New actual bounded geometry and encoder caches observed. R14 fixtures retained; setup only until independent native preflight review.'
save(D/'PREMEASUREMENT_PINS_R15.json',p)
print(json.dumps({'packet':sha(D/'PREMEASUREMENT_PINS_R15.json'),'runtime':p['runtime'],'fixture':sha(D/'SOURCE_FIXTURE.json'),'observer':sha(D/'counter_probe_r15.js')}))
