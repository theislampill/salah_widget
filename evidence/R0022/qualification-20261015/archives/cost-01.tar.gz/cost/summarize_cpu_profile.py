from pathlib import Path
import collections,hashlib,json,sys
p=Path(sys.argv[1]);profile=json.loads(p.read_bytes());nodes={n['id']:n for n in profile['nodes']}
parent={child:n['id']for n in nodes.values()for child in n.get('children',[])}
self_us=collections.Counter();inclusive_us=collections.Counter()
assert len(profile['samples'])==len(profile['timeDeltas'])
for ident,delta in zip(profile['samples'],profile['timeDeltas']):
 self_us[ident]+=delta
 while True:
  inclusive_us[ident]+=delta
  if ident not in parent:break
  ident=parent[ident]
def row(ident):
 f=nodes[ident]['callFrame'];return {'node':ident,'name':f['functionName'],'url':f['url'],'lineOneBased':f['lineNumber']+1,'selfMs':self_us[ident]/1000,'inclusiveMs':inclusive_us[ident]/1000}
accept=[n['id']for n in nodes.values()if n['callFrame']['functionName']=='accept' and '/candidate/real-sky/native-sky.js' in n['callFrame']['url']]
assert accept, 'Actual native accept node missing'
desc=set()
def visit(i):
 if i in desc:return
 desc.add(i)
 for c in nodes[i].get('children',[]):visit(c)
for ident in accept:visit(ident)
summary={'schema':'r0022-cpu-sampling-summary/v1','profileSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'samples':len(profile['samples']),'sampledMs':sum(profile['timeDeltas'])/1000,'scope':'Sampling diagnostic only. Self-time rows are disjoint; inclusive times overlap and must not be added to descendant self-times. No qualifying cost result.','acceptNodes':[row(i)for i in accept],'acceptDescendantSelfMs':sum(self_us[i]for i in desc)/1000,'acceptTopSelf':[row(i)for i in sorted(desc,key=lambda i:self_us[i],reverse=True)[:30]],'allTopSelf':[row(i)for i in sorted(nodes,key=lambda i:self_us[i],reverse=True)[:20]]}
out=p.with_name('profile-summary.json');assert not out.exists();out.write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
