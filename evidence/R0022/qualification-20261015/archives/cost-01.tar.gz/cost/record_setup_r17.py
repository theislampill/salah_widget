from pathlib import Path
import datetime,hashlib,json
C=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
packet=C/'PREMEASUREMENT_PINS_R17.json';assert sha(packet)=='12aa1e8b6c6a04ca724b2e6109757150628469429bcbf96ba9ee0fced57f555f'
p=json.loads(packet.read_bytes());p.update(status='APPROVED_FOR_SETUP_ONLY',adapterSha256=sha(C/'run_native_cost_r17.py'),packetSha256=sha(packet),reviewer='/root/r0022_independent_review',recordedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),provenance='Root transcription of actual independent reviewer FINAL_ANSWER before native setup; no signature/formal lifecycle receipt.',verdict='All45packetpins/135runtimefiles match; sixexactinstrumentationremovals restore source. Driver change onlyR6binding/scope. OldR16fixture/failedbuildretained. OneC1original+displaysetup only. No warmup/timinguntilactualcurrentness/input/inventory/timer/cleanupreview.')
with(C/'SETUP_REVIEW_R17_CHROMIUM.json').open('x',encoding='utf-8')as f:f.write(json.dumps(p,indent=2)+'\n')
print(sha(C/'SETUP_REVIEW_R17_CHROMIUM.json'))
