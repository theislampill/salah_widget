# Selected R0022 resource scope

Source: selected-r2 runtime `4045c38b37d4918164187004261e68754bd99b1b0485233689b17d2d2bf8ed9d`; preview `7a841954254f23f214ee8ee66dd1c879b2d1c2bd19465be68bf605987580554d`; host `d112c2b525be0c4d279525985356fc8be15435a2ca641fd5d08501c97c925510`.

This is a source inventory for independent review. It is not a performance verdict or an assertion that the entire application heap is bounded. Actual retained-array and resource observations remain in each original timing slot.

## Added allocation owners

- `nativeAtmosphereFields` adds one Float64 lunar grid with `(gx+1)*(gy+1)*3` entries and one Float64 lunar raster with `width*height*3` entries. Each is local to one call. The lunar raster survives only with its accepted raster; the grid does not escape. The existing background, solar and aerosol planes are preserved. Actual equality of sampled channels permits identical interpolation to be performed once; this adds no cache or approximation.
- `nativeLunarNightDisplay` creates one Float64 copy of the lunar raster when a nonzero lunar contribution is eligible for the night leg. It returns the mapped plane and a small fixed-shape diagnostic object when samples exceed the approved knee. Raw lunar and sky planes remain separately accessible. A below-knee-only copy is temporary, not retained.
- Deep-night presentation creates a mapped sky plane. It creates separate total-light and diffuse-background planes only when those separate contributions exist; the atmosphere-only preview retains its established shared read-only output ownership. Raw input planes never alias mapped output. Twilight uses its existing output allocation structure plus the separately declared mapped lunar plane.
- The native full raster is 325×530; one RGB Float64 plane is 4,134,000 bytes. Fast preview is 65×106 and its plane is 165,360 bytes. These are fixed native dimensions, not per-frame accumulated history. A new accepted result replaces the prior frame. Preview replacement likewise replaces the prior preview result.
- New-frame host composition assembles one 325×530 RGBA buffer (689,000 bytes), using the already composed region and encoding only the untouched tail. The encoded tail is a bounded temporary; its subarray input is a view of existing data. The previous full-frame-plus-overwritten-region encoding is eliminated. Publication remains after the same currentness fence. Same-frame foreground changes retain the existing regional path.

## Ownership and execution frequency

There is no new module-global cache, provider, request, worker, controller, event listener, rAF chain, interval, canvas, texture, or readback in the two authored changes. The existing four-entry camera geometry cache and physical model caches are unchanged. In particular, the existing B-V fit cache has no new global boundedness claim.

The lunar decomposition and mapping run when building the existing preview or accepting the existing physical worker result. They are not inserted into the ordinary repeated foreground-composition path. Existing solar mask/canvas capture and native update scheduling remain their original owners; the change does not add a new per-frame solver or network/readback action.

## Measurement boundary

The disposable observer records actual jobs, render requests, rAF/timer/interval ownership, inherited and new listeners/providers, network requests, canvas/backing allocation events, readbacks, and reachable unique retained arrays/buffers. It does not instrument every transient JavaScript allocation or claim worker/GPU allocator coverage. Temporary typed arrays are accounted for by the source owners above; their CPU/GC impact remains in the untrimmed synchronous timing samples.

Original atmosphere/paint/renderMoon compare the original native owner against the selected candidate at matched Madinah inputs. Added admission/full-preview/fast-preview compare delivered main against selected H1 at matched Orlando inputs. Raw-result cloning and observer checks occur outside the timed admission call, with their durations retained separately; their possible GC effects are not excluded from noise interpretation.

No acceptance follows from this inventory alone. All six scopes must satisfy the unchanged pre-adopted median and p95 budget, resource/currentness checks, and fixed noise policy. Default Firefox R12's 1 ms clock is ineligible for this budget. A separately reviewed precise-timer test profile, if admitted, is reported as such; it does not replace the ordinary Firefox visual environment.
