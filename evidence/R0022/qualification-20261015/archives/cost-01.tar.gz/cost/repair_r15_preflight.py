from pathlib import Path
import hashlib,json,shutil
D=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copyfile(D/'PREMEASUREMENT_PINS_R15.json',D/'PREMEASUREMENT_PINS_R15_PROPOSAL1.json')
for name in ['run_native_cost_r15.py','run_native_cost_firefox_r15.py']:
 p=D/name;s=p.read_text();shutil.copyfile(p,D/(name+'.proposal1'))
 anchor="     quiescence.append({'scene':kind,'side':side,'state':state,"
 insert="""     resource_observation=await frame.evaluate('''()=>{const o=__r0022CostObserver,before=o.live(),first=o.snapshot(),second=o.snapshot(),after=o.live();if(JSON.stringify(before)!==JSON.stringify(after))throw new Error('Inventory read changed live resources');if(JSON.stringify(first)!==JSON.stringify(second))throw new Error('Inventory unstable while quiescent');return {before,first,second,after};}''')
"""
 assert s.count(anchor)==1;s=s.replace(anchor,insert+anchor.replace("'state':state,","'state':state,'resourceObservation':resource_observation,"))
 p.write_text(s,encoding='utf-8')
p=json.loads((D/'PREMEASUREMENT_PINS_R15.json').read_bytes());p['files']={n:sha(D/n)for n in p['files']};p['files']['repair_r15_preflight.py']=sha(Path(__file__))
p['scope']+=' Before measurement, every actual setup side now reads two post-quiescence resource snapshots and requires stable complete snapshots and unchanged live counters.'
(D/'PREMEASUREMENT_PINS_R15.json').write_text(json.dumps(p,indent=2)+'\n',encoding='utf-8');print(sha(D/'PREMEASUREMENT_PINS_R15.json'))
