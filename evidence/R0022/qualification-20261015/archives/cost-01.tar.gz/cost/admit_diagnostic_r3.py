from pathlib import Path
import datetime,hashlib,json,subprocess,sys
C=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
p=C/'ADMISSION_DIAGNOSTIC_R3_PROPOSAL.json';assert sha(p)=='3bfc1c0a3e4c1f9ecf06446057775c22920bcabafa4be601b6880b06bdf788f8'
r=json.loads(p.read_bytes());assert sha(C/'run_admission_diagnostic_r3.py')==r['adapterSha256']=='e3ac6ac68c7006eb64696ba9c98d7419defd5bb55268e457a876b411fb082a1e'
r.update(status='APPROVED_FOR_DIAGNOSTIC',reviewer='/root/r0022_independent_review',reviewCarrier='Root transcription of actual independent revision2 return before execution',proposalSha256=sha(p),reviewedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),controls='Reviewer executed actual loop success/preparation failure/run failure/verification failure/async rejection. Five controls retained expected partial records.',limitation='Transport-aborted partialPageRecord is unassociated unless side and timing establish current slot. Missing profile/resource/currentness violation/identity drift prevents causal attribution. No qualifying verdict/noise retry/source authority.')
review=C/'ADMISSION_DIAGNOSTIC_R3_REVIEW.json';assert not review.exists();review.write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'reviewSha256':sha(review)}),flush=True)
cmd=['C:/workspace/ai/cp9-integration-20261005/venv/Scripts/python.exe','-I','-B',str(C/'run_admission_diagnostic_r3.py'),'--engine','chromium','--dpr','1','--out',str(C/'admission-diagnostic-r3'),'--review',str(review),'--decision',str(C/'ADOPTED_BUDGET_R17_CHROMIUM.json')]
sys.exit(subprocess.call(cmd))
