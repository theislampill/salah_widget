from pathlib import Path
import datetime,hashlib,json
C=Path(__file__).resolve().parent;D=C.parent/'qualification'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,v):
 assert not p.exists();p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
packet=C/'PREMEASUREMENT_PINS_R16.json';assert sha(packet)=='292e2afbda28253c0cd5209a77b6322595b0fb8bd068862ce6c50ba9e9001e3f'
p=read(packet);p.update(status='APPROVED_FOR_SETUP_ONLY',adapterSha256=sha(C/'run_native_cost_r16.py'),packetSha256=sha(packet),reviewer='/root/r0022_independent_review',recordedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),provenance='Root transcription of actual independent reviewer FINAL_ANSWER before native setup; no signature or formal lifecycle receipt.',verdict='All40packetpins/135runtimefiles match;six exact fixture reconstructions. Actual inventory controls pass stable-read,finite-vector,vector-count,maskURL/rows/clear. One serial C1 setup original and display pairs only; exits before warmup/timing. Actual returned setup must independently qualify current paired inputs,quiescence,inventory,timer,cleanup before timing.')
save(C/'SETUP_REVIEW_R16_CHROMIUM.json',p)
cell=D/'candidate-firefox-dpr2-clear-stages-selected-r4-fixture-r7'
r={'schema':'r0022-independent-original-watch-review/v1','reviewer':'/root/r0022_independent_review','recordedBy':'/root','recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'carrier':'Actual reviewer FINAL_ANSWER restated its completed R7 review; no replay or new original-pixel acquisition claimed','bindings':{'report':sha(cell/'results.json'),'dispatch':sha(D/(cell.name+'-dispatch.json')),'inspection':sha(cell/'original-sequence-r1/inspection.json'),'capabilityGap':sha(D/'firefox-recording-capability-r2.json')},'videoSha256':'61c1dbcdcd44e6210022b0d413bd9724d8aa43efd396599b0f79bdbb9beb74c4','boundedCredit':'Clear-scene H1 original still appearance and observed field/stage propagation.','originalWatch':'FAIL_READABILITY','counterevidence':'Pale/incomplete original full-viewport frames at0.8–1.4seconds and3.0/3.2/3.8seconds. Later readable frames do not erase them.','unresolved':'Actual native surface/committed-paint association to the same returned frame bytes.','limits':['No product versus capture attribution','No continuous-watch PASS','No R0021 startup timing credit','No replay authorization','No closure acceptance']}
save(D/'independent-r7-original-watch-review.json',r)
print(json.dumps({'setupReview':sha(C/'SETUP_REVIEW_R16_CHROMIUM.json'),'R7review':sha(D/'independent-r7-original-watch-review.json')}))
