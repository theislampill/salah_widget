import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const R='C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget';
const {nativePaintCostAdapters}=await import(pathToFileURL(R+'/tests/r0022-paint-cost.mjs'));
const raw=fs.readFileSync(new URL('./receiver.mjs',import.meta.url),'utf8'),start=raw.indexOf('export async function proveOriginalQuiescence('),end=raw.indexOf('export async function measure(');
const s={nativePaintCostAdapters,requestAnimationFrame:cb=>queueMicrotask(cb),setTimeout:cb=>queueMicrotask(cb)};
vm.createContext(s);vm.runInContext(raw.slice(start,end).replace('export async','async'),s);
const fixture={phase:.9198668624377639,diameter:109};
function fake(mutation){
 let calls=0;
 const count={renderRequests:0,pendingJobs:0,rafChains:0,timerChains:0,intervalChains:0,listeners:1,providers:1,networkRequests:0,readbacks:0,textureAllocations:0,canvasCreates:0,backingResets:0};
 const functions={renderMoon(){calls++;if(mutation==='request')count.renderRequests++;if(mutation==='pending')count.pendingJobs++;},atmosphere(){return {};},model(){return {};},paint(){}};
 return {eval:name=>name==='moonSky.frac'?(mutation==='phase'||mutation==='later-phase'&&calls>0?.92:fixture.phase):functions[name],__r0022CostObserver:{live:()=>({...count}),snapshot:()=>({...count})},qaState:()=>{count.readbacks++;return {moonTruth:{phaseFraction:.92}};},SalahMoonRuntime:{get state(){return {current:!(mutation==='later-currentness'&&calls>0),pending:false,currentNativeFraction:fixture.phase,accepted:{scene:{fraction:fixture.phase}},phasePrecision:{diameterDevicePixels:mutation==='geometry'?110:109,signedPositionDrift:0}};}}};
}
for(const mutation of [null,'phase','geometry','pending','request','later-phase','later-currentness']){
 const result=await s.proveOriginalQuiescence({windows:{original:fake(),candidate:fake(mutation)},fixture});
 assert.equal(result.rows.length,18);assert.equal(result.status,mutation?'FAILED_RETAINED':'QUIESCENT');
 if(mutation)assert(result.failures.length);console.log(JSON.stringify({mutation,status:result.status,scope:'Synthetic preflight fault controls only; no native qualification'}));
}
