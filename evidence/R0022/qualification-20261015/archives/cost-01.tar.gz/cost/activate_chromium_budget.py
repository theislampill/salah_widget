"""Record the owner's conditional adoption after the actual independent return."""
import hashlib,json
from datetime import datetime,timezone
from pathlib import Path
D=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
 assert not p.exists()
 p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
packet=D/'PREMEASUREMENT_PINS_R9.json'
assert sha(packet)=='d5fb497a2092e64d2c72e2d95b270b7664c2f1788f9b0cac209034c7c30e9fcc'
review=json.loads(packet.read_bytes())
assert sha(D/'run_native_cost.py')==review['files']['run_native_cost.py']
review.update(status='APPROVED_FOR_MEASUREMENT',adapterSha256=review['files']['run_native_cost.py'],packetSha256=sha(packet),reviewer='/root/r0022_independent_review',recordedAtUtc=datetime.now(timezone.utc).isoformat(),provenance='Executor transcription of actual independent reviewer public return; no cryptographic signature or serving-model attestation claimed',scope='Chromium DPR1 only; atmosphere, paint, renderMoon, nativeAdmission, nativePreview, nativeFastPreview synchronous function calls',setupSha256='34d37dc82b64e57fe96aaa5178aa3d68aaf45fa8ef9d4bbfd53d06e550378b1a',verdict='Owner conditional budget-adoption prerequisites satisfied: served native functions, matched actual inputs, fair original/current-main baselines, observer controls, currentness and quiescence confirmed. R9 normalizes only each document clock origin in a comparison copy. Chromium observed timer approximately 0.1 ms. Normal fresh checks required during measurement.',exclusions=['Worker terrain cost','Asynchronous completion','Total application/GPU cost','Startup timing','Firefox DPR2 measurement'],outcomes='Allocation/growth and budget results remain unmeasured. Fixed median and p95 rule, four ABBA rounds and unchanged noise policy required.')
save(D/'MEASUREMENT_REVIEW_R9_CHROMIUM.json',review)
decision=json.loads((D/'CONDITIONAL_BUDGET.json').read_bytes())
decision.update(approved=True,approvedBeforeMeasurement=True,approvedAtUtc=datetime.now(timezone.utc).isoformat(),scope='Chromium DPR1 and six synchronous scopes listed in the independent review',independentReviewSha256=sha(D/'MEASUREMENT_REVIEW_R9_CHROMIUM.json'),conditionalRecordSha256=sha(D/'CONDITIONAL_BUDGET.json'),noisePolicySha256=sha(D/'NOISE_POLICY.json'),disposition='Activated under direct owner conditional authorization after actual independent APPROVED_FOR_MEASUREMENT return; no qualifying timing or warmup has yet been collected.',statistics=['median','p95'],comparison='candidate <= baseline + max(0.25 ms, 0.10 * baseline)',blocks='5-second warmup per side followed by four paired 5-second ABBA rounds per scope')
save(D/'ADOPTED_BUDGET_CHROMIUM.json',decision)
print(json.dumps({'reviewSha256':sha(D/'MEASUREMENT_REVIEW_R9_CHROMIUM.json'),'budgetSha256':sha(D/'ADOPTED_BUDGET_CHROMIUM.json'),'activatedAtUtc':decision['approvedAtUtc']}))
