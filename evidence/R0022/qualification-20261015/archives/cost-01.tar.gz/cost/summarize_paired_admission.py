from pathlib import Path
import collections,hashlib,json,statistics,sys
folder=Path(sys.argv[1]);raw=json.loads((folder/'diagnostic.json').read_bytes())
result={'schema':'r0022-paired-admission-ownership/v1','diagnosticSha256':hashlib.sha256((folder/'diagnostic.json').read_bytes()).hexdigest(),'scope':'Sampling ownership diagnostic only. Self times partition samples; inclusive times overlap. Never add ancestor inclusive and descendant self. GC samples outside accept are unassigned, not asserted caused by product or observer. No cost PASS or threshold decision.','slots':[]}
for slot in raw['slots']:
 p=folder/slot['profile'];data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==slot['profileSha256']
 profile=json.loads(data);nodes={n['id']:n for n in profile['nodes']};parent={c:n['id']for n in nodes.values()for c in n.get('children',[])}
 self_us=collections.Counter();inclusive_us=collections.Counter();paths={}
 for ident in nodes:
  chain=[ident]
  while chain[-1]in parent:chain.append(parent[chain[-1]])
  paths[ident]=chain
 assert len(profile['samples'])==len(profile['timeDeltas'])
 for ident,delta in zip(profile['samples'],profile['timeDeltas']):
  self_us[ident]+=delta
  for ancestor in paths[ident]:inclusive_us[ancestor]+=delta
 accepts={n['id']for n in nodes.values()if n['callFrame']['functionName']=='accept'and('/'+slot['side']+'/real-sky/native-sky.js')in n['callFrame']['url']}
 assert accepts,'Actual native accept stack missing'
 inside={i for i in nodes if any(a in paths[i]for a in accepts)}
 def frame(i):
  f=nodes[i]['callFrame'];return {'node':i,'name':f['functionName'],'url':f['url'],'lineOneBased':f['lineNumber']+1}
 def row(i):return {**frame(i),'selfMs':self_us[i]/1000,'inclusiveMs':inclusive_us[i]/1000,'ancestors':[frame(a)for a in paths[i][1:]]}
 calls=slot['calls'];assert calls and all(c['completed']for c in calls)
 out={'index':slot['index'],'side':slot['side'],'profileSha256':slot['profileSha256'],'calls':len(calls),'elapsedMs':slot['elapsedMs'],'phaseMedians':{name:statistics.median(c[name]for c in calls)for name in ['prepareMs','runMs','verifyMs']},'sampledMs':sum(profile['timeDeltas'])/1000,'acceptSelfPartitionMs':sum(self_us[i]for i in inside)/1000,'outsideAcceptSelfPartitionMs':sum(self_us[i]for i in nodes if i not in inside)/1000,'acceptTopSelf':[row(i)for i in sorted(inside,key=lambda i:self_us[i],reverse=True)if self_us[i]>0],'allTopSelf':[row(i)for i in sorted(nodes,key=lambda i:self_us[i],reverse=True)if self_us[i]>0]}
 result['slots'].append(out)
out=folder/'ownership.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
for s in result['slots']:
 print(json.dumps({k:s[k]for k in ['index','side','calls','elapsedMs','phaseMedians','sampledMs','acceptSelfPartitionMs']}))
 print(json.dumps([{'name':r['name'],'line':r['lineOneBased'],'selfPerCallMs':r['selfMs']/s['calls'],'inclusivePerCallMs':r['inclusiveMs']/s['calls'],'url':r['url']}for r in s['acceptTopSelf'][:12]]))
print(json.dumps({'ownershipSha256':hashlib.sha256(out.read_bytes()).hexdigest()}))
