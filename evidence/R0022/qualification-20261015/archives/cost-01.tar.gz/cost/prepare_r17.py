from pathlib import Path
import hashlib,json,shutil,subprocess,sys
C=Path(__file__).resolve().parent;O=C.parent;R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
assert read(O/'browser-lease.json')['status']=='FREE'and not(O/'native-resource.lock').exists()
assert read(O/'selected-r6-recovery-r1/RUNTIME.json')['treeSha256']=='4905c090ff7963fd59c3944636f6f64fa534a5182918f4ade379c438a2f5762b'
assert sha(R/'real-sky/native-host.mjs')=='da14d0de3e0ae3ac814bcf810d4c08a8416de6fc8d0e2737b95584257810e57e'
retained=C/'retained-fixture-r16';retained.mkdir(exist_ok=False)
old=read(C/'SOURCE_FIXTURE.json')
for row in old['files']:
 p=C/row['side']/row['path'];assert sha(p)==row['fixtureSha256'];q=retained/row['side']/row['path'];q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
shutil.copyfile(C/'SOURCE_FIXTURE.json',retained/'SOURCE_FIXTURE.json')
s=(C/'prepare_sources_r16.py').read_text(encoding='utf-8').replace('selected-r5','selected-r6-recovery-r1')
(C/'prepare_sources_r17.py').write_text(s,encoding='utf-8',newline='\n')
subprocess.run([sys.executable,'-I','-S','-B',str(C/'prepare_sources_r17.py')],check=True)
s=(C/'run_native_cost_r16.py').read_text(encoding='utf-8').replace('selected-r5','selected-r6-recovery-r1').replace('R5 exact setup','R6 exact setup')
(C/'run_native_cost_r17.py').write_text(s,encoding='utf-8',newline='\n')
p=read(C/'PREMEASUREMENT_PINS_R16.json');p['files']={n:sha(C/n)for n in p['files']}
for n in ['prepare_r17.py','prepare_sources_r17.py','run_native_cost_r17.py','evaluate_admission_r16.py']:p['files'][n]=sha(C/n)
p['runtime']=read(O/'selected-r6-recovery-r1/RUNTIME.json')['treeSha256'];p['sourceRepair']={n:sha(R/n)for n in p['sourceRepair']}
p['sourceRepair']['tests/real-sky/native-host-streams.test.mjs']=sha(R/'tests/real-sky/native-host-streams.test.mjs')
p['scope']='Selected-r6-recovery-r1. Same approved R16 observer/counter/receiver/evaluator semantics and fixedbudget/noise. Only source binding differs: exact encoder interval reuse and singleprivatefinalRGBA destination. One changed nativeAdmission fullfourABBA comparison after5s warmups; otherfive scopes unmeasured. Actual setup review before measurement. R16controlled failure retained, notnoise retry.'
save(C/'PREMEASUREMENT_PINS_R17.json',p)
print(json.dumps({'packet':sha(C/'PREMEASUREMENT_PINS_R17.json'),'adapter':sha(C/'run_native_cost_r17.py'),'receiver':sha(C/'receiver_r16.mjs'),'runtime':p['runtime'],'fixture':sha(C/'SOURCE_FIXTURE.json')}))
