from pathlib import Path
import json,hashlib,datetime
D=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
packet=D/'PREMEASUREMENT_PINS_R15.json';assert sha(packet)=='702792ba51192b22a9294691f230bf78a0b2475c01840905edd38e4a768b737e'
setup=D/'setup-firefox-dpr2-r15'
for name,h in [('setup-only.json','df53f9e075ecc7441abde0be85c38945cb47f4110c8cfa820b6f920a22121fd6'),('quiescence-all.json','a36785ef9d94160701fb4bce51712956b9d7f89b71a5c55b0a3764a351e5cd9f'),('original-repeated-quiescence.json','a470a4b44881be20f0465a012693edb2b5ca0009808fb0560ad92597ef8cb85c')]:assert sha(setup/name)==h
p=read(D/'SETUP_REVIEW_R15_FIREFOX.json');p.update(status='APPROVED_FOR_MEASUREMENT',recordedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),verdict='Independent actual setup approval: all four current paired native input states, all six raw array hashes and exposure10.610078519658003 match; stable complete cache inventories,18quiescent original calls,~0.02ms actual isolated-profile timer,zero errors or active transport. Same six scopes/full admission and fixed budget; no performance or resource-growth PASS from setup.',actualSetup={n:sha(setup/n)for n in ['setup-only.json','quiescence-all.json','original-repeated-quiescence.json','driver-observations.json']})
save(D/'MEASUREMENT_REVIEW_R15_FIREFOX.json',p)
b=read(D/'ADOPTED_BUDGET_R14_FIREFOX.json');b.update(approvedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),independentReviewSha256=sha(D/'MEASUREMENT_REVIEW_R15_FIREFOX.json'),disposition='Activated under direct owner conditional authority after independent actual R15 Firefox setup approval, before qualifying warmup or samples. Same thresholds and full six scopes; repaired candidate, not a noise retry.')
save(D/'ADOPTED_BUDGET_R15_FIREFOX.json',b)
print(json.dumps({'review':sha(D/'MEASUREMENT_REVIEW_R15_FIREFOX.json'),'budget':sha(D/'ADOPTED_BUDGET_R15_FIREFOX.json')}))
