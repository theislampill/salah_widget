"""Apply the fixed pre-run noise policy; never overwrite original raw timings."""
import argparse,hashlib,json,statistics
from pathlib import Path
D=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def noise_scope(scope):
 rows=scope['slots']
 assert [(r['block'],r['order'],r['side'])for r in rows]==[(b,i,s)for b in range(4)for i,s in enumerate('ABBA')]
 values=[v for r in rows if r['side']=='A'for v in r['durationsMs']]
 median=statistics.median(values)
 rounds=[statistics.median([v for r in rows if r['side']=='A'and r['block']==b for v in r['durationsMs']])for b in range(4)]
 drift=max(rounds)-min(rounds);limit=max(.25,.20*median)
 return {'name':scope['name'],'baselineMedianMs':median,'baselineRoundMediansMs':rounds,'driftMs':drift,'limitMs':limit,'status':'CONTROLLED'if drift<=limit else'INCONCLUSIVE_NOISE'}
def control(rounds):
 s={'name':'control','slots':[{'block':b,'order':i,'side':side,'durationsMs':[rounds[b]if side=='A'else 1]}for b in range(4)for i,side in enumerate('ABBA')]}
 return noise_scope(s)
assert control([1,1,1,1.25])['status']=='CONTROLLED'
assert control([1,1,1,1.251])['status']=='INCONCLUSIVE_NOISE'
assert control([10,10,10,12])['status']=='CONTROLLED'
assert control([10,10,10,12.01])['status']=='INCONCLUSIVE_NOISE'
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('run',type=Path);a=p.parse_args()
 policy=D/'NOISE_POLICY.json';assert sha(policy)=='7ebff50f1d329b04e6f6004909c88faff702579d63dd474fbebdf7732f9142c9'
 raw_path=a.run/'raw.json';raw=json.loads(raw_path.read_bytes());assert raw['status']=='RAW_BATCHES_RETURNED'
 assert len(raw['scopes'])==6 and all(s['status']=='RAW_BATCHES_RETURNED'for s in raw['scopes'])
 results=[noise_scope(s)for s in raw['scopes']]
 disposition='CONTROLLED'if all(s['status']=='CONTROLLED'for s in results)else'INCONCLUSIVE_NOISE'
 record={'schema':'r0022-cost-noise-assessment/v1','originalRawSha256':sha(raw_path),'policySha256':sha(policy),'evaluatorSha256':sha(Path(__file__)),'status':disposition,'scopes':results,'scope':'Exact predeclared baseline round-median drift only. All original candidate calls retained; no outliers excluded. This is not independent provenance or budget acceptance.'}
 for path,value in [(a.run/'noise-assessment.json',record),(a.run/'noise-assessed-input.json',{**raw,'noiseDisposition':disposition,'noiseEvidence':record})]:
  with path.open('x',encoding='utf-8')as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
 print(json.dumps(record))
