from pathlib import Path
import ast,hashlib,json,shutil
C=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
retained=C/'diagnostic-r3-rejected-proposal-v1';retained.mkdir(exist_ok=False)
for n in ['prepare_admission_diagnostic_r3.py','run_admission_diagnostic_r3.py','ADMISSION_DIAGNOSTIC_R3_PROPOSAL.json']:
 shutil.copyfile(C/n,retained/n)
save(retained/'REJECTION.json',{'reviewer':'/root/r0022_independent_review','nativeExecution':False,'findings':['sha() accepted bytes, but slot passed Path; would fail before retaining timings.','Tight synchronous loop changed parent-frame rAF and awaited preparation/verification cadence from R17.','Partial call/slot/profile cleanup custody insufficient.'],'scope':'Actual independent pre-execution rejection; proposal not run.'})
s=(C/'run_admission_diagnostic_r3.py').read_text(encoding='utf-8')
start=s.index('   setup_script=');end=s.index('\n finally:\n  server.shutdown()',start)
s=s[:start]+'''   save(a.out/'diagnostic.json',raw)
   profiler=None;raw['cleanup']={};raw['errors']=[]
   try:
    setup_script="""async()=>{const m=await import('/collector.mjs'),p=__r0022CostProbe;window.__r0022DiagnosticAdapter=m.admissionCostAdapter({...p.binding,rawResult:p.raw.result,request:p.raw.request,snapshot:()=>__r0022CostObserver.snapshot(),clone:v=>structuredClone(v)});}"""
    loop_script=(D/'diagnostic_loop_r3.js').read_text(encoding='utf-8')
    for side in ['baseline','candidate']:
     await frames[side].evaluate(setup_script)
     warm=await page.evaluate(loop_script,{'side':side,'durationMs':5000});raw['warmups'].append(warm);save(a.out/'diagnostic.json',raw)
     if warm['status']!='DIAGNOSTIC_CALLS_RETURNED':raise RuntimeError('Diagnostic warmup failed; retained')
    profiler=await ctx.new_cdp_session(page);await profiler.send('Profiler.enable')
    for index,side in enumerate(['baseline','candidate','candidate','baseline']):
     slot={'index':index,'side':side,'status':'ACQUIRING','errors':[],'before':None,'after':None,'calls':[]};raw['slots'].append(slot)
     save(a.out/'diagnostic.json',raw);started=False
     try:
      slot['before']=await frames[side].evaluate('()=>({observer:__r0022CostObserver.snapshot(),native:__r0022CostProbe.binding.readState()})')
      save(a.out/'diagnostic.json',raw)
      await profiler.send('Profiler.start');started=True
      result=await page.evaluate(loop_script,{'side':side,'durationMs':5000});slot.update(result)
      if slot['status']!='DIAGNOSTIC_CALLS_RETURNED':raw['errors'].append('Diagnostic call failure in slot '+str(index))
     except BaseException as error:
      slot['errors'].append(type(error).__name__+': '+str(error));slot['status']='INCOMPLETE'
      try:slot['partialPageRecord']=await asyncio.wait_for(page.evaluate('()=>window.__r0022DiagInProgress??null'),10)
      except BaseException as partial:slot['errors'].append('Partial read: '+str(partial))
     finally:
      save(a.out/'diagnostic.json',raw)
      if started:
       try:
        profile=await asyncio.wait_for(profiler.send('Profiler.stop'),15);profile_path=a.out/('slot-'+str(index)+'-'+side+'.cpuprofile');save(profile_path,profile['profile'])
        slot.update(profile=profile_path.name,profileSha256=sha(profile_path.read_bytes()))
       except BaseException as error:slot['errors'].append('Profiler stop/save: '+str(error))
      try:slot['after']=await asyncio.wait_for(frames[side].evaluate('()=>({observer:__r0022CostObserver.snapshot(),native:__r0022CostProbe.binding.readState()})'),10)
      except BaseException as error:slot['errors'].append('After snapshot: '+str(error))
      if slot['errors']:slot['status']='INCOMPLETE';raw['errors'].extend(slot['errors'])
      save(a.out/'diagnostic.json',raw)
     if raw['errors']:break
   except BaseException as error:raw['errors'].append(type(error).__name__+': '+str(error))
   finally:
    if profiler is not None:
     try:await asyncio.wait_for(profiler.detach(),10);raw['cleanup']['profilerDetached']=True
     except BaseException as error:raw['cleanup']['profilerError']=str(error)
    try:await asyncio.wait_for(ctx.close(),15);raw['cleanup']['contextClosed']=True
    except BaseException as error:raw['cleanup']['contextError']=str(error)
    try:await asyncio.wait_for(browser.close(),15);raw['cleanup']['browserClosed']=True;clean=True
    except BaseException as error:raw['cleanup']['browserError']=str(error)
    raw['status']='DIAGNOSTIC_RETURNED'if not raw['errors']and len(raw['slots'])==4 and clean else'INCOMPLETE'
    errors.extend(raw['errors']);save(a.out/'diagnostic.json',raw)
'''+s[end:]
ast.parse(s);(C/'run_admission_diagnostic_r3.py').write_text(s,encoding='utf-8',newline='\n')
p=json.loads((C/'ADMISSION_DIAGNOSTIC_R3_PROPOSAL.json').read_bytes())
p.update(adapterSha256=sha(C/'run_admission_diagnostic_r3.py'),revision=2,rejectedProposalSha256=sha(retained/'ADMISSION_DIAGNOSTIC_R3_PROPOSAL.json'),cadence='Parent-frame rAF with finite 10s watchdog before every call; await prepare and verify; synchronous admission, matching R17 collector phase order. Pulse is outside phase timings. Warmup uses same cadence.',failureCustody='Persist slot skeleton and before snapshot before profiler start; retain partial per-call stage/error; save raw before profiler stop and after failures; stop/detach/context/browser cleanup attempted independently. FREE only after actual browser.close completion.')
for n in ['diagnostic_loop_r3.js','revise_admission_diagnostic_r3.py']:p['files'][n]=sha(C/n)
save(C/'ADMISSION_DIAGNOSTIC_R3_PROPOSAL.json',p)
print(json.dumps({'driver':p['adapterSha256'],'proposal':sha(C/'ADMISSION_DIAGNOSTIC_R3_PROPOSAL.json'),'loop':sha(C/'diagnostic_loop_r3.js')}))
