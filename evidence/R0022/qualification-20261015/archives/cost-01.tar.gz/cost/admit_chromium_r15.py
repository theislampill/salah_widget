from pathlib import Path
import json,hashlib,datetime
D=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
packet=D/'PREMEASUREMENT_PINS_R15.json';assert sha(packet)=='702792ba51192b22a9294691f230bf78a0b2475c01840905edd38e4a768b737e'
setup=D/'setup-chromium-dpr1-r15'
for name,h in [('setup-only.json','d87843b30fbeaf03cf6d6f70c07e7aed21e2b68795e8586eb46176cab788a167'),('quiescence-all.json','e363f634578fedd29165935f37e40b527b718e05ca2d13db668d9e187ee133f3'),('original-repeated-quiescence.json','f20fde51875173c461b1b48ee2d225648647842a8b0f635aa947e4b6278b09f2')]:assert sha(setup/name)==h
p=read(D/'SETUP_REVIEW_R15_CHROMIUM.json');p.update(status='APPROVED_FOR_MEASUREMENT',recordedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),verdict='Independent actual setup approval: all four current paired native input states, all six raw array hashes and exposure10.610078519658007 match; stable complete cache inventories,18quiescent original calls,~0.1ms actual timer,zero errors or active transport. Same six scopes/full admission and fixed budget; no performance or resource-growth PASS from setup.',actualSetup={n:sha(setup/n)for n in ['setup-only.json','quiescence-all.json','original-repeated-quiescence.json','driver-observations.json']})
save(D/'MEASUREMENT_REVIEW_R15_CHROMIUM.json',p)
b=read(D/'ADOPTED_BUDGET_R14_CHROMIUM.json');b.update(approvedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),independentReviewSha256=sha(D/'MEASUREMENT_REVIEW_R15_CHROMIUM.json'),disposition='Activated under direct owner conditional authority after independent actual R15 Chromium setup approval, before qualifying warmup or samples. Same thresholds and full six scopes; repaired candidate, not a noise retry.')
save(D/'ADOPTED_BUDGET_R15_CHROMIUM.json',b)
print(json.dumps({'review':sha(D/'MEASUREMENT_REVIEW_R15_CHROMIUM.json'),'budget':sha(D/'ADOPTED_BUDGET_R15_CHROMIUM.json')}))
