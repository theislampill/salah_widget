from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
s=(D/'run_native_cost_r15.py').read_text();old=(D/'run_admission_diagnostic_r1.py').read_text()
start=s.index("   ctx,page,frames=await setup('original'");end=s.index('\n finally:\n  server.shutdown()',start)
a=old.index("   ctx,page,frames=await setup('display'",old.index('async def setup'));b=old.index('\n finally:\n  server.shutdown()',a)
s=s[:start]+old[a:b]+s[end:]
needle="assert review['status']==('APPROVED_FOR_SETUP_ONLY'if a.prepare_only else'APPROVED_FOR_MEASUREMENT')and review['adapterSha256']==sha(Path(__file__).read_bytes())"
assert needle in s;s=s.replace(needle,"assert review['status']=='APPROVED_FOR_DIAGNOSTIC'and review['adapterSha256']==sha(Path(__file__).read_bytes())\n assert a.engine=='chromium'and a.dpr==1 and not a.prepare_only")
s=s.replace("'scope':'One serial cost setup and six predeclared ABBA function scopes'","'scope':'One serial R4 actual admission CPU diagnostic;12warmcalls then5seconds; no qualifying cost or noise retry'")
s=s.replace(" raw=None;admission="," clean=False;raw=None;admission=")
s=s.replace("save(a.out/'diagnostic.json',raw);await ctx.close();await browser.close()","save(a.out/'diagnostic.json',raw);await ctx.close();await browser.close();clean=True")
s=s.replace("'finishedAtUtc':now(),'errors':errors", "'finishedAtUtc':now(),'ownedNativeCleanupEstablished':clean,'errors':errors")
needle="  lease.update(status='FREE',owner=None,finishedAtUtc=now());save(O/'browser-lease.json',lease);assert(O/'native-resource.lock').read_text()==a.out.name;(O/'native-resource.lock').unlink()"
assert needle in s;s=s.replace(needle,"""  if clean:
   lease.update(status='FREE',owner=None,finishedAtUtc=now());save(O/'browser-lease.json',lease);assert(O/'native-resource.lock').read_text()==a.out.name;(O/'native-resource.lock').unlink()
  else:
   lease.update(status='RECOVERY_REQUIRED',owner='R0022 root',reason='Native diagnostic closure not established');save(O/'browser-lease.json',lease)""")
(D/'run_admission_diagnostic_r2.py').write_text(s,encoding='utf-8')
v=json.loads((D/'PREMEASUREMENT_PINS_R15.json').read_bytes());v.update(adapterSha256=sha(D/'run_admission_diagnostic_r2.py'),scope='One five-second actual R4 candidate admission CPU profile after12warmcalls, same matched display inputs and actual guarded observer fixtures. Separate prepare/clone/verify/GC by stacks;no qualifying cost or noise-repeat credit. Release only after successful native closure; otherwise hold.',priorRawSha256=sha(D/'measure-chromium-dpr1-r15/raw.json'))
(D/'ADMISSION_DIAGNOSTIC_R2_PROPOSAL.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8');print(json.dumps({'proposal':sha(D/'ADMISSION_DIAGNOSTIC_R2_PROPOSAL.json'),'adapter':sha(D/'run_admission_diagnostic_r2.py')}))
