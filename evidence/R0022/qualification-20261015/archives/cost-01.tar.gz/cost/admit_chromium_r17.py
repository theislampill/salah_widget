from pathlib import Path
import datetime,hashlib,json
C=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,v):
 with p.open('x',encoding='utf-8')as f:f.write(json.dumps(v,indent=2)+'\n')
assert sha(C/'PREMEASUREMENT_PINS_R17.json')=='12aa1e8b6c6a04ca724b2e6109757150628469429bcbf96ba9ee0fced57f555f'
actual={'setup-only.json':'1b22711aaa56075ff245ae8003cd6481da1d6f5be4f26211aedaa520c0404f95','quiescence-all.json':'446b035e3a8ddca79d76eb4c0c9b35591fcbc93a0ccc98b9b4c3cfa3c0453022','original-repeated-quiescence.json':'29602c0f2b77a0483c106a7bd80287a211d701d2b348f31a0444585fc9053948','driver-observations.json':'5ccc1a9a7ba8090804ad230bcf803104ffc3f53b710c11240dd4b3107973ec08'}
for name,digest in actual.items():assert sha(C/'setup-chromium-dpr1-r17'/name)==digest
p=read(C/'SETUP_REVIEW_R17_CHROMIUM.json');p.update(status='APPROVED_FOR_MEASUREMENT',recordedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),provenance='Root transcription of actual reviewer FINAL_ANSWER before any qualifying warmup/timing.',actualSetup=actual,verdict='Four observations/twosourcepairs/all18repeatcalls verified. Exact currentness/phase/geometry/weather/physicalinputs/sixrawarrayhashes/exposure match. Resourceinventoriesstableincludingfinitevectors/encoder/singlemaskURL. Actualtimer~0.1ms.45pins/135runtimefilesmatch;cleanuptrue/errors[]/transportinactive. OneC1nativeAdmission4ABBA/16full5sslots prescribedwarmups. Nootherscope/fullA03credit.',resultConsumer={'path':'evaluate_admission_r16.py','sha256':sha(C/'evaluate_admission_r16.py')})
save(C/'MEASUREMENT_REVIEW_R17_CHROMIUM.json',p)
b=read(C/'CONDITIONAL_BUDGET.json');b.update(approved=True,approvedBeforeMeasurement=True,approvedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='CHROMIUM DPR1 default isolated context; ONLY nativeAdmission fourfullABBA',independentReviewSha256=sha(C/'MEASUREMENT_REVIEW_R17_CHROMIUM.json'),conditionalRecordSha256=sha(C/'CONDITIONAL_BUDGET.json'),noisePolicySha256=sha(C/'NOISE_POLICY.json'),statistics=['median','p95'],comparison='candidate <= baseline + max(0.25 ms, 0.10 * baseline)',blocks='5-second warmup per side followed by four paired5-second ABBA rounds',disposition='Direct owner conditional budget activated after actual independent R17 setup approval, before any qualifying warmup/timing. Newsourcecomparison, notnoise retry; no thresholdchange/otherscopeapproval.')
save(C/'ADOPTED_BUDGET_R17_CHROMIUM.json',b);print(json.dumps({'review':sha(C/'MEASUREMENT_REVIEW_R17_CHROMIUM.json'),'budget':sha(C/'ADOPTED_BUDGET_R17_CHROMIUM.json')}))
