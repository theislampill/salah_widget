import fs from 'node:fs';import crypto from 'node:crypto';import assert from 'node:assert/strict';
import {encodeNativeDisplay as prior} from 'file:///C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget/real-sky/native-host.mjs';
import {encodeNativeFrame} from 'file:///C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget/real-sky/native-encoding.mjs';
import {nativeSkyPresentation} from 'file:///C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget/real-sky/native-preview.mjs';
import {encodeNativeDisplay as candidate,encodeNativeDisplayInto} from './native-host-r6-testable.mjs';
const O='C:/Users/theis/.codex/work-products/r0022-execution-20261015',sh=v=>crypto.createHash('sha256').update(v).digest('hex');
const raw=fs.readFileSync(O+'/capture-chromium-dpr1-r4/ORIGINAL_INPUTS.json'),records=[];
function revive(v){if(v?.$typed){const bytes=fs.readFileSync(v.file);assert.equal(sh(bytes),v.sha256);assert.equal(bytes.length,v.byteLength);const a=bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength),T=globalThis[v.$typed];assert(T);const result=new T(a);assert.equal(result.length,v.length);records.push({sha256:v.sha256,bytes:bytes.length,type:v.$typed});return result;}if(Array.isArray(v))return v.map(revive);if(v&&typeof v==='object')return Object.fromEntries(Object.entries(v).map(([k,w])=>[k,revive(w)]));return v;}
const input=revive(JSON.parse(raw)).original,physical=input.result.raster,E=physical.effectiveExposure;
const mapped=nativeSkyPresentation({...physical,...input.fields},input.request.options.view,input.admission.native.solarAnchor);
const outputs=[],durations={};
for(const [name,linear]of [['physical',physical.linear],['H1',mapped.linear]]){
 const before=sh(new Uint8Array(linear.buffer,linear.byteOffset,linear.byteLength)),oracle=encodeNativeFrame(linear,E);
 assert.deepEqual(candidate(linear,E),oracle);assert.deepEqual(prior(linear,E),oracle);
 for(const rows of [0,183,284,530]){const bytes=new Uint8ClampedArray(325*530*4),start=325*rows*3;encodeNativeDisplayInto(linear.subarray(0,start),E,bytes);encodeNativeDisplayInto(linear.subarray(start),E,bytes,325*rows*4);assert.deepEqual(bytes,oracle);}
 assert.equal(sh(new Uint8Array(linear.buffer,linear.byteOffset,linear.byteLength)),before);outputs.push({name,inputSha256:before,encodedSha256:sh(oracle),bytes:oracle.length});
 // One bounded local diagnostic; retained native scene, no solver/browser or
 // cost-budget credit. Alternating order and all durations retained.
 durations[name]={R5:[],R6:[]};prior(linear,E);candidate(linear,E);
 for(let round=0;round<12;round++)for(const [label,fn]of (round%2?[['R6',candidate],['R5',prior]]:[['R5',prior],['R6',candidate]])){const t=performance.now();fn(linear,E);durations[name][label].push(performance.now()-t);}
}
const report={schema:'r0022-r6-retained-native-encoder-diagnostic/v1',sourceSha256:sh(fs.readFileSync(new URL('./native-host-r6.mjs',import.meta.url))),testSha256:sh(fs.readFileSync(new URL(import.meta.url))),inputManifestSha256:sh(raw),inputBuffers:records,exposure:E,outputs,durations,allocationChange:{temporaryFullFrameRGBABytesRemoved:689000,retainedStateAddedBytes:0},scope:'Exact encoding oracle/native retained inputs only. Node diagnostic is not native warmed-cost qualification or whole-scene acceptance.'};
fs.writeFileSync(new URL('./native-encoding-equivalence.json',import.meta.url),JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({outputs,durations,source:report.sourceSha256}));
