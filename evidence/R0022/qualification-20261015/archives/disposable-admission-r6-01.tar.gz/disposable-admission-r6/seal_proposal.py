from pathlib import Path
import hashlib,json,subprocess
P=Path(__file__).resolve().parent
R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget')
node='C:/workspace/ai/cp9-integration-20261005/toolchain/node-v22.16.0-win-x64/node.exe'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
tests=[P/n for n in ['native-host-encoding.test.mjs','native-host-composition.test.mjs','encoder-streams.test.mjs']]
r=subprocess.run([node,'--test',*[str(p) for p in tests]],capture_output=True);(P/'tests.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
v={'schema':'r0022-bounded-source-repair/v1','status':'PROPOSED_FOR_INDEPENDENT_REVIEW','preimage':{'real-sky/native-host.mjs':sha(R/'real-sky/native-host.mjs'),'real-sky/native-preview.mjs':sha(R/'real-sky/native-preview.mjs')},'candidate':{'real-sky/native-host.mjs':sha(P/'native-host-r6.mjs')},'tests':[{'path':p.name,'sha256':sha(p)} for p in tests],'testResultSha256':sha(P/'tests.log'),'testableSourceSha256':sha(P/'native-host-r6-testable.mjs'),'nativeRetainedInputResultSha256':sha(P/'native-encoding-equivalence.json'),'exactChanges':['Per-call RGB last-code oracle interval reuse with unchanged validation/exposure multiplication and binary search fallback','Encode joined foreground prefix and raw physical tail into one private final RGBA buffer; preserve raw prefix validation and final publication fence'],'retainedStateAdded':0,'temporaryEncodedBytesRemovedPerFullFrame':689000,'budget':'Unchanged; R16 controlled failure retained; Node diagnostic does not establish native budget','integration':'Not yet authorised by independent review; original R5 worktree unchanged.'}
(P/'SOURCE_REPAIR_R6_PROPOSAL.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8');print(json.dumps({'proposalSha256':sha(P/'SOURCE_REPAIR_R6_PROPOSAL.json'),'testResultSha256':sha(P/'tests.log'),'testsExit':r.returncode}))
