# R6 proposed host encoding scope

This proposal changes only `real-sky/native-host.mjs` from R5. It adds no
physical sample, display adjustment, provider, controller, listener, timer,
animation loop, canvas, texture or readback. The lunar preview owner remains
`e4f70bd5935b31ffd56deff017e854b0afcd192f8937090b8140773af61fce0f`.

The encoder retains R5's fixed 26,624-byte oracle search table. Three previous
RGB codes are local scalars reset for each encoding call. A code is reused
only inside its exact binary64 interval, after the existing finite input
validation and original exposure multiplication. The immutable encoding oracle
and its transition values remain unchanged. There is no retained pixel or
physical-light cache.

Full-frame composition allocates one private 325 by 530 RGBA buffer of
689,000 bytes. The joined prefix and untouched raw tail write directly into it.
This removes the temporary encoded prefix and tail, whose combined size was
689,000 bytes per full acceptance. Both linear sources, including the replaced
raw prefix, retain their validation. The framebuffer is published only after
the existing final currentness check. An error cannot publish a partial image.
Same-frame foreground changes still allocate and publish only their existing
bounded row region. No final output buffer is retained by this optimization.

All R5 physical-field allocation, bounded geometry-cache, single published
solar-mask URL, native foreground capture and Moon-material ownership remain
unchanged. The original raw fields and H1 display fields retain separate
ownership. No temporary array or raw field is moved outside the timed admission
function to improve the comparison.

The retained native-input diagnostic shows exact physical and H1 output bytes
and reduced local encoding duration. It is not a browser performance result.
R16's controlled median/p95 failure remains operative until a newly reviewed
source and actual matched native comparison satisfy the unchanged budget.
