from pathlib import Path
import hashlib
D=Path(__file__).resolve().parent;R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget')
s=(R/'real-sky/native-host.mjs').read_text(encoding='utf-8')
needle='/** DOM ownership adapter; native PBR/calendar/weather remain native source code. */'
helper='''// Solar obstruction depends on captured alpha only. Existing owned capture
// arrays provide its exact previous input; no radiance or weather is cached.
export function sameNativeCloudAlpha(a,b){
 if(!(a instanceof Uint8ClampedArray)||!(b instanceof Uint8ClampedArray)||a.length!==b.length||a.length%4)return false;
 for(let i=3;i<a.length;i+=4)if(a[i]!==b[i])return false;
 return true;
}

'''
assert s.count(needle)==1;s=s.replace(needle,helper+needle)
s=s.replace('previousPresentation=null,previousMoonBottom=0','previousPresentation=null,previousSolarMask=null,previousMoonBottom=0')
s=s.replace('previousPresentation=null;previousMoonBottom=0','previousPresentation=null;previousSolarMask=null;previousMoonBottom=0')
needle='const solarMask=foreground.prepareSolarMask(capture.cloudRGBA,rows);'
replacement='''const reuseSolarMask=previousSolarMask!==null&&previousPresentation?.rows===rows&&sameNativeCloudAlpha(previousPresentation.cloudRGBA,capture.cloudRGBA);
    const solarMask=reuseSolarMask?previousSolarMask:foreground.prepareSolarMask(capture.cloudRGBA,rows);'''
assert s.count(needle)==1;s=s.replace(needle,replacement)
s=s.replace('previousPresentation=presentation;status.presentationDraws++;','previousPresentation=presentation;previousSolarMask=solarMask;status.presentationDraws++;')
s=s.replace('previousPresentation=null;status.last=null;status.status=\'disposed\'','previousPresentation=null;previousSolarMask=null;status.last=null;status.status=\'disposed\'')
for name,content in [('native-host.mask-r5.source.mjs',s),('native-host.mask-r5.probe.mjs',s.replace("from './","from 'file:///C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget/real-sky/"))]:
 p=D/name;assert not p.exists();p.write_text(content,encoding='utf-8',newline='\n');print(name,hashlib.sha256(p.read_bytes()).hexdigest())
t=(R/'tests/real-sky/native-host-composition.test.mjs').read_text(encoding='utf-8')
t=t.replace("from '../../real-sky/", "from 'file:///C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget/real-sky/")
t=t.replace("import {encodeNativeDisplay} from 'file:///C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget/real-sky/native-host.mjs';", "import {encodeNativeDisplay,sameNativeCloudAlpha} from './native-host.mask-r5.probe.mjs';")
t=t.replace("fs.readFileSync(new URL('../../real-sky/native-host.mjs',import.meta.url),'utf8')","fs.readFileSync(new URL('./native-host.mask-r5.source.mjs',import.meta.url),'utf8')")
t=t.replace("import {nativeForeground,nativeCalendarRegion,nativeForegroundRows,sameNativePresentation}","import {nativeForeground,nativeCalendarRegion,nativeForegroundRows,sameNativePresentation,nativeSolarTransmission}")
t=t.replace('previousPresentation:null,previousMoonBottom:0','previousPresentation:null,previousSolarMask:null,previousMoonBottom:0')
t=t.replace('\n  nativeForeground,nativeCalendarRegion,nativeForegroundRows,sameNativePresentation,','\n  nativeForeground,nativeCalendarRegion,nativeForegroundRows,sameNativePresentation,sameNativeCloudAlpha,')
t=t.replace('const pixels=new Uint8ClampedArray(expected.length).fill(29),draws=[],encoded=[],errors=[];let checks=0;','const pixels=new Uint8ClampedArray(expected.length).fill(29),draws=[],encoded=[],errors=[],maskCalls=[];let checks=0;')
t=t.replace("prepareSolarMask(){if(maskError)throw Error('invalid solar mask');return 'mask';}","prepareSolarMask(rgba,count){maskCalls.push({rgba:rgba.slice(),rows:count,bytes:nativeSolarTransmission(rgba)});if(maskError)throw Error('invalid solar mask');return 'mask-'+maskCalls.length;}")
t=t.replace('return {s,pixels,expected,encoded,draws,errors,capture,rerun()', 'return {s,pixels,expected,encoded,draws,errors,capture,maskCalls,rerun()')
t+='''
test('new accepted frame with exact cloud alpha reuses only published solar mask',()=>{
 const h=fixture(183);assert.equal(h.maskCalls.length,1);const expected=h.pixels.slice(),prior=h.s.frame;
 h.s.frame={...prior};h.rerun();assert.equal(h.maskCalls.length,1);assert.equal(h.draws.length,2);assert.deepEqual(h.pixels,expected);
 h.capture.cloudRGBA[0]++;h.s.frame={...prior};h.rerun();assert.equal(h.maskCalls.length,1,'RGB changes do not alter solar obstruction');
 h.capture.cloudRGBA[3]++;h.s.frame={...prior};h.rerun();assert.equal(h.maskCalls.length,2,'alpha change must regenerate');
 assert.notDeepEqual(h.maskCalls[0].bytes,h.maskCalls[1].bytes);
 h.s.previousPresentation.rows++;h.s.frame={...prior};h.rerun();assert.equal(h.maskCalls.length,3,'row support change must regenerate');
 h.s.previousPresentation=null;h.s.previousSolarMask=null;h.s.frame={...prior};h.rerun();assert.equal(h.maskCalls.length,4,'withdrawn state cannot reuse mask');
});
test('failed publication leaves solar reuse state unpublished',()=>{
 const h=fixture(183,{expire:true});assert.equal(h.maskCalls.length,1);assert.equal(h.s.previousSolarMask,null);assert.equal(h.s.previousPresentation,null);assert.equal(h.draws.length,0);
});
test('solar mask comparator validates types, lengths and every alpha boundary',()=>{
 const a=new Uint8ClampedArray(325*183*4),b=a.slice();assert(sameNativeCloudAlpha(a,b));
 for(const i of [3,325*4-1,a.length-1]){b[i]=1;assert(!sameNativeCloudAlpha(a,b));b[i]=0;}
 for(const b of [new Uint8Array(a.length),new Uint8ClampedArray(a.length-1),new Uint8ClampedArray(a.length+4),null])assert(!sameNativeCloudAlpha(a,b));
});
'''
(D/'actual-mask-r5.test.mjs').write_text(t,encoding='utf-8',newline='\n')
