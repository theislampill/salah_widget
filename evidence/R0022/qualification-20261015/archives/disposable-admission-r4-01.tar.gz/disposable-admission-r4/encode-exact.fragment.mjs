// Exact acceleration of the existing native encoder. Buckets bound a search
// among its oracle-derived binary64 transition values; they never approximate
// an output or interpolate a value. Only immutable table geometry is retained.
let nativeDisplayEncodeCache=null;
function encodeNativeDisplay(linear,exposure=12){
 if(!Number.isFinite(exposure)||exposure<0||exposure>100000)throw new RangeError('Invalid native display exposure');
 if(linear.length%3)throw new RangeError('RGB buffer required');
 if(!nativeDisplayEncodeCache){
  const edges=nativeEncodingThresholds(),bins=8192,scale=bins/edges[255],low=new Uint8Array(bins),high=new Uint16Array(bins);
  let lo=0,hi=1;
  for(let b=0;b<bins;b++){
   while(lo<255&&Math.floor(edges[lo+1]*scale)<b)lo++;
   hi=Math.max(hi,lo+1);
   while(hi<256&&Math.floor(edges[hi]*scale)<=b)hi++;
   low[b]=lo;high[b]=hi;
  }
  nativeDisplayEncodeCache={edges,scale,low,high};
 }
 const {edges,scale,low,high}=nativeDisplayEncodeCache,bytes=new Uint8ClampedArray(linear.length/3*4);
 const code=y=>{if(y>=edges[255])return 255;const b=Math.floor(y*scale);let lo=low[b],hi=high[b];while(hi-lo>1){const middle=(lo+hi)>>>1;if(y<edges[middle])hi=middle;else lo=middle;}return lo;};
 for(let i=0,j=0;i<linear.length;i+=3,j+=4){
  const r=linear[i],g=linear[i+1],b=linear[i+2];
  if(!Number.isFinite(r)||!Number.isFinite(g)||!Number.isFinite(b))throw new RangeError('Nonfinite native frame channel');
  bytes[j]=code(exposure*Math.max(0,r));
  bytes[j+1]=g===r?bytes[j]:code(exposure*Math.max(0,g));
  bytes[j+2]=b===r?bytes[j]:b===g?bytes[j+1]:code(exposure*Math.max(0,b));
  bytes[j+3]=255;
 }
 return bytes;
}
