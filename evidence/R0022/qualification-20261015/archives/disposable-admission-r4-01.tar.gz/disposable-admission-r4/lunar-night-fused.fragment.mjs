// Rigid camera geometry only: no sky sample, UTC, radiance, atmosphere or
// exposure survives a call. Four native-size camera/grid entries bound state.
const lunarGeometryCache=new Map();
function lunarGeometry(view,gx,gy){
 const mapping=skyProjection(view),width=mapping.width,height=mapping.height;
 const key=JSON.stringify([view.type??'camera',width,height,view.azDeg??180,view.altDeg??35,view.fovYDeg??90,view.rollDeg??0,gx,gy]);
 const bounded=(view.type??'camera')==='camera'&&width===325&&height===530&&Number.isInteger(gx)&&gx>0&&gx<=68&&Number.isInteger(gy)&&gy>0&&gy<=68;
 if(!bounded)throw new RangeError('Lunar admission geometry must be a bounded native camera/grid');
 if(lunarGeometryCache.has(key))return lunarGeometryCache.get(key);
 const directions=new Array((gx+1)*(gy+1)),omega=new Float64Array(directions.length),above=new Uint8Array(width*height);
 const ix=new Uint16Array(width),tx=new Float64Array(width),iy=new Uint32Array(height),ty=new Float64Array(height);
 for(let y=0;y<=gy;y++)for(let x=0;x<=gx;x++){
  const px=x*width/gx,py=y*height/gy,i=y*(gx+1)+x;if(!mapping.above(px,py))continue;
  directions[i]=mapping.unproject(px,py);omega[i]=mapping.solidAngle(px,py)/V_ZERO_ILLUMINANCE_LUX;
 }
 for(let x=0;x<width;x++){const u=(x+.5)/width*gx,j=Math.min(gx-1,Math.floor(u));ix[x]=j;tx[x]=u-j;}
 for(let y=0;y<height;y++){
  const v=(y+.5)/height*gy,j=Math.min(gy-1,Math.floor(v));iy[y]=j*(gx+1);ty[y]=v-j;
  for(let x=0;x<width;x++)above[y*width+x]=mapping.above(x+.5,y+.5)?1:0;
 }
 const geometry={width,height,gx,gy,directions,omega,above,ix,tx,iy,ty};
 if(lunarGeometryCache.size===4)lunarGeometryCache.delete(lunarGeometryCache.keys().next().value);
 lunarGeometryCache.set(key,geometry);return geometry;
}

/** Same deep-night physical samples and H1 formula, with expansion and display
 * assembly in one pass. The lunar proxy is neutral at every original model
 * node; interpolate it once and explicitly retain all three raw RGB channels.
 * Camera geometry is reusable. Every physical sample remains current-call work.
 */
export function nativeLunarNightPresentation(raster,view,residualNight,gx,gy){
 if(!(raster.physicalState?.sun?.altDeg<-20)||positiveChannel(raster.solarBackgroundLinear))throw new RangeError('Lunar fused admission requires the physical solar-zero domain');
 const source=raster.skyBackgroundLinear??raster.backgroundLinear,E=raster.effectiveExposure;
 if(!source||source.length!==325*530*3||source.length!==raster.linear?.length||!Number.isFinite(E)||E<=0)throw new RangeError('Lunar display requires matched raw fields and original exposure');
 const geometry=lunarGeometry(view,gx,gy),{width,height,directions,omega,above,ix,tx,iy,ty}=geometry;
 const model=createSkyModel(raster.physicalState,raster.atmosphere,{residualNight}),grid=new Float64Array(directions.length);
 for(let i=0;i<directions.length;i++)if(directions[i])grid[i]=model.sample(directions[i]).moonLuminance*omega[i];
 const moon=new Float64Array(source.length),shown=new Float64Array(source.length),sky=new Float64Array(source.length);
 const linear=raster.linear===source?sky:new Float64Array(source.length),diffuse=raster.diffuseLinear,background=diffuse?new Float64Array(source.length):sky;
 let pixels=0;
 for(let y=0;y<height;y++)for(let x=0;x<width;x++){
  const p=y*width+x,i=p*3;
  let r=0;
  if(above[p]){
   const tl=iy[y]+ix[x],bl=tl+gx+1,t=tx[x],u=ty[y];
   r=(grid[tl]*(1-t)+grid[tl+1]*t)*(1-u)+(grid[bl]*(1-t)+grid[bl+1]*t)*u;
  }
  moon[i]=r;moon[i+1]=r;moon[i+2]=r;
  const sr=source[i],sg=source[i+1],sb=source[i+2];
  if(!Number.isFinite(r)||r<0||!Number.isFinite(sr)||!Number.isFinite(sg)||!Number.isFinite(sb)||r>sr||r>sg||r>sb)throw new RangeError('Invalid lunar share of raw non-solar atmosphere');
  const z=E*(.2126*r+.7152*r+.0722*r);
  if(!Number.isFinite(z))throw new RangeError('Invalid lunar display energy');
  const scale=z<=.003?1:lunarDisplayTarget(z)/z,s=r*scale;
  shown[i]=s;shown[i+1]=s;shown[i+2]=s;
  sky[i]=sr-r+s;sky[i+1]=sg-r+s;sky[i+2]=sb-r+s;
  if(linear!==sky){linear[i]=raster.linear[i]-sr+sky[i];linear[i+1]=raster.linear[i+1]-sg+sky[i+1];linear[i+2]=raster.linear[i+2]-sb+sky[i+2];}
  if(background!==sky){background[i]=sky[i]+diffuse[i];background[i+1]=sky[i+1]+diffuse[i+1];background[i+2]=sky[i+2]+diffuse[i+2];}
  if(z>.003)pixels++;
 }
 if(!pixels)return {...raster,lunarBackgroundLinear:moon};
 return {...raster,linear,skyBackgroundLinear:sky,backgroundLinear:background,physicalSkyBackgroundLinear:source,lunarBackgroundLinear:moon,lunarNightDisplayLinear:shown,lunarDisplayPresentation:lunarDisplayMetadata(E,pixels,1)};
}
