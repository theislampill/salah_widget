import fs from 'node:fs';import crypto from 'node:crypto';import assert from 'node:assert/strict';import {pathToFileURL}from'node:url';
const R='C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget',D='C:/Users/theis/.codex/work-products/r0022-execution-20261015/disposable-admission-r4';
const module=pathToFileURL(R+'/real-sky/native-encoding.mjs').href,{encodeNativeFrame,nativeEncodingThresholds}=await import(module);
const fragment=fs.readFileSync(D+'/encode-exact.fragment.mjs','utf8'),instrumented='import {nativeEncodingThresholds} from '+JSON.stringify(module)+';\n'+fragment+'\nexport {encodeNativeDisplay};export const retained=()=>nativeDisplayEncodeCache;';
const {encodeNativeDisplay,retained}=await import('data:text/javascript;base64,'+Buffer.from(instrumented).toString('base64'));
const sh=v=>crypto.createHash('sha256').update(v).digest('hex');
const words=new BigUint64Array(1),float=new Float64Array(words.buffer);
const next=(v,delta)=>{float[0]=v;words[0]+=BigInt(delta);return float[0];};
let comparisons=0;const rows=[];
for(const E of [0,1e-10,.5,1,12,24,100000]){
 const raw=[-Number.MAX_VALUE,-1,-0,0,Number.MIN_VALUE,Number.MAX_VALUE],edges=nativeEncodingThresholds();
 for(const edge of edges.subarray(1))for(const d of [-1,0,1]){const e=next(edge,d);raw.push(e/Math.max(E,Number.MIN_VALUE));}
 let seed=12345;
 for(let i=0;i<24000;i++){seed=(Math.imul(seed,1664525)+1013904223)>>>0;raw.push((seed/4294967296)*12/Math.max(E,1e-10));}
 const values=raw.filter(Number.isFinite);while(values.length%3)values.push(0);
 const a=encodeNativeFrame(Float64Array.from(values),E),b=encodeNativeDisplay(Float64Array.from(values),E);assert(Buffer.from(a).equals(Buffer.from(b)));comparisons+=values.length;rows.push({exposure:E,channels:values.length,sha256:sh(a)});
}
// Every bucket boundary's nearest binary64 values plus oracle transitions.
const cache=retained(),values=[];
for(let b=1;b<8192;b++)for(const d of [-2,-1,0,1,2]){const y=next(b/cache.scale,d);values.push(y,y,y);}
assert(Buffer.from(encodeNativeDisplay(Float64Array.from(values),1)).equals(Buffer.from(encodeNativeFrame(Float64Array.from(values),1))));comparisons+=values.length;
for(const values of [[NaN,0,0],[0,Infinity,0],[0,0,-Infinity]])assert.throws(()=>encodeNativeDisplay(values,1),RangeError);
for(const E of [-1,NaN,Infinity,100001])assert.throws(()=>encodeNativeDisplay([0,0,0],E),RangeError);
assert.throws(()=>encodeNativeDisplay([1],1),RangeError);
const input=Float64Array.from({length:325*530*3},(_,i)=>.003+(i/3|0)/10000000),duration={original:[],prototype:[]};
for(let round=0;round<12;round++)for(const [name,fn]of (round%2?[['prototype',encodeNativeDisplay],['original',encodeNativeFrame]]:[['original',encodeNativeFrame],['prototype',encodeNativeDisplay]])){const start=performance.now();fn(input,24);duration[name].push(performance.now()-start);}
const report={schema:'r0022-exact-native-encoding-prototype/v1',fragmentSha256:sh(fragment),testSha256:sh(fs.readFileSync(new URL(import.meta.url))),comparisons,rows,negativeControls:8,retainedBytes:cache.edges.byteLength+cache.low.byteLength+cache.high.byteLength,diagnosticMs:duration,scope:'Existing encoder exact oracle comparison. Node diagnostic only, no native cost or whole-scene credit.'};
fs.writeFileSync(D+'/encoder-equivalence-r1.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(report));
