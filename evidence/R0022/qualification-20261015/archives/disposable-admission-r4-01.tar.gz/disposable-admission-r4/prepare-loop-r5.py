from pathlib import Path
import hashlib
D=Path(__file__).resolve().parent;R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget')
s=(D/'native-preview.component-r2.source.mjs').read_text(encoding='utf-8')
start=s.index(' let pixels=0;\n for(let y=0;y<height;y++)for(let x=0;x<width;x++){',s.index('export function nativeLunarNightPresentation'))
end=s.index('\n if(!pixels)return',start)
old=s[start:end]
new=''' let pixels=0;
 const rawLinear=raster.linear,assembleLinear=linear!==sky,assembleBackground=background!==sky;
 for(let y=0;y<height;y++){
  const top=iy[y],lower=top+gx+1,u=ty[y],oneMinusU=1-u;
  for(let x=0;x<width;x++){
   const p=y*width+x,i=p*3;
   let r=0;
   if(above[p]){
    const tl=top+ix[x],bl=lower+ix[x],t=tx[x],oneMinusT=1-t;
    r=(grid[tl]*oneMinusT+grid[tl+1]*t)*oneMinusU+(grid[bl]*oneMinusT+grid[bl+1]*t)*u;
   }
   moon[i]=r;moon[i+1]=r;moon[i+2]=r;
   const sr=source[i],sg=source[i+1],sb=source[i+2];
   if(!Number.isFinite(r)||r<0||!Number.isFinite(sr)||!Number.isFinite(sg)||!Number.isFinite(sb)||r>sr||r>sg||r>sb)throw new RangeError('Invalid lunar share of raw non-solar atmosphere');
   const z=E*(.2126*r+.7152*r+.0722*r);
   if(!Number.isFinite(z))throw new RangeError('Invalid lunar display energy');
   const scale=z<=.003?1:lunarDisplayTarget(z)/z,s=r*scale;
   shown[i]=s;shown[i+1]=s;shown[i+2]=s;
   const vr=sr-r+s,vg=sg-r+s,vb=sb-r+s;
   sky[i]=vr;sky[i+1]=vg;sky[i+2]=vb;
   if(assembleLinear){linear[i]=rawLinear[i]-sr+vr;linear[i+1]=rawLinear[i+1]-sg+vg;linear[i+2]=rawLinear[i+2]-sb+vb;}
   if(assembleBackground){background[i]=vr+diffuse[i];background[i+1]=vg+diffuse[i+1];background[i+2]=vb+diffuse[i+2];}
   if(z>.003)pixels++;
  }
 }'''
s=s[:start]+new+s[end:]
for name,content in [('native-preview.loop-r5.source.mjs',s),('native-preview.loop-r5.probe.mjs',s.replace("from './","from 'file:///C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget/real-sky/"))]:
 p=D/name;assert not p.exists();p.write_text(content,encoding='utf-8',newline='\n');print(name,hashlib.sha256(p.read_bytes()).hexdigest())
t=(D/'verify-component-r2.mjs').read_text(encoding='utf-8').replace('component-r2','loop-r5').replace('component-equivalence-r2.json','loop-equivalence-r5.json')
# Compare the exact integrated R4 path in diagnostic timings, not the older unfused implementation.
needle="old.nativeSkyPresentation({...result.raster,lunarBackgroundLinear:old.nativeLunarAtmosphereField(result.raster.physicalState,result.raster.atmosphere,request.options.view,request.options.diffuse.residualNight,41,67)},request.options.view)"
assert needle in t;t=t.replace(needle,"old.nativeLunarNightPresentation(result.raster,request.options.view,request.options.diffuse.residualNight,41,67)")
(D/'verify-loop-r5.mjs').write_text(t,encoding='utf-8',newline='\n')
