import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const R='C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget',O='C:/Users/theis/.codex/work-products/r0022-execution-20261015',D=O+'/disposable-admission-r4';
const sha=v=>crypto.createHash('sha256').update(v).digest('hex'),bytes=v=>Buffer.from(v.buffer,v.byteOffset,v.byteLength);
const old=await import(pathToFileURL(R+'/real-sky/native-preview.mjs'));
const probe=fs.readFileSync(D+'/native-preview.component-r3.probe.mjs','utf8');
const extra='\nexport const inspectLunarGeometry=()=>[...lunarGeometryCache].map(([key,g])=>({key,typedBytes:Object.values(g).filter(ArrayBuffer.isView).reduce((n,a)=>n+a.byteLength,0),nodes:g.directions.length,directions:g.directions.filter(Boolean).length,keys:Object.keys(g)}));';
const neo=await import('data:text/javascript;base64,'+Buffer.from(probe+extra).toString('base64'));
const {nativeJob}=await import(pathToFileURL(R+'/real-sky/native-contract.mjs'));
const {physicalSkyState}=await import(pathToFileURL(R+'/real-sky/core/src/sky-state.mjs'));
const {NativeSkyEngine}=await import(pathToFileURL(R+'/real-sky/native-engine.mjs'));
const {encodeNativeFrame}=await import(pathToFileURL(R+'/real-sky/native-encoding.mjs'));
const snapshot=(change={})=>({utcMs:Date.parse('2026-09-25T02:00:00Z'),lat:28.5383,lon:-81.3792,heightM:0,generation:2,sceneIdentity:'R0022-disposable-exact-fused',camera:{azDeg:180,altDeg:45,fovYDeg:90,rollDeg:0},weather:{vis:20000,cloud:0,code:0,temp:28},units:'c',lp:0,timeScale:1,...change});
const rows=[];
function equal(label,a,b){
 assert.deepEqual(Object.keys(b).sort(),Object.keys(a).sort(),label+' keys');const fields=[];
 for(const key of Object.keys(a)){if(ArrayBuffer.isView(a[key])){assert.equal(b[key].constructor,a[key].constructor);assert(bytes(a[key]).equals(bytes(b[key])),label+'/'+key);fields.push({key,bytes:a[key].byteLength,sha256:sha(bytes(a[key]))});}else assert.deepEqual(b[key],a[key],label+'/'+key);}
 return fields;
}
function compare(label,raster,view,residualNight,grid){
 const raw=Object.fromEntries(Object.entries(raster).filter(([,v])=>ArrayBuffer.isView(v)).map(([k,v])=>[k,Buffer.from(bytes(v))]));
 const a=old.nativeSkyPresentation({...raster,lunarBackgroundLinear:old.nativeLunarAtmosphereField(raster.physicalState,raster.atmosphere,view,residualNight,...grid)},view);
 const b=neo.nativeLunarNightPresentation(raster,view,residualNight,...grid),fields=equal(label,a,b);
 for(const [key,v]of Object.entries(raw))assert(bytes(raster[key]).equals(v),label+' raw '+key);
 for(const key of ['stellarLinear','diffuseLinear'])if(raster[key])assert.equal(b[key],raster[key],label+' nonlunar ref '+key);
 if(b.lunarDisplayPresentation){assert.notEqual(b.linear.buffer,raster.linear.buffer);assert.equal(b.physicalSkyBackgroundLinear,raster.skyBackgroundLinear);assert.notEqual(b.lunarBackgroundLinear.buffer,b.lunarNightDisplayLinear.buffer);assert(b.lunarNightDisplayLinear.some(v=>v>0));}
 rows.push({label,fields,cache:neo.inspectLunarGeometry()});return {a,b};
}
function physicalFixture(s,grid=[41,67],adjust={}){
 const job=nativeJob(s,true),state={...physicalSkyState(job.observer),...adjust},view=job.options.view,atmosphere=job.options.atmosphere;
 assert(state.sun.altDeg<-20);
 const fields=old.nativeAtmosphereFields(state,atmosphere,view,job.options.diffuse.residualNight,...grid),source=fields.background;
 return {raster:{width:325,height:530,linear:source,backgroundLinear:source,skyBackgroundLinear:source,physicalState:state,atmosphere,effectiveExposure:24/(1+24*fields.mean/.5),nominalExposure:24},view,residualNight:job.options.diffuse.residualNight,grid};
}
const run=(label,f)=>compare(label,f.raster,f.view,f.residualNight,f.grid);
const original=physicalFixture(snapshot());const clear=run('clear-A',original);
run('same-camera-current-UTC',physicalFixture(snapshot({utcMs:Date.parse('2026-09-25T03:00:00Z')})));
run('same-camera-physical-Moon-below',physicalFixture(snapshot({utcMs:Date.parse('2026-09-18T07:00:00Z')})));
run('same-camera-weather',physicalFixture(snapshot({weather:{vis:6000,cloud:65,code:63,temp:20}})));
for(const [label,camera,grid]of [
 ['azimuth-B',{azDeg:195,altDeg:45,fovYDeg:90,rollDeg:0},[41,67]],
 ['horizon',{azDeg:180,altDeg:0,fovYDeg:90,rollDeg:0},[41,67]],
 ['fov',{azDeg:180,altDeg:45,fovYDeg:80,rollDeg:0},[41,67]],
 ['roll',{azDeg:180,altDeg:45,fovYDeg:90,rollDeg:15},[41,67]],
 ['grid',{azDeg:180,altDeg:45,fovYDeg:90,rollDeg:0},[24,40]],
 ['grid-bound',{azDeg:180,altDeg:45,fovYDeg:90,rollDeg:0},[68,68]],
 ])run(label,physicalFixture(snapshot({camera}),grid));
assert.equal(neo.inspectLunarGeometry().length,4);
assert(!neo.inspectLunarGeometry().some(g=>g.key==='["camera",325,530,180,45,90,0,41,67]'),'old A evicted');
const returned=run('A-after-eviction',original);equal('A exact return',clear.b,returned.b);
for(const phaseAngleDeg of [0,8,90,150,170,180])for(const altDeg of [-.25,0,20,85]){
 const state=original.raster.physicalState;
 run('phase-alt-'+phaseAngleDeg+'-'+altDeg,physicalFixture(snapshot(),[41,67],{moon:{...state.moon,phaseAngleDeg,altDeg}}));
}
const lower={...original,raster:{...original.raster,effectiveExposure:1e-20}};run('below-shoulder-identity',lower);
let negativeControls=0;
for(const [label,f]of [
 ['solar-boundary',()=>neo.nativeLunarNightPresentation({...original.raster,physicalState:{...original.raster.physicalState,sun:{...original.raster.physicalState.sun,altDeg:-20}}},original.view,original.residualNight,41,67)],
 ['positive-solar',()=>neo.nativeLunarNightPresentation({...original.raster,solarBackgroundLinear:new Float64Array([1])},original.view,original.residualNight,41,67)],
 ['NaN-raw',()=>{const source=original.raster.skyBackgroundLinear.slice();source[100]=NaN;neo.nativeLunarNightPresentation({...original.raster,skyBackgroundLinear:source},original.view,original.residualNight,41,67);}],
 ['wrong-exposure',()=>neo.nativeLunarNightPresentation({...original.raster,effectiveExposure:Infinity},original.view,original.residualNight,41,67)],
 ['grid-too-large',()=>neo.nativeLunarNightPresentation(original.raster,original.view,original.residualNight,69,67)],
 ['grid-fractional',()=>neo.nativeLunarNightPresentation(original.raster,original.view,original.residualNight,41.5,67)],
 ['camera-invalid',()=>neo.nativeLunarNightPresentation(original.raster,{...original.view,fovYDeg:NaN},original.residualNight,41,67)],
 ['wrong-size',()=>neo.nativeLunarNightPresentation(original.raster,{...original.view,width:326},original.residualNight,41,67)],
 ]){assert.throws(f,RangeError,label);negativeControls++;}
const read=p=>fs.readFileSync(R+'/vendor/real-sky/'+p,'utf8');
const engine=new NativeSkyEngine({catalogueText:read('data/bright-stars.json'),manifestText:read('data/registered-starlight/runtime-manifest.json'),assetTexts:{128:read('data/registered-starlight/V-nside128.json')}});
const request=nativeJob(snapshot(),true),result=await engine.render(request);engine.dispose();
assert.equal(result.status,'ready');assert.equal(result.diffuseAsset.mode,'registered');assert(result.sources.length>1000);assert(result.raster.stellarLinear.some(v=>v>0)&&result.raster.diffuseLinear.some(v=>v>0));
const actual=compare('actual-catalogue-diffuse-worker',result.raster,request.options.view,request.options.diffuse.residualNight,[41,67]);
const encoded=encodeNativeFrame(actual.b.linear,actual.b.effectiveExposure);assert(bytes(encoded).equals(bytes(encodeNativeFrame(actual.a.linear,actual.a.effectiveExposure))));
const durations={r3:[],prototype:[]};
for(let i=0;i<12;i++)for(const side of (i%2?['prototype','r3']:['r3','prototype'])){const start=performance.now();if(side==='r3')old.nativeSkyPresentation({...result.raster,lunarBackgroundLinear:old.nativeLunarAtmosphereField(result.raster.physicalState,result.raster.atmosphere,request.options.view,request.options.diffuse.residualNight,41,67)},request.options.view);else neo.nativeLunarNightPresentation(result.raster,request.options.view,request.options.diffuse.residualNight,41,67);durations[side].push(performance.now()-start);}
const record={schema:'r0022-disposable-fused-equivalence/v1',scope:'Source test using actual immutable numerical model and actual catalogue/diffuse native engine. Node diagnostic durations are not native warmed cost or visual acceptance.',oldSha256:sha(fs.readFileSync(R+'/real-sky/native-preview.mjs')),sourceSha256:sha(fs.readFileSync(D+'/native-preview.component-r3.source.mjs')),probeSha256:sha(probe),testSha256:sha(fs.readFileSync(new URL(import.meta.url))),rows,negativeControls,actualSources:result.sources.length,encodedSha256:sha(bytes(encoded)),encodedBytes:encoded.byteLength,diagnosticDurationsMs:durations};
fs.writeFileSync(D+'/component-equivalence-r3.json',JSON.stringify(record,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:'EXACT',rows:rows.length,negativeControls,actualSources:result.sources.length,encodedSha256:record.encodedSha256,diagnosticDurationsMs:durations,cache:neo.inspectLunarGeometry()}));
