from pathlib import Path
import hashlib
D=Path(__file__).resolve().parent
s=(D/'native-preview.component-r2.source.mjs').read_text(encoding='utf-8')
s=s.replace("import {angularSeparation} from './core/src/astronomy.mjs';","import {angularSeparation,DEG,clamp} from './core/src/astronomy.mjs';")
s=s.replace('vectors=new Array(directions.length),omega=', 'vectors=new Array(directions.length),targetAirmass=new Float64Array(directions.length),omega=')
s=s.replace('vectors[i]=horizontalDirection(directions[i]);omega[i]=','vectors[i]=horizontalDirection(directions[i]);targetAirmass[i]=(1-.96*Math.cos(Math.max(0,directions[i].altDeg)*DEG)**2)**(-.5);omega[i]=')
s=s.replace('directions,vectors,omega,above','directions,vectors,targetAirmass,omega,above')
before=''' for(let i=0;i<directions.length;i++)if(directions[i]){
  const h=directions[i],rho=angularSeparation(vectors[i],moonVector);
  const moon=moonSkyLuminance({moonAltDeg:state.moon.altDeg,targetAltDeg:h.altDeg,separationDeg:rho,phaseAngleDeg:state.moon.phaseAngleDeg,extinctionMag:k,distanceKm:state.moon.distanceKm??384400,angularRadiusDeg:state.moon.angularRadiusDeg??.25})*lunarScatteringAlbedo;
  grid[i]=moon*cloudTransmissionFor(h,a,null,state.utcMs)*omega[i];
 }'''
after=''' // Exact per-call factors from the immutable KS function. Retain its
 // left-to-right multiplication order rather than combining coefficients.
 const ma=state.moon.altDeg,phase=state.moon.phaseAngleDeg,radius=state.moon.angularRadiusDeg??.25,distance=state.moon.distanceKm??384400;
 moonSkyLuminance({moonAltDeg:ma,targetAltDeg:90,separationDeg:90,phaseAngleDeg:phase,extinctionMag:k,distanceKm:distance,angularRadiusDeg:radius});
 const u=clamp(ma/radius,-1,1),visibleDisc=(Math.acos(-u)+u*Math.sqrt(Math.max(0,1-u*u)))/Math.PI;
 const I=10**(-.4*(3.84+.026*phase+4e-9*phase**4));
 const transmission=10**(-.4*k*(1-.96*Math.cos(Math.max(0,ma)*DEG)**2)**(-.5)),distanceFactor=(384400/distance)**2;
 for(let i=0;i<directions.length;i++)if(directions[i]){
  const h=directions[i];let luminance=0;
  if(ma>-radius&&k!==0){
   const separation=angularSeparation(vectors[i],moonVector),rho=Math.max(radius,separation),c=Math.cos(rho*DEG),t=clamp((rho-8)/4,0,1),blend=t*t*(3-2*t);
   const near=6.2e7/(rho*rho),far=10**(6.15-rho/40),f=10**5.36*(1.06+c*c)+near*(1-blend)+far*blend;
   luminance=(1e-5/Math.PI)*f*I*transmission*(-Math.expm1(-.4*Math.LN10*k*targetAirmass[i]))*distanceFactor*visibleDisc;
  }
  const moon=luminance*lunarScatteringAlbedo;
  grid[i]=moon*cloudTransmissionFor(h,a,null,state.utcMs)*omega[i];
 }'''
assert s.count(before)==1
s=s.replace(before,after)
probe=s.replace("from './","from 'file:///C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget/real-sky/")
for name,content in [('native-preview.component-r3.source.mjs',s),('native-preview.component-r3.probe.mjs',probe)]:
 p=D/name
 assert not p.exists()
 p.write_text(content,encoding='utf-8',newline='\n');print(name,hashlib.sha256(p.read_bytes()).hexdigest())
test=(D/'verify-component-r2.mjs').read_text(encoding='utf-8').replace('component-r2','component-r3').replace('component-equivalence-r2.json','component-equivalence-r3.json')
(D/'verify-component-r3.mjs').write_text(test,encoding='utf-8',newline='\n')
