from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent
source=(D/'native-preview.source.mjs').read_text(encoding='utf-8')
assert "import {createSkyModel,patatTwilight,V_ZERO_ILLUMINANCE_LUX}" in source
source=source.replace('import {createSkyModel,patatTwilight,V_ZERO_ILLUMINANCE_LUX}','import {createSkyModel,moonSkyLuminance,patatTwilight,V_ZERO_ILLUMINANCE_LUX}')
source=source.replace("import {phaseHG,horizontalDirection} from './core/src/atmosphere.mjs';","import {phaseHG,horizontalDirection,rayleighOpticalDepth,aerosolOpticalDepth,cloudTransmissionFor} from './core/src/atmosphere.mjs';\nimport {angularSeparation} from './core/src/astronomy.mjs';")
source=source.replace('const directions=new Array((gx+1)*(gy+1)),omega=', 'const directions=new Array((gx+1)*(gy+1)),vectors=new Array(directions.length),omega=')
source=source.replace('directions[i]=mapping.unproject(px,py);omega[i]=','directions[i]=mapping.unproject(px,py);vectors[i]=horizontalDirection(directions[i]);omega[i]=')
source=source.replace('gx,gy,directions,omega,above,ix,tx,iy,ty','gx,gy,directions,vectors,omega,above,ix,tx,iy,ty')
source=source.replace('{width,height,directions,omega,above,ix,tx,iy,ty}=geometry','{width,height,directions,vectors,omega,above,ix,tx,iy,ty}=geometry')
before=' for(let i=0;i<directions.length;i++)if(directions[i])grid[i]=model.sample(directions[i]).moonLuminance*omega[i];'
after=''' // The immutable sky model still validates this current physical state and
 // normalises its atmosphere. Extract only its lunar term using the SAME
 // exported core functions and operation order; unused natural/solar RGB and
 // per-sample metadata do not belong to this component admission.
 const state=raster.physicalState,a=model.atmosphere,moonVector=horizontalDirection(state.moon);
 const tauR=rayleighOpticalDepth(550,a),tauA=aerosolOpticalDepth(550,a),totalTau=tauR+tauA+a.greyTau;
 const lunarScatteringAlbedo=totalTau>0?(tauR+tauA*a.aerosolAlbedo)/totalTau:0,k=1.0857362047581296*totalTau;
 for(let i=0;i<directions.length;i++)if(directions[i]){
  const h=directions[i],rho=angularSeparation(vectors[i],moonVector);
  const moon=moonSkyLuminance({moonAltDeg:state.moon.altDeg,targetAltDeg:h.altDeg,separationDeg:rho,phaseAngleDeg:state.moon.phaseAngleDeg,extinctionMag:k,distanceKm:state.moon.distanceKm??384400,angularRadiusDeg:state.moon.angularRadiusDeg??.25})*lunarScatteringAlbedo;
  grid[i]=moon*cloudTransmissionFor(h,a,null,state.utcMs)*omega[i];
 }'''
assert source.count(before)==1
source=source.replace(before,after)
probe=source.replace("from './","from 'file:///C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget/real-sky/")
for name,content in [('native-preview.component-r2.source.mjs',source),('native-preview.component-r2.probe.mjs',probe)]:
 p=D/name
 assert not p.exists()
 p.write_text(content,encoding='utf-8',newline='\n')
 print(name,hashlib.sha256(p.read_bytes()).hexdigest())
test=(D/'verify-fused.mjs').read_text(encoding='utf-8').replace('native-preview.probe.mjs','native-preview.component-r2.probe.mjs').replace('native-preview.source.mjs','native-preview.component-r2.source.mjs').replace('equivalence-r1.json','component-equivalence-r2.json')
needle="const lower={...original,raster:{...original.raster,effectiveExposure:1e-20}};"
added='''for(const phaseAngleDeg of [0,8,90,150,170,180])for(const altDeg of [-.25,0,20,85]){
 const state=original.raster.physicalState;
 run('phase-alt-'+phaseAngleDeg+'-'+altDeg,physicalFixture(snapshot(),[41,67],{moon:{...state.moon,phaseAngleDeg,altDeg}}));
}
'''
assert needle in test
test=test.replace(needle,added+needle)
(D/'verify-component-r2.mjs').write_text(test,encoding='utf-8',newline='\n')
