import fs from'node:fs';import vm from'node:vm';import assert from'node:assert/strict';import crypto from'node:crypto';import{pathToFileURL}from'node:url';
const R='C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget',D='C:/Users/theis/.codex/work-products/r0022-execution-20261015/disposable-admission-r4';
const sha=v=>crypto.createHash('sha256').update(v).digest('hex'),bytes=v=>Buffer.from(v.buffer,v.byteOffset,v.byteLength);
const before=await import(pathToFileURL(R+'/real-sky/native-preview.mjs')),after=await import(pathToFileURL(D+'/native-preview.probe.mjs'));
const {nativeJob}=await import(pathToFileURL(R+'/real-sky/native-contract.mjs'));
const {NativeSkyEngine}=await import(pathToFileURL(R+'/real-sky/native-engine.mjs'));
const {encodeNativeFrame,nativeEncodingThresholds}=await import(pathToFileURL(R+'/real-sky/native-encoding.mjs'));
const source=fs.readFileSync(D+'/native-host.source.mjs','utf8'),oldSource=fs.readFileSync(R+'/real-sky/native-host.mjs','utf8');
const snapshot={utcMs:Date.parse('2026-09-25T02:00:00Z'),lat:28.5383,lon:-81.3792,heightM:0,generation:2,sceneIdentity:'native-host-actual-oracle',camera:{azDeg:180,altDeg:45,fovYDeg:90,rollDeg:0},weather:{vis:20000,cloud:0,code:0,temp:28},units:'c',lp:0,timeScale:1};
const read=p=>fs.readFileSync(R+'/vendor/real-sky/'+p,'utf8'),engine=new NativeSkyEngine({catalogueText:read('data/bright-stars.json'),manifestText:read('data/registered-starlight/runtime-manifest.json'),assetTexts:{128:read('data/registered-starlight/V-nside128.json')}});
const request=nativeJob(snapshot,true),result=await engine.render(request);engine.dispose();assert(result.sources.length>1000&&result.raster.diffuseLinear.some(v=>v>0));
function invoke(code,display){const accept=code.slice(code.indexOf(' function accept('),code.indexOf('\n function failure('));
 const c={...display,frame:null,job:null,snapshot:()=>snapshot,lifecycle:{current:()=>true},status:{rejections:0,renders:0},physical:true,host:{capture:()=>({})},compose(){},publish(){},result,request};vm.createContext(c);vm.runInContext(accept+'\naccept(result,1,request);',c);return {c,accept};}
const a=invoke(oldSource,before),b=invoke(source,after),fields=[];
assert.deepEqual(Object.keys(a.c.frame.raster).sort(),Object.keys(b.c.frame.raster).sort());
for(const [key,v]of Object.entries(a.c.frame.raster)){const w=b.c.frame.raster[key];if(ArrayBuffer.isView(v)){assert(bytes(v).equals(bytes(w)),key);fields.push({key,bytes:v.byteLength,sha256:sha(bytes(v))});}else assert.deepEqual(w,v,key);}
for(const runner of [a,b]){const held=runner.c.frame;runner.c.lifecycle.current=()=>false;vm.runInContext('accept(result,2,request);',runner.c);assert.equal(runner.c.frame,held);assert.equal(runner.c.status.rejections,1);assert.equal(runner.c.status.renders,1);}
const helper=source.slice(source.indexOf('let nativeDisplayEncodeCache='),source.indexOf('/** DOM ownership adapter')).replace('export function','function');
const ctx={nativeEncodingThresholds,Uint8ClampedArray,Uint8Array,Uint16Array};vm.createContext(ctx);vm.runInContext(helper,ctx);
const expected=encodeNativeFrame(a.c.frame.raster.linear,a.c.frame.raster.effectiveExposure),actual=ctx.encodeNativeDisplay(b.c.frame.raster.linear,b.c.frame.raster.effectiveExposure);assert(bytes(expected).equals(bytes(actual)));
// Run the existing actual-composition adversarial fixture on this exact host,
// substituting only its own revised encoder where the test records call sizes.
let fixture=fs.readFileSync(R+'/tests/real-sky/native-host-composition.test.mjs','utf8');
fixture=fixture.replace("import {encodeNativeFrame} from '../../real-sky/native-encoding.mjs';","import {encodeNativeFrame,nativeEncodingThresholds} from "+JSON.stringify(pathToFileURL(R+'/real-sky/native-encoding.mjs').href)+";\n"+helper);
fixture=fixture.replace("'../../real-sky/native-composition.mjs'",JSON.stringify(pathToFileURL(R+'/real-sky/native-composition.mjs').href));
fixture=fixture.replace("fs.readFileSync(new URL('../../real-sky/native-host.mjs',import.meta.url),'utf8')",'fs.readFileSync('+JSON.stringify(D+'/native-host.source.mjs')+',\'utf8\')');
fixture=fixture.replace('encodeNativeFrame(a,E){encoded.push(a.length);return encodeNativeFrame(a,E);}','encodeNativeDisplay(a,E){encoded.push(a.length);return encodeNativeDisplay(a,E);}');
fs.writeFileSync(D+'/actual-compose-r1.test.mjs',fixture,{flag:'wx'});
const report={schema:'r0022-disposable-host-oracle/v1',sourceSha256:sha(source),previewSha256:sha(fs.readFileSync(D+'/native-preview.source.mjs')),testSha256:sha(fs.readFileSync(new URL(import.meta.url))),actualCatalogueSources:result.sources.length,fields,encodedBytes:actual.byteLength,encodedSha256:sha(bytes(actual)),staleRejectBoth:true,compositionFixture:sha(fixture),scope:'Actual authored admission bodies and current immutable catalogue/diffuse worker. Separate actual-composition fixture prepared; no native browser cost or visual acceptance.'};
fs.writeFileSync(D+'/host-oracle-r1.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({status:'EXACT',fields:fields.length,encodedBytes:actual.byteLength,actualSources:result.sources.length,encodedSha256:report.encodedSha256}));
