from pathlib import Path
import hashlib
D=Path(__file__).resolve().parent;R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget')
s=(R/'real-sky/native-host.mjs').read_text(encoding='utf-8')
assert hashlib.sha256((R/'real-sky/native-host.mjs').read_bytes()).hexdigest()=='a5e6ce93f271a013ebf0f74561a4597cbf3c4a399f754c715078592c0d258992'
s=s.replace("import {encodeNativeFrame} from './native-encoding.mjs';","import {nativeEncodingThresholds} from './native-encoding.mjs';")
s=s.replace('nativeAtmosphereFields,nativeLunarAtmosphereField,nativeSkyPresentation','nativeAtmosphereFields,nativeLunarNightPresentation,nativeSkyPresentation')
s=s.replace('encodeNativeFrame','encodeNativeDisplay')
before='''   let fields;
   if(result.raster.physicalState.sun.altDeg<-20){
    fields={lunarBackgroundLinear:nativeLunarAtmosphereField(result.raster.physicalState,result.raster.atmosphere,request.options.view,request.options.diffuse.residualNight,...grid)};
   }else{
    const all=nativeAtmosphereFields(result.raster.physicalState,result.raster.atmosphere,request.options.view,request.options.diffuse.residualNight,...grid);
    fields={solarAerosolLinear:all.solarAerosolLinear,solarBackgroundLinear:all.solarBackgroundLinear,lunarBackgroundLinear:all.lunarBackgroundLinear,twilightDisplay:all.twilightDisplay};
   }
   result={...result,raster:nativeSkyPresentation({...result.raster,...fields},request.options.view,host.capture().solarAnchor)};'''
after='''   if(result.raster.physicalState.sun.altDeg<-20){
    result={...result,raster:nativeLunarNightPresentation(result.raster,request.options.view,request.options.diffuse.residualNight,...grid)};
   }else{
    const all=nativeAtmosphereFields(result.raster.physicalState,result.raster.atmosphere,request.options.view,request.options.diffuse.residualNight,...grid);
    const fields={solarAerosolLinear:all.solarAerosolLinear,solarBackgroundLinear:all.solarBackgroundLinear,lunarBackgroundLinear:all.lunarBackgroundLinear,twilightDisplay:all.twilightDisplay};
    result={...result,raster:nativeSkyPresentation({...result.raster,...fields},request.options.view,host.capture().solarAnchor)};
   }'''
assert s.count(before)==1
s=s.replace(before,after)
mark='/** DOM ownership adapter; native PBR/calendar/weather remain native source code. */'
fragment=(D/'encode-exact-r2.fragment.mjs').read_text(encoding='utf-8').replace('function encodeNativeDisplay','export function encodeNativeDisplay')
s=s.replace(mark,fragment+'\n'+mark)
p=D/'native-host.source.mjs';assert not p.exists();p.write_text(s,encoding='utf-8',newline='\n');print(hashlib.sha256(p.read_bytes()).hexdigest())
