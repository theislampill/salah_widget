/* Separate instrumented preservation run, never ordinary startup-timing proof. */
(()=>{
 const stages=window.__r0022StageObservation={records:[],worker:[],held:[],hold:false,releasing:false,ticks:0,startedAt:null,lastTick:null,errors:[]};
 let first,serial=0;const seen={first:new WeakSet(),preview:new WeakSet(),refined:new WeakSet()};
 const summary=r=>r?{width:r.width,height:r.height,physical:r.physicalState,exposure:r.effectiveExposure,lunar:r.lunarDisplayPresentation??null,
  raw:r.lunarBackgroundLinear?{length:r.lunarBackgroundLinear.length,positive:r.lunarBackgroundLinear.some(v=>v>0),first12000Maximum:Math.max(...r.lunarBackgroundLinear.subarray(0,12000))}:null,
  mapped:r.lunarNightDisplayLinear?{length:r.lunarNightDisplayLinear.length,positive:r.lunarNightDisplayLinear.some(v=>v>0)}:null,
  rawSkySeparate:!!r.physicalSkyBackgroundLinear&&r.physicalSkyBackgroundLinear!==r.skyBackgroundLinear,drawn:r.drawn??null}:null;
 const record=(name,frame)=>{if(!frame?.raster||seen[name].has(frame.raster))return;seen[name].add(frame.raster);const native=window.SalahNativeSkyHost?.capture(false),s=window.realSkyState?.();stages.records.push({name,at:performance.now(),native,sky:s?{status:s.status,utc:s.presentationUtcMs,displayed:s.displayed,lifecycle:s.lifecycle}:null,preview:window.SalahSkyPreview?.state,moon:window.SalahMoonRuntime?.state,field:summary(frame.raster),firstSnapshot:name==='first'?first?.snapshot:null});};
 const fault=(stage,e)=>{if(stages.errors.length<32)stages.errors.push({stage,at:performance.now(),message:String(e?.message??e)});};
 Object.defineProperty(window,'SalahFirstPaint',{configurable:true,get:()=>first,set(value){first=value;try{if(value?.value)record('first',value.value);}catch(e){fault('first',e);}}});
 const W=Worker;window.Worker=class extends W{
  constructor(...args){super(...args);this.__r0022Id=++serial;this.__r0022Moon=false;this.addEventListener('message',e=>{const m=e.data;if(stages.releasing||this.__r0022Moon||m?.kind!=='result')return;stages.worker.push({event:'result',id:m.id,worker:this.__r0022Id,utc:m.result?.utcMs,at:performance.now()});if(stages.hold){e.stopImmediatePropagation();stages.held.push({owner:this,event:e});}});}
  postMessage(m,...rest){if(m?.kind==='boot')this.__r0022Moon='offline'in m;if(!this.__r0022Moon&&m?.kind==='render')stages.worker.push({event:'submit',id:m.id,worker:this.__r0022Id,utc:m.job.observer.utcMs,native:m.job.native,observer:m.job.observer,at:performance.now()});return super.postMessage(m,...rest);}
 };
 stages.release=()=>{stages.hold=false;const held=stages.held.splice(0),receipt=held.map(x=>({id:x.event.data.id,utc:x.event.data.result?.utcMs,worker:x.owner.__r0022Id}));stages.releasing=true;try{for(const item of held)item.owner.dispatchEvent(new MessageEvent('message',{data:item.event.data}));}finally{stages.releasing=false;}return receipt;};
 // An init script may run in the iframe's initial about:blank document.
 // Window listeners survive its replacement; a document listener and its rAF
 // do not. Start once per actual document and retire stale-document callbacks.
 const documents=new WeakMap(),started=new WeakSet();let documentSerial=0,activeDocument=null;
 const documentId=d=>{if(!documents.has(d))documents.set(d,++documentSerial);return documents.get(d);};
 stages.starts=[];
 const start=()=>{
  const d=document;if(d.URL==='about:blank'||d.readyState==='loading'||started.has(d))return;
  started.add(d);activeDocument=d;stages.startedAt=performance.now();
  const id=documentId(d);stages.starts.push({id,url:d.URL,at:stages.startedAt,timeOrigin:performance.timeOrigin});
  const tick=()=>{
   if(document!==d||activeDocument!==d)return;
   stages.ticks++;stages.lastTick=performance.now();
   try{if(d.querySelector('.c')?.classList.contains('real-sky-composed'))record('refined',window.realSkyFrame?.());else record('preview',window.SalahSkyPreview?.frame);}catch(e){fault('tick',e);}
   requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
 };
 window.addEventListener('DOMContentLoaded',e=>{if(e.target===document)start();});
 window.addEventListener('pageshow',e=>{if(e.target===document)start();});
 start();
 window.__r0022ReadStages=()=>({document:{id:documentId(document),url:document.URL,active:activeDocument===document,readAt:performance.now(),timeOrigin:performance.timeOrigin},starts:stages.starts,ticks:stages.ticks,startedAt:stages.startedAt,lastTick:stages.lastTick,errors:stages.errors,records:stages.records,worker:stages.worker,held:stages.held.map(x=>({id:x.event.data.id,utc:x.event.data.result?.utcMs})),hold:stages.hold});
})();
