"""Actual settings route and original native ownership fences, after capture."""
import asyncio,json
STATE="""()=>{const m=window.SalahMoonRuntime.state,n=window.SalahNativeSkyHost.capture(false),s=window.realSkyState?.(),p=document.querySelector('.mphoto').getBoundingClientRect();return {native:n,sky:s,preview:window.SalahSkyPreview?.state,moon:m,surface:!!window.SalahMoonRuntime.surface(),photo:{x:p.x,y:p.y,width:p.width,height:p.height},classes:document.querySelector('.c').className,settings:{open:document.querySelector('.c').classList.contains('settings-open'),display:getComputedStyle(document.querySelector('#settings')).display},stages:window.__r0022ReadStages?.()};}"""
async def _lifecycle_controls(page,frame,out,mode):
 records=[];failures=[]
 def check(value,reason):
  if not value:failures.append(reason)
 async def take(name):
  state=await frame.evaluate(STATE);state['name']=name;file=f'{mode}-lifecycle-{name}.png';await page.screenshot(path=str(out/file));state['image']=file;records.append(state)
  (out/f'{mode}-lifecycle-partial.json').write_text(json.dumps({'records':records,'failures':failures},indent=2)+'\n',encoding='utf-8');return state
 async def ready():
  await frame.wait_for_function("window.realSkyState?.().status==='ready'&&window.SalahMoonRuntime?.state.current&&window.SalahMoonRuntime?.state.visibleSource==='refined-terrain'",timeout=90000)
 async def edit(la,lo,label):
  await frame.locator('.buckle.interactive').click();check(await frame.locator('#settings').is_visible(),'Actual settings failed to open')
  await frame.locator('#set-lat').fill(str(la));await frame.locator('#set-lon').fill(str(lo));await frame.locator('#set-label').fill(label);await frame.locator('#setClose').click()
 await ready();before=await take('before');a=before['native']
 # Hold a genuine result from the current A request; the next UI route revokes
 # it. Do not mutate its UTC/native/generation or replace it with a fake raster.
 await frame.evaluate("()=>{__r0022StageObservation.hold=true;SalahRealSky.request(true);}")
 await frame.wait_for_function('__r0022StageObservation.held.length>0',timeout=20000)
 await edit(25.7617,-80.1918,'B fixture');b=await take('b-with-old-a-held')
 check(b['native']['lat']==25.7617 and b['native']['generation']>a['generation'],'Actual settings failed A to B')
 check(not b['sky'].get('last')or b['sky']['last']['native']['generation']==b['native']['generation'],'Old A sky remained admitted at B')
 await edit(a['lat'],a['lon'],'CENTRAL FL');ab=await take('a-return-with-old-a-held')
 check(ab['native']['generation']>=a['generation']+2,'A-B-A reused target generation')
 check(not ab['sky'].get('last')or ab['sky']['last']['native']['generation']==ab['native']['generation'],'First A result survived successor A generation')
 released=await frame.evaluate('()=>__r0022StageObservation.release()');await ready();after=await take('a-b-a-current')
 check(after['sky']['last']['native']['generation']==after['native']['generation'],'Refinement target/generation mismatch after release')
 check(after['sky']['lifecycle']['rejected']>before['sky']['lifecycle']['rejected']or after['sky']['lifecycle']['superseded']>before['sky']['lifecycle']['superseded'],'Held stale result was not rejected/superseded')
 # Explicit seek is through the existing supported native clock owner.
 sought=await frame.evaluate('()=>SalahClock.set({rate:0,utcMs:SalahNativeSkyHost.capture(false).utcMs+1800000})');seek=await take('seek-withdrawal')
 check(seek['moon']['epoch']>after['moon']['epoch'],'Seek did not revoke lunar epoch');check(abs(seek['native']['utcMs']-sought['utcMs'])<1,'Seek time not owned by native clock')
 await ready();await take('seek-current')
 await frame.evaluate('()=>SalahClock.set({live:true})');await ready();live=await take('live-return')
 check(live['native']['timeScale']==1 and live['moon']['epoch']>seek['moon']['epoch'],'Ordinary live return did not revoke seek')
 # Reference profile has no admitted physical-reference scene; it must withdraw.
 withdrawal=await frame.evaluate("()=>{SalahMoonRuntime.setProfile('reference');return {surface:!!SalahMoonRuntime.surface(),state:SalahMoonRuntime.state};}")
 check(not withdrawal['surface']and not withdrawal['state']['current'],'Unsupported reference profile leaked calendar material');await take('reference-withdrawal')
 await frame.evaluate("()=>SalahMoonRuntime.setProfile('calendar')");await ready();await take('calendar-return')
 invalid=await frame.evaluate("()=>{try{SalahMoonRuntime.setReferenceScene({mode:'physical-reference'});return false;}catch(e){return e instanceof RangeError;}}")
 check(invalid,'Malformed reference geometry was admitted')
 final=await take('final')
 for row in records:
  check(abs(row['photo']['width']-before['photo']['width'])<.5,'Calendar body width changed in '+row['name'])
  pp=row['moon'].get('phasePrecision')or{};bound=pp.get('targetPositionErrorBound');check(bound is None or bound<=.041600001,'Phase displacement bound failed in '+row['name'])
  sky=row.get('sky')or{};utc=sky.get('presentationUtcMs')
  if 'real-sky-composed'in row['classes']and utc is not None:check(abs(row['native']['utcMs']-utc)<=30000,'Displayed sky exceeded original age bound in '+row['name'])
 return {'status':'PASS'if not failures else'FAIL','failures':failures,'releasedOriginalResults':released,'records':records,'scope':'Instrumented ownership/actual settings preservation. No startup timing, extension-parent, blanket motion or whole-issue credit.'}

async def lifecycle_controls(page,frame,out,mode):
 try:return await _lifecycle_controls(page,frame,out,mode)
 except Exception as error:
  path=out/f'{mode}-lifecycle-partial.json';partial=json.loads(path.read_bytes())if path.exists()else{'records':[],'failures':[]}
  partial.update(status='FAIL',exception={'type':type(error).__name__,'message':str(error)},scope='Partial instrumented lifecycle sequence retained after failure; no PASS.')
  partial['failures'].append('Lifecycle did not complete: '+str(error));return partial
