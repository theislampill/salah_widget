from pathlib import Path
import hashlib,json
O=Path(__file__).resolve().parent;R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget');D=O/'disposable-admission-r4';B=O/'selected-r3/retained-source'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((O/'browser-lease.json').read_bytes())['status']=='FREE'and not(O/'native-resource.lock').exists()
expected=json.loads((O/'selected-r3/RUNTIME.json').read_bytes())
for name in ['real-sky/native-preview.mjs','real-sky/native-host.mjs','real-sky/native-sky.js','index.html','offline.html']:
 assert sha(R/name)==expected['files'][name]['sha256']
 target=B/name;target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();target.write_bytes((R/name).read_bytes())
for name,source,pin in [('native-preview','native-preview.source.mjs','eff32805165a7daa28be83baf0723a7f4f9049dbd55eb789962da899ce3f7537'),('native-host','native-host.source.mjs','53b75248e8c3849d4cb53396280d0ece8b2fae7e9b215aa7dae36f6f10eaaebe')]:
 assert sha(D/source)==pin
 (R/('real-sky/'+name+'.mjs')).write_bytes((D/source).read_bytes())
print(json.dumps({'status':'AUTHORED_INTEGRATED_PENDING_BUILD','retained':str(B),'preview':sha(R/'real-sky/native-preview.mjs'),'host':sha(R/'real-sky/native-host.mjs')}))
