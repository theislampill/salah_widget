from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,sys
O=Path(__file__).resolve().parent;R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget');D=O/'selected-r4'
node='C:/workspace/ai/cp9-integration-20261005/toolchain/node-v22.16.0-win-x64/node.exe'
def read(p):return json.loads(p.read_bytes())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert read(O/'browser-lease.json')['status']=='FREE'
assert read(Path('C:/Users/theis/Documents/Codex/salah-rlgwo-execution-20261009/ACTIVE_LEDGER.json'))['resourceLeases']['heavy-browser']['status']=='FREE'
assert read(Path('C:/Users/theis/.codex/work-products/r0024-execution-20261015/execution.json'))['heavyLease']['kind']=='FREE'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='fc8d13338f9274a768580cda5a805492f80c510d'
assert sha(R/'real-sky/native-preview.mjs')=='eff32805165a7daa28be83baf0723a7f4f9049dbd55eb789962da899ce3f7537'
assert sha(R/'real-sky/native-host.mjs')=='53b75248e8c3849d4cb53396280d0ece8b2fae7e9b215aa7dae36f6f10eaaebe'
D.mkdir();lock=O/'native-resource.lock'
with lock.open('x')as f:f.write('build-selected-r4')
lease={'status':'ACTIVE','owner':'R0022 root','leaseId':'build-selected-r4','startedAtUtc':now(),'scope':'Canonical build and bounded source qualification'};save(O/'browser-lease.json',lease)
checks=[]
try:
 for name,cmd in [('build-1.log',[sys.executable,'-B','tools/build_native.py']),('v1.log',[sys.executable,'-B','tools/verify_v1.py']),('gain.log',[node,'tests/r0022-baseline-balance.cjs']),('native-tests.log',[node,'--test',*[str(p)for p in (R/'tests/real-sky').glob('native-*.test.mjs')]]),('lunar-consumers.log',[node,'tests/r0022-lunar-consumers.cjs','--cp8-snapshot-only']),('cost-controls.log',[node,'--test','tests/r0022-paint-cost.test.mjs']),('cost-evaluator-controls.log',[sys.executable,'-B','tests/r0022-paint-cost.test.py'])]:
  with (D/name).open('xb')as f:p=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
  checks.append({'log':name,'command':cmd,'exitCode':p.returncode});save(D/'checks.json',checks)
  if p.returncode:raise RuntimeError(name+' failed; retained')
 spec=importlib.util.spec_from_file_location('identity',R/'tools/cp9/runtime_identity.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);first=m.runtime_identity(R)
 with (D/'build-2.log').open('xb')as f:subprocess.run([sys.executable,'-B','tools/build_native.py'],cwd=R,stdout=f,stderr=subprocess.STDOUT,check=True)
 assert m.runtime_identity(R)==first
 base=read(O/'qualification/baseline-runtime.json');changed=[p for p in base['files']if base['files'][p]!=first['files'][p]]
 assert set(changed)=={'index.html','offline.html','real-sky/native-sky.js','real-sky/native-preview.mjs','real-sky/native-host.mjs'}
 save(D/'RUNTIME.json',first);save(D/'SOURCE.json',{'atUtc':now(),'base':'fc8d13338f9274a768580cda5a805492f80c510d','runtime':first['treeSha256'],'changed':changed,'protectedUnchanged':len(base['files'])-len(changed),'buildDeterministic':True,'contract':'R0022-L1-H1-K003-H020-v1','checks':checks,'scope':'Source/build only; selected-r1 native observations retained at original identity, not automatically transferred. Native cost and affected composition/currentness pending.'})
 print(json.dumps({'runtime':first['treeSha256'],'changed':changed,'checks':[{'log':x['log'],'exitCode':x['exitCode']}for x in checks]}))
finally:
 lease.update(status='FREE',owner=None,finishedAtUtc=now());save(O/'browser-lease.json',lease);assert lock.read_text()=='build-selected-r4';lock.unlink()
