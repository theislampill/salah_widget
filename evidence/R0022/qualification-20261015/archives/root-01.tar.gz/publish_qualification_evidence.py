"""Append reviewed non-deploying evidence; never touch the main ref or close an issue."""
from pathlib import Path,PurePosixPath
import datetime,hashlib,json,os,subprocess,urllib.request
O=Path(__file__).resolve().parent;R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget');P=O/'publication-qualification';E=O/'publication-qualification-effects'
BASE='fc8d13338f9274a768580cda5a805492f80c510d';PARENT='c44a4d2df44ee9eef59faba9d524f742163e1270';BRANCH='codex/r0022-evidence-20261015';PREFIX='evidence/R0022/qualification-20261015/'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def git(*args,env=None):return subprocess.check_output(['git',*args],cwd=R,env=env)
def api(path):return json.loads(subprocess.check_output(['gh','api','repos/theislampill/salah_widget/'+path]))
def record(name,v):
 with(E/name).open('x',encoding='utf-8')as f:f.write(json.dumps(v,indent=2)+'\n')
assert read(O/'browser-lease.json')['status']=='FREE'and not(O/'native-resource.lock').exists()
assert not E.exists(),'Reconcile any prior publication effect before retry'
assert git('rev-parse','HEAD').decode().strip()==BASE
assert git('remote','get-url','origin').decode().strip()=='https://github.com/theislampill/salah_widget.git'
assert api('git/ref/heads/main')['object']['sha']==BASE
assert api('git/ref/heads/'+BRANCH)['object']['sha']==PARENT
assert git('rev-parse','refs/heads/'+BRANCH).decode().strip()==PARENT
assert api('issues/34')['state']=='open'
pages=api('pages');assert pages['source']=={'branch':'main','path':'/'}and pages['build_type']=='legacy'
manifest=read(P/'payload-manifest.json');assert manifest['base']==BASE and manifest['priorEvidenceCommit']==PARENT
review=read(O/'QUALIFICATION_STATUS_REVIEW.json');assert review['status']=='ACCEPTED_FOR_TRUTHFUL_NONCLOSING_PUBLICATION'
assert review['qualificationStatusSha256']==manifest['qualificationStatusSha256']==sha((O/'QUALIFICATION_STATUS.json').read_bytes())
declared=manifest['archives']+manifest['directCopies']
expected={'payload-manifest.json'}
for row in declared:
 rel=PurePosixPath(row['path']);assert not rel.is_absolute()and'..'not in rel.parts and str(rel)==row['path']and':'not in row['path']and'\\'not in row['path']
 assert row['path']not in expected,('Duplicate package path',row['path']);expected.add(row['path'])
 path=P/row['path'];assert path.resolve().is_relative_to(P.resolve())and path.is_file()and path.stat().st_size==row['bytes']and sha(path.read_bytes())==row['sha256'],('Package byte drift',row['path'])
actual_files={p.relative_to(P).as_posix()for p in P.rglob('*')if p.is_file()}
assert actual_files==expected,('Undeclared or missing package files',sorted(actual_files-expected),sorted(expected-actual_files))
assert sha((P/'QUALIFICATION_STATUS.json').read_bytes())==review['qualificationStatusSha256']
assert (P/'QUALIFICATION_STATUS_REVIEW.json').read_bytes()==(O/'QUALIFICATION_STATUS_REVIEW.json').read_bytes()
E.mkdir();env=os.environ.copy();env['GIT_INDEX_FILE']=str(E/'temporary-evidence-index')
git('read-tree',PARENT,env=env);files=[]
for p in sorted(P.rglob('*')):
 if not p.is_file():continue
 rel=PREFIX+p.relative_to(P).as_posix();blob=git('hash-object','-w','--',str(p)).decode().strip()
 git('update-index','--add','--cacheinfo','100644,'+blob+','+rel,env=env)
 files.append({'path':rel,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'blobSha':blob})
tree=git('write-tree',env=env).decode().strip()
changed=git('diff-tree','--no-commit-id','--name-only','-r',PARENT,tree).decode().splitlines();assert changed and all(p.startswith(PREFIX)for p in changed)
msg=E/'commit-message.txt';msg.write_text('Preserve R0022 H1 qualification and unresolved evidence\n\nRetain original native gain, whole-scene pixels, stage/currentness controls, paired CPU cost and all contrary observations with exact source identities. This non-deploying evidence snapshot does not grant merge, delivery or issue-closure acceptance.\n\nCo-Authored-By: Codex <noreply@openai.com>\n',encoding='utf-8')
commit=git('commit-tree',tree,'-p',PARENT,'-F',str(msg)).decode().strip()
record('push-intent.json',{'atUtc':now(),'branch':BRANCH,'base':BASE,'parent':PARENT,'commit':commit,'tree':tree,'files':files,'manifestSha256':sha((P/'payload-manifest.json').read_bytes()),'independentReviewSha256':sha((O/'QUALIFICATION_STATUS_REVIEW.json').read_bytes()),'authority':'Direct owner execution order permits immutable non-deploying evidence publication. No main, merge, issue-state or deployment effect.'})
git('update-ref','refs/heads/'+BRANCH,commit,PARENT)
result=subprocess.run(['git','push','origin',commit+':refs/heads/'+BRANCH],cwd=R,capture_output=True)
record('push-result.json',{'atUtc':now(),'exitCode':result.returncode,'stdout':result.stdout.decode(),'stderr':result.stderr.decode()});assert result.returncode==0,'Inspect actual remote before any retry'
assert api('git/ref/heads/'+BRANCH)['object']['sha']==commit
actual=api('git/commits/'+commit);assert actual['tree']['sha']==tree and[p['sha']for p in actual['parents']]==[PARENT]
post_pages=api('pages')
record('git-readback.json',{'atUtc':now(),'commit':actual,'main':api('git/ref/heads/main')['object']['sha'],'issue34':api('issues/34')['state'],'pages':{k:post_pages[k]for k in ['source','build_type']}})
http=[]
for row in files:
 local=git('cat-file','blob',row['blobSha']);assert len(local)==row['bytes']and sha(local)==row['sha256']
 url='https://raw.githubusercontent.com/theislampill/salah_widget/'+commit+'/'+row['path']
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'R0022-evidence-readback'}),timeout=120)as response:
  data=response.read();assert response.status==200;status=response.status
 assert len(data)==row['bytes']and sha(data)==row['sha256']
 http.append({'path':row['path'],'status':status,'bytes':len(data),'sha256':sha(data),'atUtc':now()})
 print(json.dumps({'readback':row['path'],'bytes':len(data)}),flush=True)
record('http-readback.json',{'commit':commit,'files':http,'allMatch':True})
final_main=api('git/ref/heads/main')['object']['sha'];final_issue=api('issues/34');final_pages=api('pages')
assert final_main==BASE and final_issue['state']=='open'
assert final_pages['source']=={'branch':'main','path':'/'}and final_pages['build_type']=='legacy'
record('final-state.json',{'atUtc':now(),'main':final_main,'issue34':{'state':final_issue['state'],'state_reason':final_issue['state_reason']},'pages':{k:final_pages[k]for k in ['source','build_type']},'evidenceCommit':commit})
print(json.dumps({'evidenceCommit':commit,'tree':tree,'files':len(files),'httpByteReadback':True,'url':'https://github.com/theislampill/salah_widget/tree/'+commit+'/'+PREFIX,'mainUnchanged':BASE,'issue34':'open'}))
