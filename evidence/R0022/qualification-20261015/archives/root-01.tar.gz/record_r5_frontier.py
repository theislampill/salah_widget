from pathlib import Path
import datetime,hashlib,json
O=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
p=O/'EXECUTION.json';old=p.read_bytes();h=O/'frontier-history'/f'{hashlib.sha256(old).hexdigest()}.json'
if not h.exists():h.write_bytes(old)
v=json.loads(old);runtime=read(O/'selected-r5/RUNTIME.json')['treeSha256']
v['retainedDispositions']['A03']='R15 actual96slots/125948calls retained INCOMPLETE/INCONCLUSIVE_NOISE. Admission21.6/24.7ms exceeds15.18/18.81ms; all four candidate rounds over budget. Other five scopes controlled within budget at R4. R14 controlled admission failure retained. R5 changes require fresh affected cost; no performance PASS.'
v['ownerDisplayGate']['sourceState']='Selected-r5 runtime '+runtime+'; exact approved H1 unchanged. Independent R5 source integration approved; canonical2build identity and184native tests pass. Eighteen preview raster/job cases equal accepted R1; native cost pending.'
v['next']='Independent R16 setup-source review, then serial C1 actual setup, independent actual setup review and pre-run budget activation; only then admission-only full four ABBA rounds. Preserve Firefox original-watch failure and external native surface/frame association gap. No merge or closure gate is ready.'
v['continuation'].update(atUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceFrontier='R5 integrated and generated. Source approval '+sha(O/'disposable-admission-r4/SOURCE_REPAIR_R5_REVIEW.json')+'; PREMEASUREMENT_PINS_R16 '+sha(O/'cost/PREMEASUREMENT_PINS_R16.json')+'. R15/source fixtures preserved.',mandatoryCredit='Original native gains/material retained, current source controls pass. R7 first/preview/refined metadata accepted within recorded scope; R7 original full-card watch contains pale/incomplete frames and fails continuous acceptance. Actual cause remains unresolved; no endpoint substitution. R0018/R0024 preserved; PR43 draft failures remain separate.')
p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
print(sha(p))
