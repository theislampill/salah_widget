"""Lossless evidence snapshot; previously published and base-identical bytes use immutable locators."""
from pathlib import Path,PurePosixPath
import datetime,gzip,hashlib,io,json,shutil,tarfile
O=Path(__file__).resolve().parent;P=O/'publication-qualification'
PRIOR='c44a4d2df44ee9eef59faba9d524f742163e1270';BASE='fc8d13338f9274a768580cda5a805492f80c510d'
def read(p):return json.loads(p.read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
assert read(O/'browser-lease.json')['status']=='FREE'and not(O/'native-resource.lock').exists()
assert (O/'QUALIFICATION_STATUS.json').exists(),'Final snapshot status must first be reviewed'
P.mkdir(exist_ok=False)
known={}
old=read(O/'publication/payload-manifest.json')
for a in old['archives']:
 for f in a['files']:
  known[(f['sha256'],f['bytes'])]={'kind':'prior-archive','commit':PRIOR,'path':'evidence/R0022/owner-display-20261015/'+a['path'],'archiveSha256':a['sha256'],'member':f['original']}
for path,f in read(O/'qualification/baseline-runtime.json')['files'].items():
 known[(f['sha256'],f['bytes'])]={'kind':'git-file','commit':BASE,'path':path}
excludedRoots={'publication','publication-effects','publication-qualification','publication-qualification-effects'}
rows=[];unique={};groups={}
for path in sorted(O.rglob('*')):
 if not path.is_file():continue
 rel=path.relative_to(O)
 if rel.parts[0]in excludedRoots or '__pycache__'in rel.parts or path.name=='native-resource.lock':continue
 data=path.read_bytes();key=(sha(data),len(data));row={'path':rel.as_posix(),'bytes':len(data),'sha256':key[0]}
 if key in known:row['location']=known[key]
 else:
  if key not in unique:
   unique[key]=(rel.as_posix(),path)
   group='/'.join(rel.parts[:2])if rel.parts[0]in ['qualification','cost']and len(rel.parts)>2 else rel.parts[0]if len(rel.parts)>1 else'root'
   groups.setdefault(group,[]).append((key,rel.as_posix(),path))
  row['location']={'kind':'snapshot-object','sha256':key[0]}
 rows.append(row)
archives=[];objects={}
for group,files in sorted(groups.items()):
 chunks=[];current=[];size=0
 for item in files:
  if current and size+item[0][1]>80*1024**2:chunks.append(current);current=[];size=0
  current.append(item);size+=item[0][1]
 if current:chunks.append(current)
 for ordinal,chunk in enumerate(chunks,1):
  name=group.replace('/','--')+f'-{ordinal:02}.tar.gz';dest=P/'archives'/name;dest.parent.mkdir(exist_ok=True)
  with dest.open('wb')as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,compresslevel=6,mtime=0)as gz,tarfile.open(fileobj=gz,mode='w')as tf:
   for key,member,path in chunk:
    b=path.read_bytes();assert(sha(b),len(b))==key,'Evidence changed during assembly'
    ti=tarfile.TarInfo(member);ti.size=len(b);ti.mode=0o644;ti.mtime=0;tf.addfile(ti,io.BytesIO(b))
  assert dest.stat().st_size<90*1024**2,('Archive exceeds publication bound',name)
  with tarfile.open(dest,'r:gz')as tf:
   members=tf.getmembers();assert[m.name for m in members]==[x[1]for x in chunk]
   for m,(key,member,path)in zip(members,chunk):
    assert m.isfile()and'..'not in PurePosixPath(m.name).parts
    b=tf.extractfile(m).read();assert(sha(b),len(b))==key
    objects[key[0]]={'archive':'archives/'+name,'member':member,'bytes':key[1]}
  archives.append({'path':'archives/'+name,'bytes':dest.stat().st_size,'sha256':sha(dest.read_bytes()),'members':len(chunk)})
  print(json.dumps({'archive':name,'members':len(chunk),'bytes':dest.stat().st_size}),flush=True)
direct=[O/'QUALIFICATION_README.md',O/'QUALIFICATION_STATUS.json',O/'QUALIFICATION_STATUS_REVIEW.json',O/'EXECUTION.json',O/'qualification/remaining-scenes-gallery/index.html',O/'qualification/remaining-scenes-gallery/originals.json',O/'qualification/display-cost-repair-equivalence-r7.json',O/'qualification/firefox-recording-capability-r2.json',O/'andon-cord-pull-r1/RETURN.md',O/'andon-cord-pull-r1/ACCEPTANCE.json',O/'andon-cord-pull-r1/CURRENT_COST_RETURN.md',O/'andon-cord-pull-r1/external-capture-packet/PACKET.json',O/'andon-cord-pull-r1/external-capture-packet/index.html',O/'andon-cord-pull-r1/retained-trace-controls/MANIFEST.json',O/'cost/admission-diagnostic-r3/diagnostic.json',O/'cost/admission-diagnostic-r3/ownership.json',O/'cost/measure-chromium-dpr1-r17/admission-scope-assessment.json']
direct.extend((O/'andon-cord-pull-r1/retained-trace-controls').glob('*.jpeg'))
gallery=read(O/'qualification/remaining-scenes-gallery/originals.json')
direct.extend(O/'qualification'/r['image']for r in gallery['images'])
direct.extend((O/'final-source').rglob('*'))
direct=[p for p in direct if p.is_file()]
for p in direct:
 dest=P/p.relative_to(O);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest);assert sha(dest.read_bytes())==sha(p.read_bytes())
manifest={'schema':'r0022-qualification-evidence-snapshot/v1','createdAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':BASE,'priorEvidenceCommit':PRIOR,'qualificationStatusSha256':sha((O/'QUALIFICATION_STATUS.json').read_bytes()),'originals':rows,'objects':objects,'archives':archives,'directCopies':[{'path':p.relative_to(O).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in direct],'scope':'Exact retained evidence, including failed and partial native observations. Collection or publication does not confer acceptance, delivery or issue closure. Duplicate streams resolve through immutable prior archives or production commit; unique streams are losslessly archived.','excluded':['Publication packages and publication-effect directories are excluded from their own recursive snapshot.','Python bytecode caches and the active native lock are excluded.','No personal profile, desktop or clipboard acquisition was used.']}
write(P/'payload-manifest.json',manifest)
print(json.dumps({'originalPaths':len(rows),'uniqueNewStreams':len(objects),'archives':len(archives),'archiveBytes':sum(a['bytes']for a in archives),'manifestSha256':sha((P/'payload-manifest.json').read_bytes())}))
