from pathlib import Path
import hashlib,json
O=Path(__file__).resolve().parent;P=O/'disposable-admission-r4';R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
review=read(P/'SOURCE_REPAIR_R5_REVIEW.json');assert review['status']=='APPROVED_FOR_SOURCE_INTEGRATION'
assert read(O/'browser-lease.json')['status']=='FREE'and not(O/'native-resource.lock').exists()
for name,digest in review['files'].items():assert sha(P/name)==digest,(name,'review drift')
assert sha(R/'real-sky/native-preview.mjs')=='eff32805165a7daa28be83baf0723a7f4f9049dbd55eb789962da899ce3f7537'
assert sha(R/'real-sky/native-host.mjs')=='53b75248e8c3849d4cb53396280d0ece8b2fae7e9b215aa7dae36f6f10eaaebe'
retained=O/'retained-source-r4';assert not retained.exists();retained.mkdir()
for name,donor in [('real-sky/native-preview.mjs','native-preview.loop-r5.source.mjs'),('real-sky/native-host.mjs','native-host.mask-r5.source.mjs')]:
 p=R/name;q=retained/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes());p.write_bytes((P/donor).read_bytes())
test=(P/'actual-mask-r5.test.mjs').read_text(encoding='utf-8')
test=test.replace("from 'file:///C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget/real-sky/","from '../../real-sky/")
test=test.replace("from './native-host.mask-r5.probe.mjs'","from '../../real-sky/native-host.mjs'")
test=test.replace("new URL('./native-host.mask-r5.source.mjs',import.meta.url)","new URL('../../real-sky/native-host.mjs',import.meta.url)")
p=R/'tests/real-sky/native-host-composition.test.mjs';q=retained/'native-host-composition.test.mjs';q.write_bytes(p.read_bytes());p.write_text(test,encoding='utf-8',newline='\n')
p=R/'tests/real-sky/native-lunar-cache.test.mjs';q=retained/'native-lunar-cache.test.mjs';q.write_bytes(p.read_bytes());s=p.read_text(encoding='utf-8')
s=s.replace('directions:g.directions.length,bytes:','directions:g.directions.length,vectors:g.vectors.filter(Boolean).length,finiteVectors:g.vectors.filter(Boolean).every(v=>Array.isArray(v)&&v.length===3&&v.every(Number.isFinite)),bytes:')
s=s.replace('assert(r.directions<=4761);','assert(r.directions<=4761&&r.vectors<=4761&&r.finiteVectors);')
p.write_text(s,encoding='utf-8',newline='\n')
# Keep the regression oracle on the unchanged complete sampler, not on the
# optimized function itself after integration.
s=(P/'verify-loop-component-r5.mjs').read_text(encoding='utf-8')
start=s.index("const R=");end=s.index("const snapshot=")
imports='''const owner=new URL('../../real-sky/native-preview.mjs',import.meta.url);
const sha=v=>crypto.createHash('sha256').update(v).digest('hex'),bytes=v=>Buffer.from(v.buffer,v.byteOffset,v.byteLength);
const reference=await import(owner),source=fs.readFileSync(owner,'utf8').replace(/from '(\\.\\/[^']+)'/g,(_,v)=>'from '+JSON.stringify(new URL(v,owner).href));
const inspect='\\nexport const inspectCache=()=>[...lunarGeometryCache].map(([key,g])=>({key,nodeCount:g.directions.length,vectorCount:g.vectors.filter(Boolean).length,finiteVectors:g.vectors.filter(Boolean).every(v=>Array.isArray(v)&&v.length===3&&v.every(Number.isFinite)),typedBytes:Object.values(g).filter(ArrayBuffer.isView).reduce((n,v)=>n+v.byteLength,0)}));';
const load=s=>import('data:text/javascript;base64,'+Buffer.from(s+inspect).toString('base64'));
const candidate=await load(source);
const {nativeJob}=await import('../../real-sky/native-contract.mjs'),{physicalSkyState}=await import('../../real-sky/core/src/sky-state.mjs');
const oracle=(raster,view,residual,gx,gy)=>reference.nativeSkyPresentation({...raster,lunarBackgroundLinear:reference.nativeLunarAtmosphereField(raster.physicalState,raster.atmosphere,view,residual,gx,gy)},view);
'''
s=s[:start]+imports+s[end:]
s=s.replace('reference.nativeLunarNightPresentation(f.raster,f.view,residual,41,67)','oracle(f.raster,f.view,residual,41,67)')
s=s.replace('for(const m of [reference,candidate])try{m.nativeLunarNightPresentation','for(const m of [{nativeLunarNightPresentation:oracle},candidate])try{m.nativeLunarNightPresentation')
s=s[:s.index('const record=')]+"console.log(JSON.stringify({componentCases:rows.length,negativeCases:bad.length,killedMutations:killed,cache:inventory}));\n"
(R/'tests/real-sky/native-lunar-boundaries.test.mjs').write_text(s,encoding='utf-8',newline='\n')
p=R/'docs/real-sky/LUNAR_DISPLAY.md';q=retained/'LUNAR_DISPLAY.md';q.write_bytes(p.read_bytes());s=p.read_text(encoding='utf-8')
s=s.replace('directions, solid angles and interpolation coordinates, never physical samples,','directions, their finite three-component vectors, solid angles and interpolation\ncoordinates, never physical samples,')
s=s.replace('Each call still samples the current physical model.','Each call still validates the current physical model and calls its unchanged\nexported lunar luminance and cloud-transmission functions. No scattering\nequation or calibrated constant is duplicated in the display owner.')
s=s.replace('Both caches are included in the scoped resource observation.','The geometry and encoder caches are included in the scoped resource observation.\nThe host also retains the last published solar-obstruction URL. It reuses that\nURL only when captured cloud alpha and row support match exactly, and clears it\nwith the previous presentation. This avoids identical PNG encoding; changed\nalpha still reaches the original mask producer before publication.')
p.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps({'preview':sha(R/'real-sky/native-preview.mjs'),'host':sha(R/'real-sky/native-host.mjs'),'status':'AUTHORED_ONLY_BUILD_PENDING'}))
