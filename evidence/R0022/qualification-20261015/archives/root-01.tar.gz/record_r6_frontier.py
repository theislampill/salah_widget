from pathlib import Path
import datetime,hashlib,json
O=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
p=O/'EXECUTION.json';old=p.read_bytes();q=O/'frontier-history'/f'{hashlib.sha256(old).hexdigest()}.json'
if not q.exists():q.write_bytes(old)
v=json.loads(old);runtime=read(O/'selected-r6-recovery-r1/RUNTIME.json')['treeSha256']
v['ownerDisplayGate']['sourceState']='Selected-r6-recovery-r1 runtime '+runtime+'; fixedapprovedH1unchanged. IndependentR6hostsourceintegrationapproved.2canonicalbuildsexact/190native tests+gain/consumers/V1/costcontrolsPASS. FirstbuildOSError22retained; completecanonicalrecoveryverified. Newnativecostpending.'
v['continuation'].update(atUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),runtime=runtime,selectedSource='selected-r6-recovery-r1/SOURCE.json',sourceFrontier='R6 sourceapproved/integrated/generated. Review '+sha(O/'disposable-admission-r6/SOURCE_REPAIR_R6_REVIEW.json')+'; setup packet R17 '+sha(O/'cost/PREMEASUREMENT_PINS_R17.json')+'. R16costcontrolledfailure retained; priornativepixelskeep originalidentities.')
v['next']='Independent R17 setup-only packet review, then actual C1 setup and independent currentness/input/observer review before unchangedbudget activation and16slot nativeAdmission comparison. Otherfivecostscopes pending; no merge/closuregate.'
p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8');print(sha(p))
