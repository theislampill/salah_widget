from pathlib import Path
import datetime,hashlib,json,subprocess
O=Path(__file__).resolve().parent;P=O/'disposable-admission-r6';R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,v):
 with p.open('x',encoding='utf-8')as f:f.write(json.dumps(v,indent=2)+'\n')
assert read(O/'browser-lease.json')['status']=='FREE'and not(O/'native-resource.lock').exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='fc8d13338f9274a768580cda5a805492f80c510d'
assert sha(P/'SOURCE_REPAIR_R6_PROPOSAL.json')=='7ece4be8b380c424a4aec82ba4a4055fb56bf28e5226a542f4f9c1ac2ce0001e'
assert sha(P/'native-host-r6.mjs')=='da14d0de3e0ae3ac814bcf810d4c08a8416de6fc8d0e2737b95584257810e57e'
proposal=read(P/'SOURCE_REPAIR_R6_PROPOSAL.json')
for path,digest in proposal['preimage'].items():assert sha(R/path)==digest
for f in proposal['tests']:assert sha(P/f['path'])==f['sha256']
save(P/'SOURCE_REPAIR_R6_REVIEW.json',{'schema':'r0022-source-integration-review/v1','status':'APPROVED_FOR_SOURCE_INTEGRATION','reviewer':'/root/r0022_independent_review','recordedBy':'/root','provenance':'Transcription of actual independent reviewer FINAL_ANSWER; no signature/formal lifecycle receipt claimed','recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'proposalSha256':sha(P/'SOURCE_REPAIR_R6_PROPOSAL.json'),'hostSha256':sha(P/'native-host-r6.mjs'),'previewSha256':sha(R/'real-sky/native-preview.mjs'),'verdict':'Exact interval reuse and single private destination preserve oracle bytes, validation/overflow, raw inputs, regional updates/solar-mask ownership and final publication fences. All19focusedtests independently executed; retained physical/H1 full689000byte outputs independently reproduced against oracle on pinnedNode22.','next':'One fresh affected native admission comparison warranted after canonical build/fresh fixtures/actual setup review; unchangedbudget,notnoise retry.','limits':'R16 controlled failure retained; otherfivecostscopes and fullscopeacceptance remainpending; no performancePASS.'})
retained=O/'retained-source-r5';retained.mkdir(exist_ok=False)
for name in ['real-sky/native-host.mjs','tests/real-sky/native-host-composition.test.mjs','docs/real-sky/LUNAR_DISPLAY.md']:
 p=R/name;q=retained/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
(R/'real-sky/native-host.mjs').write_bytes((P/'native-host-r6.mjs').read_bytes())
for donor,target in [('native-host-composition.test.mjs','native-host-composition.test.mjs'),('encoder-streams.test.mjs','native-host-streams.test.mjs')]:
 s=(P/donor).read_text(encoding='utf-8')
 s=s.replace("'file:///C:/Users/theis/.codex/work-products/r0022-execution-20261015/disposable-admission-r6/native-host-r6-testable.mjs'","'../../real-sky/native-host.mjs'")
 s=s.replace("'file:///C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget/real-sky/","'../../real-sky/")
 s=s.replace("'./native-host-r6-testable.mjs'","'../../real-sky/native-host.mjs'").replace("'./native-host-r6.mjs'","'../../real-sky/native-host.mjs'")
 assert 'file:///'not in s and 'r6-testable'not in s
 (R/'tests/real-sky'/target).write_text(s,encoding='utf-8',newline='\n')
p=R/'docs/real-sky/LUNAR_DISPLAY.md';s=p.read_text(encoding='utf-8');anchor='codes. The geometry and encoder caches are included in the scoped resource observation.'
assert s.count(anchor)==1
s=s.replace(anchor,'codes. Within one encoding call, a preceding RGB code is reused only while\nthe current value remains in that exact oracle interval. The composed prefix\nand untouched raw tail write into one private final RGBA buffer; validation\nand the final publication fence precede visible output. This removes bounded\ntemporary encoding copies without caching pixels or physical light.\nThe geometry and encoder caches are included in the scoped resource observation.')
p.write_text(s,encoding='utf-8',newline='\n')
s=(O/'build_performance_repair_r5.py').read_text(encoding='utf-8').replace('selected-r5','selected-r6').replace('09789327a637e5af9dec4ef90c02cf3f24650ff2ef9c9201b5552b019b17fc0e','da14d0de3e0ae3ac814bcf810d4c08a8416de6fc8d0e2737b95584257810e57e')
(O/'build_performance_repair_r6.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps({'review':sha(P/'SOURCE_REPAIR_R6_REVIEW.json'),'host':sha(R/'real-sky/native-host.mjs'),'preview':sha(R/'real-sky/native-preview.mjs'),'state':'AUTHORED_ONLY_BUILD_PENDING'}))
