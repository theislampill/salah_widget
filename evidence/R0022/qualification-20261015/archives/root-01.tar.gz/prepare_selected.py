from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,sys
O=Path(__file__).resolve().parent
R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget')
D=O/'selected-r1';D.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
assert json.loads((O/'decision/OWNER_ACCEPTANCE.json').read_bytes())['selected']=='H1'
assert json.loads((O/'browser-lease.json').read_bytes())['status']=='FREE'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='fc8d13338f9274a768580cda5a805492f80c510d'
source=Path('C:/Users/theis/Documents/Codex/salah-rlgwo-execution-20261009/integration/r0022-balance-test-join-r1/test-workspace/tests/r0022-baseline-balance.cjs')
target=R/'tests/r0022-baseline-balance.cjs'
(D/'baseline-balance-before.cjs').write_bytes(target.read_bytes())
target.write_bytes(source.read_bytes())
save(D/'gain-fixture-intake.json',{'source':str(source),'sha256':sha(source),'previousSha256':sha(D/'baseline-balance-before.cjs'),'scope':'Previously independently accepted actual-consumer assertion repair; final selected source still tested below.'})
node='C:/workspace/ai/cp9-integration-20261005/toolchain/node-v22.16.0-win-x64/node.exe'
commands=[('build-1.log',[sys.executable,'-B','tools/build_native.py']),('v1.log',[sys.executable,'-B','tools/verify_v1.py']),('gain.log',[node,'tests/r0022-baseline-balance.cjs']),('lunar-consumers.log',[node,'tests/r0022-lunar-consumers.cjs','--cp8-snapshot-only']),('display-tests.log',[node,'--test','tests/real-sky/native-lunar-display.test.mjs','tests/real-sky/native-preview.test.mjs','tests/real-sky/native-first-paint.test.mjs','tests/real-sky/native-preview-host.test.mjs','tests/real-sky/native-composition.test.mjs','tests/real-sky/native-lifecycle.test.mjs'])]
results=[]
for name,cmd in commands:
 with (D/name).open('wb')as f:p=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 results.append({'log':name,'command':cmd,'exitCode':p.returncode})
 save(D/'checks.json',results)
 if p.returncode:print(json.dumps(results));raise SystemExit(p.returncode)
spec=importlib.util.spec_from_file_location('identity',R/'tools/cp9/runtime_identity.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
first=m.runtime_identity(R)
with (D/'build-2.log').open('wb')as f:subprocess.run([sys.executable,'-B','tools/build_native.py'],cwd=R,stdout=f,stderr=subprocess.STDOUT,check=True)
assert m.runtime_identity(R)==first
base=json.loads((O/'comparison/BASE_RUNTIME.json').read_bytes())
changed=[p for p in base['files']if base['files'][p]!=first['files'][p]]
assert set(changed)=={'index.html','offline.html','real-sky/native-sky.js','real-sky/native-preview.mjs','real-sky/native-host.mjs'}
save(D/'RUNTIME.json',first)
save(D/'SOURCE.json',{'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runtime':first['treeSha256'],'changed':changed,'protectedUnchanged':len(base['files'])-len(changed),'buildDeterministic':True,'contract':'R0022-L1-H1-K003-H020-v1','checks':results})
print(json.dumps({'runtime':first['treeSha256'],'changed':changed,'checks':results}))
