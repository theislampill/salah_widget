from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,zipfile
O=Path(__file__).resolve().parent;D=O/'qualification';C=O/'cost'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
at=datetime.now(timezone.utc).isoformat()
name='candidate-firefox-dpr2-clear-stages-selected-r4-fixture-r7'
report=read(D/name/'results.json');dispatch=read(D/(name+'-dispatch.json'));run=report['runs'][0]
assert report['nativeCleanup']=='CONTEXT_AND_BROWSER_CLOSE_RETURNED' and dispatch['ownedNativeCleanupEstablished']
assert read(O/'browser-lease.json')['status']=='FREE' and not(O/'native-resource.lock').exists()
stage={'schema':'r0022-root-stage-readback/v1','recordedAtUtc':at,'reportSha256':sha(D/name/'results.json'),'dispatchSha256':sha(D/(name+'-dispatch.json')),'qualification':run['final']['stageQualification'],'cleanup':report['nativeCleanup'],'runtimeUnchanged':dispatch['runtimeUnchanged'],'errors':report['errors'],'scope':'First/preview/refined observed field propagation; no ordinary timing or continuous pixel acceptance.'}
save(D/'r7-stage-readback.json',stage)
cost={'schema':'r0022-independent-review-transcription/v1','recordedBy':'root','reviewer':'/root/r0022_independent_review','recordedAtUtc':at,'actualReviewCarrier':'Reviewer messages and final return observed in this execution','rawSha256':sha(C/'measure-chromium-dpr1-r15/raw.json'),'verdict':'INCOMPLETE / INCONCLUSIVE_NOISE','checkedSlots':96,'untrimmedCalls':125948,'admission':{'baselineMedianP95Ms':[13.8,17.1],'candidateMedianP95Ms':[21.6,24.7],'limitsMs':[15.18,18.81],'baselineRoundMediansMs':[14.4,13.8,15.0,11.7],'candidateRoundMediansMs':[21.8,22.3,22.5,18.4],'baselineSpreadMs':3.3,'noiseLimitMs':2.76,'allRoundCandidateAboveBudget':True},'otherFiveScopes':'CONTROLLED and within fixed median/p95 budget','resources':'96 slots stable and quiescent; no new provider/network/worker/texture/callback ownership. Four admission readbacks per call on both sides. Actual geometry cache one entry/2856 directions/204708 typed bytes; encoder26624 bytes. Session observation, not total JS heap or indefinite growth proof.','limitations':['No cost PASS','No noise retry endorsed without actual correctable cause','R14 controlled failure retained','R4 exact-current profile is decision relevant']}
save(C/'independent-r15-result-review.json',cost)
archive=Path('C:/Users/theis/AppData/Local/ms-playwright/firefox-1522/firefox/omni.ja')
expected={'chrome/juggler/content/protocol/PageHandler.js':'be188cb57c1197d81bc0887a32f9ed831b1b91b955a4ace6e7a7cee81dd7a670','chrome/juggler/content/TargetRegistry.js':'b430c0f6a9f946eb2082c85948f19d19bbe9233124055562f3e79c45fb66a98e','chrome/juggler/content/protocol/Protocol.js':'20637fcc7138ec1f9a664bfa064a9cb440b72cf098e7582cb03ea0a4c2fa5c0f'}
assert sha(archive)=='963205a9d5775ae93084b2cc3916f8539af841041692e3376ada4e35a427e1b8'
members=[]
with zipfile.ZipFile(archive)as z:
 for name,digest in expected.items():
  data=z.read(name);assert hashlib.sha256(data).hexdigest()==digest
  members.append({'path':name,'sha256':digest,'bytes':len(data)})
driver=Path(dispatch['driver']['cli']).parent/'lib/coreBundle.js'
assert sha(driver)=='f74353fcb8e406756a70a6af0dfc4a5069acd577e35ec9d923ccf36ac009c2f5'
capability={'schema':'r0022-firefox-recording-capability/v1','recordedAtUtc':at,'independentReviewer':'/root/r0022_independent_review','reviewCarrier':'Actual reviewer current-source readback and final return; this file is root transcription with independently repeated hashes','archive':{'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive)},'members':members,'driver':{'path':str(driver),'sha256':sha(driver)},'lines':{'TargetRegistry.js':'780-806 native call/callback','Protocol.js':'726-731 data,deviceWidth,deviceHeight,timestamp','PageHandler.js':'336-357 distinct drawSnapshot screenshot','coreBundle.js':'43698-43707 forwards bytes and timestamp*1000'},'finding':'Installed Firefox native screencast surface exposes JPEG bytes/dimensions/time, without selected native backend/surface, committed paint epoch or a pre-JPEG association. Separate Page.screenshot drawSnapshot cannot replace or attribute unreadable original continuous watch frames.','nextDiscriminatingCapability':'An actual source/backend-to-frame association that identifies native surface/committed paint for the same returned frame bytes. No existing association command found in inspected exposed path.','retainedCounterevidence':'Original R0022 Firefox rain/retry/lifecycle pale or corrupt full-card frames; video and trace share producer and are not independent.','notEstablished':['Product versus native capture cause','Permanent Firefox unavailability','Full-scene temporal PASS'],'authority':'No browser SDK build, recorder substitution, frame filtering or blind replay is authorized by this record.'}
save(D/'firefox-recording-capability-r2.json',capability)
p=O/'EXECUTION.json';old=p.read_bytes();history=O/'frontier-history';history.mkdir(exist_ok=True);target=history/(hashlib.sha256(old).hexdigest()+'.json')
if not target.exists():target.write_bytes(old)
v=json.loads(old)
v['next']='Review and run one exact-current R4 admission CPU diagnostic after FREE lease. R15 retained noisy over-budget admission, no retry or cost PASS. R7 stage metadata returned; independently inspect original pixels. Resolve bounded admission cost; keep Firefox native surface-to-frame association gap explicit. No merge gate or closure claim.'
v['ownerDisplayGate']['sourceState']='Selected-r4 runtime aeb48299afebe391f205a435c7b5aaf8a34b3e1413dfabbac21756d02e8d3de5; fixed reviewed H1 unchanged. Original/raw equivalence and deterministic canonical build accepted. Cost incomplete.'
v['continuation'].update(atUtc=at,mandatoryCredit='Original16native gain/material slots and actual-source36gain retained. R6 exact ABA metadata accepted; observer initial-document repair independently proved. R7 first/preview/refined metadata returned without errors and awaited native closure; pixel review pending. Original pale Firefox continuous watch failures remain unresolved.',sourceFrontier='R4 source/build frozen; R15 C1 six-scope comparison INCOMPLETE due admission noise with every-round over-budget contrary result. F2 setup admitted but cost intentionally unexecuted. No noisy repeat spent. One R4 admission profile proposal awaiting review. Same reviewer retained; final owner exact-head/base merge and remaining ordinary visual acceptance reserved.')
save(p,v)
print(json.dumps({'stage':stage,'written':{str(p.relative_to(O)):sha(p)for p in [D/'r7-stage-readback.json',C/'independent-r15-result-review.json',D/'firefox-recording-capability-r2.json',O/'EXECUTION.json']}},indent=2))
