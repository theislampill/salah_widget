from pathlib import Path
import datetime,hashlib,json
O=Path(__file__).resolve().parent
R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget')
P=O/'disposable-admission-r6';P.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
assert json.loads((O/'browser-lease.json').read_bytes())['status']=='FREE'
assert not (O/'native-resource.lock').exists()
source=R/'real-sky/native-host.mjs'
assert sha(source)=='09789327a637e5af9dec4ef90c02cf3f24650ff2ef9c9201b5552b019b17fc0e'
s=source.read_text(encoding='utf-8');(P/'native-host-r5.mjs').write_bytes(source.read_bytes())
old="""export function encodeNativeDisplay(linear,exposure=12){
 if(!Number.isFinite(exposure)||exposure<0||exposure>100000)throw new RangeError('Invalid native display exposure');
 if(linear.length%3)throw new RangeError('RGB buffer required');"""
new="""export function encodeNativeDisplay(linear,exposure=12){
 const bytes=new Uint8ClampedArray(linear.length/3*4);
 return encodeNativeDisplayInto(linear,exposure,bytes);
}
// The destination remains private until composition passes its currentness
// fence. Encoding a joined prefix and raw tail avoids disposable RGBA copies.
export function encodeNativeDisplayInto(linear,exposure,bytes,offset=0){
 if(!Number.isFinite(exposure)||exposure<0||exposure>100000)throw new RangeError('Invalid native display exposure');
 if(linear.length%3)throw new RangeError('RGB buffer required');
 if(!(bytes instanceof Uint8ClampedArray)||!Number.isSafeInteger(offset)||offset<0||offset%4||offset+linear.length/3*4>bytes.length)throw new RangeError('Invalid native display destination');"""
assert s.count(old)==1;s=s.replace(old,new)
old=""" const {edges,scale,low,high}=nativeDisplayEncodeCache,bytes=new Uint8ClampedArray(linear.length/3*4);
 const code=y=>{if(y>=edges[255])return 255;const b=Math.min(low.length-1,Math.floor(y*scale));let lo=low[b],hi=high[b];while(hi-lo>1){const middle=(lo+hi)>>>1;if(y<edges[middle])hi=middle;else lo=middle;}return lo;};
 for(let i=0,j=0;i<linear.length;i+=3,j+=4){"""
new=""" const {edges,scale,low,high}=nativeDisplayEncodeCache;
 // Reuse only an exact oracle interval from this call's preceding pixel.
 // Exposure, input validity and every sharp transition still reach the same
 // code search. No physical value or prior frame is retained here.
 let previousR=0,previousG=0,previousB=0;
 const code=(y,previous)=>{if(y>=edges[previous]&&(previous===255||y<edges[previous+1]))return previous;if(y>=edges[255])return 255;const b=Math.min(low.length-1,Math.floor(y*scale));let lo=low[b],hi=high[b];while(hi-lo>1){const middle=(lo+hi)>>>1;if(y<edges[middle])hi=middle;else lo=middle;}return lo;};
 for(let i=0,j=offset;i<linear.length;i+=3,j+=4){"""
assert s.count(old)==1;s=s.replace(old,new)
old="""  bytes[j]=code(exposure*Math.max(0,r));
  bytes[j+1]=g===r?bytes[j]:code(exposure*Math.max(0,g));
  bytes[j+2]=b===r?bytes[j]:b===g?bytes[j+1]:code(exposure*Math.max(0,b));"""
new="""  bytes[j]=previousR=code(exposure*Math.max(0,r),previousR);
  bytes[j+1]=previousG=g===r?bytes[j]:code(exposure*Math.max(0,g),previousG);
  bytes[j+2]=previousB=b===r?bytes[j]:b===g?bytes[j+1]:code(exposure*Math.max(0,b),previousB);"""
assert s.count(old)==1;s=s.replace(old,new)
start=s.index('    const region=new ImageData(encodeNativeDisplay(')
end=s.index("    card.style.setProperty('--native-sun-cloud-mask'",start)
s=s[:start]+"""    const full=paintedFrame!==frame,bytes=new Uint8ClampedArray(325*(full?530:rows)*4);
    encodeNativeDisplayInto(joined.linear,frame.raster.effectiveExposure,bytes);
    const reuseSolarMask=previousSolarMask!==null&&previousPresentation?.rows===rows&&sameNativeCloudAlpha(previousPresentation.cloudRGBA,capture.cloudRGBA);
    const solarMask=reuseSolarMask?previousSolarMask:foreground.prepareSolarMask(capture.cloudRGBA,rows);
    if(full){
     // Preserve validation of the overwritten raw prefix. Encode the untouched
     // tail directly after the joined region in the private final framebuffer.
     const raw=frame.raster.linear,start=325*rows*3;
     if(raw.length!==325*530*3)throw new RangeError('Native frame dimensions');
     for(let i=0;i<start;i++)if(!Number.isFinite(raw[i]))throw new RangeError('Nonfinite native frame channel');
     encodeNativeDisplayInto(raw.subarray(start),frame.raster.effectiveExposure,bytes,325*rows*4);
    }
    const image=new ImageData(bytes,325,full?530:rows);
    if(!lifecycle.current(job,snapshot())){clear('superseded during composition');return;}
    ctx.putImageData(image,0,0);
"""+s[end:]
(P/'native-host-r6.mjs').write_text(s,encoding='utf-8',newline='\n')
testable=s.replace("from './", "from '"+(R/'real-sky').as_uri()+'/')
(P/'native-host-r6-testable.mjs').write_text(testable,encoding='utf-8',newline='\n')
for name in ['native-host-encoding.test.mjs','native-host-composition.test.mjs']:
 t=(R/'tests/real-sky'/name).read_text(encoding='utf-8')
 t=t.replace("'../../real-sky/native-host.mjs'",repr((P/'native-host-r6-testable.mjs').as_uri()))
 t=t.replace("'../../real-sky/",repr((R/'real-sky').as_uri()+'/')[0:-1])
 t=t.replace('encodeNativeDisplay,sameNativeCloudAlpha','encodeNativeDisplay,encodeNativeDisplayInto,sameNativeCloudAlpha')
 t=t.replace('  ImageData:class','  encodeNativeDisplayInto(a,E,b,offset){encoded.push(a.length);return encodeNativeDisplayInto(a,E,b,offset);},\n  ImageData:class')
 (P/name).write_text(t,encoding='utf-8',newline='\n')
save(P/'PREIMAGE.json',{'sourceSha256':sha(source),'candidateSha256':sha(P/'native-host-r6.mjs'),'testableSha256':sha(P/'native-host-r6-testable.mjs'),'scope':'Disposable host encoding only; no integration or performance acceptance.'})
# Preserve the actual independent result before updating the local frontier.
save(O/'cost/independent-r16-result-review.json',{'schema':'r0022-independent-result-transcription/v1','reviewer':'/root/r0022_independent_review','source':'Actual reviewer message and final return in this conversation','rawSha256':'7fe77c96a3d556bf5883d941c5d8a175b353c2416e4be87188da284048568837','status':'CONTROLLED_FAIL_SCOPE','allSlots':16,'allCalls':2306,'baselineMedianMs':14.5,'baselineP95Ms':16.80000001192093,'candidateMedianMs':18.69999998807907,'candidateP95Ms':23.599999994039536,'medianLimitMs':15.95,'p95LimitMs':18.48000001311302,'roundMedianSpreadMs':.14999999105930328,'noiseLimitMs':2.9,'resourceFinding':'Inventories stable within and between slots; candidate3 readbacks/call, baseline4; cleanup established/errors0/active transport0','noNoiseRetry':True,'A03':'INCOMPLETE','disposableRecommendations':['Per-call exact encoder interval reuse','Direct encoding into final private RGBA buffer'],'authority':'No integration/performance/closure acceptance from recommendations.'})
p=O/'EXECUTION.json';old=p.read_bytes();(O/'frontier-history'/f'{hashlib.sha256(old).hexdigest()}.json').write_bytes(old)
v=json.loads(old);v['retainedDispositions']['A03']='R16 selected-r5 admission CONTROLLED FAIL:18.7/23.6ms vs15.95/18.48ms,16slots2306untrimmedcalls. No noise retry. Five other scopes unmeasured inR16; priorR4passes not relabelled. R14/R15 failures/noise retained. FullA03 incomplete.'
v['next']='Disposable R6 exact host encoder and private destination tests, independent review before any integration. No native replay pending new source evidence. Preserve original Firefox watch failure and missing native surface/frame association.'
v['continuation'].update(atUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),runtime='2e8ee64f0c0ae612593336a744b0c88d1cb5a186cc453b65178da581149ce07f',selectedSource='selected-r5/SOURCE.json',cost=v['retainedDispositions']['A03'])
save(p,v)
print(json.dumps({'disposable':str(P),'source':sha(P/'native-host-r6.mjs'),'productionUnchanged':sha(source),'frontier':sha(p)}))
