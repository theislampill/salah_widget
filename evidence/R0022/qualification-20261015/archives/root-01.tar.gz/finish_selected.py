from pathlib import Path
import datetime,importlib.util,json,subprocess,sys
O=Path(__file__).resolve().parent;R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget');D=O/'selected-r1'
node='C:/workspace/ai/cp9-integration-20261005/toolchain/node-v22.16.0-win-x64/node.exe'
spec=importlib.util.spec_from_file_location('identity',R/'tools/cp9/runtime_identity.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
first=m.runtime_identity(R)
cmds=[('lunar-consumers.log',[node,'tests/r0022-lunar-consumers.cjs','--cp8-snapshot-only']),('qualification-tests.log',[node,'--test',*[str(p)for p in (R/'tests/real-sky').glob('native-*.test.mjs')]]),('build-2.log',[sys.executable,'-B','tools/build_native.py']),('v1-r2.log',[sys.executable,'-B','tools/verify_v1.py'])]
results=[]
for name,cmd in cmds:
 with (D/name).open('xb')as f:p=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 results.append({'log':name,'exitCode':p.returncode})
 if p.returncode:print(json.dumps(results));raise SystemExit(p.returncode)
assert m.runtime_identity(R)==first,'canonical build was not deterministic'
base=json.loads((O/'comparison/BASE_RUNTIME.json').read_bytes());changed=[p for p in base['files']if base['files'][p]!=first['files'][p]]
assert set(changed)=={'index.html','offline.html','real-sky/native-sky.js','real-sky/native-preview.mjs','real-sky/native-host.mjs'}
for name,value in [('RUNTIME.json',first),('SOURCE.json',{'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runtime':first['treeSha256'],'changed':changed,'protectedUnchanged':len(base['files'])-len(changed),'buildDeterministic':True,'contract':'R0022-L1-H1-K003-H020-v1','checks':results,'gain':'gain-r2.log','retainedFailure':'gain.log:31pass4fail; obsolete inline consumer assumption corrected to actual bound host/worker'})]:
 (D/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'runtime':first['treeSha256'],'checks':results,'changed':changed}))
