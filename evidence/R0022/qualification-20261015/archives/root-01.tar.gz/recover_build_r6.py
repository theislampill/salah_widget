from pathlib import Path
import datetime,hashlib,json,subprocess,sys
O=Path(__file__).resolve().parent;R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((O/'browser-lease.json').read_bytes())['status']=='FREE'and not(O/'native-resource.lock').exists()
record={'schema':'r0022-bounded-build-recovery/v1','atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'failedLogSha256':sha(O/'selected-r6/build-1.log'),'failure':'Canonical builder OSError22 opening existing offline.html for second generated Moon injection write; source build already began. No successful runtime claimed.','partialOfflineSha256':sha(R/'offline.html'),'observation':'Exact existing regular file was readable, unchanged and openable with write-only handle without writing after failure. No symlink/reparse point or active native lease. Cause is unresolved; no builder mutation.','action':'One complete canonical regeneration and deterministic second build, retaining original failure directory. Ordinary owner-authorised generated-output recovery.'}
(O/'selected-r6/recovery-decision.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
s=(O/'build_performance_repair_r6.py').read_text(encoding='utf-8').replace('selected-r6','selected-r6-recovery-r1')
p=O/'build_performance_repair_r6_recovery_r1.py';p.write_text(s,encoding='utf-8',newline='\n')
subprocess.run([sys.executable,'-I','-S','-B',str(p)],check=True)
