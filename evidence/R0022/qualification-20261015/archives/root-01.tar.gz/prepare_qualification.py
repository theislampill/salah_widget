from pathlib import Path
import hashlib,importlib.util,json,shutil,subprocess
O=Path(__file__).resolve().parent;R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget');D=O/'qualification';D.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
source=O/'ordinary/capture_ordinary.py';assert sha(source)=='29cb0f80e57948be323ccf00d1c9c116c870d75687bf3306e6c721650d800e27'
s=source.read_text(encoding='utf-8')
def replace(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
replace("if a.scene=='dawn':stamp='2026-09-25T10:40:00Z'", "if a.scene=='dawn':stamp='2026-09-25T10:40:00Z'\n if a.anchor:stamp=a.anchor\n viewport=dict(zip(['width','height'],map(int,a.viewport.split('x'))))")
replace("hd=11+(datetime(int(year),int(month),int(day))-datetime(2026,9,24)).days\n   if not 1<=hd<=30:raise ValueError('Calendar fixture outside bounded capture dates')\n   v['data']['date']['hijri'].update(day=str(hd),month={'number':4,'en':'Rabi al-Thani'},year='1448')", "offset=(datetime(int(year),int(month),int(day))-datetime(2026,9,24)).days\n   month_delta,day_index=divmod(10+offset,30);hd=day_index+1;hm=4+month_delta\n   assert 1<=hm<=12\n   v['data']['date']['hijri'].update(day=str(hd),month={'number':hm,'en':'Synthetic civil fixture'},year='1448')")
assert s.count("{'width':390,'height':600}")==2
s=s.replace("{'width':390,'height':600}",'viewport')
replace("'scope':'Isolated browser/profile; fixed accepted Orlando substitute; wall-clock progresses at real 1x.","'scope':'Isolated browser/profile; declared Orlando scene; wall-clock progresses at real 1x.")
replace("'syntheticHijri':'civil fixture: 2026-09-24 = 1448-04-11; not a local religious-calendar assertion'", "'syntheticHijri':'bounded 30-day synthetic civil months anchored at 2026-09-24 = 1448-04-11; not a local religious-calendar assertion'")
replace("p.add_argument('--layers',action='store_true'", "p.add_argument('--anchor');p.add_argument('--viewport',default='375x800')\n p.add_argument('--layers',action='store_true'")
replace("firstPaint:window.SalahFirstPaint?.preparedAt,moon:", "firstPaint:{preparedAt:window.SalahFirstPaint?.preparedAt,snapshot:window.SalahFirstPaint?.snapshot,physical:window.SalahFirstPaint?.value?.raster?.physicalState,lunar:window.SalahFirstPaint?.value?.raster?.lunarDisplayPresentation},display:window.__r0022DisplayRead?.(),moon:")
display=r'''()=>{
 const frame=window.realSkyFrame?.(),r=frame?.raster,preview=window.SalahSkyPreview?.frame;
 const stats=a=>{if(!a)return null;let positive=0,sum=0,max=0,nonfinite=0;for(const v of a){if(!Number.isFinite(v))nonfinite++;if(v>0)positive++;sum+=v;max=Math.max(max,v);}return {length:a.length,positive,sum,max,nonfinite};};
 const per=r=>r?{physical:r.physicalState,exposure:r.effectiveExposure,lunar:r.lunarDisplayPresentation??null,raw:stats(r.lunarBackgroundLinear),mapped:stats(r.lunarNightDisplayLinear),rawSky:stats(r.physicalSkyBackgroundLinear),stellar:stats(r.stellarLinear),diffuse:stats(r.diffuseLinear),drawn:r.drawn,utc:frame?.utcMs}:null;
 return {refined:per(r),preview:per(preview?.raster),previewKeys:preview?Object.keys(preview):null};
}'''
replace("if a.trace:await ctx.add_init_script(TRACE)", "await ctx.add_init_script('window.__r0022DisplayRead='+"+repr(display)+")\n  if a.trace:await ctx.add_init_script(TRACE)")
(D/'capture_qualified.py').write_text(s,encoding='utf-8')
# A served current-main baseline with every runtime byte checked; no worktree,
# product configuration, original evidence or startup-owner file is changed.
B=D/'baseline-current';B.mkdir()
base=json.loads((O/'comparison/BASE_RUNTIME.json').read_bytes());selected=json.loads((O/'selected-r1/RUNTIME.json').read_bytes())
for rel,want in base['files'].items():
 p=B/rel;p.parent.mkdir(parents=True,exist_ok=True)
 if want==selected['files'][rel]:shutil.copyfile(R/rel,p)
 else:p.write_bytes(subprocess.check_output(['git','show','fc8d13338f9274a768580cda5a805492f80c510d:'+rel],cwd=R))
 assert sha(p)==want['sha256'],rel
save(D/'baseline-runtime.json',base)
cases=[
 {'name':'clear','scene':'clear','anchor':'2026-09-25T02:00:00Z','physical':'bright eligible Moon'},
 {'name':'cloud','scene':'partial','anchor':'2026-09-25T02:00:00Z','physical':'bright Moon/cloud35'},
 {'name':'rain','scene':'rain','anchor':'2026-09-25T02:00:00Z','physical':'bright Moon/cloud65/labelled current model rain2mm'},
 {'name':'below','scene':'clear','anchor':'2026-09-18T07:00:00Z','physical':'Sun-51.27 Moon-41.04 fraction.447'},
 {'name':'near-new','scene':'clear','anchor':'2026-09-11T23:35:00Z','physical':'real low-illumination ~.009, Moon above and Sun just below horizon; retain legitimate weak astronomical scattering'},
 {'name':'deep-dawn','scene':'dawn','anchor':'2026-09-25T10:00:00Z','physical':'Sun-17.36 Moon+.764, transition shoulder'},
 {'name':'dawn-below','scene':'dawn','anchor':'2026-09-25T11:15:00Z','physical':'Sun-.947 below horizon'},
 {'name':'dawn-above','scene':'dawn','anchor':'2026-09-25T11:40:00Z','physical':'Sun+4.537 above horizon'},
 {'name':'day','scene':'day','anchor':'2026-09-25T17:00:00Z','physical':'Sun+60.12 daylight'}]
save(D/'SCENES.json',{'schema':'r0022-selected-native-scenes/v1','fixedContract':'R0022-L1-H1-K003-H020-v1','ordinary':'real1x, original unstripped PNG/native video/trace; no simulation phase or time overrides','cases':cases,'engines':['chromium','firefox'],'dprPolicy':'DPR1 Chromium andDPR2Firefox across scenes; oppositeDPR clear coverage separately. Exact325x530card,375x800constrained viewport;1100x900 desktop clear separately.','recovery':'Separate slow/missing asset and native settings A-B-A/seek/profile controls after ordinary acquisition.','adapter':{'path':str(D/'capture_qualified.py'),'sha256':sha(D/'capture_qualified.py')},'parentAdapter':sha(source),'baseline':base['treeSha256'],'candidate':selected['treeSha256']})
print(json.dumps({'adapter':sha(D/'capture_qualified.py'),'baseline':base['treeSha256'],'candidate':selected['treeSha256'],'scenes':len(cases)}))
