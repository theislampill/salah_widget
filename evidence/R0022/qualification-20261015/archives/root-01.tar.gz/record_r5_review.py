from pathlib import Path
import datetime,hashlib,json
O=Path(__file__).resolve().parent;P=O/'disposable-admission-r4'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
proposal=P/'SOURCE_REPAIR_R5_PROPOSAL.json'
assert sha(proposal)=='75f91107777b7e4da5121ac490b212f28b95b5a4abb698254ee3e28027a832f4'
p=json.loads(proposal.read_bytes())
for name,digest in p['files'].items():assert sha(P/name)==digest
record={'schema':'r0022-independent-review-transcription/v1','recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'recorder':'/root','reviewer':'/root/r0022_independent_review','carrier':'Actual collaboration FINAL_ANSWER received by root after compaction; root transcription, not a reviewer-authored signature','status':'APPROVED_FOR_SOURCE_INTEGRATION','proposalSha256':sha(proposal),'files':p['files'],'findings':['No blocking source finding.','10 host tests;12 component cases;17 rejection controls;two killed mutants;37 equivalence cases;eight negatives;actual1008-source catalogue/diffuse oracle independently verified.','Additional middle-alpha,changed-row support and invalid-capture controls verified.','Original Node22 reproduces retained records exactly.Node24 preserves candidate/reference equality;cross-engine physical hashes differ.'],'next':'Canonical build and fresh inventory/setup review;admission-only batch may retain all four ABBA rounds and unchanged thresholds.','limits':['No timing,A03,six-row or closure acceptance.','R15 noisy contrary cost and prior admission failures retained.','Firefox original-watch defects remain unresolved.']}
out=P/'SOURCE_REPAIR_R5_REVIEW.json';assert not out.exists();out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(sha(out))
