# Native sky integration

The selected R0022 lunar display candidate is based on production
`fc8d13338f9274a768580cda5a805492f80c510d`. Its two authored display owners share
the fixed H1 lunar shoulder through existing first/preview/refined callers.
The raw physical fields, catalogue/diffuse inputs, frozen V1 and V5 material
remain unchanged. No startup draft or numerical vendor/core patch is imported.
See [LUNAR_DISPLAY.md](LUNAR_DISPLAY.md) for units, exact formula, owner visual
acceptance and the still-open qualification/delivery boundary.

## Historical CP9 integration candidate

This historical intake integrated the supplied cumulative CP1–CP9 real-sky programme onto
`main` **fd2972ba64225fe9d6848e92497e6d0ed20ea624** (tree
`c5382ee6cb32e71992da963f56b00c2eaa091d1c`). The following records describe that
Draft PR intake and do not confer current release or merge approval.

## Source reconstruction

The attached `Salah_Real_Sky_Checkpoint_9.zip` is 218,870,451 bytes, SHA-256
`8d094b138c5970eae087a96458bcaefd8c988a12b2abd1fbc0c1b34b9f0c9bff`.
CRC, all 2,230 manifest-listed payloads, all 162 native baseline entries and the
213-file authoritative `widget/` inventory verified locally. Its canonical
runtime-tree SHA-256 is
`2ebde007ff96fa1b69e9df97f785d41bcf6c38437342913a2d10bed128cdd45b`.

The archive records native commit `205750350c64b77ebdc3ebcadcc39a6eb949994b`,
parent CP8.3 archive `a056d3789cb614355cc27af286907add231293ba42b2288894cdd3edca8d29a3`,
and scientific CP7.6 archive `f30470a68d02e47d83e5fd0d063a5320936802161e5d2b9ba701ba48d72f5e45`.
These are **archive provenance**, not an assertion of independent ancestry.
PR #38 was not fetched, changed or used as an implementation donor; the
implementation inputs are current main and the supplied CP9 archive. Locally
available archive-pinned historical commits were read only as test controls,
as distinguished in the qualification report.

There are two meaningful deltas:

1. Current main → CP9's native baseline: 22 of main's 34 files are byte-identical;
   twelve differ; no main-only file is missing from the archive. Changes cover
   admission/generation ownership, accepted clock/calendar, weather evidence,
   cloud continuity, native lunar fallback/opacity, configuration and installer
   safeguards, builder recovery and their regression fixtures. These native
   prerequisites are reconstructed in their own commit.
2. Native baseline → cumulative CP9 product: 51 additions and eleven changed
   files, comprising generated index integration and ten fixture adaptations.
   The real catalogue, registered diffuse source, physical transport, currentness,
   worker-failure policy, composition and asset lifecycle are the new runtime.

Main's resolved-latitude solar calculation and 325×530 embed geometry are retained.
There is no newer main-only semantic delta to arbitrate at intake. The existing
main documentation/plans are retained and amended; historical galleries,
receipts, reconciliation donor and checkpoint copies are not installed as product.

The native source baseline's WEATHER fixture omitted `_pbrFailed`: 129 failures
were reproduced before carrying forward CP9's explicit declaration extraction.
That repair changes fixture coverage, not product assertions. Four inherited TODO
placeholders remain TODO and are not qualification evidence.

## DAG execution

Starting state: eleven historically closed findings, one scientific boundary,
and three mandatory OPEN nodes. N001 and N002 are independently ready; N003's
final acceptance depends on both. Historical PASS does not qualify changed bytes.
The per-node ledger and fresh command receipts record the final dispositions.

See [qualification and remaining gates](QUALIFICATION.md), the
[current DAG ledger](DAG_LEDGER.json), and the [evidence index](evidence/README.md).
The runtime stays PARTIAL. No archive receipt has been promoted to current PASS.
[`CANDIDATE_SOURCE_IDENTITY.json`](CANDIDATE_SOURCE_IDENTITY.json) inventories the
final authored inputs and test/tool sources separately from the served runtime.

## Ownership and future Moon package

Native authored HTML/CSS, lunar geometry/orientation, phase and terminator,
material/PBR, Earthshine and textures live in `src/native/index.html`; native
configuration and builder sources live beside it. `tools/build_native.py` owns
the deterministic root entry, worker/bundle/CSS/data and offline expansion.
`real-sky/native-*.mjs` and `native-host-hooks.js` own the integration boundaries.
`vendor/real-sky` is an immutable scientific oracle and its test inputs; copied
`real-sky/core` is generated. Physical Moon illumination/occultation stays distinct
from the enlarged native calendar Moon. Composition is owned by
`real-sky/native-composition.mjs`. The forthcoming Moon-PBR donor should be
reconciled at those authored owners, then regenerate outputs and rerun lunar,
material, opacity, composition, currentness and performance controls.

More specifically: `moonNow()` / `renderMoon()` own the native calendar geometry
and phase; `renderMoonPBR()` / `_prepMoonPBR()` / `MOON_ALBEDO` / `MOON_NORMAL`
own the current material, Earthshine, terrain/normal textures and display mapping.
`native-host-hooks.js` exposes the native lunar surface without replacing its
owner. `native-contract.mjs` owns its calendar cutout; `native-composition.mjs`
owns foreground combination and `native-encoding.mjs` the exact shared encoding.
Physical lunar sky illumination/occultation is retained in the scientific
`sky-state` / `physical-sky-renderer` owners, not inferred from the enlarged
calendar-disc position. Tests in `tests/r0022*`, `tests/real-sky/`, and the material
and composition probes in `tools/cp9/` are the affected qualification surfaces.

The 186 retained scientific files include upstream inputs, provenance and older
data fixtures consumed by the unchanged scientific suites. They are build/test
inputs, not another deployed viewer. Root bundles and `offline.html` intentionally
duplicate generated data for the two delivery forms; there is no copied `widget/`
tree, archive gallery, reconciliation donor or earlier checkpoint archive in Git.

## Acceptance boundary

No newly written status file supplies completion by itself. N001 retains the
250 ms maximum heartbeat/dialog budget across every loaded trial. N002 retains
the 30,000 ms accepted-UTC fence and the four-rate availability target. N003
requires actual platform/entry/lifecycle/provider evidence and rejects stale,
missing, duplicated or fixture-mislabelled records. Independent review remains
required before merge/release. This task ends with a Draft PR, without merging.
