async()=>{
 const bytes=async a=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new Uint8Array(a.buffer,a.byteOffset,a.byteLength))),v=>v.toString(16).padStart(2,'0')).join('');
 const qa=qaState(),raw=window.__r0022CostProbe?.raw,binding=window.__r0022CostProbe?.binding;
 const weather=(0,eval)('typeof selectedWeather==="function"?selectedWeather():weather');
 const commonWeather=weather?Object.fromEntries(['code','temp','rh','dew','vis','wind','windDir','gust','cloud','cloudLow','cloudMid','cloudHigh','precip'].map(k=>[k,weather[k]??null])):null;
 const native=window.SalahNativeSkyHost?.capture();
 const arrays={};if(raw)for(const [key,value]of Object.entries(raw.result.raster))if(ArrayBuffer.isView(value))arrays[key]={type:value.constructor.name,length:value.length,bytes:value.byteLength,sha256:await bytes(value)};
 const originalConsumed=(0,eval)('atmosphere(model())');
 const gainKeys=['moonlightIntensity','moonBeam','moonGlow','moonLocalWash','lunarHalo','lunarCorona','moonParhelia','cloudMoonLit','cloudMoonX','cloudMoonY','cloudMoonCol'];
 const nativeGains=Object.fromEntries(gainKeys.map(k=>[k,originalConsumed[k]??null]));
 if(nativeGains.moonGlow===null||nativeGains.moonLocalWash===null){
  const legacy=window.__r0022OriginalGainBindings;
  if(legacy?.sourceSha256!=='446453b522f56f5f1bc0afd1a3abd09b73756754fa58a6b3b0ff09ce953a2eec')throw new Error('Missing pinned original consumer expressions');
  nativeGains.moonLocalWash=(0,eval)('(()=>{'+legacy.wash+' return mw;})()');
  nativeGains.moonGlow=(0,eval)('((frac)=>('+legacy.glow+'))(moonSky.frac)');
 }
 if(Object.values(nativeGains).some(v=>v==null)||!(nativeGains.moonlightIntensity>0&&nativeGains.moonBeam>0&&nativeGains.moonGlow>0))throw new Error('Actual eligible native consumers were not reached');
 return {qa,native,commonWeather,nativeGains,resolvedSite:(0,eval)('({lat,lon,tz})'),localGlowCSS:document.querySelector('.mglow').style.getPropertyValue('--mgo'),actualNativeUTC:(0,eval)('simNow()'),actualNativeRate:(0,eval)('TIMESCALE'),
  raw:raw?{request:raw.request,result:{utcMs:raw.result.utcMs,observer:raw.result.observer,native:raw.result.native,physicalState:raw.result.raster.physicalState,atmosphere:raw.result.raster.atmosphere,effectiveExposure:raw.result.raster.effectiveExposure,arrays},current:binding.current(raw.request)}:null};
}
