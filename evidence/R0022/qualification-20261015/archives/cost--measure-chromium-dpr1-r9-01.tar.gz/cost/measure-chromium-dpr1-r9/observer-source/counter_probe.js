/* Disposable native cost observer. Never included in the production build. */
(()=>{
 const native={raf:requestAnimationFrame.bind(window),cancel:cancelAnimationFrame.bind(window),timeout:setTimeout.bind(window),clearTimeout:clearTimeout.bind(window),interval:setInterval.bind(window),clearInterval:clearInterval.bind(window),add:EventTarget.prototype.addEventListener,remove:EventTarget.prototype.removeEventListener,fetch:fetch.bind(window)};
 const rafs=new Map(),timers=new Map(),intervals=new Map(),listeners=new Map(),workers=new Map(),fetches=new Set(),caches=[];
 let serial=0,listenerSerial=0,workerSerial=0,networkRequests=0,readbacks=0,textureAllocations=0,canvasCreates=0,backingResets=0,listenerReference=0,providerReference=0,quiesced=false;
 const listenerIds=new WeakMap(),targetIds=new WeakMap();
 const id=(map,value)=>{if(!map.has(value))map.set(value,++listenerSerial);return map.get(value);};
 window.requestAnimationFrame=fn=>{let key=native.raf(t=>{rafs.delete(key);fn(t);});rafs.set(key,{name:fn.name,source:String(fn).slice(0,160)});return key;};
 window.cancelAnimationFrame=key=>{rafs.delete(key);return native.cancel(key);};
 window.setTimeout=(fn,delay,...args)=>{let key=native.timeout((...rest)=>{timers.delete(key);if(typeof fn==='function')fn(...rest);else(0,eval)(fn);},delay,...args);timers.set(key,{delay,name:fn.name??'string'});return key;};
 window.clearTimeout=key=>{timers.delete(key);return native.clearTimeout(key);};
 window.setInterval=(fn,delay,...args)=>{let key=native.interval(fn,delay,...args);intervals.set(key,{delay,name:fn.name??'string'});return key;};
 window.clearInterval=key=>{intervals.delete(key);return native.clearInterval(key);};
 EventTarget.prototype.addEventListener=function(type,fn,options){
  if(!fn||options?.signal?.aborted)return native.add.call(this,type,fn,options);
  const key=id(targetIds,this)+':'+type+':'+id(listenerIds,fn)+':'+!!(typeof options==='boolean'?options:options?.capture);
  if(listeners.has(key))return;
  const wrapped=options?.once?function(...args){listeners.delete(key);return typeof fn==='function'?fn.apply(this,args):fn.handleEvent(...args);}:fn;
  listeners.set(key,{type,once:!!options?.once,wrapped});
  if(options?.signal)native.add.call(options.signal,'abort',()=>listeners.delete(key),{once:true});
  return native.add.call(this,type,wrapped,options);
 };
 EventTarget.prototype.removeEventListener=function(type,fn,options){
  const key=fn?id(targetIds,this)+':'+type+':'+id(listenerIds,fn)+':'+!!(typeof options==='boolean'?options:options?.capture):null,wrapped=listeners.get(key)?.wrapped??fn;
  listeners.delete(key);return native.remove.call(this,type,wrapped,options);
 };
 window.fetch=(...args)=>{const key=++serial;networkRequests++;fetches.add(key);return native.fetch(...args).finally(()=>fetches.delete(key));};
 const XHR=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.send=function(...args){const key=++serial;networkRequests++;fetches.add(key);native.add.call(this,'loadend',()=>fetches.delete(key),{once:true});return XHR.apply(this,args);};
 const W=Worker;window.Worker=class extends W{
  constructor(...args){super(...args);this.__costId=++workerSerial;const record={id:this.__costId,pending:new Set(),terminated:false};workers.set(this.__costId,record);native.add.call(this,'message',e=>{const m=e.data;if(m?.kind==='ready')record.pending.delete('boot');if(['result','error','fatal'].includes(m?.kind)){if(m.id!=null)record.pending.delete(m.id);else record.pending.clear();}});}
  postMessage(m,...rest){const record=workers.get(this.__costId);if(m?.kind==='boot')record.pending.add('boot');if(m?.kind==='render')record.pending.add(m.id);if(m?.kind==='cancel')record.pending.clear();return super.postMessage(m,...rest);}
  terminate(){const r=workers.get(this.__costId);r.pending.clear();r.terminated=true;return super.terminate();}
 };
 const create=Document.prototype.createElement;Document.prototype.createElement=function(name,...rest){const value=create.call(this,name,...rest);if(String(name).toLowerCase()==='canvas'){canvasCreates++;textureAllocations++;}return value;};
 for(const key of ['width','height']){const descriptor=Object.getOwnPropertyDescriptor(HTMLCanvasElement.prototype,key);Object.defineProperty(HTMLCanvasElement.prototype,key,{...descriptor,set(value){backingResets++;textureAllocations++;return descriptor.set.call(this,value);}});}
 for(const [owner,key]of [[CanvasRenderingContext2D.prototype,'getImageData'],[HTMLCanvasElement.prototype,'toDataURL'],[HTMLCanvasElement.prototype,'toBlob']]){const original=owner[key];owner[key]=function(...args){readbacks++;return original.apply(this,args);};}
 function live(){return {pendingJobs:fetches.size+[...workers.values()].reduce((n,w)=>n+w.pending.size,0),rafChains:rafs.size,timerChains:timers.size,intervalChains:intervals.size,listeners:listeners.size,providers:[...workers.values()].filter(w=>!w.terminated).length,networkRequests,readbacks,textureAllocations,canvasCreates,backingResets,timers:[...timers.values()],intervals:[...intervals.values()],raf:[...rafs.values()],workers:[...workers.values()].map(w=>({...w,pending:[...w.pending]})),quiesced};}
 function retained(){
  const arrays=new Set(),buffers=new Set(),seen=new WeakSet();
  const walk=(v,depth=0)=>{if(!v||typeof v!=='object'||seen.has(v)||depth>12)return;seen.add(v);if(ArrayBuffer.isView(v)){arrays.add(v);buffers.add(v.buffer);return;}if(v instanceof ArrayBuffer){buffers.add(v);return;}if(v instanceof Map){for(const pair of v)walk(pair,depth+1);return;}if(Array.isArray(v)||Object.getPrototypeOf(v)===Object.prototype)for(const key of Object.keys(v))walk(v[key],depth+1);};
  walk(window.realSkyFrame?.());walk(window.SalahSkyPreview?.frame?.raster);walk(window.SalahMoonRuntime?.surface?.());walk(caches);walk(window.__r0022CostPreviewResult);
  try{walk((0,eval)('({alb:typeof _mAlb!=="undefined"?_mAlb:null,nrm:typeof _mNrm!=="undefined"?_mNrm:null,out:typeof _moonOut!=="undefined"?_moonOut?.data:null})'));}catch(error){throw new Error('Retained native material inventory unavailable: '+error);}
  return {retainedArrays:arrays.size,retainedBytes:[...buffers].reduce((n,b)=>n+b.byteLength,0)};
 }
 const api=window.__r0022CostObserver={live,retained,native,caches,
  quiesce(){if(quiesced)throw new Error('Already quiesced');const before=live();if(before.pendingJobs)throw new Error('Pending native work before quiescence');for(const key of rafs.keys())native.cancel(key);rafs.clear();for(const key of timers.keys())native.clearTimeout(key);timers.clear();for(const key of intervals.keys())native.clearInterval(key);intervals.clear();for(const a of document.getAnimations())a.pause();quiesced=true;listenerReference=listeners.size;providerReference=[...workers.values()].filter(w=>!w.terminated).length;return {before,after:live(),inheritedListenerRegistrations:listenerReference,inheritedProviders:providerReference,scope:'Only callbacks added by timed native scope are compared; inherited application ownership is separately recorded. No counters reset.'};},
  snapshot(){const state=live();return {...state,absoluteListeners:state.listeners,absoluteProviders:state.providers,listeners:state.listeners-listenerReference,providers:state.providers-providerReference,...retained(),inventoryScope:'New listener/provider ownership since observed quiescence; other counters absolute. Inherited active ownership is retained separately.'};}
 };
 window.__r0022CostProbe={captureRaw(result,request){if(result?.status==='ready')this.raw={result:structuredClone(result),request:structuredClone(request)};},bind(value){this.binding=value;}};
})();
