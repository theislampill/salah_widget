import {collectCostScope,nativePaintCostAdapters,admissionCostAdapter} from '/collector.mjs';

export async function proveOriginalQuiescence({windows,fixture}){
 const proof={status:'QUIESCENT',fixture,rows:[],failures:[]};
 const fields=['renderRequests','pendingJobs','rafChains','timerChains','intervalChains','listeners','providers','networkRequests','readbacks','textureAllocations','canvasCreates','backingResets'];
 for(const [side,w]of Object.entries(windows)){
  const o=w.__r0022CostObserver,adapters=nativePaintCostAdapters(w,()=>o.snapshot());
  const moon=side==='candidate'?w.SalahMoonRuntime.state:null;
  const phase=w.qaState().moonTruth.phaseFraction;
  if(phase!==fixture.phase)proof.failures.push(side+':native phase differs');
  if(moon&&(!moon.current||moon.pending||moon.currentNativeFraction!==fixture.phase||moon.accepted?.scene?.fraction!==fixture.phase||moon.phasePrecision.diameterDevicePixels!==fixture.diameter||Math.abs(moon.phasePrecision.signedPositionDrift)>1e-10))proof.failures.push(side+':canonical current surface/footprint not established');
  const before=o.live();
  for(let round=0;round<3;round++)for(const [name,adapter]of Object.entries(adapters)){
   await new Promise(resolve=>requestAnimationFrame(resolve));
   await adapter.prepare?.();await adapter.run();await adapter.verify?.();
   await new Promise(resolve=>setTimeout(resolve,25));
   const after=o.live();proof.rows.push({side,round,name,before,after,moon:side==='candidate'?w.SalahMoonRuntime.state:null});
   for(const key of fields)if(after[key]!==before[key])proof.failures.push(side+'/'+round+'/'+name+':'+key+' changed');
   if(after.pendingJobs||after.rafChains||after.timerChains||after.intervalChains)proof.failures.push(side+'/'+round+'/'+name+':new active native work');
  }
 }
 if(proof.failures.length)proof.status='FAILED_RETAINED';
 return proof;
}

export async function measure({windows,binding,adapterSha256,persist}){
 const raw={...structuredClone(binding),schema:'r0022-paint-cost/v1',measurementKind:'actual-browser',status:'ACQUIRING',scopes:[]};
 const original=windows.original,selected=windows.candidate;
 const originalAdapters=nativePaintCostAdapters(original,()=>original.__r0022CostObserver.snapshot());
 const selectedAdapters=nativePaintCostAdapters(selected,()=>selected.__r0022CostObserver.snapshot());
 // Functions and source-scoped observer are obtained once, outside all clocks.
 const scopes=[...['atmosphere','paint','renderMoon'].map(name=>({name,A:originalAdapters[name],B:selectedAdapters[name]}))];
 // The native original functions are measured in the original Madinah scene.
 // Then both current-source sides enter one legitimate fixed Orlando clock via
 // the existing SalahClock owner. No source-age or target fence is bypassed.
 await persist(structuredClone(raw));
 for(const scope of scopes){
  raw.scopes.push(null);const index=raw.scopes.length-1;
  const result=await collectCostScope({...scope,adapterSha256,persist:async value=>{raw.scopes[index]=value;await persist(structuredClone(raw));}});
  raw.scopes[index]=result;if(result.status!=='RAW_BATCHES_RETURNED'){raw.status='INCOMPLETE';await persist(raw);return raw;}
 }
 // Reset is performed by the native outer driver, not inside this collector.
 raw.status='ORIGINAL_SCOPES_RETURNED';await persist(structuredClone(raw));return raw;
}

export async function measureDisplay({windows,binding,adapterSha256,persist,raw}){
 const admission=w=>{const p=w.__r0022CostProbe;if(!p.raw||!p.binding)throw new Error('Actual raw admission not available');return admissionCostAdapter({...p.binding,rawResult:p.raw.result,request:p.raw.request,snapshot:()=>w.__r0022CostObserver.snapshot(),clone:v=>w.structuredClone(v)});};
 const preview=(w,rate)=>{const snapshot={...w.SalahNativeSkyHost.capture(),timeScale:rate};let previous;return {snapshot:()=>w.__r0022CostObserver.snapshot(),prepare(){previous=w.__r0022CostPreviewResult;},run(){w.__r0022CostPreviewResult=w.__r0022CostPreview(snapshot);},verify(){const r=w.__r0022CostPreviewResult;if(r===previous||r?.utcMs!==snapshot.utcMs||r.job?.observer?.utcMs!==snapshot.utcMs||!(r.raster.physicalState?.moon?.altDeg>0)||!r.raster.linear?.some(v=>v>0))throw new Error('Preview did not produce the actual eligible physical scene');if(w.__r0022CostSide==='candidate'&&(!r.raster.lunarBackgroundLinear?.some(v=>v>0)||r.raster.lunarDisplayPresentation?.contract!=='R0022-L1-H1-K003-H020-v1'))throw new Error('Selected H1 contract not consumed');}};};
 const scopes=[{name:'nativeAdmission',A:admission(windows.baseline),B:admission(windows.candidate)},...[[1,'nativePreview'],[600,'nativeFastPreview']].map(([rate,name])=>({name,A:preview(windows.baseline,rate),B:preview(windows.candidate,rate)}))];
 raw.status='ACQUIRING';raw.changedScopes=binding.changedScopes;
 for(const scope of scopes){
  raw.scopes.push(null);const index=raw.scopes.length-1;
  const result=await collectCostScope({...scope,adapterSha256,persist:async value=>{raw.scopes[index]=value;await persist(structuredClone(raw));}});
  raw.scopes[index]=result;if(result.status!=='RAW_BATCHES_RETURNED'){raw.status='INCOMPLETE';await persist(raw);return raw;}
 }
 raw.status='RAW_BATCHES_RETURNED';await persist(structuredClone(raw));return raw;
}
