from pathlib import Path
import hashlib,json,zipfile
A=Path(__file__).resolve().parent;O=A.parent;Q=O/'qualification'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def pin(p):return {'path':p.relative_to(O).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)}
dest=A/'external-capture-packet';dest.mkdir(exist_ok=False)
cap=read(Q/'firefox-recording-capability-r2.json')
archive=Path(cap['archive']['path']);assert sha(archive)==cap['archive']['sha256']
excerpts=[]
with zipfile.ZipFile(archive)as z:
 for row in cap['members']:
  data=z.read(row['path']);assert hashlib.sha256(data).hexdigest()==row['sha256']
  name=Path(row['path']).name
  lo,hi={'TargetRegistry.js':(780,806),'Protocol.js':(726,731),'PageHandler.js':(336,357)}[name]
  lines=data.decode('utf-8').splitlines()
  excerpts.append({'archiveMember':row,'firstLine':lo,'lastLine':hi,'text':'\n'.join(lines[lo-1:hi])})
case=Q/'candidate-firefox-dpr2-clear-stages-selected-r4-fixture-r7';result=read(case/'results.json')
trace=read(A/'retained-trace-controls/MANIFEST.json');inspection=read(case/'original-sequence-r1/inspection.json')
files=[Q/'firefox-recording-capability-r2.json',A/'RETURN.md',A/'retained-trace-controls/MANIFEST.json',A/'ROOT_RETAINED_PIXEL_OBSERVATION.json',case/'results.json',case/'capture-trace.zip',case/'original-sequence-r1/inspection.json']
files.extend(Path(r['file'])for r in trace['rows']);files.extend((case/'video').glob('*.webm'))
packet={'schema':'r0022-native-capture-external-discriminator/v1','status':'PREPARED_NOT_SENT','recipient':'Native capture/tooling owner; no recipient identity or contact is asserted','authority':'Bounded diagnosis only; no browser/source build or recorder substitution requested or performed','originalSourceRuntime':result['runtime'],'browser':result['browser'],'driver':result['driverOverride'],'viewportCss':[375,800],'cardCss':[325,530],'dpr':result['dpr'],'capability':cap,'sourceExcerpts':excerpts,'files':[pin(p)for p in files],'question':'For the SAME returned failing native JPEG, was the committed rendered surface pale, or did capture/JPEG production change healthy pixels?','requiredWitness':['PageTarget and document identity','Selected native backend and surface identity','Committed paint identity associated with that surface','Pre-capture or pre-JPEG pixel bytes for that SAME returned frame','Returned JPEG bytes and event identity'],'known':'Original native JPEGs are already pale/incomplete; a downstream WebM-only or PNG-extraction-only cause is excluded. Trace/video share a producer.','unknown':'Rendering versus native capture/JPEG production; timestamp and frameSwapWallTime do not provide a committed-paint association.','followup':'Demonstrate the association capability and obtain bounded independent review before any affected native diagnostic or repair. Preserve failed original watches. No later-still or metrics substitution.'}
(dest/'PACKET.json').write_text(json.dumps(packet,indent=2)+'\n',encoding='utf-8')
html='''<!doctype html><meta charset="utf-8"><title>R0022 original Firefox capture controls</title><style>body{font:16px system-ui;background:#18202c;color:#edf2fa;margin:24px}main{display:flex;gap:20px;align-items:flex-start;flex-wrap:wrap}figure{margin:0;width:375px}img{width:375px;height:800px;display:block}figcaption{min-height:80px;line-height:1.5}a{color:#99cbff}p{max-width:1000px;line-height:1.5}</style><h1>Retained original Firefox JPEGs</h1><p>These are original bytes extracted from the existing trace, without re-encoding or cropping. The failed frames remain failed. Different event times are shown; they do not identify the same committed paint or establish independent capture paths.</p><main>'''
labels=['Lower viewport becomes pale at approximately y=426.','Entire viewport is pale.','Later readable card and external marker; does not replace the failed watch.']
for i,label in zip([1,2,3],labels):
 row=trace['rows'][i]
 html+=f'<figure><figcaption>{label}<br>Event timestamp {row["event"]["timestamp"]} ms.</figcaption><img src="../retained-trace-controls/original-trace-control-{i}.jpeg" alt="Original Firefox control {i}"></figure>'
html+='</main><p>The missing discriminator is a same-frame association between PageTarget/document, selected surface/backend, committed paint, pre-JPEG pixels and returned JPEG bytes. This package is prepared for the tooling owner; it has not been sent and does not authorize a browser build or recording substitution.</p><p><a href="PACKET.json">Exact original/source inventory</a></p>'
(dest/'index.html').write_text(html,encoding='utf-8')
print(json.dumps({'packetSha256':sha(dest/'PACKET.json'),'htmlSha256':sha(dest/'index.html'),'files':len(files)}))
