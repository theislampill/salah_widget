from pathlib import Path
import hashlib,json,zipfile
D=Path(__file__).resolve().parent;O=D.parent
source=O/'qualification/candidate-firefox-dpr2-clear-stages-selected-r4-fixture-r7/capture-trace.zip'
def sha(b):return hashlib.sha256(b).hexdigest()
assert sha(source.read_bytes())=='e76b2359578faafbc174a747329af931a8d3c4a16fab1b23615f6dc677a38b2f'
out=D/'retained-trace-controls';out.mkdir(exist_ok=False)
rows=[]
with zipfile.ZipFile(source)as z:
 events=[json.loads(b)for b in z.read('trace.trace').splitlines()];frames=[v for v in events if v.get('type')=='screencast-frame']
 targets=[frames[0]['timestamp']+v for v in [0,1000,3000,10000]]
 for ordinal,t in enumerate(targets):
  event=min(frames,key=lambda v:abs(v['timestamp']-t));member='resources/'+event['sha1'];b=z.read(member);p=out/f'original-trace-control-{ordinal}.jpeg';p.write_bytes(b)
  rows.append({'event':event,'requestedEventTimestamp':t,'zipMember':member,'file':str(p),'bytes':len(b),'sha256':sha(b)})
record={'schema':'r0022-retained-trace-byte-extraction/v1','source':str(source),'sourceSha256':sha(source.read_bytes()),'rows':rows,'scope':'Exact original JPEG bytes extracted without re-encoding. Event timestamp selection only; no claimed videoPTS/committedpaint/surface association or new acquisition. Can test whether pale pixels exist before downstream WebM encoding; cannot distinguish native rendering vs upstream capture/JPEG cause.'}
(out/'MANIFEST.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');print(json.dumps({'manifestSha256':sha((out/'MANIFEST.json').read_bytes()),'rows':rows}))
