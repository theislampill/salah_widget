from pathlib import Path
import datetime,hashlib,json,shutil
A=Path(__file__).resolve().parent;O=A.parent
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
assert read(O/'browser-lease.json')['status']=='FREE'and not(O/'native-resource.lock').exists()
accept={'schema':'r0022-direct-andon-executor-acceptance/v1','atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'caller':'/root','reviewer':'/root/r0022_independent_review','inputSha256':sha(A/'INPUT.json'),'returnTranscriptionSha256':sha(A/'RETURN.md'),'reviewerVerification':'Actual same-reviewer return confirms faithful substance, separated executor disposition, exact source pins and bounded post-compaction reconciliation. Not a verbatim transcript or host receipt.','result':'ACCEPTED_BOUNDED_DIAGNOSIS_BOTH_ABNORMALITIES_OPEN','cpu':'R17 controlled FAIL; one current-source diagnostic proposal under independent review before execution. No further speculative source change.','firefox':'Original watches FAIL_READABILITY; same-frame source/surface/paint/pre-JPEG witness absent. External tooling packet prepared, not sent. No replay.','unchangedContract':'R0022-L1-H1-K003-H020-v1','formalLifecycleReceipts':'UNVERIFIED','effectAuthority':'Existing user authorization only; no new source scope, thresholds, release, six-row acceptance or closure authority.'}
assert not(A/'ACCEPTANCE.json').exists();save(A/'ACCEPTANCE.json',accept)
front=O/'EXECUTION.json';oldsha=sha(front);history=O/'frontier-history';history.mkdir(exist_ok=True)
old=history/(oldsha+'.json')
if not old.exists():shutil.copyfile(front,old)
v=read(front);v['next']='One independently reviewed current-R6 baseline/candidate admission ownership diagnostic before any further source optimization. Firefox original-watch failure retained; exact external tooling discriminator prepared. No merge/closure gate.'
v['continuation']['atUtc']=accept['atUtc'];v['continuation']['cost']='R17 independently confirmed CONTROLLED FAIL: candidate16.6/19.5ms; limits15.84/18.7ms;2392 untrimmedcalls. Full A03 incomplete. Prior failures/noise retained.'
v['continuation']['andonReturn']={'path':str(A/'RETURN.md'),'sha256':sha(A/'RETURN.md'),'acceptanceSha256':sha(A/'ACCEPTANCE.json'),'bothAbnormalities':'OPEN','externalDiscriminator':str(A/'external-capture-packet/PACKET.json')}
v['ownerDisplayGate']['sourceState']='Selected-r6-recovery-r1 runtime4905c090ff7963fd59c3944636f6f64fa534a5182918f4ade379c438a2f5762b. Source integration/build and source controls accepted in recorded scope. R17 native admission cost controlled failure; no later source edits.'
save(front,v)
print(json.dumps({'acceptance':sha(A/'ACCEPTANCE.json'),'frontier':sha(front),'previous':oldsha}))
