import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL}from'node:url';
import crypto from'node:crypto';
import assert from'node:assert/strict';
const O='C:/Users/theis/.codex/work-products/r0022-execution-20261015',R='C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget';
const oldPath=O+'/selected-r1/native-preview-before-cost-repair.mjs',newPath=R+'/real-sky/native-preview.mjs';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const beforeBytes=fs.readFileSync(oldPath),afterBytes=fs.readFileSync(newPath);
const rebase=bytes=>bytes.toString().replace(/from '(\.\/[^']+)'/g,(_,v)=>'from '+JSON.stringify(pathToFileURL(path.resolve(R,'real-sky',v)).href));
const before=await import('data:text/javascript;base64,'+Buffer.from(rebase(beforeBytes)).toString('base64'));
const after=await import(pathToFileURL(newPath));
const cases=JSON.parse(fs.readFileSync(O+'/qualification/SCENES.json')).cases;
const rows=[];
for(const c of cases)for(const rate of [1,600]){
 const weather={vis:20000,cloud:c.name==='cloud'?35:c.name==='rain'?65:0,code:c.name==='cloud'?2:c.name==='rain'?63:0,temp:28};
 const snapshot={utcMs:Date.parse(c.anchor),lat:28.5383,lon:-81.3792,heightM:0,generation:2,sceneIdentity:'R0022-byte-exact-display-repair',camera:{azDeg:180,altDeg:45,fovYDeg:90,rollDeg:0},weather,units:'c',lp:0,timeScale:rate};
 const a0=performance.now(),a=before.renderNativeBackgroundPreview(snapshot),aMs=performance.now()-a0;
 const b0=performance.now(),b=after.renderNativeBackgroundPreview(snapshot),bMs=performance.now()-b0;
 const fields=[];
 for(const key of Object.keys(a.raster)){
  const av=a.raster[key],bv=b.raster[key];
  if(ArrayBuffer.isView(av)){
   assert.equal(av.constructor,bv.constructor,key);const ab=Buffer.from(av.buffer,av.byteOffset,av.byteLength),bb=Buffer.from(bv.buffer,bv.byteOffset,bv.byteLength);assert(ab.equals(bb),c.name+'/'+rate+'/'+key);
   fields.push({field:key,bytes:ab.length,sha256:sha(ab)});
  }else assert.deepEqual(bv,av,c.name+'/'+rate+'/'+key);
 }
 assert.deepEqual(Object.keys(b.raster),Object.keys(a.raster));assert.deepEqual(b.job,a.job);
 rows.push({scene:c.name,rate,exactRasterFields:fields,diagnosticOnlyMs:{before:aMs,after:bMs}});
}
const record={schema:'r0022-display-cost-repair-equivalence/v1',beforeSha256:sha(beforeBytes),afterSha256:sha(afterBytes),importBinding:'Only relative before-module imports rebased to unchanged exact current authored/core dependencies; before implementation bytes retained separately.',rows,scope:'Executed actual preview owners, every returned typed-array byte and other raster/job value equal. Diagnostic single-call Node wall times are not native warmed cost or independent visual acceptance.'};
const out=O+'/qualification/display-cost-repair-equivalence-'+(process.argv[2]??'r1')+'.json';fs.writeFileSync(out,JSON.stringify(record,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:'BYTE_IDENTICAL_RASTERS',rows:rows.length,beforeSha256:record.beforeSha256,afterSha256:record.afterSha256,diagnosticOnly:rows.map(r=>({scene:r.scene,rate:r.rate,...r.diagnosticOnlyMs}))}));
