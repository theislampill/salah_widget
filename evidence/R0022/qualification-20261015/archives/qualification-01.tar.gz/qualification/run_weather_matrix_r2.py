from pathlib import Path
import json,subprocess,sys
D=Path(__file__).resolve().parent
cells=[('baseline','chromium',1,'cloud'),('candidate','chromium',1,'cloud'),('baseline','chromium',1,'rain'),('candidate','chromium',1,'rain'),('candidate','firefox',2,'cloud'),('candidate','firefox',2,'rain')]
receipts=[]
for source,engine,dpr,case in cells:
 cmd=[sys.executable,'-I','-S','-B',str(D/'run_cell_r2.py'),'--source',source,'--engine',engine,'--dpr',str(dpr),'--case',case]
 p=subprocess.run(cmd)
 path=D/f'{source}-{engine}-dpr{dpr}-{case}-r2-dispatch.json'
 receipt=json.loads(path.read_bytes())if path.exists()else{'status':'NO_RECEIPT'}
 receipts.append({'cell':[source,engine,dpr,case],'exitCode':p.returncode,'receipt':str(path)})
 (D/'weather-matrix-r2-progress.json').write_text(json.dumps(receipts,indent=2)+'\n')
 if p.returncode or receipt.get('captureErrors') or not receipt.get('runtimeUnchanged'):raise SystemExit('Cell retained; weather matrix stopped for inspection')
print('WEATHER_MATRIX_RETURNED_FOR_PIXEL_REVIEW',flush=True)
