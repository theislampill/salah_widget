from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent;O=D.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
s=(D/'capture_instrumented_r4.py').read_text().replace('stage_observer_r3.js','stage_observer_r4.js')
s=s.replace('def qualify_clear_stages(stages):','def qualify_clear_stages(stages,prior=None,expected_url=None):')
anchor=" if not stages.get('ticks',0):failures.append({'missingObserverTicks':True})"
extra="""
 doc=stages.get('document')or{};starts=stages.get('starts')or[]
 if not doc.get('active')or not expected_url or doc.get('url')!=expected_url:failures.append({'observerDocumentNotCurrent':doc})
 if len(starts)!=1 or starts[0].get('id')!=doc.get('id')or starts[0].get('url')!=expected_url:failures.append({'observerDocumentStarts':starts})
 if not isinstance(doc.get('readAt'),(int,float))or not isinstance(stages.get('lastTick'),(int,float))or not 0<=doc['readAt']-stages['lastTick']<1000:failures.append({'observerNotRecentlyRunning':True})
 if not prior or stages.get('ticks',0)<=prior.get('ticks',0)or stages.get('lastTick',0)<=prior.get('lastTick',0):failures.append({'observerDidNotAdvance':True})
"""
assert s.count(anchor)==1;s=s.replace(anchor,anchor+extra)
s=s.replace("qualify_clear_stages(final.get('stages'))","qualify_clear_stages(final.get('stages'),initial.get('stages'),frame.url)")
(D/'capture_instrumented_r5.py').write_text(s,encoding='utf-8')
s=(D/'run_instrumented_r6.py').read_text().replace('selected-r3','selected-r4').replace('capture_instrumented_r4.py','capture_instrumented_r5.py').replace('stage_observer_r3.js','stage_observer_r4.js')
s=s.replace("assert a.case=='clear' and a.source=='candidate' and a.lifecycle,'This correction packet is scoped to the eligible candidate clear lifecycle cell'","assert a.case=='clear'and a.source=='candidate'and a.engine=='firefox'and a.dpr==2 and not a.lifecycle and not a.hold and not a.missing and a.recover_at is None,'Only the selected Firefox clear stage cell is admitted; prior R6 lifecycle is retained'")
s=s.replace("['stage_observer_r4.js','celestial_lifecycle_check_r2.py']","['stage_observer_r4.js']")
s=s.replace('One serial instrumented native stage and lifecycle preservation cell; no ordinary timing credit','One serial instrumented Firefox clear stage cell; retained R6 lifecycle is not replayed; no ordinary timing credit')
anchor="name=f'{a.source}-{a.engine}-dpr{a.dpr}-{a.case}-{a.label}';"
extra="""review=read(D/'instrumented-r7-review.json');assert review['status']=='APPROVED_FOR_ONE_STAGE_CELL'and review['runtime']==expected['treeSha256']
for filename,digest in review['files'].items():assert ident(D/filename)['sha256']==digest,('Review drift',filename)
"""
assert s.count(anchor)==1;s=s.replace(anchor,extra+anchor)
s=s.replace("receipt['finishedAtUtc']=now();receipt['runtimeUnchanged']=m.runtime_identity(root)==expected;save", "receipt['finishedAtUtc']=now();receipt['runtimeUnchanged']=m.runtime_identity(root)==expected\n if not receipt['runtimeUnchanged']:receipt['status']='FAILED_RETAINED';receipt.setdefault('captureErrors',[]).append('Consumed runtime drift')\n save")
(D/'run_instrumented_r7.py').write_text(s,encoding='utf-8')
packet={'runtime':json.loads((O/'selected-r4/RUNTIME.json').read_bytes())['treeSha256'],'files':{name:sha(D/name)for name in ['capture_instrumented_r5.py','run_instrumented_r7.py','stage_observer_r4.js','prepare_instrumented_r7.py']},'positiveControl':sha(D/'raf-document-positive-r1/results.json'),'scope':'One selected R4 Firefox DPR2 actual clear scene,60s,ordinary1x,original native video and trace plus snapshots. Instrumented only: first/preview/refined H1 propagation and current-document observer progress. Document must match actual iframe URL, one start, advance since15s and last tick within1000ms at final read. No lifecycle replay, ordinary timing or automatic pixel credit. R6 and pale original failures retained.'}
(D/'instrumented-r7-proposal.json').write_text(json.dumps(packet,indent=2)+'\n',encoding='utf-8');print(sha(D/'instrumented-r7-proposal.json'))
