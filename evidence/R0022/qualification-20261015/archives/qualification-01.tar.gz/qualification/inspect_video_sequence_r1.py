"""Decode original native video; make labelled, unscaled full-card sequences.

All-frame hashes/extrema are custody/blank controls, never a visual PASS.
Labels are video PTS, not asserted navigation latency. Original videos and
selected full viewport frames are retained; sheets omit only outside-card space.
"""
import argparse,hashlib,json,shutil,subprocess,zipfile
from datetime import datetime,timezone
from pathlib import Path
from PIL import Image,ImageDraw
D=Path(__file__).resolve().parent;O=D.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
p=argparse.ArgumentParser();p.add_argument('cell');p.add_argument('--label',default='original-sequence-r1');a=p.parse_args()
cell=D/a.cell;r=json.loads((cell/'results.json').read_bytes());run=r['runs'][0];video=Path(run['video']);out=cell/a.label
assert not out.exists()and json.loads((O/'browser-lease.json').read_bytes())['status']=='FREE'and not(O/'native-resource.lock').exists()
ffmpeg=Path(shutil.which('ffmpeg'));ffprobe=Path(shutil.which('ffprobe'))
assert ffmpeg.is_file()and ffprobe.is_file()
out.mkdir()
with(O/'native-resource.lock').open('x')as lock:lock.write(a.cell+'-decode')
lease={'leaseId':a.cell+'-decode','status':'ACTIVE','owner':'R0022 root','scope':'Serial offline original-video decoding only','startedAtUtc':datetime.now(timezone.utc).isoformat()};save(O/'browser-lease.json',lease)
rows=[];selected_rows=[];sheet=None;sheet_names=[];selection_index=0;proc=None;inputs={};failure=None
try:
 dispatch=D/(a.cell+'-dispatch.json');receipt=json.loads(dispatch.read_bytes());adapter=Path(receipt['adapter']['path'])
 inputs={str(path):sha(path)for path in [video,cell/'results.json',cell/'capture-trace.zip',dispatch,adapter,Path(__file__).resolve(),ffmpeg,ffprobe]}
 assert sha(adapter)==receipt['adapter']['sha256']==r['harnessSha256']
 # Bind crop coordinates to the original exact iframe fixture and actual card.
 source=adapter.read_text(encoding='utf-8');assert 'body style="margin:8px;background:#1a2335"'in source
 assert 'width:330px;height:534px;border:0;border-radius:28px;overflow:hidden'in source
 assert r['entry']=='iframe'and {k:run['final']['card'][k]for k in ['x','y','width','height']}=={'x':0,'y':0,'width':325,'height':530}
 command=receipt['command'];viewport=list(map(int,command[command.index('--viewport')+1].split('x')))
 probe=json.loads(subprocess.check_output([str(ffprobe),'-v','error','-select_streams','v:0','-show_entries','stream=width,height,r_frame_rate:frame=best_effort_timestamp_time','-of','json',str(video)],timeout=90))
 stream=probe['streams'][0];width,height=stream['width'],stream['height'];pts=[float(f['best_effort_timestamp_time'])for f in probe['frames']]
 assert [width,height]==viewport and width>=333 and height>=538 and len(pts)>500 and all(b>=a for a,b in zip(pts,pts[1:]))
 targets=[i/5 for i in range(26)]+list(range(6,16))+list(range(20,61,5))
 requests=[{'requestedPtsSeconds':t,'frame':min(range(len(pts)),key=lambda i:abs(pts[i]-t))}for t in targets]
 for request in requests:
  request['actualPtsSeconds']=pts[request['frame']];request['differenceSeconds']=abs(request['actualPtsSeconds']-request['requestedPtsSeconds'])
 assert pts[0]<=.04 and pts[-1]>=60 and all(r['differenceSeconds']<=.041 for r in requests)
 selected={r['frame']for r in requests};assert len(selected)==len(targets)
 with (out/'decoder.log').open('wb')as err:
  proc=subprocess.Popen([str(ffmpeg),'-v','warning','-i',str(video),'-fps_mode','passthrough','-f','rawvideo','-pix_fmt','rgb24','-'],stdout=subprocess.PIPE,stderr=err)
  size=width*height*3
  for i,t in enumerate(pts):
   data=proc.stdout.read(size);assert len(data)==size
   original=Image.frombytes('RGB',(width,height),data);extrema=original.getextrema()
   row={'frame':i,'ptsSeconds':t,'decodedRgbSha256':hashlib.sha256(data).hexdigest(),'allBlack':max(v[1]for v in extrema)==0};rows.append(row)
   if i not in selected:continue
   name=f'original-frame-{i:05}.png';original.save(out/name)
   # The native recording is deliberately CSS-size; do not infer DPR dimensions.
   card=original.crop((8,8,333,538))
   tile=selection_index%12
   if tile==0:sheet=Image.new('RGB',(325*4,550*3),(245,245,245))
   x=(tile%4)*325;y=(tile//4)*550
   sheet.paste(card,(x,y+20));ImageDraw.Draw(sheet).text((x+3,y+3),f'frame {i} / video {t:.3f}s',fill=(0,0,0))
   selected_rows.append({**row,'file':name,'fileSha256':sha(out/name),'sheet':selection_index//12+1,'tile':tile})
   selection_index+=1
   if tile==11 or i==max(selected):
    sheet_name=f'full-card-sequence-{len(sheet_names)+1:02}.png';sheet.save(out/sheet_name);sheet_names.append(sheet_name)
  assert proc.stdout.read(1)==b''and proc.wait()==0
 trace=[]
 with zipfile.ZipFile(cell/'capture-trace.zip')as z:
  for name in z.namelist():
   if name.endswith('.trace'):
    for line in z.read(name).splitlines():
     e=json.loads(line)
     if e.get('type')=='screencast-frame':trace.append(e)
 gaps=[b['timestamp']-a['timestamp']for a,b in zip(trace,trace[1:])if'timestamp'in a and'timestamp'in b]
 save(out/'trace-frames.json',trace)
 unchanged=all(sha(Path(path))==digest for path,digest in inputs.items());assert unchanged
 save(out/'inspection.json',{'schema':'r0022-original-video-sequence/v1','inputsBefore':inputs,'inputsUnchangedAfter':unchanged,'originalVideo':{'path':str(video),'sha256':sha(video),'bytes':video.stat().st_size},'resultSha256':sha(cell/'results.json'),'decoder':{'path':str(ffmpeg),'sha256':sha(ffmpeg)},'probe':{'path':str(ffprobe),'sha256':sha(ffprobe),'stream':stream},'frames':rows,'requestedSelections':requests,'selectedOriginalFrames':selected_rows,'sheets':[{'path':name,'sha256':sha(out/name)}for name in sheet_names],'trace':{'sourceSha256':sha(cell/'capture-trace.zip'),'count':len(trace),'maxTimestampGapMs':max(gaps)if gaps else None},'fullCardCrop':[8,8,325,530],'cropBasis':'Exact retained adapter iframe margin8/card CSS325x530 plus actual native card x0/y0/325x530 and video dimensions equal declared viewport; no resampling','scope':'Original native video fully decoded. Selected original full-view frames and unscaled complete-card temporal sheets for human/model pixel review; no in-card layer or pixel removed. PTS is not navigation timing. This sampling, hashes and blank control do not alone certify every-frame continuity, opacity, motion, startup timing or actual extension parent.'})
 print(json.dumps({'cell':a.cell,'frames':len(rows),'selected':len(selected_rows),'sheets':sheet_names,'allBlackFrames':sum(row['allBlack']for row in rows)}),flush=True)
except BaseException as error:
 failure={'type':type(error).__name__,'message':str(error)}
 raise
finally:
 if proc is not None:
  if proc.stdout:proc.stdout.close()
  if proc.poll()is None:
   proc.terminate()
   try:proc.wait(timeout=10)
   except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=10)
 if failure is not None:save(out/'failure-partial.json',{'failure':failure,'inputsBefore':inputs,'inputsAfter':{path:sha(Path(path))for path in inputs if Path(path).is_file()},'decodedRows':rows,'selectedRows':selected_rows,'sheets':sheet_names,'ffmpegReturnCode':proc.returncode if proc else None,'visualCredit':False})
 lease.update(status='FREE',owner=None,finishedAtUtc=datetime.now(timezone.utc).isoformat());save(O/'browser-lease.json',lease)
 assert(O/'native-resource.lock').read_text()==a.cell+'-decode';(O/'native-resource.lock').unlink()
