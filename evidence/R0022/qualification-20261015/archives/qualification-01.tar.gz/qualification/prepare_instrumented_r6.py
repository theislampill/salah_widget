from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent
def identity(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
def write_new(name,text):
 with (D/name).open('x',encoding='utf-8',newline='')as f:f.write(text)
s=(D/'capture_instrumented_r3.py').read_text(encoding='utf-8')
health=r"""
def retain_late_observer_errors(errors,stages):
 faults=[]
 if not isinstance(stages,dict):faults.append({'missingObserverAtLifecycleEnd':True})
 elif stages.get('errors'):faults.append({'lateStageObserverErrors':stages['errors']})
 if faults:errors.append({'postLifecycleObserverFailure':faults})
 return {'status':'FAIL'if faults else'PASS','failures':faults,'ticks':(stages or{}).get('ticks',0)}
"""
anchor='async def run(a):';assert s.count(anchor)==1;s=s.replace(anchor,health+'\n'+anchor)
anchor="    lifecycle=await lifecycle_controls(page,frame,a.out,mode)\n    if lifecycle['status']!='PASS':errors.append({'lifecycleFailure':lifecycle['failures']})"
assert s.count(anchor)==1
s=s.replace(anchor,anchor+"\n    lifecycle['observerAtEnd']=await frame.evaluate('()=>window.__r0022ReadStages?.()')\n    lifecycle['observerHealth']=retain_late_observer_errors(errors,lifecycle['observerAtEnd'])\n    if lifecycle['observerHealth']['status']!='PASS':\n     lifecycle['status']='FAIL';lifecycle['failures'].append('Stage observer failed during lifecycle; retained original observation errors')")
write_new('capture_instrumented_r4.py',s)
s=(D/'run_instrumented_r5.py').read_text(encoding='utf-8').replace('capture_instrumented_r3.py','capture_instrumented_r4.py')
anchor='def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()';assert s.count(anchor)==1
s=s.replace(anchor,anchor+"\ndef dispatch_status(exit_code,errors):return 'RETURNED'if exit_code==0 and not errors else'FAILED_RETAINED'")
anchor="receipt['status']='RETURNED'if result.returncode==0 and not receipt.get('captureErrors')else'FAILED_RETAINED'";assert s.count(anchor)==1
s=s.replace(anchor,"receipt['status']=dispatch_status(result.returncode,receipt.get('captureErrors'))")
write_new('run_instrumented_r6.py',s)
previous=json.loads((D/'instrumented-r5-proposal.json').read_bytes())
packet={**previous,'supersedes':identity(D/'instrumented-r5-proposal.json'),'changes':previous['changes']+['Post-lifecycle observer-health gate retains late faults and makes capture and dispatch fail; separate from the initial three-stage predicate'],'files':[identity(D/name)for name in ['capture_instrumented_r4.py','run_instrumented_r6.py','stage_observer_r3.js','celestial_lifecycle_check_r2.py','prepare_instrumented_r6.py']]}
write_new('instrumented-r6-proposal.json',json.dumps(packet,indent=2)+'\n')
print(json.dumps(identity(D/'instrumented-r6-proposal.json')))
