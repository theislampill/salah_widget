from pathlib import Path
import hashlib,json,shutil
D=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['run_instrumented_r7.py','capture_instrumented_r5.py','instrumented-r7-proposal.json']:shutil.copyfile(D/name,D/(name+'.proposal1'))
p=D/'capture_instrumented_r5.py';s=p.read_text()
anchor="   initial=await frame.evaluate(FINAL)"
extra="""
   partial={'mode':mode,'navigationAbsolute':absolute,'at15s':initial,'ordinaryCheckpoints':[],'status':'OBSERVING','video':video_file}
   report.setdefault('partialRuns',[]).append(partial);save()
"""
assert s.count(anchor)==1;s=s.replace(anchor,anchor+extra)
s=s.replace("   checkpoints=[]","   checkpoints=partial['ordinaryCheckpoints']")
anchor="    shot=f'{mode}-at{target}s.png'"
extra="""    row={'targetSeconds':target,'state':observed,'status':'STATE_RETAINED_BEFORE_PNG'};checkpoints.append(row);save()
"""
assert s.count(anchor)==1;s=s.replace(anchor,extra+anchor)
old="    checkpoints.append({'targetSeconds':target,'state':observed,'file':shot,'captureStartMs':(began-start)*1000,'captureEndMs':(time.monotonic()-start)*1000})"
new="    row.update(file=shot,captureStartMs=(began-start)*1000,captureEndMs=(time.monotonic()-start)*1000,status='PNG_RETURNED');save()"
assert s.count(old)==1;s=s.replace(old,new)
anchor="   if final['stageQualification']['status']!='PASS':errors.append({'stageQualificationFailure':final['stageQualification']['failures']})"
assert s.count(anchor)==1;s=s.replace(anchor,anchor+"\n   partial.update(final=final,status='STAGE_PREDICATE_RETAINED');save()")
anchor="  await ctx.close();await browser.close()"
assert s.count(anchor)==1;s=s.replace(anchor,anchor+"\n  report['nativeCleanup']='CONTEXT_AND_BROWSER_CLOSE_RETURNED';save()")
p.write_text(s,encoding='utf-8')
p=D/'run_instrumented_r7.py';s=p.read_text()
anchor="def dispatch_status(exit_code,errors):return 'RETURNED'if exit_code==0 and not errors else'FAILED_RETAINED'"
extra="\ndef cleanup_established(exit_code,report):return exit_code==0 and isinstance(report,dict)and report.get('nativeCleanup')=='CONTEXT_AND_BROWSER_CLOSE_RETURNED'"
assert s.count(anchor)==1;s=s.replace(anchor,anchor+extra)
old="  result=subprocess.run(cmd,env=dict(os.environ,SALAH_BROWSER=a.engine,SALAH_BROWSER_EXECUTABLE=str(exe)),stdout=stdout,stderr=stderr,timeout=480)\n receipt['exitCode']=result.returncode"
new="""  process=subprocess.Popen(cmd,env=dict(os.environ,SALAH_BROWSER=a.engine,SALAH_BROWSER_EXECUTABLE=str(exe)),stdout=stdout,stderr=stderr)
  receipt['ownedChildPid']=process.pid;save(D/(name+'-dispatch.json'),receipt)
  returncode=process.wait(timeout=480)
 receipt['exitCode']=returncode"""
assert s.count(old)==1;s=s.replace(old,new).replace('result.returncode','returncode')
anchor='finally:\n'
extra="""except BaseException as error:
 receipt['status']='FAILED_RETAINED';receipt['operationFailure']={'type':type(error).__name__,'message':str(error),'atUtc':now()}
 receipt.setdefault('captureErrors',[]).append('Native operation did not return cleanly; owned cleanup requires reconciliation')
"""
assert s.count(anchor)==1;s=s.replace(anchor,extra+anchor)
old=" lease.update(status='FREE',owner=None,finishedAtUtc=now());save(O/'browser-lease.json',lease)\n assert lock.read_text()==name;lock.unlink()"
new=""" terminal=read(out/'results.json')if (out/'results.json').exists()else None
 clean=cleanup_established(receipt.get('exitCode'),terminal);receipt['ownedNativeCleanupEstablished']=clean
 if clean:
  lease.update(status='FREE',owner=None,finishedAtUtc=now());save(O/'browser-lease.json',lease)
  assert lock.read_text()==name;lock.unlink()
 else:
  receipt['status']='FAILED_RETAINED';lease.update(status='RECOVERY_REQUIRED',owner='R0022 root',reason='Owned child/native closure not established',childPid=receipt.get('ownedChildPid'));save(O/'browser-lease.json',lease)
 save(D/(name+'-dispatch.json'),receipt)"""
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s,encoding='utf-8')
p=D/'instrumented-r7-proposal.json';v=json.loads(p.read_bytes());v['files']={n:sha(D/n)for n in v['files']};v['files']['repair_instrumented_r7_custody.py']=sha(Path(__file__));v['scope']+=' Progressive actual checkpoint custody; process PID and operation-failure receipt; FREE requires clean child exit plus successful native context/browser close, otherwise hold RECOVERY_REQUIRED with owned lock.'
p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8');print(sha(p))
