from pathlib import Path
import argparse,json,subprocess,sys
D=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--group',choices=['negatives','dawn','coverage','recovery'],required=True);p.add_argument('--start',type=int,default=0);p.add_argument('--count',type=int,default=100);a=p.parse_args()
groups={
 'negatives':[(source,engine,dpr,case,[])for case in ['below','near-new']for source,engine,dpr in [('baseline','chromium',1),('candidate','chromium',1),('candidate','firefox',2)]],
 'dawn':[(source,engine,dpr,case,[])for case in ['deep-dawn','dawn-below','dawn-above','day']for source,engine,dpr in [('baseline','chromium',1),('candidate','chromium',1),('candidate','firefox',2)]],
 'coverage':[('candidate','chromium',2,'clear',[]),('candidate','firefox',1,'clear',[]),('candidate','firefox',2,'clear',[]),('candidate','chromium',1,'clear',['--viewport','1100x900'])],
 'recovery':[('candidate','chromium',1,'clear',['--hold','all','--delay','20']),('candidate','firefox',2,'clear',['--hold','all','--missing','--recover-at','20'])]
}
receipts=[]
for i,(source,engine,dpr,case,extra)in list(enumerate(groups[a.group]))[a.start:a.start+a.count]:
 label=f'{a.group}-{i+1}';cmd=[sys.executable,'-I','-S','-B',str(D/'run_cell_r2.py'),'--source',source,'--engine',engine,'--dpr',str(dpr),'--case',case,'--label',label]+extra
 result=subprocess.run(cmd);path=D/f'{source}-{engine}-dpr{dpr}-{case}-{label}-dispatch.json';receipt=json.loads(path.read_bytes())if path.exists()else{'status':'NO_RECEIPT'}
 receipts.append({'source':source,'engine':engine,'dpr':dpr,'case':case,'label':label,'exitCode':result.returncode,'receipt':str(path)})
 (D/(a.group+f'-{a.start}-progress.json')).write_text(json.dumps(receipts,indent=2)+'\n',encoding='utf-8')
 if result.returncode or receipt.get('captureErrors')or not receipt.get('runtimeUnchanged'):raise SystemExit('Failed acquisition retained; group stopped')
print(a.group.upper()+'_RETURNED_FOR_ORIGINAL_PIXEL_REVIEW',flush=True)
