(()=>{
 const events=[],documents=new WeakMap(),callbacks=new WeakMap();let docId=0,callbackId=0,droppedEvents=0;
 const doc=()=>{if(!documents.has(document))documents.set(document,++docId);return {id:documents.get(document),url:document.URL,ready:document.readyState,timeOrigin:performance.timeOrigin,at:performance.now(),top:window===top};};
 const log=(event,data={})=>{if(events.length<1500)events.push({event,...doc(),...data});else droppedEvents++;};
 const raf=requestAnimationFrame,cancel=cancelAnimationFrame;
 const identity=fn=>{if(!callbacks.has(fn))callbacks.set(fn,++callbackId);return callbacks.get(fn);};
 window.requestAnimationFrame=function(callback){
  const cid=identity(callback),source=Function.prototype.toString.call(callback);let id;
  id=raf.call(window,function(t){log('callback-enter',{cid,id,t});try{return callback.call(this,t);}finally{log('callback-exit',{cid,id});}});
  log('schedule',{cid,id,name:callback.name,source:source.length<1500?source:null});return id;
 };
 window.cancelAnimationFrame=function(id){log('cancel',{id,stack:new Error().stack});return cancel.call(window,id);};
 const dom=()=>{log('DOMContentLoaded');requestAnimationFrame(function independentDOMSentinel(){log('DOM-RAF-sentinel');});setTimeout(()=>log('DOM-timer-sentinel'),0);};
 document.addEventListener('DOMContentLoaded',dom,{once:true});
 window.addEventListener('pageshow',e=>log('pageshow',{persisted:e.persisted}),{once:true});
 log('init');window.__readRafDocumentProbe=()=>({events,droppedEvents,document:doc(),stages:window.__r0022ReadStages?.()});
})();
