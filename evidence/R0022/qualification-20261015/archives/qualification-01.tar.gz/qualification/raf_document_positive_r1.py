from pathlib import Path
import asyncio,hashlib,http.server,json,os,sys,threading,datetime
from playwright.async_api import async_playwright
D=Path(__file__).resolve().parent;O=D.parent;R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget')
sys.path.insert(0,str(R/'tools/cp9'))
from browser_runtime import launch_browser,browser_identity
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
async def run():
 review=read(D/'raf-document-positive-r1-review.json')
 assert review['status']=='APPROVED_FOR_ONE_POSITIVE_CONTROL'and review['adapterSha256']==sha(Path(__file__))
 assert review['probeSha256']==sha(D/'raf_document_probe.js')and review['observerSha256']==sha(D/'stage_observer_r4.js')
 assert read(O/'browser-lease.json')['status']=='FREE'and not(O/'native-resource.lock').exists()
 assert read(Path('C:/Users/theis/Documents/Codex/salah-rlgwo-execution-20261009/ACTIVE_LEDGER.json'))['resourceLeases']['heavy-browser']['status']=='FREE'
 assert read(Path('C:/Users/theis/.codex/work-products/r0024-execution-20261015/execution.json'))['heavyLease']['kind']=='FREE'
 prior=read(D/'candidate-firefox-dpr2-clear-stages-lifecycle-selected-r3-fixture-r6-dispatch.json');driver=prior['driver'];browser=prior['browser']
 assert sha(Path(browser['path']))==browser['sha256']and sha(Path(driver['node']))==driver['nodeSha256']
 cli=Path(driver['cli']);core=cli.parent
 for name,h in driver['files'].items():assert sha(core/name)==h,('driver drift',name)
 os.environ.update(SALAH_BROWSER='firefox',SALAH_BROWSER_EXECUTABLE=browser['path'])
 import playwright._impl._transport as transport
 transport.compute_driver_executable=lambda:(driver['node'],driver['cli'])
 name='raf-document-positive-r1';out=D/name;assert not out.exists();out.mkdir()
 (O/'native-resource.lock').write_text(name);lease={'status':'ACTIVE','owner':'R0022 root','leaseId':name,'scope':'Three-second minimal isolated Firefox observer positive control; no product/native-stage/pixel credit','startedAtUtc':now()};save(O/'browser-lease.json',lease)
 requests=[]
 class Handler(http.server.BaseHTTPRequestHandler):
  def log_message(self,*args):pass
  def do_GET(self):
   requests.append(self.path)
   body=b'<!doctype html><meta charset="utf-8"><body style="margin:8px;background:#1a2335"><iframe src="/child" style="width:330px;height:534px;border:0"></iframe>'if self.path=='/parent'else b'<!doctype html><meta charset="utf-8"><body><div class="c">Minimal observer diagnostic</div>'
   self.send_response(200);self.send_header('Content-Type','text/html');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
 server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
 report={'scope':lease['scope'],'adapterSha256':sha(Path(__file__)),'probeSha256':sha(D/'raf_document_probe.js'),'observerSha256':sha(D/'stage_observer_r4.js'),'reviewSha256':sha(D/'raf-document-positive-r1-review.json'),'priorDispatchSha256':sha(D/'candidate-firefox-dpr2-clear-stages-lifecycle-selected-r3-fixture-r6-dispatch.json'),'browserBinary':browser,'driver':driver,'requests':requests,'errors':[],'frames':[],'status':'ACQUIRING'}
 save(out/'results.json',report)
 try:
  async with async_playwright()as pw:
   instance=None;ctx=None;page=None
   try:
    instance=await launch_browser(pw);ctx=await instance.new_context(viewport={'width':375,'height':800},device_scale_factor=2,timezone_id='America/New_York',locale='en-US',reduced_motion='no-preference',record_video_dir=str(out/'video'),record_video_size={'width':375,'height':800})
    await ctx.tracing.start(screenshots=True,snapshots=False,sources=False)
    await ctx.add_init_script((D/'raf_document_probe.js').read_text(encoding='utf-8')+'\n'+(D/'stage_observer_r4.js').read_text(encoding='utf-8'))
    page=await ctx.new_page();page.on('pageerror',lambda e:report['errors'].append(str(e)))
    await page.goto(f'http://127.0.0.1:{server.server_port}/parent',wait_until='domcontentloaded')
    report['checkpoints']=[]
    for delay in [1,2]:
     await asyncio.sleep(delay)
     point=[]
     for frame in page.frames:
      v=await frame.evaluate('()=>window.__r0022ReadStages?.()');point.append({'url':frame.url,'stages':v})
     report['checkpoints'].append(point);save(out/'results.json',report)
     expected={f'http://127.0.0.1:{server.server_port}/parent',f'http://127.0.0.1:{server.server_port}/child'}
     assert len(point)==2 and {r['url']for r in point}==expected,('Missing declared parent/child',point)
     for row in point:
      v=row['stages'];url=row['url']
      assert v and v['document']['active']and v['document']['url']==url and v['ticks']>0 and len(v['starts'])==1 and not v['errors'],('Observer not current',url,v)
      assert 0<=v['document']['readAt']-v['lastTick']<150,('Observer stopped',v)
    before,after=[{row['url']:row['stages']for row in point}for point in report['checkpoints']]
    assert before.keys()==after.keys()==expected
    for url in expected:assert after[url]['ticks']>before[url]['ticks']and after[url]['lastTick']>before[url]['lastTick']
    report['browser']=browser_identity(instance);report['status']='POSITIVE_CONTROL_RETURNED'
   except Exception as e:
    report['errors'].append({'operationFailure':str(e)});report['status']='FAILED_RETAINED'
   finally:
    if page:
     for frame in page.frames:
      try:report['frames'].append({'url':frame.url,'observation':await frame.evaluate('()=>window.__readRafDocumentProbe?.()')})
      except Exception as e:report['errors'].append({'frameReadFailure':str(e),'url':frame.url})
    save(out/'results.json',report)
    if ctx:
     try:await ctx.tracing.stop(path=str(out/'trace.zip'))
     except Exception as e:report['errors'].append({'traceCloseFailure':str(e)})
     try:await ctx.close()
     except Exception as e:report['errors'].append({'contextCloseFailure':str(e)})
    if instance:
     try:await instance.close()
     except Exception as e:report['errors'].append({'browserCloseFailure':str(e)})
    if report['errors']:report['status']='FAILED_RETAINED'
    save(out/'results.json',report)
  print(json.dumps({'status':report['status'],'frames':[{'url':x['url'],'events':len(x['observation']['events']),'droppedEvents':x['observation']['droppedEvents'],'ticks':x['observation']['stages']['ticks'],'lastTick':x['observation']['stages']['lastTick']}for x in report['frames']if x.get('observation')],'errors':report['errors']}))
 finally:
  save(out/'results.json',report);server.shutdown();lease.update(status='FREE',owner=None,finishedAtUtc=now());save(O/'browser-lease.json',lease);assert(O/'native-resource.lock').read_text()==name;(O/'native-resource.lock').unlink()
asyncio.run(run())
