import ast,copy,hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent
def load(name,file='capture_instrumented_r5.py'):
 p=D/file;tree=ast.parse(p.read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name==name];assert len(nodes)==1;ns={};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(p),'exec'),ns);return ns[name]
f=load('qualify_clear_stages');good=json.loads((D/'stage-observer-r3-controls.json').read_bytes())['consumerInputs']['good'];url='http://fixture/salah_widget/index.html'
good.update(ticks=100,lastTick=59999,document={'id':1,'url':url,'active':True,'readAt':60000},starts=[{'id':1,'url':url}]);prior={'ticks':20,'lastTick':15000};cases=[]
def check(name,v):assert v,name;cases.append(name)
check('current advancing actual three-stage fields admitted',f(good,prior,url)['status']=='PASS')
for name in ['first','preview','refined']:
 b=copy.deepcopy(good);b['records']=[r for r in b['records']if r['name']!=name];check('missing '+name,f(b,prior,url)['status']=='FAIL')
for key,value in [('ticks',20),('lastTick',15000),('errors',[{'stage':'tick'}]),('document',{'id':1,'url':'about:blank','active':False,'readAt':60000}),('starts',[]),('starts',[{'id':1,'url':url},{'id':1,'url':url}])]:
 b=copy.deepcopy(good);b[key]=value;check('bad '+key+str(value),f(b,prior,url)['status']=='FAIL')
b=copy.deepcopy(good);b['lastTick']=58999;check('no recent callbacks',f(b,prior,url)['status']=='FAIL')
for name in ['first','preview','refined']:
 for key in ['raw','mapped','rawSkySeparate','lunar']:
  b=copy.deepcopy(good);next(r for r in b['records']if r['name']==name)['field'][key]=None;check(name+' missing '+key,f(b,prior,url)['status']=='FAIL')
check('no prior observation',f(good,None,url)['status']=='FAIL');check('wrong actual frame URL',f(good,prior,'http://wrong') ['status']=='FAIL')
cleanup=load('cleanup_established','run_instrumented_r7.py');closed={'nativeCleanup':'CONTEXT_AND_BROWSER_CLOSE_RETURNED'}
check('clean child plus actual close marker required',cleanup(0,closed))
for code,report in [(None,closed),(1,closed),(0,None),(0,{}),(0,{'nativeCleanup':'ATTEMPTED'})]:check('unknown cleanup held '+str((code,report)),not cleanup(code,report))
out={'cases':cases,'status':'PASS','scope':'Actual pure observer-health, H1 stage and cleanup-release predicate controls; no native credit','files':{n:hashlib.sha256((D/n).read_bytes()).hexdigest()for n in ['capture_instrumented_r5.py','run_instrumented_r7.py','test_instrumented_r7.py']}}
(D/'instrumented-r7-controls.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
