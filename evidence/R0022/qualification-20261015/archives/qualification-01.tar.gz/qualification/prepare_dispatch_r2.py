from pathlib import Path
D=Path(__file__).resolve().parent
s=(D/'run_cell.py').read_text(encoding='utf-8').replace("'capture_qualified.py'","'capture_qualified_r2.py'").replace("default='r1'","default='r2'")
anchor=" receipt['status']='RETURNED'if result.returncode==0 else'FAILED_RETAINED'"
assert s.count(anchor)==1
s=s.replace(anchor,""" if result.returncode==0:
  report=read(out/'results.json');state=report['runs'][0]['final'];weather=state.get('native',{}).get('weather');truth=state.get('qa',{}).get('wxTruth',{});composition=state.get('sky',{}).get('last',{}).get('composition',{})
  receipt['weatherAdmission']={'nativeWeather':weather,'source':truth.get('currentWeatherSource'),'model':truth.get('model'),'cloud':composition}
  if weather is None or not truth.get('model',{}).get('sourceValidAt'):
   receipt['captureErrors'].append('Controlled weather was not actually admitted')
  if a.case in ['cloud','rain'] and not composition.get('meanCloudAlpha',0)>0:
   receipt['captureErrors'].append('Eligible controlled clouds did not reach the actual native composition')
 receipt['status']='RETURNED'if result.returncode==0 and not receipt.get('captureErrors')else'FAILED_RETAINED'""")
s=s.replace("raise SystemExit(receipt.get('exitCode',1))","raise SystemExit(0 if receipt['status']=='RETURNED' else 2)")
(D/'run_cell_r2.py').write_text(s,encoding='utf-8',newline='')
s=(D/'run_weather_matrix.py').read_text(encoding='utf-8').replace("'run_cell.py'","'run_cell_r2.py'").replace('-r1-dispatch.json','-r2-dispatch.json').replace('weather-matrix-progress.json','weather-matrix-r2-progress.json')
(D/'run_weather_matrix_r2.py').write_text(s,encoding='utf-8',newline='')
