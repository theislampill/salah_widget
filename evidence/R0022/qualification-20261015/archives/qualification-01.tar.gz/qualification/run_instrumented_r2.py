from pathlib import Path
import argparse,datetime,hashlib,importlib.util,json,os,subprocess,sys
O=Path(__file__).resolve().parent.parent;D=O/'qualification';R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget')
def read(p):return json.loads(p.read_bytes())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def ident(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
p=argparse.ArgumentParser();p.add_argument('--engine',choices=['chromium','firefox'],required=True);p.add_argument('--dpr',type=int,choices=[1,2],required=True);p.add_argument('--case',required=True);p.add_argument('--source',choices=['baseline','candidate'],default='candidate');p.add_argument('--label',default='r2');p.add_argument('--viewport',default='375x800');p.add_argument('--hold',choices=['sky','moon','all']);p.add_argument('--missing',action='store_true');p.add_argument('--delay',default='20');p.add_argument('--recover-at');p.add_argument('--lifecycle',action='store_true');a=p.parse_args()
case=next(c for c in read(D/'SCENES.json')['cases']if c['name']==a.case)
root=R if a.source=='candidate'else D/'baseline-current';expected=read(O/'selected-r2/RUNTIME.json')if a.source=='candidate'else read(D/'baseline-runtime.json')
s=importlib.util.spec_from_file_location('identity',R/'tools/cp9/runtime_identity.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
assert m.runtime_identity(root)==expected
assert read(O/'browser-lease.json')['status']=='FREE' and not (O/'native-resource.lock').exists()
assert read(Path('C:/Users/theis/Documents/Codex/salah-rlgwo-execution-20261009/ACTIVE_LEDGER.json'))['resourceLeases']['heavy-browser']['status']=='FREE'
assert read(Path('C:/Users/theis/.codex/work-products/r0024-execution-20261015/execution.json'))['heavyLease']['kind']=='FREE'
prior=read(Path('C:/Users/theis/.codex/work-products/r0024-execution-20261015/native')/a.engine/('resume-r2'if a.engine=='chromium'else'resume-r6')/'results.json')['capability'];exe=Path(prior['executable']);driver=prior['driver']
assert ident(exe)['sha256']==prior['executableSha256'];assert ident(Path(driver['node']))['sha256']==driver['nodeSha256'];assert ident(Path(driver['cli']))['sha256']==driver['files']['cli.js']
name=f'{a.source}-{a.engine}-dpr{a.dpr}-{a.case}-{a.label}';out=D/name;assert not out.exists()
helpers={name:ident(D/name)for name in ['stage_observer.js','celestial_lifecycle_check.py']}
out.mkdir();(out/'observers').mkdir()
for helper_name,identity in helpers.items():(out/'observers'/helper_name).write_bytes((D/helper_name).read_bytes())
lock=O/'native-resource.lock'
with lock.open('x')as f:f.write(name)
lease={'leaseId':name,'status':'ACTIVE','owner':'R0022 root','scope':'One serial instrumented native stage and lifecycle preservation cell; no ordinary timing credit','startedAtUtc':now(),'runtime':expected['treeSha256']};save(O/'browser-lease.json',lease)
cmd=['C:/workspace/ai/cp9-integration-20261005/venv/Scripts/python.exe','-I','-B',str(D/'capture_instrumented.py'),'--root',str(root),'--out',str(out),'--scene',case['scene'],'--anchor',case['anchor'],'--viewport',a.viewport,'--modes','cold','--dpr',str(a.dpr),'--video','--video-only','--capture-trace','--driver-node',driver['node'],'--driver-cli',driver['cli']]
if a.hold:cmd+=['--hold',a.hold,'--delay',a.delay]
if a.missing:cmd+=['--missing']
if a.recover_at:cmd+=['--recover-at',a.recover_at]
if a.lifecycle:cmd+=['--lifecycle']
receipt={'schema':'r0022-native-cell-dispatch/v1','startedAtUtc':now(),'name':name,'command':cmd,'case':case,'runtime':expected['treeSha256'],'adapter':ident(D/'capture_instrumented.py'),'browser':ident(exe),'driver':driver,'status':'STARTED','instrumentation':helpers}
try:
 print('EXECUTING '+name,flush=True)
 with (D/(name+'-stdout.log')).open('xb')as stdout,(D/(name+'-stderr.log')).open('xb')as stderr:
  result=subprocess.run(cmd,env=dict(os.environ,SALAH_BROWSER=a.engine,SALAH_BROWSER_EXECUTABLE=str(exe)),stdout=stdout,stderr=stderr,timeout=480)
 receipt['exitCode']=result.returncode
 if (out/'results.json').exists():receipt['captureStatus']=read(out/'results.json')['status'];receipt['captureErrors']=read(out/'results.json')['errors']
 if result.returncode==0:
  report=read(out/'results.json');state=report['runs'][0]['final'];weather=state.get('native',{}).get('weather');truth=state.get('qa',{}).get('wxTruth',{});sky=state.get('sky')or{};last=sky.get('last')or{};composition=last.get('composition')or{}
  receipt['weatherAdmission']={'nativeWeather':weather,'source':truth.get('currentWeatherSource'),'model':truth.get('model'),'cloud':composition}
  receipt['skyObservation']={'status':sky.get('status'),'assets':sky.get('assets'),'errors':sky.get('errors',[]),'hasFinalComposition':bool(last)}
  if weather is None or not truth.get('model',{}).get('sourceValidAt'):
   receipt['captureErrors'].append('Controlled weather was not actually admitted')
  if a.case in ['cloud','rain'] and not composition.get('meanCloudAlpha',0)>0:
   receipt['captureErrors'].append('Eligible controlled clouds did not reach the actual native composition')
 receipt['status']='RETURNED'if result.returncode==0 and not receipt.get('captureErrors')else'FAILED_RETAINED'
finally:
 receipt['instrumentationUnchanged']=all(ident(D/name)['sha256']==identity['sha256']==ident(out/'observers'/name)['sha256']for name,identity in helpers.items())
 if not receipt['instrumentationUnchanged']:receipt['status']='FAILED_RETAINED';receipt.setdefault('captureErrors',[]).append('Consumed observer helper source drift')
 receipt['finishedAtUtc']=now();receipt['runtimeUnchanged']=m.runtime_identity(root)==expected;save(D/(name+'-dispatch.json'),receipt)
 lease.update(status='FREE',owner=None,finishedAtUtc=now());save(O/'browser-lease.json',lease)
 assert lock.read_text()==name;lock.unlink()
print(json.dumps({k:v for k,v in receipt.items()if k in ['name','status','captureStatus','captureErrors','exitCode','runtimeUnchanged']}),flush=True)
raise SystemExit(0 if receipt['status']=='RETURNED' else 2)
