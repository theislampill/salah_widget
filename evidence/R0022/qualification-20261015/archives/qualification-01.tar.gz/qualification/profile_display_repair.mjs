import{pathToFileURL}from'node:url';
import fs from'node:fs';
const R='C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget';
const{renderNativeBackgroundPreview}=await import(pathToFileURL(R+'/real-sky/native-preview.mjs'));
const s={utcMs:Date.parse('2026-09-25T02:00:00Z'),lat:28.5383,lon:-81.3792,heightM:0,generation:2,sceneIdentity:'R0022-offline-cost-diagnosis',camera:{azDeg:180,altDeg:45,fovYDeg:90,rollDeg:0},weather:{vis:20000,cloud:0,code:0,temp:28},units:'c',lp:0,timeScale:1};
let result,calls=0;const start=performance.now();
while(performance.now()-start<5000){result=renderNativeBackgroundPreview(s);calls++;}
console.log(JSON.stringify({scope:'Five-second source diagnostic only; Node is not native browser cost qualification',calls,elapsedMs:performance.now()-start,contract:result.raster.lunarDisplayPresentation.contract,rawLunar:result.raster.lunarBackgroundLinear[0]}));
