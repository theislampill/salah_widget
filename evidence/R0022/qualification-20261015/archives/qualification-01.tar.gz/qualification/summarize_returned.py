"""Offline observations from original retained native results; no pixel PASS."""
from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent
rows=[]
for p in sorted(D.glob('*/results.json')):
 x=json.loads(p.read_bytes())
 if 'runtimeUnchanged'not in x or not x.get('runs'):continue
 run=x['runs'][0];final=run.get('final')
 if not final:continue
 checkpoints=[('15',run['at15s'])]+[(str(z['targetSeconds']),z['state'])for z in run.get('ordinaryCheckpoints',[])]+[('final',final)]
 observations=[]
 for label,v in checkpoints:
  sky=v.get('sky')or{};native=v.get('native')or{};qa=v.get('qa')or{};truth=qa.get('wxTruth')or{};display=(v.get('display')or{}).get('refined')or{};physical=display.get('physical')or{};last=sky.get('last')or{}
  native_binding=last.get('native')or{};moon=v.get('moon')or{}
  observations.append({'checkpoint':label,'weather':qa.get('wx'),'model':truth.get('model'),'permissions':truth.get('permissions'),'visualPermissions':truth.get('visualPermissions'),'current':truth.get('current'),'modelGateReason':truth.get('modelGateReason'),'nativeWeather':native.get('weather'),'nativeUTC':native.get('utcMs'),'rate':native.get('timeScale'),'generation':native.get('generation'),'presentedUTC':sky.get('presentationUtcMs'),'skyStatus':sky.get('status'),'skyBinding':native_binding,'card':v.get('card'),'prayerRows':v.get('prayerRows'),'moonCurrent':moon.get('current'),'moonSource':moon.get('visibleSource'),'moonEpoch':moon.get('epoch'),'moonGeneration':moon.get('generation'),'moonLight':(qa.get('moonTruth')or{}).get('lunarLight'),'physicalSunAlt':physical.get('sun',{}).get('altDeg'),'physicalMoonAlt':physical.get('moon',{}).get('altDeg'),'physicalMoonFraction':physical.get('moon',{}).get('illuminatedFraction'),'lunarDisplay':display.get('lunar'),'raw':display.get('raw'),'mapped':display.get('mapped'),'stellar':display.get('stellar'),'drawn':display.get('drawn'),'catalogue':last.get('catalogue'),'sourceCount':len(last.get('sources')or[]),'composition':last.get('composition')})
 row={'name':p.parent.name,'resultsSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'runtime':x['runtime']['treeSha256'],'engine':x['browser'],'dpr':x['dpr'],'stamp':x['stamp'],'weatherExpected':x['syntheticWeather'],'errors':x['errors'],'runtimeUnchanged':x['runtimeUnchanged'],'instrumented':x['instrumented'],'observations':observations,'scope':'Retained original metadata; full pixels and temporal sequence require independent review.'};rows.append(row)
 print(json.dumps({'name':row['name'],'errors':row['errors'],'weather':observations[-1]['weather'],'sun':observations[-1]['physicalSunAlt'],'moon':observations[-1]['physicalMoonAlt'],'fraction':observations[-1]['physicalMoonFraction'],'mappingWeight':(observations[-1]['lunarDisplay']or{}).get('nightWeight'),'rawSum':(observations[-1]['raw']or{}).get('sum'),'mappedSum':(observations[-1]['mapped']or{}).get('sum'),'moonCurrent':observations[-1]['moonCurrent']}))
(D/'retained-observations.json').write_text(json.dumps({'schema':'r0022-retained-native-observations/v1','rows':rows},indent=2,allow_nan=False)+'\n',encoding='utf-8')
