from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent;O=D.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
ordinary=(D/'run_cell_r3.py').read_text().replace('selected-r1/RUNTIME.json','selected-r2/RUNTIME.json')
target=D/'run_cell_r4.py';assert not target.exists();target.write_text(ordinary,encoding='utf-8',newline='')
instrumented=(D/'run_instrumented.py').read_text().replace('selected-r1/RUNTIME.json','selected-r2/RUNTIME.json')
# Apply the separately reviewed null-sky receipt handling without changing capture.
old=(D/'run_cell_r2.py').read_text();new=(D/'run_cell_r3.py').read_text()
start="  report=read(out/'results.json');"
end="  if weather is None"
oldblock=old[old.index(start):old.index(end)];newblock=new[new.index(start):new.index(end)]
assert instrumented.count(oldblock)==1
instrumented=instrumented.replace(oldblock,newblock)
target=D/'run_instrumented_r2.py';assert not target.exists();target.write_text(instrumented,encoding='utf-8',newline='')
names=['run_cell_r4.py','run_instrumented_r2.py','capture_qualified_r2.py','capture_instrumented.py','stage_observer.js','celestial_lifecycle_check.py','inspect_video_sequence.py']
record={'runtime':json.loads((O/'selected-r2/RUNTIME.json').read_bytes())['treeSha256'],'files':{name:sha(D/name)for name in names},'delta':'Ordinary wrapper selects new runtime only. Instrumented wrapper selects new runtime and independently reviewed nullable sky/last/composition receipt handling. Actual capture/stage/lifecycle helpers unchanged. Historical wrappers/captures preserved.'}
(D/'selected-r2-driver-pins.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');print(json.dumps(record))
