const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const D=__dirname,old=fs.readFileSync(path.join(D,'stage_observer_r3.js'),'utf8'),selected=fs.readFileSync(path.join(D,'stage_observer_r4.js'),'utf8');
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const raster=()=>({width:1,height:1,lunarBackgroundLinear:new Float64Array([.1,.1,.1]),lunarNightDisplayLinear:new Float64Array([.01,.01,.01]),physicalSkyBackgroundLinear:new Float64Array([.1,.1,.1]),skyBackgroundLinear:new Float64Array([.01,.01,.01]),lunarDisplayPresentation:{contract:'R0022-L1-H1-K003-H020-v1',kneeEnergy:.003,headroomEnergy:.020}});
function environment(source){
 let at=0,refined=false,fault=false;const queue=[],windowListeners=[];
 const makeDocument=(URL,readyState)=>({URL,readyState,listeners:[],addEventListener(name,fn,options){this.listeners.push({name,fn,options})},querySelector:()=>({classList:{contains:()=>refined}})});
 const c={WeakSet,WeakMap,Float64Array,Math,Worker:class{},MessageEvent:class{},performance:{now:()=>++at,timeOrigin:1000},document:makeDocument('about:blank','complete'),addEventListener:(name,fn)=>windowListeners.push({name,fn}),requestAnimationFrame:fn=>{queue.push(fn);return queue.length},SalahNativeSkyHost:{capture:()=>{if(fault)throw Error('observation fault');return{generation:0}}},SalahSkyPreview:{frame:null,state:{}},SalahMoonRuntime:{state:{}},realSkyState:()=>({status:'ready'}),realSkyFrame:()=>c.refinedFrame};
 c.window=c;vm.runInNewContext(source,c);
 return{c,queue,replace(url='http://fixture/child'){const previous=c.document;c.document=makeDocument(url,'loading');queue.length=0;return previous},event(name,target=c.document){for(const l of windowListeners)if(l.name===name)l.fn({target});for(const l of target.listeners)if(l.name===name)l.fn({target})},ready(){c.document.readyState='interactive'},tick(){assert(queue.length);queue.shift()()},refined(v){refined=v},fault(v){fault=v}};
}
const cases=[];function control(name,fn){fn();cases.push({name,status:'PASS'})}
control('initial complete about:blank callback loss distinguishes old and fixed observer',()=>{
 const a=environment(old),b=environment(selected);assert.equal(a.queue.length,1);assert.equal(b.queue.length,0);
 for(const e of[a,b]){e.replace();e.ready();e.c.SalahSkyPreview.frame={raster:raster()};e.event('DOMContentLoaded')}
 assert.equal(a.queue.length,0);assert.equal(b.queue.length,1);b.tick();assert.equal(b.c.__r0022ReadStages().ticks,1);assert.equal(b.c.__r0022ReadStages().document.active,true);
});
control('repeated DOM and pageshow events cannot multiply the current chain',()=>{
 const e=environment(selected);e.replace();e.ready();e.event('DOMContentLoaded');for(let i=0;i<3;i++){e.event('DOMContentLoaded');e.event('pageshow')}
 assert.equal(e.queue.length,1);assert.equal(e.c.__r0022ReadStages().starts.length,1);e.tick();assert.equal(e.queue.length,1);
});
control('stale-document events cannot start a chain and stale callbacks cannot continue',()=>{
 const e=environment(selected);const blank=e.replace();e.ready();e.event('DOMContentLoaded',blank);assert.equal(e.queue.length,0);e.event('DOMContentLoaded');const oldTick=e.queue[0],oldDoc=e.replace('http://fixture/second');e.ready();e.event('pageshow',oldDoc);assert.equal(e.queue.length,0);e.event('pageshow');assert.equal(e.queue.length,1);const ticks=e.c.__r0022ReadStages().ticks;oldTick();assert.equal(e.queue.length,1);assert.equal(e.c.__r0022ReadStages().ticks,ticks);
});
control('first setter independent of RAF retains same raster first and preview records',()=>{
 const e=environment(selected);e.replace();const frame={raster:raster()};e.c.SalahFirstPaint={value:frame};e.c.SalahSkyPreview.frame=frame;e.ready();e.event('DOMContentLoaded');e.tick();assert.equal(e.c.__r0022ReadStages().records.map(r=>r.name).join(','),'first,preview');
});
control('first and tick errors retained without losing native value or future observations',()=>{
 const e=environment(selected);e.replace();const value={value:{raster:raster()}};e.fault(true);e.c.SalahFirstPaint=value;assert.equal(e.c.SalahFirstPaint,value);e.c.SalahSkyPreview.frame={raster:raster()};e.ready();e.event('DOMContentLoaded');e.tick();assert.equal(e.queue.length,1);assert.equal(e.c.__r0022ReadStages().errors.length,2);e.fault(false);e.c.SalahSkyPreview.frame={raster:raster()};e.tick();assert.equal(e.c.__r0022ReadStages().records[0].name,'preview');assert.equal(e.c.__r0022ReadStages().errors.length,2);
});
control('current refined records remain source-bound after preview',()=>{
 const e=environment(selected);e.replace();e.ready();e.c.SalahSkyPreview.frame={raster:raster()};e.event('DOMContentLoaded');e.tick();e.refined(true);e.c.refinedFrame={raster:raster()};e.tick();assert.equal(e.c.__r0022ReadStages().records.map(r=>r.name).join(','),'preview,refined');
});
const out={schema:'r0022-observer-document-controls/v1',scope:'VM document-lifecycle controls, not native stage or pixel qualification.',sources:{old:sha(old),selected:sha(selected),test:sha(fs.readFileSync(__filename))},cases};fs.writeFileSync(path.join(D,'stage-observer-r4-controls.json'),JSON.stringify(out,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(out));
