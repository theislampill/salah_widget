from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent

def identity(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}

def write_new(name,text):
 p=D/name
 with p.open('x',encoding='utf-8',newline='')as f:f.write(text)

s=(D/'capture_instrumented.py').read_text(encoding='utf-8')
s=s.replace("with_name('stage_observer.js')","with_name('stage_observer_r2.js')")
s=s.replace('from celestial_lifecycle_check import lifecycle_controls','from celestial_lifecycle_check_r2 import lifecycle_controls')
validation = r"""
def qualify_clear_stages(stages):
 # This predicate belongs only to the pinned eligible clear-night correction.
 # Missing observer callbacks/errors cannot earn transition credit.
 stages=stages or {};records=stages.get('records',[]);failures=[]
 if not stages.get('ticks',0):failures.append({'missingObserverTicks':True})
 if stages.get('errors'):failures.append({'stageObserverErrors':stages['errors']})
 counts={}
 for name in ['first','preview','refined']:
  actual=[r for r in records if r.get('name')==name];counts[name]=len(actual)
  if not actual:failures.append({'missingActualDisplayStage':name});continue
  def admitted(r):
   field=r.get('field')or{};contract=field.get('lunar')or{}
   return (contract.get('contract')=='R0022-L1-H1-K003-H020-v1'
    and contract.get('kneeEnergy')==.003 and contract.get('headroomEnergy')==.020
    and (field.get('raw')or{}).get('positive') and (field.get('mapped')or{}).get('positive')
    and field.get('rawSkySeparate'))
  if not any(admitted(r)for r in actual):failures.append({'unprovedH1Propagation':name})
 return {'status':'PASS'if not failures else'FAIL','failures':failures,'counts':counts,'ticks':stages.get('ticks',0),'scope':'Observed eligible clear-scene first/preview/refined field propagation only; no timing or whole-scene pixel credit.'}
"""
anchor='async def run(a):';assert s.count(anchor)==1;s=s.replace(anchor,validation+'\n'+anchor)
anchor="   final=await frame.evaluate(FINAL)\n   await page.screenshot(path=str(a.out/f'{mode}-final.png'),timeout=30000)"
assert s.count(anchor)==1
s=s.replace(anchor,"   final=await frame.evaluate(FINAL)\n   final['stageQualification']=qualify_clear_stages(final.get('stages'))\n   if final['stageQualification']['status']!='PASS':errors.append({'stageQualificationFailure':final['stageQualification']['failures']})\n   await page.screenshot(path=str(a.out/f'{mode}-final.png'),timeout=30000)")
write_new('capture_instrumented_r2.py',s)
s=(D/'run_instrumented_r3.py').read_text(encoding='utf-8')
s=s.replace("'capture_instrumented.py'","'capture_instrumented_r2.py'").replace("'stage_observer.js'","'stage_observer_r2.js'").replace("'celestial_lifecycle_check.py'","'celestial_lifecycle_check_r2.py'")
anchor="case=next(c for c in read(D/'SCENES.json')['cases']if c['name']==a.case)"
assert s.count(anchor)==1;s=s.replace(anchor,anchor+"\nassert a.case=='clear' and a.source=='candidate' and a.lifecycle,'This correction packet is scoped to the eligible candidate clear lifecycle cell'")
assert 'for helper_name,identity in helpers.items()'in s
assert 'for name,identity in helpers.items():(out'not in s
write_new('run_instrumented_r4.py',s)
packet={'schema':'r0022-instrumented-correction-proposal/v1','sourceRuntime':'fb0378ee1300a39380a8dd203452cffc24de05b56839d4d56f76246ac4b24073','status':'PREPARED_FOR_INDEPENDENT_REVIEW','scope':'One corrected Firefox DPR2 eligible clear instrumented lifecycle cell; no ordinary startup timing credit or replay of failed pale ordinary watches.','retainedFailure':'candidate-firefox-dpr2-clear-stages-lifecycle-selected-r3/results.json: exact A return failed, only first stage was recorded','changes':['Wait for actual settings label autofocus and verify all three form literals before close; require exact lat/lon/timezone on B and returned A','Arm one observer rAF chain on document readiness; expose ticks and bounded errors, retain errors as FAIL','Deduplicate per stage, since first and preview may share the same raster','Require all actual first/preview/refined eligible H1 stage records before recording transition credit','Retain source generator history without regenerating the obsolete helper-copy loop or old helper names'],'files':[identity(D/name)for name in ['capture_instrumented_r2.py','run_instrumented_r4.py','stage_observer_r2.js','celestial_lifecycle_check_r2.py','prepare_instrumented_r4.py']]}
write_new('instrumented-r4-proposal.json',json.dumps(packet,indent=2)+'\n')
print(json.dumps(identity(D/'instrumented-r4-proposal.json')))
