"""Explicit native metadata predicates; never substitutes for original pixels."""
from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent
expected={'baseline':'33ce3ee48c2bb2037a4073d3090f40c4892560721d10fcead0a4dda00b36ce93','candidate':'fe73f4796bdc9e4292e20b48bde69b839cf6cda87cf768c53d53be4191a47953'}
rows=[];retained_failures=[]
for p in sorted(D.glob('*/results.json')):
 name=p.parent.name
 if not name.startswith(('baseline-','candidate-')):continue
 x=json.loads(p.read_bytes())
 if any('-'+case+'-r1'in name for case in ['cloud','rain']):
  retained_failures.append({'name':name,'status':'INVALID_WEATHER_FIXTURE_RETAINED_NO_WEATHER_CREDIT','resultsSha256':hashlib.sha256(p.read_bytes()).hexdigest()});continue
 if x.get('instrumented')or x.get('hold'):continue
 if not x.get('runs')or not x['runs'][0].get('final'):continue
 fail=[];count=0
 def check(value,why):
  global count
  count+=1
  if not value:fail.append(why)
 check(x['runtime']['treeSha256']==expected[name.split('-')[0]],'Exact runtime differs')
 check(x['runtimeUnchanged']and not x['errors']and not x.get('nonfiniteDiagnostics'),'Acquisition errors/nonfinite/source drift')
 run=x['runs'][0];points=[('15',run['at15s'])]+[(str(c['targetSeconds']),c['state'])for c in run.get('ordinaryCheckpoints',[])]+[('final',run['final'])]
 for label,v in points:
  n=v['native'];q=v['qa'];s=v['sky'];m=v['moon'];r=(v['display']or{}).get('refined')or{};t=q['wxTruth'];c=(s.get('last')or{}).get('composition')or{};tag=name+'/'+label
  check(n['lat']==28.5383 and n['lon']==-81.3792 and n['tz']=='America/New_York'and n['timeScale']==1,tag+' native site/rate')
  check(n['camera']=={'azDeg':180,'altDeg':45,'fovYDeg':90,'rollDeg':0},tag+' camera')
  check(v['card']['width']==325 and v['card']['height']==530 and len(v['prayerRows'])==6 and q['cache']['prayerLoaded']and q['cache']['tomorrowLoaded'],tag+' card/prayer readiness')
  check(q['wx']['code']==x['syntheticWeather']['code']and q['wx']['cloud']==x['syntheticWeather']['cloud'],tag+' weather')
  model=t.get('model')or{};quantity=model.get('quantity')or{}
  check(model.get('sourceValidAt')is not None and model.get('provider')=='Open-Meteo'and quantity.get('value')==x['syntheticWeather']['precipMm']and quantity.get('kind')=='preceding-interval-amount'and quantity.get('instantaneous')is False,tag+' model provenance/quantity')
  check(t['permissions']['rain']is False and t['permissions']['lightning']is False and not t['observedPresent'],tag+' no invented present observation/lightning')
  check(t['visualPermissions']['rain']==(x['syntheticWeather']['code']==63)and not t['visualPermissions']['lightning'],tag+' visual weather authority')
  check(s['status']=='ready'and s['last']['native']['generation']==n['generation']and s['last']['native']['sceneIdentity']==n['sceneIdentity']and abs(n['utcMs']-s['presentationUtcMs'])<=30000,tag+' sky currentness')
  check(m['current']and m['visibleSource']in ['initial-terrain','terrain-preview','refined-terrain']and not m['legacyFallback']and not m['errors']and m['phasePrecision']['targetPositionErrorBound']<=.041600001,tag+' actual admitted V5 source/currentness/phase bound')
  check(s['last']['catalogue']['sha256']=='da5002f0eda9ad3e0f2cc7c95ab423043feea61e8522239d2930ca1945beef2e'and s['last']['catalogue']['records']==8921 and s['last']['catalogue']['emitters']==8884,tag+' catalogue provenance')
  check(c.get('cloudApplications')==1,tag+' one cloud transmission')
  if x['syntheticWeather']['cloud']>0:check(c.get('meanCloudAlpha',0)>0,tag+' actual positive cloud consumption')
  if name.startswith('candidate'):
   sun=r['physical']['sun']['altDeg'];moon=r['physical']['moon'];raw=r.get('raw');mapped=r.get('mapped');lunar=r.get('lunar')
   check(raw is not None and raw['nonfinite']==0,tag+' retained raw lunar physical field')
   if '-below-negatives-'in name:
    check(moon['altDeg']<0 and raw['positive']==0 and raw['sum']==0 and not lunar,tag+' actual below-horizon lunar negative')
   if '-near-new-'in name:
    check(moon['altDeg']>0 and moon['illuminatedFraction']<.015 and raw['positive']>0 and not q['moonTruth']['lunarLight']['eligible'],tag+' independent weak physical astronomy survives decorative zero')
   if sun>=-12:check(not lunar and mapped is None,tag+' no H1 intervention at twilight/day endpoint')
   if sun<-12 and moon['altDeg']>0 and raw['positive']>0:
    check(lunar is not None and lunar['contract']=='R0022-L1-H1-K003-H020-v1'and lunar['kneeEnergy']==.003 and lunar['headroomEnergy']==.020,tag+' selected fixed H1 contract')
    check(mapped is not None and mapped['nonfinite']==0 and mapped['positive']==raw['positive']and mapped['sum']>0,tag+' supported broad lunar field remains positive')
 refined=[label for label,v in points if v['moon']['current']and v['moon']['visibleSource']=='refined-terrain']
 rows.append({'name':name,'resultsSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'status':'PASS_METADATA_ONLY'if not fail else'FAIL','checks':count,'failures':fail,'refinedTerrainObservedAt':refined,'refinedTerrainDisposition':'OBSERVED_AT_LISTED_CHECKPOINTS_ONLY'if refined else'NOT_OBSERVED_NO_REFINED_CREDIT','moonSourceSequence':[{'at':label,'source':v['moon']['visibleSource'],'current':v['moon']['current'],'status':v['moon']['status']}for label,v in points],'scope':'Actual post-15s native input/currentness/preservation predicates only. No original-pixel, first-paint, temporal, timing, final visual, cost or closure credit.'})
report={'schema':'r0022-native-metadata-predicates/v1','rows':rows,'retainedFailures':retained_failures,'failures':sum(len(r['failures'])for r in rows)}
(D/'metadata-predicates.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'rows':len(rows),'checks':sum(r['checks']for r in rows),'failures':report['failures'],'failedRows':[r for r in rows if r['failures']],'retainedInvalidWeather':len(retained_failures)},indent=2))
