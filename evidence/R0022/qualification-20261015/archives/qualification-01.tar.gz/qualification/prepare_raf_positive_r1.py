from pathlib import Path
D=Path(__file__).resolve().parent
s=(D/'diagnose_raf_document_r1.py').read_text().replace('raf-document-diagnostic-r1','raf-document-positive-r1').replace('stage_observer_r3.js','stage_observer_r4.js').replace('APPROVED_FOR_ONE_DIAGNOSTIC','APPROVED_FOR_ONE_POSITIVE_CONTROL').replace('Three-second minimal isolated Firefox document/RAF diagnosis; no product/native-stage/pixel credit','Three-second minimal isolated Firefox observer positive control; no product/native-stage/pixel credit')
old="    await asyncio.sleep(3);report['browser']=browser_identity(instance);report['status']='DIAGNOSTIC_RETURNED'"
new="""    report['checkpoints']=[]
    for delay in [1,2]:
     await asyncio.sleep(delay)
     point=[]
     for frame in page.frames:
      v=await frame.evaluate('()=>window.__r0022ReadStages?.()');point.append({'url':frame.url,'stages':v})
      assert v and v['document']['active']and v['document']['url']==frame.url and v['ticks']>0 and len(v['starts'])==1 and not v['errors'],('Observer not current',frame.url,v)
      assert 0<=v['document']['readAt']-v['lastTick']<150,('Observer stopped',v)
     report['checkpoints'].append(point);save(out/'results.json',report)
    for a,b in zip(*report['checkpoints']):assert a['url']==b['url']and b['stages']['ticks']>a['stages']['ticks']and b['stages']['lastTick']>a['stages']['lastTick']
    report['browser']=browser_identity(instance);report['status']='POSITIVE_CONTROL_RETURNED'"""
assert old in s;s=s.replace(old,new)
(D/'raf_document_positive_r1.py').write_text(s,encoding='utf-8')
