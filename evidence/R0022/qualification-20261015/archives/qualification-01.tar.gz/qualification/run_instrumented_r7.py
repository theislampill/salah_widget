from pathlib import Path
import argparse,datetime,hashlib,importlib.util,json,os,subprocess,sys
O=Path(__file__).resolve().parent.parent;D=O/'qualification';R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget')
def read(p):return json.loads(p.read_bytes())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def dispatch_status(exit_code,errors):return 'RETURNED'if exit_code==0 and not errors else'FAILED_RETAINED'
def cleanup_established(exit_code,report):return exit_code==0 and isinstance(report,dict)and report.get('nativeCleanup')=='CONTEXT_AND_BROWSER_CLOSE_RETURNED'
def ident(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
p=argparse.ArgumentParser();p.add_argument('--engine',choices=['chromium','firefox'],required=True);p.add_argument('--dpr',type=int,choices=[1,2],required=True);p.add_argument('--case',required=True);p.add_argument('--source',choices=['baseline','candidate'],default='candidate');p.add_argument('--label',default='r2');p.add_argument('--viewport',default='375x800');p.add_argument('--hold',choices=['sky','moon','all']);p.add_argument('--missing',action='store_true');p.add_argument('--delay',default='20');p.add_argument('--recover-at');p.add_argument('--lifecycle',action='store_true');a=p.parse_args()
case=next(c for c in read(D/'SCENES.json')['cases']if c['name']==a.case)
assert a.case=='clear'and a.source=='candidate'and a.engine=='firefox'and a.dpr==2 and not a.lifecycle and not a.hold and not a.missing and a.recover_at is None,'Only the selected Firefox clear stage cell is admitted; prior R6 lifecycle is retained'
root=R if a.source=='candidate'else D/'baseline-current';expected=read(O/'selected-r4/RUNTIME.json')if a.source=='candidate'else read(D/'baseline-runtime.json')
s=importlib.util.spec_from_file_location('identity',R/'tools/cp9/runtime_identity.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
assert m.runtime_identity(root)==expected
assert read(O/'browser-lease.json')['status']=='FREE' and not (O/'native-resource.lock').exists()
assert read(Path('C:/Users/theis/Documents/Codex/salah-rlgwo-execution-20261009/ACTIVE_LEDGER.json'))['resourceLeases']['heavy-browser']['status']=='FREE'
assert read(Path('C:/Users/theis/.codex/work-products/r0024-execution-20261015/execution.json'))['heavyLease']['kind']=='FREE'
prior=read(Path('C:/Users/theis/.codex/work-products/r0024-execution-20261015/native')/a.engine/('resume-r2'if a.engine=='chromium'else'resume-r6')/'results.json')['capability'];exe=Path(prior['executable']);driver=prior['driver']
assert ident(exe)['sha256']==prior['executableSha256'];assert ident(Path(driver['node']))['sha256']==driver['nodeSha256'];assert ident(Path(driver['cli']))['sha256']==driver['files']['cli.js']
review=read(D/'instrumented-r7-review.json');assert review['status']=='APPROVED_FOR_ONE_STAGE_CELL'and review['runtime']==expected['treeSha256']
for filename,digest in review['files'].items():assert ident(D/filename)['sha256']==digest,('Review drift',filename)
name=f'{a.source}-{a.engine}-dpr{a.dpr}-{a.case}-{a.label}';out=D/name;assert not out.exists()
helpers={name:ident(D/name)for name in ['stage_observer_r4.js']}
out.mkdir();(out/'observers').mkdir()
for helper_name,identity in helpers.items():(out/'observers'/helper_name).write_bytes((D/helper_name).read_bytes())
lock=O/'native-resource.lock'
with lock.open('x')as f:f.write(name)
lease={'leaseId':name,'status':'ACTIVE','owner':'R0022 root','scope':'One serial instrumented Firefox clear stage cell; retained R6 lifecycle is not replayed; no ordinary timing credit','startedAtUtc':now(),'runtime':expected['treeSha256']};save(O/'browser-lease.json',lease)
cmd=['C:/workspace/ai/cp9-integration-20261005/venv/Scripts/python.exe','-I','-B',str(D/'capture_instrumented_r5.py'),'--root',str(root),'--out',str(out),'--scene',case['scene'],'--anchor',case['anchor'],'--viewport',a.viewport,'--modes','cold','--dpr',str(a.dpr),'--video','--video-only','--capture-trace','--driver-node',driver['node'],'--driver-cli',driver['cli']]
if a.hold:cmd+=['--hold',a.hold,'--delay',a.delay]
if a.missing:cmd+=['--missing']
if a.recover_at:cmd+=['--recover-at',a.recover_at]
if a.lifecycle:cmd+=['--lifecycle']
receipt={'schema':'r0022-native-cell-dispatch/v1','startedAtUtc':now(),'name':name,'command':cmd,'case':case,'runtime':expected['treeSha256'],'adapter':ident(D/'capture_instrumented_r5.py'),'browser':ident(exe),'driver':driver,'status':'STARTED','instrumentation':helpers}
try:
 print('EXECUTING '+name,flush=True)
 with (D/(name+'-stdout.log')).open('xb')as stdout,(D/(name+'-stderr.log')).open('xb')as stderr:
  process=subprocess.Popen(cmd,env=dict(os.environ,SALAH_BROWSER=a.engine,SALAH_BROWSER_EXECUTABLE=str(exe)),stdout=stdout,stderr=stderr)
  receipt['ownedChildPid']=process.pid;save(D/(name+'-dispatch.json'),receipt)
  returncode=process.wait(timeout=480)
 receipt['exitCode']=returncode
 if (out/'results.json').exists():receipt['captureStatus']=read(out/'results.json')['status'];receipt['captureErrors']=read(out/'results.json')['errors']
 if returncode==0:
  report=read(out/'results.json');state=report['runs'][0]['final'];weather=state.get('native',{}).get('weather');truth=state.get('qa',{}).get('wxTruth',{});sky=state.get('sky')or{};last=sky.get('last')or{};composition=last.get('composition')or{}
  receipt['weatherAdmission']={'nativeWeather':weather,'source':truth.get('currentWeatherSource'),'model':truth.get('model'),'cloud':composition}
  receipt['skyObservation']={'status':sky.get('status'),'assets':sky.get('assets'),'errors':sky.get('errors',[]),'hasFinalComposition':bool(last)}
  if weather is None or not truth.get('model',{}).get('sourceValidAt'):
   receipt['captureErrors'].append('Controlled weather was not actually admitted')
  if a.case in ['cloud','rain'] and not composition.get('meanCloudAlpha',0)>0:
   receipt['captureErrors'].append('Eligible controlled clouds did not reach the actual native composition')
 receipt['status']=dispatch_status(returncode,receipt.get('captureErrors'))
except BaseException as error:
 receipt['status']='FAILED_RETAINED';receipt['operationFailure']={'type':type(error).__name__,'message':str(error),'atUtc':now()}
 receipt.setdefault('captureErrors',[]).append('Native operation did not return cleanly; owned cleanup requires reconciliation')
finally:
 receipt['instrumentationUnchanged']=all(ident(D/name)['sha256']==identity['sha256']==ident(out/'observers'/name)['sha256']for name,identity in helpers.items())
 if not receipt['instrumentationUnchanged']:receipt['status']='FAILED_RETAINED';receipt.setdefault('captureErrors',[]).append('Consumed observer helper source drift')
 receipt['finishedAtUtc']=now();receipt['runtimeUnchanged']=m.runtime_identity(root)==expected
 if not receipt['runtimeUnchanged']:receipt['status']='FAILED_RETAINED';receipt.setdefault('captureErrors',[]).append('Consumed runtime drift')
 save(D/(name+'-dispatch.json'),receipt)
 terminal=read(out/'results.json')if (out/'results.json').exists()else None
 clean=cleanup_established(receipt.get('exitCode'),terminal);receipt['ownedNativeCleanupEstablished']=clean
 if clean:
  lease.update(status='FREE',owner=None,finishedAtUtc=now());save(O/'browser-lease.json',lease)
  assert lock.read_text()==name;lock.unlink()
 else:
  receipt['status']='FAILED_RETAINED';lease.update(status='RECOVERY_REQUIRED',owner='R0022 root',reason='Owned child/native closure not established',childPid=receipt.get('ownedChildPid'));save(O/'browser-lease.json',lease)
 save(D/(name+'-dispatch.json'),receipt)
print(json.dumps({k:v for k,v in receipt.items()if k in ['name','status','captureStatus','captureErrors','exitCode','runtimeUnchanged']}),flush=True)
raise SystemExit(0 if receipt['status']=='RETURNED' else 2)
