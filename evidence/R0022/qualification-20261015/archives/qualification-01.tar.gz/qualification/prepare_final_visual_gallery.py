"""Assemble links to original complete-scene images; never alter image bytes."""
from pathlib import Path
import hashlib,html,json

D=Path(__file__).resolve().parent
rows=[
 ('Cloudy eligible night','baseline-chromium-dpr1-cloud-r2','candidate-chromium-dpr1-cloud-r2','candidate-firefox-dpr2-cloud-r2'),
 ('Rainy eligible night','baseline-chromium-dpr1-rain-r2','candidate-chromium-dpr1-rain-r2','candidate-firefox-dpr2-rain-r2'),
 ('Physical Moon below horizon','baseline-chromium-dpr1-below-negatives-1','candidate-chromium-dpr1-below-negatives-2','candidate-firefox-dpr2-below-negatives-3'),
 ('Real low-illumination Moon near sunset','baseline-chromium-dpr1-near-new-negatives-4','candidate-chromium-dpr1-near-new-negatives-5','candidate-firefox-dpr2-near-new-negatives-6'),
 ('Deep dawn, H1 transition leg','baseline-chromium-dpr1-deep-dawn-dawn-1','candidate-chromium-dpr1-deep-dawn-dawn-2','candidate-firefox-dpr2-deep-dawn-dawn-3'),
 ('Dawn below solar horizon','baseline-chromium-dpr1-dawn-below-dawn-4','candidate-chromium-dpr1-dawn-below-dawn-5','candidate-firefox-dpr2-dawn-below-dawn-6'),
 ('Dawn above solar horizon','baseline-chromium-dpr1-dawn-above-dawn-7','candidate-chromium-dpr1-dawn-above-dawn-8','candidate-firefox-dpr2-dawn-above-dawn-9'),
 ('Daylight','baseline-chromium-dpr1-day-dawn-10','candidate-chromium-dpr1-day-dawn-11','candidate-firefox-dpr2-day-dawn-12'),
]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
assert read(D.parent/'browser-lease.json')['status']=='FREE' and not(D.parent/'native-resource.lock').exists()
out=D/'remaining-scenes-gallery';out.mkdir(exist_ok=False)
manifest=[];sections=[]
for title,*cells in rows:
 figures=[]
 for label,cell in zip(['Delivered main · Chromium DPR1','H1 · Chromium DPR1','H1 · Firefox DPR2'],cells):
  folder=D/cell;image=folder/'cold-at60s.png';result=folder/'results.json';dispatch=D/(cell+'-dispatch.json')
  r=read(result);d=read(dispatch)
  assert d['status']=='RETURNED'and d['runtimeUnchanged']and not r['errors']and image.is_file()
  item={'title':title,'label':label,'cell':cell,'runtime':d['runtime'],'image':image.relative_to(D).as_posix(),'imageSha256':sha(image),'resultSha256':sha(result),'dispatchSha256':sha(dispatch),'case':d['case']};manifest.append(item)
  href='../'+item['image'];figures.append('<figure><figcaption>'+html.escape(label)+'</figcaption><a href="'+html.escape(href)+'"><img src="'+html.escape(href)+'" alt="'+html.escape(title+' — '+label)+'"></a><details><summary>Original source and scene</summary><code>'+html.escape(cell)+'</code><p>Runtime <code>'+d['runtime']+'</code></p><p>Anchor '+html.escape(d['case']['anchor'])+'</p></details></figure>')
 sections.append('<section><h2>'+html.escape(title)+'</h2><div class="grid">'+''.join(figures)+'</div></section>')
body='''<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>R0022 remaining ordinary full scenes</title>
<style>body{font:16px/1.5 system-ui,sans-serif;margin:24px;background:#f3f5f7;color:#16202b}main{max-width:1200px;margin:auto}h1{font-size:28px}h2{font-size:22px}section{margin:40px 0}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:20px}figure{margin:0}figcaption{font-weight:650;margin-bottom:8px}img{display:block;width:100%;height:auto}code{font-size:12px;overflow-wrap:anywhere}details{font-size:13px;margin-top:8px}@media(max-width:700px){.grid{grid-template-columns:1fr}}</style>
<main><h1>R0022 remaining ordinary full scenes</h1><p>The owner has accepted H1's canonical clear scene and fixed contract. These retained ordinary appearances are prepared for the eventual final visual decision. This gallery is not a ready-to-merge claim.</p><p><strong>Unresolved evidence:</strong> original Firefox continuous recordings contain pale or incomplete frames. Healthy stills here do not replace those failed watches. Current candidate warmed admission cost and final complete-scope review also remain required.</p><p>Every image links to its original unstripped viewport PNG. No image pixels or layers are changed. The visible strip outside the card is a capture clock marker. Firefox DPR2 originals have twice the pixel dimensions and are displayed at the same CSS size here; opening an image preserves its native resolution.</p><p>These ordinary recordings belong to selected-r1. The exact-output comparison in <a href="../display-cost-repair-equivalence-r7.json">display-cost-repair-equivalence-r7.json</a> binds 18 preview raster/job cases to selected-r5; the independent component and host controls have their own scope. These originals are not relabelled as a later runtime. Metadata, native temporal evidence, preservation and cost are separate from these still comparisons.</p><p>Rain is the controlled current-model preceding-interval amount, not an assertion of observed present precipitation. The real low-illumination case is near sunset, not a fabricated near-new night. The Firefox below-horizon Moon still has the current terrain preview at 60 seconds; it does not prove refined terrain. Existing large solar appearance is preserved in dawn/day. PR43 timing and actual-extension-parent limitations remain open.</p>'''+''.join(sections)+'</main>'
(out/'index.html').write_text(body,encoding='utf-8')
(out/'originals.json').write_text(json.dumps({'schema':'r0022-original-scene-gallery/v1','scope':'Original full-viewport still comparison only; final owner decision pending','images':manifest},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'images':len(manifest),'html':str(out/'index.html'),'sha256':sha(out/'index.html')}))
