/* Bounded observer fault controls. These are not native display qualification. */
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const D=__dirname, old=fs.readFileSync(path.join(D,'stage_observer.js'),'utf8'), selected=fs.readFileSync(path.join(D,'stage_observer_r3.js'),'utf8');
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const raster=()=>({width:1,height:1,lunarBackgroundLinear:new Float64Array([.1,.1,.1]),lunarNightDisplayLinear:new Float64Array([.01,.01,.01]),physicalSkyBackgroundLinear:new Float64Array([.1,.1,.1]),skyBackgroundLinear:new Float64Array([.01,.01,.01]),lunarDisplayPresentation:{contract:'R0022-L1-H1-K003-H020-v1',kneeEnergy:.003,headroomEnergy:.020}});
function environment(source,{dropBeforeReady=false,dropAll=false}={}){
 let at=0,ready='loading',refined=false,captureThrows=false;const queue=[],listeners=[];
 const context={WeakSet,Float64Array,Math,Worker:class {},MessageEvent:class {},performance:{now:()=>++at},
  document:{get readyState(){return ready},addEventListener:(name,fn,options)=>listeners.push({name,fn,options}),querySelector:()=>({classList:{contains:()=>refined}})},
  requestAnimationFrame:fn=>{if(!dropAll&&!(dropBeforeReady&&ready==='loading'))queue.push(fn);return at},
  SalahNativeSkyHost:{capture:()=>{if(captureThrows)throw Error('injected observation fault');return {generation:0}}},
  SalahSkyPreview:{frame:null,state:{}},SalahMoonRuntime:{state:{}},realSkyState:()=>({status:'ready'}),realSkyFrame:()=>context.refinedFrame};
 context.window=context;vm.runInNewContext(source,context,{filename:'actual-observer.js'});
 return {context,queue,ready(){ready='interactive';for(const row of [...listeners])if(row.name==='DOMContentLoaded'){row.fn();if(row.options?.once)listeners.splice(listeners.indexOf(row),1)}},tick(){assert(queue.length>0);queue.shift()()},refined(v){refined=v},fault(v){captureThrows=v}};
}
const cases=[];
function control(name,fn){fn();cases.push({name,status:'PASS'})}
control('pre-DOM callback loss is discriminated, not attributed to Firefox',()=>{
 const a=environment(old,{dropBeforeReady:true}),b=environment(selected,{dropBeforeReady:true});
 a.context.SalahSkyPreview.frame={raster:raster()};b.context.SalahSkyPreview.frame={raster:raster()};a.ready();b.ready();
 assert.equal(a.queue.length,0);assert.equal(b.queue.length,1);b.ready();assert.equal(b.queue.length,1);b.tick();assert.equal(b.context.__r0022ReadStages().ticks,1);
});
control('same raster legitimately records first then preview separately',()=>{
 const a=environment(old),b=environment(selected);for(const e of [a,b]){const frame={raster:raster()};e.context.SalahFirstPaint={value:frame};e.context.SalahSkyPreview.frame=frame;e.ready();e.tick()}
 assert.equal(a.context.__r0022ReadStages().records.length,1);assert.equal(b.context.__r0022ReadStages().records.map(r=>r.name).join(','),'first,preview');
});
control('first observation exception preserves prepared native value and records failure',()=>{
 const a=environment(old),b=environment(selected);const prepared={value:{raster:raster()}};
 for(const e of [a,b]){e.fault(true);try{e.context.SalahFirstPaint=prepared}catch(error){e.context.SalahFirstPaint=Object.freeze({error:String(error)})}}
 assert.notEqual(a.context.SalahFirstPaint,prepared);assert.equal(b.context.SalahFirstPaint,prepared);assert.equal(b.context.__r0022ReadStages().errors[0].stage,'first');
});
control('tick observation exception remains FAIL and does not erase later observation',()=>{
 const a=environment(old),b=environment(selected);for(const e of [a,b]){e.context.SalahSkyPreview.frame={raster:raster()};e.ready();e.fault(true)}
 assert.throws(()=>a.tick(),/injected/);assert.equal(a.queue.length,0);b.tick();assert.equal(b.queue.length,1);assert.equal(b.context.__r0022ReadStages().errors.length,1);
 b.fault(false);b.context.SalahSkyPreview.frame={raster:raster()};b.tick();assert.equal(b.context.__r0022ReadStages().records[0].name,'preview');assert.equal(b.context.__r0022ReadStages().errors.length,1);
});
const good=environment(selected);const frame={raster:raster()};good.context.SalahFirstPaint={value:frame};good.context.SalahSkyPreview.frame=frame;good.ready();good.tick();good.refined(true);good.context.refinedFrame={raster:raster()};good.tick();
const stalled=environment(selected,{dropAll:true});stalled.ready();
const failed=environment(selected);failed.fault(true);failed.context.SalahFirstPaint={value:{raster:raster()}};
const out={schema:'r0022-stage-observer-fault-controls/v1',scope:'Controlled observer behavior only; no identification of the retained native Firefox callback failure.',sources:{old:sha(old),selected:sha(selected),test:sha(fs.readFileSync(__filename))},cases,consumerInputs:{good:good.context.__r0022ReadStages(),stalled:stalled.context.__r0022ReadStages(),firstException:failed.context.__r0022ReadStages()}};
fs.writeFileSync(path.join(D,'stage-observer-r3-controls.json'),JSON.stringify(out,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({status:'PASS',cases:cases.length,sources:out.sources}));
