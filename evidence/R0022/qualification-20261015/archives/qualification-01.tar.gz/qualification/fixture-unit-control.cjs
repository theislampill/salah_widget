const fs=require('node:fs'),assert=require('node:assert/strict');
const source=fs.readFileSync('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget/src/native/index.html','utf8');
const start=source.indexOf('function wxUnitsMatch('),end=source.indexOf('\nfunction wxResponseZoneMatches',start);
assert(start>=0&&end>start);
const test=eval('('+source.slice(start,end)+')');
for(const units of ['c','f']){
 const suffix=units.toUpperCase();
 assert.equal(test({temperature_2m:'\u00c2\u00b0'+suffix},{units}),false);
 assert.equal(test({temperature_2m:'\u00b0'+suffix},{units}),true);
 assert.equal(test({temperature_2m:'\u00b0'+(units==='c'?'F':'C')},{units}),false);
}
console.log('PASS: exact native unit gate rejects retained malformed labels and wrong units; accepts corrected matching labels. Source-only fixture discriminator.');
