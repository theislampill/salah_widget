"""Exercise the actual capture predicates without importing/launching a browser."""
import ast,copy,hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load_function(path,name):
 tree=ast.parse(path.read_text(encoding='utf-8'));nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name==name];assert len(nodes)==1
 namespace={};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),namespace);return namespace[name]
qualify=load_function(D/'capture_instrumented_r4.py','qualify_clear_stages')
site_matches=load_function(D/'celestial_lifecycle_check_r2.py','site_matches')
inputs=json.loads((D/'stage-observer-r3-controls.json').read_bytes())['consumerInputs'];cases=[]
def check(name,condition):
 assert condition,name;cases.append({'name':name,'status':'PASS'})
check('actual three-stage observer positive',qualify(inputs['good'])['status']=='PASS')
check('armed observer without callbacks fails',qualify(inputs['stalled'])['status']=='FAIL')
check('first observation exception fails',qualify(inputs['firstException'])['status']=='FAIL')
for name in ['first','preview','refined']:
 bad=copy.deepcopy(inputs['good']);bad['records']=[r for r in bad['records']if r['name']!=name]
 check('missing '+name+' fails',qualify(bad)['status']=='FAIL')
for name in ['first','preview','refined']:
 for field in ['raw','mapped','rawSkySeparate','lunar']:
  bad=copy.deepcopy(inputs['good']);record=next(r for r in bad['records']if r['name']==name);record['field'][field]=None
  check(name+' missing '+field+' fails',qualify(bad)['status']=='FAIL')
bad=copy.deepcopy(inputs['good']);bad['errors']=[{'stage':'tick','message':'injected observation fault'}]
check('healthy later stages do not erase observer fault',qualify(bad)['status']=='FAIL')
for key,value in [('contract','unapproved'),('kneeEnergy',.004),('headroomEnergy',.021)]:
 bad=copy.deepcopy(inputs['good']);bad['records'][0]['field']['lunar'][key]=value
 check('altered '+key+' fails',qualify(bad)['status']=='FAIL')
native={'lat':28.5383,'lon':-81.3792,'tz':'America/New_York'}
check('exact A accepted',site_matches(native,28.5383,-81.3792,'America/New_York'))
check('retained hybrid longitude rejected',not site_matches({**native,'lon':-80.1918},28.5383,-81.3792,'America/New_York'))
check('wrong latitude rejected',not site_matches({**native,'lat':25.7617},28.5383,-81.3792,'America/New_York'))
check('wrong timezone rejected',not site_matches({**native,'tz':'UTC'},28.5383,-81.3792,'America/New_York'))
late_check=load_function(D/'capture_instrumented_r4.py','retain_late_observer_errors')
dispatch=load_function(D/'run_instrumented_r6.py','dispatch_status')
errors=[];late=copy.deepcopy(inputs['good']);late['errors']=[{'stage':'tick','message':'only after the 60s predicate'}]
check('pre-lifecycle stage positive remains distinct',qualify(inputs['good'])['status']=='PASS')
check('late-only exception retained in actual capture errors',late_check(errors,late)['status']=='FAIL' and bool(errors))
check('late-only exception fails actual dispatch consumer',dispatch(0,errors)=='FAILED_RETAINED')
check('missing post-lifecycle observer fails actual capture and dispatch',late_check(errors,None)['status']=='FAIL' and dispatch(0,errors)=='FAILED_RETAINED')
healthy=[];check('healthy later observation returns without invented faults',late_check(healthy,inputs['good'])['status']=='PASS' and dispatch(0,healthy)=='RETURNED')
out={'schema':'r0022-instrumented-consumer-controls/v1','scope':'Actual pure capture predicates, not native execution or scene qualification.','files':{name:sha(D/name)for name in ['capture_instrumented_r4.py','celestial_lifecycle_check_r2.py','stage-observer-r3-controls.json','test_instrumented_r6.py','run_instrumented_r6.py']},'cases':cases}
with (D/'instrumented-r6-controls.json').open('x',encoding='utf-8')as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps({'status':'PASS','cases':len(cases),'files':out['files']}))
