from pathlib import Path
D=Path(__file__).resolve().parent
s=(D/'stage_observer_r3.js').read_text()
start=s.index(' // Arm after the actual document is ready.')
end=s.index(' window.__r0022ReadStages=',start)
s=s[:start]+''' // An init script may run in the iframe's initial about:blank document.
 // Window listeners survive its replacement; a document listener and its rAF
 // do not. Start once per actual document and retire stale-document callbacks.
 const documents=new WeakMap(),started=new WeakSet();let documentSerial=0,activeDocument=null;
 const documentId=d=>{if(!documents.has(d))documents.set(d,++documentSerial);return documents.get(d);};
 stages.starts=[];
 const start=()=>{
  const d=document;if(d.URL==='about:blank'||d.readyState==='loading'||started.has(d))return;
  started.add(d);activeDocument=d;stages.startedAt=performance.now();
  const id=documentId(d);stages.starts.push({id,url:d.URL,at:stages.startedAt,timeOrigin:performance.timeOrigin});
  const tick=()=>{
   if(document!==d||activeDocument!==d)return;
   stages.ticks++;stages.lastTick=performance.now();
   try{if(d.querySelector('.c')?.classList.contains('real-sky-composed'))record('refined',window.realSkyFrame?.());else record('preview',window.SalahSkyPreview?.frame);}catch(e){fault('tick',e);}
   requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
 };
 window.addEventListener('DOMContentLoaded',e=>{if(e.target===document)start();});
 window.addEventListener('pageshow',e=>{if(e.target===document)start();});
 start();
''' + s[end:]
needle='()=>({ticks:stages.ticks,'
assert s.count(needle)==1
s=s.replace(needle,"()=>({document:{id:documentId(document),url:document.URL,active:activeDocument===document,readAt:performance.now(),timeOrigin:performance.timeOrigin},starts:stages.starts,ticks:stages.ticks,")
(D/'stage_observer_r4.js').write_text(s,encoding='utf-8')
