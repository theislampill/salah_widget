import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent
p=D/'run_instrumented.py';original=p.read_bytes()
needle=b"for name,identity in helpers.items():(out/'observers'/name).write_bytes((D/name).read_bytes())"
replacement=b"for helper_name,identity in helpers.items():(out/'observers'/helper_name).write_bytes((D/helper_name).read_bytes())"
assert original.count(needle)==1
prior=D/'run_instrumented_r1.py';assert not prior.exists();prior.write_bytes(original)
new=original.replace(needle,replacement);p.write_bytes(new)
assert new.replace(replacement,needle)==original
pins=json.loads((D/'instrumented-pins.json').read_bytes())
record={'originalSha256':hashlib.sha256(original).hexdigest(),'correctedSha256':hashlib.sha256(new).hexdigest(),'finding':'Top-level helper-copy loop reused name, overwriting the cell identity before lease/receipt/log paths were constructed. No instrumented run had executed.','correction':'Rename only the helper loop variable. Actual source, observer helpers, browser procedure and outcomes unchanged.','control':{}}
for old_loop in [True,False]:
 ns={'helpers':{'stage_observer.js':1,'celestial_lifecycle_check.py':2},'name':'candidate-chromium-dpr1-clear-stages-lifecycle-r1'}
 exec('for '+('name'if old_loop else'helper_name')+', identity in helpers.items(): pass',ns)
 record['control']['old'if old_loop else'corrected']=ns['name']
assert record['control']['old']=='celestial_lifecycle_check.py'and record['control']['corrected']=='candidate-chromium-dpr1-clear-stages-lifecycle-r1'
(D/'instrumented-identity-correction.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record))
