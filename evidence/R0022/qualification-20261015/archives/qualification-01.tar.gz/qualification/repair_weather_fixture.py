from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent
p=D/'capture_qualified.py';old=p.read_bytes();s=old.decode('utf-8')
bad_c='\u00c2\u00b0C';bad_f='\u00c2\u00b0F'
assert s.count(bad_c)==3 and s.count(bad_f)==3
s=s.replace(bad_c,r'\u00b0C').replace(bad_f,r'\u00b0F')
q=D/'capture_qualified_r2.py';q.write_text(s,encoding='utf-8',newline='')
receipt={'schema':'r0022-fixture-correction/v1','before':hashlib.sha256(old).hexdigest(),'after':hashlib.sha256(q.read_bytes()).hexdigest(),'change':'Six malformed temperature-unit literals (three C, three F) become Python Unicode escapes. Values, source units gate and renderer unchanged.','retained':'All weather r1 captures remain evidence of rejected fixture weather, never cloud/rain qualification.','cause':'Actual wxUnitsMatch requires exact degree-C/F metadata; prior labels contained an extra U+00C2.','proof':'Source-bound discriminator is fixture-unit-control.cjs; actual admitted provider data must still be observed in r2.'}
(D/'weather-fixture-correction.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
