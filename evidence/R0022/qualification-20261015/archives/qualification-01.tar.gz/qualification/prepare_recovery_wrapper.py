import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent
p=D/'run_cell_r2.py';old=p.read_bytes();new=old
needle=b"composition=state.get('sky',{}).get('last',{}).get('composition',{})"
replacement=b"sky=state.get('sky')or{};last=sky.get('last')or{};composition=last.get('composition')or{}"
assert new.count(needle)==1;new=new.replace(needle,replacement)
needle=b"receipt['weatherAdmission']={'nativeWeather':weather,'source':truth.get('currentWeatherSource'),'model':truth.get('model'),'cloud':composition}"
replacement=needle+b"\r\n  receipt['skyObservation']={'status':sky.get('status'),'assets':sky.get('assets'),'errors':sky.get('errors',[]),'hasFinalComposition':bool(last)}"
assert new.count(needle)==1;new=new.replace(needle,replacement)
out=D/'run_cell_r3.py';assert not out.exists();out.write_bytes(new)
assert new.replace(replacement,needle).replace(b"sky=state.get('sky')or{};last=sky.get('last')or{};composition=last.get('composition')or{}",b"composition=state.get('sky',{}).get('last',{}).get('composition',{})")==old
for state in [{'sky':None},{'sky':{'last':None}},{'sky':{'last':{'composition':{'x':1}}}}]:
 sky=state.get('sky')or{};last=sky.get('last')or{};composition=last.get('composition')or{}
 assert composition==({'x':1}if state=={'sky':{'last':{'composition':{'x':1}}}}else{})
r=json.loads((D/'candidate-chromium-dpr1-clear-recovery-1/results.json').read_bytes())
sky=r['runs'][0]['final']['sky'];assert sky['status']=='unavailable'and sky['last']is None and sky['assets']['error']=='Native sky asset timeout'
record={'schema':'r0022-recovery-fixture-correction/v1','originalWrapperSha256':hashlib.sha256(old).hexdigest(),'correctedWrapperSha256':hashlib.sha256(new).hexdigest(),'captureAdapterUnchanged':hashlib.sha256((D/'capture_qualified_r2.py').read_bytes()).hexdigest(),'originalResultSha256':hashlib.sha256((D/'candidate-chromium-dpr1-clear-recovery-1/results.json').read_bytes()).hexdigest(),'retainedOutcome':'20-second delay exceeds native-assets.mjs default 15-second deadline. Native unavailable result with last=null is legitimate. No retry was requested, so this capture proves neither recovery nor spontaneous recovery. Wrapper exception is separate and retained.','correction':'Wrapper tolerates explicit nullable native state and records unavailable status/errors without converting it into a visual or recovery PASS. Null and actual composition controls executed offline.','nextCases':[{'engine':'chromium','dpr':1,'hold':'all','delaySeconds':5,'purpose':'Slower full assets inside existing deadline, complete original 60-second sequence.'},{'engine':'firefox','dpr':2,'hold':'all','missing':True,'recoverAtSeconds':20,'purpose':'Missing full assets with existing explicit retry after source restored; original sequence and state controls.'}],'productChange':False}
(D/'recovery-fixture-correction.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record))
