from pathlib import Path
import ast,hashlib,json
C=Path(__file__).resolve().parent;O=C.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
 assert not p.exists(),str(p)
 p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
s=(C/'run_native_cost_r17.py').read_text(encoding='utf-8')
needle="assert review['status']==('APPROVED_FOR_SETUP_ONLY'if a.prepare_only else'APPROVED_FOR_MEASUREMENT')and review['adapterSha256']==sha(Path(__file__).read_bytes())"
assert s.count(needle)==1
s=s.replace(needle,"assert review['status']=='APPROVED_FOR_DIAGNOSTIC'and review['adapterSha256']==sha(Path(__file__).read_bytes())\n assert a.engine=='chromium'and a.dpr==1 and not a.prepare_only")
s=s.replace("R6 exact setup then ONLY changed admission scope, same full5s/fourABBA policy; other scopes unmeasured","One R6 baseline/candidate ABBA CPU ownership diagnostic;5s warmup per side and four5s profiles;not qualifying cost/noise retry")
start=s.index("   ctx,page,frames=await setup('original'")
end=s.index('\n finally:\n  server.shutdown()',start)
s=s[:start]+'''   ctx,page,frames=await setup('display',['baseline','candidate'])
   save(a.out/'quiescence-all.json',quiescence)
   raw={'schema':'r0022-paired-admission-diagnostic/v1','status':'ACQUIRING','sourceRuntime':runtime_identity(R)['treeSha256'],'baselineRuntime':baseline_identity['treeSha256'],'reviewSha256':sha(review_bytes),'setupSha256':sha((a.out/'quiescence-all.json').read_bytes()),'browserVersion':browser.version,'executableSha256':prior['executableSha256'],'powerSetting':subprocess.check_output(['powercfg','/getactivescheme'],text=True).strip(),'scope':'One ABBA diagnostic, not a qualifying budget comparison or noise repeat. Full stacks and untrimmed prepare/run/verify timings; GC is not arbitrarily charged to a caller.','warmups':[],'slots':[]}
   setup_script="""async()=>{const m=await import('/collector.mjs'),p=__r0022CostProbe;window.__r0022DiagnosticAdapter=m.admissionCostAdapter({...p.binding,rawResult:p.raw.result,request:p.raw.request,snapshot:()=>__r0022CostObserver.snapshot(),clone:v=>structuredClone(v)});const a=__r0022DiagnosticAdapter,start=performance.now();let calls=0;while(performance.now()-start<5000){a.prepare();a.run();a.verify();calls++;}return {calls,elapsedMs:performance.now()-start,observer:__r0022CostObserver.snapshot(),native:__r0022CostProbe.binding.readState()};}"""
   for side in ['baseline','candidate']:
    raw['warmups'].append({'side':side,**await frames[side].evaluate(setup_script)})
    save(a.out/'diagnostic.json',raw)
   profiler=await ctx.new_cdp_session(page);await profiler.send('Profiler.enable')
   for index,side in enumerate(['baseline','candidate','candidate','baseline']):
    before=await frames[side].evaluate('()=>({observer:__r0022CostObserver.snapshot(),native:__r0022CostProbe.binding.readState()})')
    await profiler.send('Profiler.start')
    try:
     result=await frames[side].evaluate("""()=>{const a=__r0022DiagnosticAdapter,start=performance.now(),calls=[];while(performance.now()-start<5000){const t0=performance.now();a.prepare();const t1=performance.now();a.run();const t2=performance.now();a.verify();const t3=performance.now();calls.push({prepareMs:t1-t0,runMs:t2-t1,verifyMs:t3-t2,startMs:t0,endMs:t3});}return {calls,elapsedMs:performance.now()-start,timeOrigin:performance.timeOrigin};}""")
    finally:
     profile=await profiler.send('Profiler.stop');profile_path=a.out/('slot-'+str(index)+'-'+side+'.cpuprofile');save(profile_path,profile['profile'])
    after=await frames[side].evaluate('()=>({observer:__r0022CostObserver.snapshot(),native:__r0022CostProbe.binding.readState()})')
    raw['slots'].append({'index':index,'side':side,'profile':profile_path.name,'profileSha256':sha(profile_path),'before':before,'after':after,**result})
    save(a.out/'diagnostic.json',raw)
   await profiler.detach();raw['status']='DIAGNOSTIC_RETURNED';save(a.out/'diagnostic.json',raw)
   await ctx.close();await browser.close();clean=True
'''+s[end:]
ast.parse(s)
driver=C/'run_admission_diagnostic_r3.py';assert not driver.exists();driver.write_text(s,encoding='utf-8',newline='\n')
p=json.loads((C/'PREMEASUREMENT_PINS_R17.json').read_bytes())
p.update(adapterSha256=sha(driver),scope='One serial Chromium DPR1 current-R6 baseline/candidate ownership diagnostic. Existing R17 matched raw physical inputs and counter/receiver fixtures; display setup only. Five-second warmup each, one four-slot ABBA sequence with five-second CDP profile each. Complete stacks and untrimmed prepare/run/verify timings. No production edit, six-scope rerun, qualifying cost, threshold adjustment or noise-repeat credit.',priorRawSha256=sha(C/'measure-chromium-dpr1-r17/raw.json'),andonInputSha256=sha(O/'andon-cord-pull-r1/INPUT.json'),andonReturnSha256=sha(O/'andon-cord-pull-r1/RETURN.md'),rejectionCondition='If current ownership evidence does not identify a concrete avoidable operation within the two permitted owners with output-preserving discrimination, stop optimization and report unresolved implementation/constraint conflict; no inferred irreducible floor.')
p['files']['prepare_admission_diagnostic_r3.py']=sha(Path(__file__))
save(C/'ADMISSION_DIAGNOSTIC_R3_PROPOSAL.json',p)
print(json.dumps({'proposal':sha(C/'ADMISSION_DIAGNOSTIC_R3_PROPOSAL.json'),'driver':sha(driver),'andonReturn':sha(O/'andon-cord-pull-r1/RETURN.md')}))
