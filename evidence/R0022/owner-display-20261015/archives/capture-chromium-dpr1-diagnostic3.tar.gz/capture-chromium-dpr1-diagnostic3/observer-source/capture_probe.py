"""ROOT-ONLY private L1 full-composition proposal capture. Never builds a tree.

Without --execute this validates arguments/source bindings and launches nothing.
Execution uses one disposable context, the real native consumers and advancing
real1x accepted time. Returned images are an unapproved proposal, not closure.
"""
import argparse, asyncio, base64, hashlib, http.server, importlib.util, json, math, re, sys, threading, time, traceback
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlsplit

HERE=Path(__file__).resolve().parent
RUN=HERE.parent
SCHEMA='r0022-l1-full-composition-probe/v1'
REGIONS={'left_hotspot':[9,207,35,245],'open_sky':[135,76,190,100],'lower_wash':[40,433,285,452]}
PROPOSED={'left_hotspot':85,'open_sky':80,'lower_wash':80}
def sha(b): return hashlib.sha256(b).hexdigest()
def identity(p):
 b=p.read_bytes();return {'path':str(p.resolve()),'sha256':sha(b),'bytes':len(b)}
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,value): p.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def module(name,p):
 spec=importlib.util.spec_from_file_location(name,p);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
def root_lease(a):
 p=RUN/'browser-lease.json';row=read(p)
 if row.get('status')!='ACTIVE' or row.get('owner')!='R0022 root' or row.get('leaseId')!=a.lease_id or Path(row.get('command','')).resolve()!=(HERE/'capture_probe.py').resolve():raise ValueError('Exact serial R0022 browser lease required')
 return {'ledger':identity(p),'lease':row}

def require_runtime_bindings(actual,base,allowed):
 left,right=base['files'],actual['files']
 if set(left)!=set(right):raise ValueError('Served inventory changed')
 for rel,row in left.items():
  if rel not in allowed and right[rel]!=row:raise ValueError('Protected runtime drift: '+rel)
 expected=read(HERE/'BUILT_RUNTIME.json')
 if actual!=expected:raise ValueError('Runtime differs from the exact independently reviewed prototype build')
 return {'baseTreeSha256':base['treeSha256'],'actualTreeSha256':actual['treeSha256'],'fullInventoryBound':True,'declaredChangedOutputs':allowed}

def preflight(a):
 source=read(HERE/'INPUTS.json');root=a.root.resolve();out=a.out.resolve()
 if root!=Path(source['root']).resolve():raise ValueError('Wrong served worktree')
 if out.exists() or not out.is_relative_to(RUN) or out.is_relative_to(root):raise ValueError('Fresh output outside served tree required')
 for row in source['sourceRows']:
  if identity(root/row['path'])['sha256']!=row['instrumented']['sha256']:raise ValueError('Source changed: '+row['path'])
 if identity(RUN/'COMPARISON_CONTRACT.md')['sha256']!=source['contractSha256']:raise ValueError('Predeclared comparison contract changed')
 if not a.executable.is_file():raise ValueError('Explicit native executable required')
 if a.stamp is not None and datetime.fromisoformat(a.stamp.replace('Z','+00:00')).tzinfo is None:raise ValueError('UTC offset required')
 bundle=(root/'real-sky/native-sky.js').read_text(encoding='utf-8')
 for rel in ['real-sky/native-preview.mjs','real-sky/native-host.mjs']:
  authored=(root/rel).read_text(encoding='utf-8')
  compiled=re.sub(r'^import .*?;\s*$', '',authored,flags=re.M)
  compiled=re.sub(r'\bexport (?=(?:const|let|function|class|async function)\b)','',compiled)
  if compiled not in bundle:raise ValueError('Generated output does not consume '+rel)
 return {'baseCommit':source['baseCommit'],'root':str(root),'out':str(out),'sourceBindings':source['sourceRows'],'init':identity(HERE/'probe-init.js'),'executable':identity(a.executable),'browserFamily':a.browser,'dpr':a.dpr,'clockFixture':a.stamp,'rootHeavyBrowserLease':root_lease(a) if a.execute else None,'builtByThisDriver':False,'externalEffects':'Disposable headless native browser and local fixture server; no personal profile or desktop access'}

def clock_script(stamp,origin):
 if stamp is None:return ''
 anchor=datetime.fromisoformat(stamp.replace('Z','+00:00')).timestamp()*1000
 # Offset only. Original Date.now keeps advancing and original age/clock-jump
 # guards observe that advance. Never freeze/postdate a result or reset epochs.
 return "(()=>{const D=Date,offset="+json.dumps(anchor-origin)+";window.Date=class extends D{constructor(...a){super(...(a.length?a:[D.now()+offset]));}static now(){return D.now()+offset;}};})();"
def validate_export(value,out):
 """Write and bind ORIGINAL typed view bytes; never reconstruct numeric arrays."""
 rows=[];pending=[]
 def walk(v,pointer=''):
  if isinstance(v,dict) and '$typed' in v:
   if not isinstance(v.get('base64'),str):raise ValueError('Missing original binary view at '+pointer)
   b=base64.b64decode(v['base64'],validate=True)
   if len(b)!=v['byteLength'] or sha(b)!=v['sha256']:raise ValueError('Original buffer byte/hash mismatch at '+pointer)
   widths={'Int8Array':1,'Uint8Array':1,'Uint8ClampedArray':1,'Int16Array':2,'Uint16Array':2,'Int32Array':4,'Uint32Array':4,'Float32Array':4,'Float64Array':8,'BigInt64Array':8,'BigUint64Array':8}
   kind=v['$typed'];offset=v.get('byteOffset');backing=v.get('backingByteLength');length=v.get('length')
   if not isinstance(offset,int) or isinstance(offset,bool) or offset<0 or not isinstance(backing,int) or isinstance(backing,bool) or backing<offset+len(b):raise ValueError('Invalid original view/backing identity at '+pointer)
   if kind in widths:
    if not isinstance(length,int) or isinstance(length,bool) or length<0 or length*widths[kind]!=len(b):raise ValueError('Typed length/byte length mismatch at '+pointer)
   elif kind not in ['ArrayBuffer','DataView'] or length is not None:raise ValueError('Unknown original buffer type at '+pointer)
   p=out/'buffers'/(sha(pointer.encode())+'.bin');pending.append((p,b,pointer,v))
   return {k:x for k,x in v.items() if k!='base64'}|{'file':str(p)}
  if isinstance(v,dict):return {k:walk(x,pointer+'/'+k) for k,x in v.items()}
  if isinstance(v,list):return [walk(x,pointer+'/'+str(i)) for i,x in enumerate(v)]
  return v
 result=walk(value)
 if not pending:raise ValueError('No original typed buffers were captured')
 for p,b,pointer,v in pending:
  p.parent.mkdir(exist_ok=True);p.write_bytes(b)
  rows.append({'pointer':pointer,'type':v['$typed'],'length':v['length'],'byteOffset':v['byteOffset'],'backingByteLength':v['backingByteLength'],**identity(p)})
 save(out/'INPUT_BUFFER_MANIFEST.json',{'schema':SCHEMA,'rows':rows});save(out/'ORIGINAL_INPUTS.json',result)
 return {'bufferCount':len(rows),'manifest':identity(out/'INPUT_BUFFER_MANIFEST.json'),'original':identity(out/'ORIGINAL_INPUTS.json')}
WIDGET_FRAME_SOURCE='/salah_widget/index.html#local=1&motion=full'

async def owned_widget_frame(page,origin,report):
 """Bind the one declared iframe element even while its child is about:blank.

 Parent DOMContentLoaded need not imply child navigation. No new wait or
 readiness criterion: the existing bounded native-ready wait follows this.
 """
 if page.url!=origin+'/iframe':raise ValueError('Unexpected capture parent URL')
 elements=await page.query_selector_all('iframe')
 if len(elements)!=1:raise ValueError('Expected exactly one capture iframe')
 element=elements[0]
 if await element.get_attribute('src')!=WIDGET_FRAME_SOURCE:raise ValueError('Unexpected capture iframe source')
 frame=await element.content_frame()
 report['frameAcquisition']={'childUrl':None if frame is None else frame.url,'sameParent':frame is not None and frame.parent_frame is page.main_frame,'declaredSource':await element.get_attribute('src')}
 if frame is None or frame.parent_frame is not page.main_frame:raise ValueError('Missing or foreign capture child frame')
 if frame.url not in ['', 'about:blank',origin+WIDGET_FRAME_SOURCE]:raise ValueError('Unexpected initial capture child URL: '+repr(frame.url))
 report['frameBinding']={'parentUrl':page.url,'declaredSource':WIDGET_FRAME_SOURCE,'initialChildUrl':frame.url,'method':'exact iframe element content_frame; existing native readiness wait unchanged'}
 return frame,element

async def verify_widget_frame(page,origin,frame,element,report):
 if page.url!=origin+'/iframe' or frame.parent_frame is not page.main_frame:raise ValueError('Capture frame parent changed')
 if await element.get_attribute('src')!=WIDGET_FRAME_SOURCE or await element.content_frame() is not frame:raise ValueError('Capture iframe ownership changed')
 if len(await page.query_selector_all('iframe'))!=1 or frame.url!=origin+WIDGET_FRAME_SOURCE:raise ValueError('Ready capture frame URL or cardinality differs')
 report['frameBinding']['readyChildUrl']=frame.url

async def preserve_failure(frame,report,out,error):
 """Call while the Playwright session is alive; retain the original failure."""
 report['status']='FAILED_OR_GATED_NO_PAIR';report['errors'].append(str(error))
 if frame is not None:
  try:await frame.page.screenshot(path=str(out/'failure-page.png'),full_page=True,animations='allow',caret='initial')
  except Exception:pass
 report.setdefault('exceptionDetails',[]).append({'type':type(error).__name__,'repr':repr(error),'traceback':''.join(traceback.format_exception(type(error),error,error.__traceback__))})
 if frame is None:return
 try:report['commonRecordChecks']=await frame.evaluate('()=>window.__L1QAProbe.commonRecordChecks??null')
 except Exception as diagnostic:report['errors'].append('diagnostic read: '+str(diagnostic))
 try:report['releaseAfterFailure']=await frame.evaluate('()=>window.__L1QAProbe.release()')
 except Exception as restore:report['errors'].append('release: '+str(restore))
 try:
  packed=await frame.evaluate('()=>window.__L1QAProbe.exportInputs()')
  save(out/'RAW_EXPORT.json',packed)
  report['inputBuffersAfterFailure']=validate_export(packed,out)
  (out/'RAW_EXPORT.json').unlink() # exact successful binary association retained separately
 except Exception as archive:report['errors'].append('original input archive: '+str(archive))
def png_controls(out,arms,dpr):
 from PIL import Image, ImageStat
 checks=[];rois={}
 for kind in ['page','card']:
  base=Image.open(out/f'ordinary-{kind}.png').convert('RGBA')
  for label in ['A','A-restored']:
   other=Image.open(out/f'{label}-{kind}.png').convert('RGBA')
   if base.size!=other.size or base.tobytes()!=other.tobytes():raise ValueError(f'{label} {kind} differs from ordinary full-composition pixels')
   checks.append({'label':label,'kind':kind,'pixelEqualToOrdinary':True,'dimensions':list(base.size)})
 for label in arms:
  image=Image.open(out/f'{label}-page.png').convert('RGB');regions={}
  for name,rect in REGIONS.items():
   physical=[int(v*dpr) for v in rect]
   if physical[0]<0 or physical[1]<0 or physical[2]>image.width or physical[3]>image.height:raise ValueError('Inherited page ROI outside actual screenshot')
   crop=image.crop(physical);mean=sum(ImageStat.Stat(crop).mean)/3
   regions[name]={'pageCssRect':rect,'devicePixelRect':physical,'arithmeticMeanRgbCode':mean,'unapprovedProposedMax':PROPOSED[name],
                  'approval':False,'statistic':'Arithmetic mean of three RGB code channels across every captured page-ROI pixel; not calibrated luminance'}
  rois[label]=regions
 return {'ordinaryEquality':checks,'rois':rois,'roiAcceptanceClaim':False}

async def run(a,pre):
 # Third-party imports/effects occur only after root supplied --execute.
 from playwright.async_api import async_playwright
 from importlib.metadata import version
 root=a.root.resolve();out=a.out.resolve();out.mkdir(parents=True)
 runtime=module('l1_canonical_runtime',root/'tools/cp9/runtime_identity.py')
 fixture=module('l1_existing_native_fixture',root/'tests/v1_browser.py')
 before=runtime.runtime_identity(root)
 source=read(HERE/'INPUTS.json')
 try:base_binding=require_runtime_bindings(before,read(HERE/'BASE_RUNTIME.json'),source['permittedRuntimeChanges'])
 except Exception as e:
  save(out/'RESULT.json',{'schema':SCHEMA,'status':'FAILED_OR_GATED_NO_PAIR','errors':[str(e)],'runtimeBefore':before,'nativeExecuted':False,'nodeComplete':False,'ownerApproved':False});return 2
 report={'schema':SCHEMA,'status':'RUNNING_UNAPPROVED_PROPOSAL','preflight':pre,'runtimeBefore':before,
         'publishedBaseRuntimeBinding':base_binding,
         'executionEnvironment':{'python':identity(Path(sys.executable)),'pythonVersion':sys.version,'playwrightVersion':version('playwright'),'pillowVersion':version('Pillow')},
         'startedRealUtc':datetime.now(timezone.utc).isoformat(),'ownerApproved':False,'formalRepairStarted':False,'qualified':False,'nodeComplete':False,
         'scope':'One instrumented full-composition held-input display A/B/A through real native consumers. Not ordinary live-motion/startup/performance or owner acceptance.',
         'clock':'System wall clock advances; optional existing scene fixture adds a fixed UTC offset at real1x. Original accepted job UTC/epoch/phase are never changed.',
         'syntheticProviders':True,'images':[],'arms':[],'errors':[],'fonts':[],'requests':[]}
 save(out/'RESULT.json',report)
 started_wall=time.time()*1000
 anchor=datetime.fromisoformat(a.stamp.replace('Z','+00:00')) if a.stamp else datetime.now(timezone.utc)
 def provider(u):
  host=urlsplit(u).hostname;v=fixture.fixture(u,True)
  if host=='api.aladhan.com':
   d=urlsplit(u).path.rstrip('/').split('/')[-1];day,month,year=map(int,d.split('-'))
   hd=11+(datetime(year,month,day)-datetime(2026,9,24)).days
   if not 1<=hd<=30:raise ValueError('Valid synthetic civil-calendar capture is supported only within the supplied bounded dates')
   v['data']['date']['gregorian'].update(date=d,day=str(day),month={'number':month},year=str(year))
   v['data']['date']['hijri'].update(day=str(hd),month={'number':4,'en':'Rabi al-Thani'},year='1448')
   v['data']['meta']['timezone']='America/New_York'
   v['data']['timings'].update(Fajr='06:21',Sunrise='07:26',Dhuhr='13:17',Asr='16:38',Maghrib='19:08',Sunset='19:08',Isha='20:13')
  elif host=='api.open-meteo.com':
   local=anchor.astimezone(timezone(timedelta(hours=-4)));query=parse_qs(urlsplit(u).query)
   v.update(latitude=float(query.get('latitude',['28.5383'])[0]),longitude=float(query.get('longitude',['-81.3792'])[0]),elevation=0,timezone='America/New_York',utc_offset_seconds=-14400)
   v['current'].update(time=local.strftime('%Y-%m-%dT%H:%M'),interval=900,weather_code=0,cloud_cover=0,cloud_cover_low=0,cloud_cover_mid=0,cloud_cover_high=0,precipitation=0,rain=0,visibility=20000)
   v['current_units']={'time':'iso8601','interval':'seconds','temperature_2m':'°C','apparent_temperature':'°C','dew_point_2m':'°C','wind_speed_10m':'m/s','precipitation':'mm','rain':'mm','showers':'mm','snowfall':'cm'}
  elif host in ['get.geojs.io','ipinfo.io']:v={'latitude':'28.5383','longitude':'-81.3792','loc':'28.5383,-81.3792','city':'Orlando fixture','country':'United States','country_code':'US','timezone':'America/New_York'}
  return v
 class Handler(http.server.SimpleHTTPRequestHandler):
  def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(root),**kwargs)
  def log_message(self,*args):pass
  def send_bytes(self,b,kind,status=200):
   self.send_response(status);self.send_header('Content-Type',kind);self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
  def translate_path(self,p):
   relative=unquote(urlsplit(p).path.removeprefix('/salah_widget/')).lstrip('/')
   target=(root/relative).resolve()
   if not target.is_relative_to(root):raise ValueError('Served path escaped root')
   return str(target)
  def do_GET(self):
   report['requests'].append({'url':self.path,'realWallMs':time.time()*1000})
   try:
    if self.path=='/iframe':
     # This is the unchanged published startup-capture container, not the
     # product builder's325x530 embed preset. Record actual offsets below.
     self.send_bytes(b'<!doctype html><meta charset="utf-8"><body style="margin:8px;background:#1a2335"><iframe title="Prayer Times" src="/salah_widget/index.html#local=1&motion=full" style="width:330px;height:534px;border:0;border-radius:28px;overflow:hidden" scrolling="no"></iframe>','text/html')
    elif self.path.startswith('/fixture?'):
     url=parse_qs(urlsplit(self.path).query)['url'][0];body=json.dumps(provider(url)).encode();report['requests'][-1].update(responseSha256=sha(body),synthetic=True)
     self.send_bytes(body,'application/json')
    elif self.path=='/favicon.ico':self.send_bytes(b'','image/x-icon',204)
    else:super().do_GET()
   except Exception as e:
    report['errors'].append('server: '+str(e))
    try:self.send_bytes(str(e).encode(),'text/plain',500)
    except BrokenPipeError:pass
 server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
 origin=f'http://127.0.0.1:{server.server_port}'
 settings={**fixture.SETTINGS,'lat':28.5383,'lon':-81.3792,'tz':'America/New_York','label':'CENTRAL FL','method':'2','units':'c','savedAt':int(anchor.timestamp()*1000)}
 browser=ctx=page=frame=None;font_tasks=[]
 async def capture_session(pw):
  nonlocal browser,ctx,page,frame
  try:
   report['leaseBeforeLaunch']=root_lease(a)
   options={'headless':True,'executable_path':str(a.executable.resolve())}
   if a.browser=='chromium':options.update(chromium_sandbox=True,args=['--disable-dev-shm-usage'])
   browser=await getattr(pw,a.browser).launch(**options)
   if browser.browser_type.name!=a.browser:raise ValueError('Actual browser family differs from requested engine')
   report['browser']={'family':browser.browser_type.name,'version':browser.version,'executable':identity(a.executable)}
   ctx=await browser.new_context(viewport={'width':390,'height':600},device_scale_factor=a.dpr,timezone_id='America/New_York',locale='en-US',reduced_motion='no-preference')
   clock=clock_script(a.stamp,started_wall)
   setting_script='if(location.protocol==="http:"&&!localStorage.getItem('+json.dumps(fixture.ROOT_KEY)+'))localStorage.setItem('+json.dumps(fixture.ROOT_KEY)+','+json.dumps(json.dumps(settings))+');'
   fetch_script="{const original=window.fetch.bind(window);window.fetch=(input,init)=>{const u=new URL(typeof input==='string'?input:input.url,location.href);return original(u.origin!==location.origin&&['api.aladhan.com','api.open-meteo.com','api.rainviewer.com','get.geojs.io','ipinfo.io'].includes(u.hostname)?'"+origin+"/fixture?url='+encodeURIComponent(u.href):input,init);};}"
   init=(HERE/'probe-init.js').read_text(encoding='utf-8')+'\n'+clock+'\n'+setting_script+'\n'+fetch_script
   report['contextInitScript']={'sha256':sha(init.encode()),'bytes':len(init.encode()),'oneOrderedInitializer':True}
   await ctx.add_init_script(init)
   page=await ctx.new_page();page.on('pageerror',lambda e:report['errors'].append('page: '+str(e)))
   async def font_response(response):
    if response.request.resource_type=='font' or urlsplit(response.url).hostname=='fonts.googleapis.com':
     b=await response.body();p=out/'fonts'/sha(b);p.parent.mkdir(exist_ok=True);p.write_bytes(b)
     report['fonts'].append({'url':response.url,'status':response.status,'resourceType':response.request.resource_type,**identity(p)})
   def schedule_font(response):
    if response.request.resource_type=='font' or urlsplit(response.url).hostname=='fonts.googleapis.com':font_tasks.append(asyncio.create_task(font_response(response)))
   page.on('response',schedule_font)
   def failed_resource(request):
    if request.resource_type=='font' or urlsplit(request.url).hostname=='fonts.googleapis.com':report['errors'].append('required font/CSS request failed: '+request.url+' '+str(request.failure))
   page.on('requestfailed',failed_resource)
   await page.goto(origin+'/iframe',wait_until='domcontentloaded')
   frame,owned_element=await owned_widget_frame(page,origin,report)
   await frame.wait_for_function("()=>{const q=window.__L1QAProbe,m=window.SalahMoonRuntime?.state;return q?.host&&m?.current&&m.visibleSource==='refined-terrain'&&window.SalahRealSky?.state?.status==='ready'&&document.fonts.status==='loaded';}",timeout=a.ready_timeout*1000)
   await verify_widget_frame(page,origin,frame,owned_element,report)
   if font_tasks:await asyncio.gather(*font_tasks)
   report['fontResponsesBound']={'captured':len(report['fonts']),'meaning':'Actual observed CSS/font response bytes; no guessed fixed file count or claim of unused-font coverage'}
   report['leaseBeforeArm']=root_lease(a);armed=await frame.evaluate('()=>window.__L1QAProbe.arm()')
   await frame.wait_for_function('(n)=>window.__L1QAProbe.admissions>=n&&window.__L1QAProbe.ready()',arg=armed['nextAdmission'],timeout=15000)
   transaction=await frame.evaluate('()=>window.__L1QAProbe.begin()');report['ordinary']=transaction
   # Diagnostic acquisition stops on the original common-input mismatch; no arm selection.
   await frame.evaluate('()=>window.__L1QAProbe.checkpoint()')
   raise ValueError('DIAGNOSTIC_ONLY: first common checkpoint stable; no comparison requested')
   async def coordinates():
    parent=await page.locator('iframe').evaluate("el=>{const r=el.getBoundingClientRect(),s=getComputedStyle(el);return {x:r.x,y:r.y,width:r.width,height:r.height,clientLeft:el.clientLeft,clientTop:el.clientTop,clientWidth:el.clientWidth,clientHeight:el.clientHeight,transform:s.transform};}")
    child=await frame.evaluate("()=>{const r=document.querySelector('.c').getBoundingClientRect();return {card:{x:r.x,y:r.y,width:r.width,height:r.height},viewport:{width:innerWidth,height:innerHeight},dpr:devicePixelRatio};}")
    if parent['transform']!='none':raise ValueError('Undeclared transformed parent prevents exact ROI-coordinate mapping')
    if parent['clientWidth']!=child['viewport']['width'] or parent['clientHeight']!=child['viewport']['height']:raise ValueError('Parent/child scale or clipping requires an explicit new mapping')
    if child['card']['width']!=325 or child['card']['height']!=530 or parent['clientWidth']!=330 or parent['clientHeight']!=534 or child['dpr']!=a.dpr:raise ValueError('Actual protected card/capture-container geometry or DPR differs')
    child['parentIframe']=parent;child['pageCardOrigin']={'x':parent['x']+parent['clientLeft']+child['card']['x'],'y':parent['y']+parent['clientTop']+child['card']['y']}
    child['nativeCardDimensions']=[325,530];child['captureContainerDimensions']=[330,534]
    child['inheritedPageRegions']=REGIONS;child['roiBoundsApproved']=False;return child
   report['coordinates']=await coordinates()
   async def screenshots(label):
    root_lease(a)
    before_check=await frame.evaluate('()=>window.__L1QAProbe.checkpoint()');began=time.monotonic()
    await page.screenshot(path=str(out/f'{label}-page.png'),full_page=True,animations='allow',caret='initial',timeout=10000)
    await frame.locator('.c').screenshot(path=str(out/f'{label}-card.png'),animations='allow',caret='initial',timeout=10000)
    after_check=await frame.evaluate('()=>window.__L1QAProbe.checkpoint()')
    report['images'].append({'label':label,'before':before_check,'after':after_check,'captureStartMonotonic':began,'captureEndMonotonic':time.monotonic(),
      'page':identity(out/f'{label}-page.png'),'card':identity(out/f'{label}-card.png'),'coordinates':await coordinates()})
   await screenshots('ordinary')
   for label in ['A','B','C','A-restored']:
    root_lease(a)
    arm=await frame.evaluate('(label)=>window.__L1QAProbe.select(label)',label);report['arms'].append(arm)
    await screenshots(label)
   report['finalCheckpoint']=await frame.evaluate('()=>window.__L1QAProbe.checkpoint()')
   report['release']=await frame.evaluate('()=>window.__L1QAProbe.release()')
   # Export the already captured immutable inputs AFTER restoring normal
   # presentation. Export time is never asserted to be a current publication.
   packed=await frame.evaluate('()=>window.__L1QAProbe.exportInputs()');report['inputBuffers']=validate_export(packed,out)
   report['pixelControls']=png_controls(out,['A','B','C','A-restored'],a.dpr)
   if report['errors']:raise ValueError('Retained browser/server errors prevent a successful pair')
   report['status']='PAIR_CAPTURED_UNAPPROVED_PROPOSAL'
  except Exception as e:await preserve_failure(frame,report,out,e)
  finally:
   if font_tasks:
    try:await asyncio.gather(*font_tasks)
    except Exception as e:await preserve_failure(frame,report,out,ValueError('font response custody: '+str(e)))
   if ctx is not None:
    try:await ctx.close();ctx=None
    except Exception as e:report['errors'].append('context close: '+str(e))
   if browser is not None:
    try:await browser.close();browser=None
    except Exception as e:report['errors'].append('browser close: '+str(e))
 try:
  async with async_playwright() as pw:await capture_session(pw)
 except Exception as e:report['errors'].append('session: '+str(e));report['status']='FAILED_OR_GATED_NO_PAIR'
 finally:
  server.shutdown();server.server_close()
  report['runtimeAfter']=runtime.runtime_identity(root);report['runtimeUnchanged']=report['runtimeAfter']==before
  if not report['runtimeUnchanged']:report['status']='FAILED_OR_GATED_NO_PAIR';report['errors'].append('Served runtime changed during capture')
  try:report['leaseAfterCapture']=root_lease(a)
  except Exception as e:report['errors'].append(str(e))
  if report['errors']:report['status']='FAILED_OR_GATED_NO_PAIR'
  report['endedRealUtc']=datetime.now(timezone.utc).isoformat();save(out/'RESULT.json',report)
 if report['status']!='PAIR_CAPTURED_UNAPPROVED_PROPOSAL':return 2
 return 0

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--root',type=Path,required=True,help='Root-owned isolated tree already patched and built by root')
 p.add_argument('--out',type=Path,required=True,help='New root-owned evidence directory inside RUN')
 p.add_argument('--browser',choices=['chromium','firefox'],required=True)
 p.add_argument('--executable',type=Path,required=True)
 p.add_argument('--dpr',type=int,choices=[1,2],default=1)
 p.add_argument('--stamp',default=None,help='Optional existing moving wall-clock scene anchor; omission keeps actual system UTC')
 p.add_argument('--ready-timeout',type=int,default=180)
 p.add_argument('--execute',action='store_true',help='Root-only consequential action: launch the isolated native capture')
 p.add_argument('--lease-id',help='Actual ACTIVE root sole heavy-browser lease in RUN/ACTIVE_LEDGER.json; this driver never changes it')
 a=p.parse_args()
 if a.ready_timeout<1 or a.ready_timeout>180:p.error('Use the existing bounded180-second readiness window; no new resource budget')
 try:
  pre=preflight(a)
  if not a.execute:print(json.dumps({'status':'PREFLIGHT_ONLY_NO_BROWSER','preflight':pre,'nativeExecuted':False}));return 0
  return asyncio.run(run(a,pre))
 except Exception as e:
  print(json.dumps({'status':'FAILED_OR_GATED_NO_PAIR','error':str(e),'nodeComplete':False}),file=sys.stderr);return 2
if __name__=='__main__':sys.exit(main())
