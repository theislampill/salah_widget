from pathlib import Path
import hashlib,json,re,subprocess,sys,zipfile
from PIL import Image
O=Path(__file__).resolve().parent;D=O/sys.argv[1];R=json.loads((D/'results.json').read_bytes());video=Path(R['runs'][0]['video']);Q=D/'video-inspection';Q.mkdir(exist_ok=False)
ffmpeg=Path('C:/Users/theis/AppData/Local/ms-playwright/ffmpeg-1011/ffmpeg-win64.exe')
def sha(b):return hashlib.sha256(b).hexdigest()
selected={5,25,50,100,200,375,750,1125,1500};rows=[];selectedRows=[]
with (Q/'decoder.log').open('wb')as err:
 p=subprocess.Popen([str(ffmpeg),'-v','info','-i',str(video),'-f','rawvideo','-pix_fmt','rgb24','-'],stdout=subprocess.PIPE,stderr=err)
 index=0;size=390*600*3
 while True:
  b=p.stdout.read(size)
  if not b:break
  assert len(b)==size
  extrema=(min(b),max(b));row={'frame':index,'nominalSeconds':index/25,'sha256':sha(b),'minimum':extrema[0],'maximum':extrema[1],'allBlack':extrema[1]==0};rows.append(row)
  if index in selected:
   dest=Q/f'original-frame-{index:04}.png';Image.frombytes('RGB',(390,600),b).save(dest);selectedRows.append({**row,'file':dest.name})
  index+=1
 assert p.wait()==0
traceEvents=[]
with zipfile.ZipFile(D/'capture-trace.zip')as z:
 for name in z.namelist():
  if name.endswith('.trace'):
   for line in z.read(name).splitlines():
    e=json.loads(line)
    if e.get('type')=='screencast-frame':traceEvents.append(e)
 gaps=[traceEvents[i]['timestamp']-traceEvents[i-1]['timestamp']for i in range(1,len(traceEvents)) if 'timestamp'in traceEvents[i]and'timestamp'in traceEvents[i-1]]
record={'schema':'r0022-original-native-video-inspection/v1','originalVideo':{'file':str(video),'sha256':sha(video.read_bytes()),'bytes':video.stat().st_size},'decoder':{'path':str(ffmpeg),'sha256':sha(ffmpeg.read_bytes())},'frames':rows,'selectedOriginalFrames':selectedRows,'trace':{'sourceSha256':sha((D/'capture-trace.zip').read_bytes()),'frameCount':len(traceEvents),'maxTimestampGap':max(gaps)if gaps else None,'timestampUnit':'native Playwright trace milliseconds; video encoder25fps may repeat native frames'},'allBlackFrames':sum(r['allBlack']for r in rows),'scope':'Decoded original native recording, no image alteration. All-frame hashes/extrema are an integrity/blank control only; sampled original frames and full sequence still need independent visual inspection. No continuity PASS inferred from frame count or scalar.'}
(Q/'inspection.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');(Q/'trace-frames.json').write_text(json.dumps(traceEvents,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in record.items()if k not in ['frames']}))
