import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {pathToFileURL} from 'node:url';
const O='C:/Users/theis/.codex/work-products/r0022-execution-20261015',R='C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const decode=v=>{
 if(v?.$typed){const b=fs.readFileSync(v.file);assert.equal(sha(b),v.sha256);assert.equal(b.length,v.byteLength);const a=b.buffer.slice(b.byteOffset,b.byteOffset+b.length);return new globalThis[v.$typed](a);}
 if(Array.isArray(v))return v.map(decode);
 if(v&&typeof v==='object')return Object.fromEntries(Object.entries(v).map(([k,x])=>[k,decode(x)]));return v;
};
const packed=JSON.parse(fs.readFileSync(O+'/capture-chromium-dpr1-r4/ORIGINAL_INPUTS.json'));
const o=decode(packed.original),r=o.result.raster,fields=o.fields,q=o.request.options;
assert(r.drawn>0&&r.stellarLinear.some(x=>x>0));
const bytes=v=>Buffer.from(v.buffer,v.byteOffset,v.byteLength);
const before=Object.fromEntries(Object.entries(r).filter(([,v])=>ArrayBuffer.isView(v)).map(([k,v])=>[k,sha(bytes(v))]));
const m=await import(pathToFileURL(R+'/real-sky/native-preview.mjs'));
const recomputed=m.nativeAtmosphereFields(r.physicalState,r.atmosphere,q.view,q.diffuse.residualNight,...fields.grid);
let fieldError=0;for(let i=0;i<r.skyBackgroundLinear.length;i++)fieldError=Math.max(fieldError,Math.abs(recomputed.background[i]-r.skyBackgroundLinear[i])/Math.max(1,Math.abs(r.skyBackgroundLinear[i])));
assert(fieldError<=64*Number.EPSILON);
assert.equal(sha(bytes(recomputed.lunarBackgroundLinear)),sha(bytes(fields.lunarBackgroundLinear)));
const input={...r,solarBackgroundLinear:fields.solarBackgroundLinear,solarAerosolLinear:fields.solarAerosolLinear,lunarBackgroundLinear:fields.lunarBackgroundLinear,twilightDisplay:fields.twilightDisplay};
const out=m.nativeSkyPresentation(input,q.view,null);
assert.equal(out.effectiveExposure,r.effectiveExposure);assert.equal(out.physicalSkyBackgroundLinear,r.skyBackgroundLinear);
for(const key of ['stellarLinear','diffuseLinear','diffusePhysicalLinear']){assert.equal(out[key],r[key]);assert.equal(sha(bytes(out[key])),before[key]);}
let nonLunarError=0,positiveRaw=0,positiveMapped=0,formulaError=0,maxIndex=0,mappedMaxIndex=0;
const samples=[];
for(let i=0;i<r.linear.length;i+=3){
 const l=fields.lunarBackgroundLinear,Y=.2126*l[i]+.7152*l[i+1]+.0722*l[i+2],z=r.effectiveExposure*Y;
 const t=z<=.003?z:.003+.020*(z-.003)/(.020+z-.003),scale=z>0?t/z:1;
 if(z>0)positiveRaw++;
 if(out.lunarNightDisplayLinear[i]>0)positiveMapped++;
 if(l[i]>l[maxIndex])maxIndex=i;
 if(out.lunarNightDisplayLinear[i]>out.lunarNightDisplayLinear[mappedMaxIndex])mappedMaxIndex=i;
 samples.push([l[i],out.lunarNightDisplayLinear[i]]);
 for(let c=0;c<3;c++){
  const j=i+c;formulaError=Math.max(formulaError,Math.abs(out.lunarNightDisplayLinear[j]-l[j]*scale));
  nonLunarError=Math.max(nonLunarError,Math.abs((out.linear[j]-out.skyBackgroundLinear[j])-(r.linear[j]-r.skyBackgroundLinear[j])));
 }
}
assert(positiveRaw>0&&positiveRaw===positiveMapped);assert(formulaError<1e-14);assert(nonLunarError<64*Number.EPSILON);assert.equal(maxIndex,mappedMaxIndex);
samples.sort((a,b)=>a[0]-b[0]);for(let i=1;i<samples.length;i++)assert(samples[i][1]+1e-14>=samples[i-1][1]);
for(const[k,hash]of Object.entries(before))assert.equal(sha(bytes(r[k])),hash,'raw changed: '+k);
assert.throws(()=>m.nativeSkyPresentation({...input,lunarBackgroundLinear:Float64Array.from(fields.lunarBackgroundLinear,x=>x*1e12)},q.view,null),RangeError);
const globalDark=Float64Array.from(out.linear,x=>x*.9);
assert(globalDark.some((v,i)=>Math.abs((v-out.skyBackgroundLinear[i])-(r.linear[i]-r.skyBackgroundLinear[i]))>1e-10));
const result={schema:'r0022-native-captured-lunar-field-check/v1',status:'PASS_ACTUAL_CAPTURED_FIELD_SOURCE_CHECK',inputSha256:sha(fs.readFileSync(O+'/capture-chromium-dpr1-r4/ORIGINAL_INPUTS.json')),sourceSha256:sha(fs.readFileSync(R+'/real-sky/native-preview.mjs')),physicsGrid:fields.grid,samples:r.linear.length/3,catalogueDrawn:r.drawn,positiveRaw,positiveMapped,fieldError,formulaError,nonLunarError,rawPeakPixel:maxIndex/3,mappedPeakPixel:mappedMaxIndex/3,exposure:r.effectiveExposure,rawArraySha256:before,negativeMutations:['wrong lunar units rejected by actual consumer','global darkening violates actual non-lunar residual'],scope:'Original native Chromium raster and original typed bytes through exact ordinary prototype owner. Source computation supplements original full-card capture; not a second native browser or performance/continuity qualification.'};
fs.writeFileSync(O+'/h1-prototype/native-field-check.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
