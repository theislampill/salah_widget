# L1 paired complete-scene review plan — unapproved and NOT_RUN

This is one display-contract proposal, not an adopted repair or formal
qualification. Root predeclared K=.003/H=.020 and left<=85/open<=80/lower<=80
as proposed review bounds. Owner approval is absent. Source controls cannot
approve these values or qualify the ordinary scene. No prior attribution or
units proof is to be repeated.

1. Independently review the two authored-owner changes and source receipts.
   Pin the root's current joined control tree and a disposable candidate whose
   only product differences are this patch. Match all other joined source,
   generated assets, original catalogue/diffuse, fonts/UI, V5/body/opacity,
   weather/config/currentness owners. Root builds both and verifies generated
   identities/V1; child did not build. Do not apply this patch to generated core,
   immutable vendor or expanded entries.

2. Before any formal qualification, obtain owner selection of the display
   contract/bounds and complete-scene target. The first prepared capture is a
   labelled proposal A/B for that decision, never formal qualification. Use
   the preferred accepted Orlando fixture in PAIR_INPUT.json. It pins physical
   UTC1790301623718.6577, E10.591635515622682, nominal24, generation0 and the
   original physical Sun/Moon/view/atmosphere. The document's baseline UTC is
   different; do not combine its samples or later snapshot time with this frame.
   Synthetic prayer/calendar/weather inputs and pressure/AOD/residual assumptions
   stay disclosed. No SIM date/time/phase/body-position overrides are introduced.

3. One current complete accepted raw frame plus its native foreground/V5 inputs
   must be captured for both arms. Retain Float64 buffers/source identifiers and
   actual accepted job/UTC/E, currentness result, complete Moon surface/coverage
   provenance/geometry and actual cloud/UI state. Hash each before intervention.
   The retained unit JSON contains state/E and scalar probes, not the complete
   raw buffers or V5 surface. If those buffers are unavailable, stop the pair;
   do not reconstruct a stripped sky or call unrelated live frames equivalent.
   If root needs a fresh current accepted frame, predeclare its exact observed
   UTC/E/state before applying the candidate and use that one buffer set twice;
   report the new identity separately from the inherited preferred frame.

4. Extend only the private capture harness with a labelled frozen-composition
   transaction. The existing startup driver has no exact-pair freeze option.
   Freeze the accepted temporal/painter/animation state for this comparison;
   do not alter OS clock/storage or bypass native identity/age/phase fences.
   Copy the same complete raw raster into each consumer, retaining original E.
   Apply original versus proposed nativeSkyPresentation to matching authored
   lunar decomposition at the same physical direction and exact worker grid.
   Send each complete result through the actual calendar mask, native foreground
   join and retained V5 Moon compose/encode consumers with the same material,
   coverage/opaque-body geometry/cloud bytes and complete DOM layers. Keep every
   contribution and foreground. A sky-only PNG, a removed layer, arbitrary
   replacement canvas or stale result injection cannot be the accepted pair.
   The control consumer output must first match the ordinary full composite;
   otherwise the harness lacks equivalence and no candidate bounds can pass.

5. Save full-card/full-page control and candidate PNGs with pair source/runtime,
   fixture/hook hash, engine/executable/version/DPR/viewport, accepted UTC/E/state,
   input-buffer hashes, output hashes, capture wall/monotonic timing and native
   composition/currentness receipts. Verify all non-lunar/raw input hashes and
   original E after both arms. Restore the original complete composition and
   verify its output, then end the transaction. Frozen comparison is not proof
   of normal real1x motion or unchanged startup latency.

6. Use the inherited ROI rectangles, not newly selected crops:
   left_hotspot [9,207,35,245], open_sky [135,76,190,100], lower_wash
   [40,433,285,452]. Retained PNG dimensions/ROI authority are in PAIR_INPUT.json.
   Resolve their exact original capture origin/crop/scale before applying them
   to a new screenshot; never interpret a page coordinate as a native pixel or
   silently shift a rectangle. Compute arithmetic mean RGB code over the exact
   matched rectangles. Full-scenes decide; left<=85, open/lower<=80 are only the
   proposed clear-scene review bounds. Also inspect that eligible broad lunar
   illumination remains positive, the left source is not near-white, body phase
   and texture/opacity are readable, stars do not show through, fixed footprints,
   header/footer and protected gains remain acceptable. A mean alone cannot
   establish owner selection or calibration.

7. Root shows the unstripped complete pair to the owner and records exact
   approval/rejection/current source selection. Reject or return for one bounded
   repair if the wash/source remains unacceptable or lunar illumination/body
   readability is erased. Do not silently tune K/H/ROIs, remeter, relocate the
   field, raise stars or dim the whole sky. An unselected prototype remains OPEN.

Only a selected owner-approved contract/candidate proceeds to the existing
targeted qualification: eligible bright-Moon clear/cloudy/rainy nights; actual
below-horizon and low-illumination negatives; dawn on both sides of the horizon,
day; first->initial->preview->refined1x, Chromium/Firefox, DPR1/2, protected
body/gain/occlusion and raw/currentness/generation/seek/A-B-A/profile/slow-or-
missing-assets recovery. Keep first-complete-scene/callback-cost budgets exact.
The host now decomposes deep-night accepted fields; its additional allocation
and callback cost are unmeasured and remain a targeted gate. No terrain rerun
or startup/audit campaign restart is implied by this proposal.

Existing ordinary acquisition template, ROOT-ONLY and not the frozen pair:

    python tools/cp9/celestial_startup_check.py --root <verified-control-or-candidate-tree> --out <new-root-owned-evidence-directory> --scene clear --modes cold --duration 180 --video

Use recorded actual browser executable/driver, fresh root-owned output and a
serial lease. Do not add --layers. The template advances at real1x and cannot
by itself establish the frozen pair. Root must prepare/admit the capture
transaction described above; no nonexistent --freeze-pair flag is suggested.
No browser/terrain/build/performance/capture occurred in this worker.
