# R0022-L1 display-contract proposal returned

RETURNED_UNAPPROVED_DISPLAY_CONTRACT_PROPOSAL. Formal repair remains not started;
this private code is a reviewable prototype only. No shared source, builder,
browser, terrain, external write, visual selection or L1/S10 closure occurred.

The two authored owners are native-preview.mjs and native-host.mjs. Original
E/raw radiance and flux arrays are retained. The existing lunar sample/grid is
exposed separately and compressed with K=.003/H=.020 in original E*Ym energy,
using one positive RGB scale at its original physical direction. Only the
existing night branch consumes it. The existing smooth -18..-12 weight gives
full intervention at<=-18, C1 endpoints and exact absence at>=-12; the original
solar meter/registration/chroma/shoulder stays on original inputs. First paint
uses the same preview owner without changing its source module.

Completed seven-check unit and attribution proof was consumed by exact owner
hashes; no unit/attribution/terrain campaign was repeated. The retained frame
runtime differs from selected PR43 and is not called final-head acceptance.

Final cheap controls: candidate12/12 pass versus the same test bytes on pinned
base5pass/7semanticfail. Tests cover raw/E/non-lunar input preservation, common
RGB/positive ordering, zero/absent/below-horizon negatives, exact knee/C1,
twilight fade with zero and positive solar, exact original solar policy at and
above-12, endpoint derivatives, invalid-field rejection, identical old grid/mean
arithmetic, reduced-preview units and refined-host/currentness routing. The
first test syntax error and the10pass/2fail preparation attempt are preserved
separately; source and harness repairs are distinguished in REPORT.json.

This is source evidence on small synthetic arrays, not rendered ROI acceptance,
calibration, units proof, performance, native/build or public qualification.
The soft curve is mathematically strictly increasing and the declared finite
controls retain positive ordering; floating asymptotic ties are possible.

Proposed owner-review bounds remain UNAPPROVED: left ROI mean<=85 native RGB
codes, open/lower wash means<=80, eligible positive lunar contribution retained.
PAIR_INPUT.json binds inherited exact ROI rectangles and preferred UTC/E/state.
CAPTURE_PLAN.md requires the same frozen accepted complete raw/V5/foreground
input set, original E, full original versus candidate consumer pipelines and
all DOM/body/cloud/catalogue/foreground terms. No stripped ablations qualify it.
The existing startup driver has no exact frozen-pair option; the root must
prepare/admit that private capture transaction. The retained receipt is not a
serialized raw framebuffer or V5 surface. Resolve original ROI origin/scale
before metrics. Complete scenes and owner selection outrank these source tests.

Source hashes, exact minimal product/test-interface patches, immutable-source
manifest, original failures and final commands/receipts are in REPORT.json.
The expensive existing comparison fixtures need two explicit lunar-field
propagations and the same host matching-grid binding for their worker input;
their case thresholds are unchanged and they were not executed.

Main residual risk: deep-night refined host now decomposes the atmospheric field,
so additional allocation/callback cost needs the unchanged root budget gate.
The nonlinear join can change apparent body/star pixels with unchanged V5/raw
inputs. Native full-scene protected-gain/opacity/occlusion, stage/DPR/engine,
weather/negative/dawn/day/currentness/recovery qualifications remain not run.

Next: independent proposal review, root build, labelled complete-scene A/B for
owner selection. Selected contract/bounds/target must be approved before formal
qualification. Root retains integration, owner selection and closure authority.
