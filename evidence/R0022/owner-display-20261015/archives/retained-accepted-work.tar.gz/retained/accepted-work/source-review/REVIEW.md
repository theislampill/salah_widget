# R0022-L1 independent source review

**Source controls pass; the proposed full-scene pair is not ready to execute.** No introduced blocker was demonstrated by this bounded source review. This is not approval of K/H, ROI limits, a complete-scene target, repair, integration or qualification. All DAG nodes remain incomplete.

The sealed weather return `REPORT.json` SHA256 `6d732867dadf84fb6feb9d48430bc4bba5cfeacce34fe1a815894373fe7dd063` and seal `77eb2bd8aa0d3d4397b049f34d752d2eb7ad68446dda8f87313a65573236cbb5` verify. All111 manifest entries and six seal bindings match. The patch exactly reproduces the two source deltas; 35 of37 paired `real-sky` files remain identical. Root's two current owners still match the proposal base. This does not recompute or qualify the root's moving joined runtime.

| Owner | Base SHA256 | Candidate SHA256 |
| --- | --- | --- |
| real-sky/native-preview.mjs | c3f52ebc40b710f33ef24d14360cc81a09e7c8de8eec1d6d046dd4ec874ccc8e | 7a5497b43610f85fc1825cee1565a8ff29247d2ecf35e7b5cdeb4175b8fd0a3e |
| real-sky/native-host.mjs | d904064710e40921c29c5a8440eaffdb2f036aaa849d5273ba1f03e6ee5a3c70 | 85dcbe9826432e5f4d2266b0761f1eb96a4daba56b5f66480c9d36f6b3d91187 |

The proposal implements only hypothesis H1: lunar-only highlight/adaptation at the existing physical direction. H2 compact-aureole registration has not been implemented or compared in this return. The original control is not H2. No unit-conversion correction was demonstrated here; the completed unit and attribution evidence was consumed without replay.

The declared mapping is identity through z=K=.003 and `K+H*(z-K)/(H+z-K)` above K, H=.020, where z uses original E times lunar weighted relative-V0 flux. Its mathematical derivative is positive; one positive RGB scale retains lunar chromaticity and pixel direction. It asymptotes to .023; floating-point ties near that asymptote remain possible. Only the existing night branch receives the intervention, full at Sun≤−18° and absent at Sun≥−12°. The original solar meter/registration/colour/shoulder inputs remain unchanged. This is a proposed display convention, not calibrated local photometry.

Nine independent cheap controls pass: mixed nonuniform lunar/zero pixels with eight raw buffers unmutated; controls that reject the original uncompressed mapping plus exposure change, deletion and relocation; zero/daylight exact equality; nonuniform authored sampling/interpolation and excluded-pixel support; actual 30-second identity/ABA fences; deep-night host routing and step3/8/16 grid binding; opaque calendar masking and one cloud application; first/preview/detail source ownership; and the missing pair interface. Four memory-only discriminators are caught. The final run verifies 78 source digests. Small synthetic arrays and extracted function contexts are not actual native/V5/model or framebuffer evidence.

The source establishes these preservation boundaries:

- Original raw sky and lunar arrays, E, physical state, source diagnostics, stellar/diffuse and provenance references are retained and input arrays are not mutated in the tested mapping. Separate display arrays change. The current public full-frame getter returns a result AFTER presentation; it is not a serialized original worker-result custody point.
- Lunar eligibility remains in the unchanged scientific model (including the fully below-disc-horizon zero gate), using the same physical directions and neutral lunar proxy. Native accepted weather still owns cloud transmission once; this patch does not add a provider, cloud grant, native calendar-light permission or catalogue gain.
- `native-contract`, lifecycle, host composition/failure and first-paint source are unchanged. First paint calls the changed preview owner, so unchanged first-paint bytes do not imply unchanged startup behaviour. Source controls reject stale/changed identity before decomposition; real first-publication and phase/surface currentness are not tested here.
- V5 terrain/material/Earthshine/coverage, body geometry and opacity source are untouched by the two-owner patch. Their consumers add displayed atmospheric foreground to the lunar surface. The small opaque-join control changes body codes with the same material bytes while retaining zero direct-star leakage. Identical V5 inputs therefore do not establish protected gains, body appearance or full DPR/occlusion qualification.

Three material prerequisites remain:

1. **Exact pair admission.** The runner has no same-input frozen-pair option. Capture the raw worker result plus its original accepted request before `nativeSkyPresentation`, and all same V5/native/DOM inputs; reproduce the ordinary complete control, then perform a current A/B/A through the actual consumers. `--layers` is explicitly diagnostic: it paints a replacement canvas, omits `nativeCalendarRegion`, and leaves separate detail composition. The original 2026-09-25 scalar receipt and its f265 runtime cannot be treated as a current accepted raw frame at the selected PR43 runtime.
2. **Added host/first-paint cost.** Refined deep night previously skipped `nativeAtmosphereFields`; the candidate performs it synchronously at every accepted worker frame. For325×530 and grid41×67, active compression allocates eight full Float64 RGB buffers plus four grid buffers: 33,346,176 explicit allocated bytes (~31.80 MiB) on this path. This is allocation volume derived from code, not measured peak/live memory or timing. A zero lunar field still incurs decomposition; preview/day fields also allocate the additional lunar grid/raster. Worker timings and the composition timer exclude the new admission decomposition. The existing warmed native/callback/first-complete gates must measure the changed scope; no budget result is claimed.
3. **Contract and full-scene acceptance.** K/H and ROI85/80/80 are unapproved. The inherited ROIs use a390×600 DPR1 iframe-page screenshot; `.c` coordinates from the child frame alone do not establish parent-page origin/scale. Actual full-scene review must retain broad positive illumination and direction, body/gains/opacity/footprints, source/catalogue provenance, weather/negatives, twilight/day, actual publication fences and restoration. Positivity and lower codes do not satisfy those gates.

`NEXT_ROOT_OPERATION.md` gives the minimal root-owned transaction. This reviewer performed no build/browser/native/performance/scientific replay, source integration, Git/GitHub/ledger write or real profile/storage/clipboard/geolocation action. The original weather return is unchanged. Three reviewer-harness failures (syntax, omitted twilight mock, support-coordinate mismatch) are retained under `evidence`; only owned harness code was repaired, with no assertions weakened or product source edited.

Exact cheap verification commands, from any directory:

```powershell
& 'C:/Users/theis/AppData/Local/Programs/Python/Python311/python.exe' -I -S -B 'C:/Users/theis/Documents/Codex/salah-rlgwo-execution-20261009/workers/settings_docs/l1-display-review/review_inputs.py'
& 'C:/Users/theis/AppData/Local/OpenAI/Codex/bin/node.exe' 'C:/Users/theis/Documents/Codex/salah-rlgwo-execution-20261009/workers/settings_docs/l1-display-review/source_controls.mjs'
```

These commands write only this review directory. The Node controls are bound to the acquired source digests and reject drift. Root should use the sealed result for intake, not rerun these commands merely for confidence.
