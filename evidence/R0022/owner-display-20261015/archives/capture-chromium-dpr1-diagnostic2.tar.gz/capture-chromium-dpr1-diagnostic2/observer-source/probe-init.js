(()=>{
// Private QA contract only; ordinary native/worker/V5 guards remain authoritative.
function l1RequireAdmission(a){
 const bad=message=>{throw new Error('L1_PROBE_ADMISSION: '+message);};
 if(!a||a.lifecycleCurrent!==true||a.nativeCurrent!==true||a.current?.paused)bad('original currentness guard rejected');
 const {request:j,current:s,result:r,moon:m,surface:v}=a;
 if(!j?.observer||!j.native||!r?.raster||r.status!=='ready')bad('missing original request/result');
 const stamp=j.observer.utcMs;
 if(!Number.isFinite(stamp)||!Number.isFinite(s?.utcMs)||Math.abs(s.utcMs-stamp)>30000)bad('original accepted UTC expired');
 if(!Number.isSafeInteger(j.native.lifecycleEpoch)||j.native.lifecycleEpoch!==a.lifecycleEpoch)bad('lifecycle epoch changed');
 if(r.utcMs!==stamp||r.observer?.utcMs!==stamp||r.raster.physicalState?.utcMs!==stamp)bad('borrowed or relabelled UTC');
 if(JSON.stringify(r.native)!==JSON.stringify(j.native))bad('result native authority differs from request');
 const q=r.raster,w=q.width,h=q.height,count=w*h*3;
 if(!Number.isInteger(w)||!Number.isInteger(h)||w<1||h<1||j.options?.view?.width!==w||j.options?.view?.height!==h||j.options?.dpr!==1)bad('raw/request dimensions differ');
 if(!Number.isFinite(q.effectiveExposure)||q.effectiveExposure<=0)bad('original exposure missing');
 const array=(x,type,length)=>ArrayBuffer.isView(x)&&x.constructor.name===type&&x.length===length;
 for(const name of ['linear','backgroundLinear','skyBackgroundLinear','stellarLinear'])if(!array(q[name],'Float64Array',count))bad('original raw '+name+' is missing');
 const hash=x=>typeof x==='string'&&/^[a-f0-9]{64}$/i.test(x);
 if(q.diffuseState?.enabled){
  for(const name of ['diffuseLinear','diffusePhysicalLinear'])if(!array(q[name],'Float64Array',count))bad('original diffuse '+name+' is missing');
  if(typeof q.diffuseState.sourceId!=='string'||!q.diffuseState.sourceId||!hash(q.diffuseState.sourceSha256)||!hash(q.diffuseState.catalogueSha256))bad('diffuse source binding is missing');
 }
 if(!m?.current||!m.accepted||!Number.isSafeInteger(m.epoch)||m.accepted.scene?.mode!=='calendar-canonical')bad('actual calendar V5 source is unavailable');
 const p=m.phasePrecision;
 if(p?.maximumPositionErrorDevicePixels!==.0416||!Number.isFinite(p.targetPositionErrorBound)||p.targetPositionErrorBound<0||p.targetPositionErrorBound>p.maximumPositionErrorDevicePixels)bad('original V5 phase bound rejected');
 if(a.expectedMoon&&(m.epoch!==a.expectedMoon.epoch||JSON.stringify(m.accepted)!==JSON.stringify(a.expectedMoon.accepted)))bad('V5 epoch/profile/physical scene changed');
 if(!v||v.identity!==m.accepted.identity||!Number.isInteger(v.size)||v.size<8||v.size>768||!Number.isFinite(v.extent)||v.extent<=0)bad('V5 physical surface identity/shape is missing');
 const n=v.size*v.size;
 if(!array(v.linear,'Float32Array',3*n)||!array(v.calendarLinear,'Float32Array',3*n)||!array(v.coverage,'Float32Array',n))bad('actual V5 buffers are missing');
 for(let i=0;i<n;i++){
  const c=v.coverage[i];if(!Number.isFinite(c)||c<0||c>1)bad('V5 coverage is invalid');
  for(let k=0;k<3;k++)for(const field of [v.linear,v.calendarLinear]){const x=field[3*i+k];if(!Number.isFinite(x)||x<0||x>c+1e-6)bad('V5 premultiplied material is invalid');}
 }
 return true;
}
function l1RequireCommon(expected,actual){
 const required=['rawResult','request','lunarFields','v5Inputs','nativeForeground','domAndFonts'];
 const valid=x=>typeof x==='string'&&/^[a-f0-9]{64}$/i.test(x);
 if(!expected||!actual)throw new Error('L1_PROBE_COMMON: absent map');
 for(const key of required)if(!valid(expected[key])||!valid(actual[key]))throw new Error('L1_PROBE_COMMON: missing or malformed '+key);
 const left=Object.keys(expected).sort(),right=Object.keys(actual).sort();
 if(JSON.stringify(left)!==JSON.stringify(right))throw new Error('L1_PROBE_COMMON: key set changed');
 for(const key of left)if(!valid(expected[key])||!valid(actual[key])||expected[key]!==actual[key])throw new Error('L1_PROBE_COMMON: changed '+key);
 return true;
}

// Injected only into root's disposable QA context. Contract functions are
// prepended by prepare_probe.py; no clock, permissions or product layer removal.
if(window.__L1QAProbe)throw Error('L1_PROBE: duplicate init');
const l1Sha=async bytes=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');
const l1Utf8=value=>new TextEncoder().encode(JSON.stringify(value));
const l1View=v=>new Uint8Array(v.buffer,v.byteOffset,v.byteLength);
async function l1Record(v,full=false){
 if(v===undefined)return {$undefined:true};
 if(typeof v==='number'&&!Number.isFinite(v))return {$number:String(v)};
 if(v===null||typeof v!=='object')return v;
 if(ArrayBuffer.isView(v)||v instanceof ArrayBuffer){
  const b=v instanceof ArrayBuffer?new Uint8Array(v):l1View(v),out={$typed:v.constructor.name,length:v.length??null,byteOffset:v.byteOffset??0,byteLength:b.length,backingByteLength:v.buffer?.byteLength??b.length,sha256:await l1Sha(b)};
  if(full){let s='';for(let i=0;i<b.length;i+=16384)s+=String.fromCharCode(...b.subarray(i,i+16384));out.base64=btoa(s);}return out;
 }
 if(Array.isArray(v))return Promise.all(v.map(x=>l1Record(x,full)));
 if(v instanceof Map)return {$map:await l1Record([...v.entries()],full)};
 if(v instanceof Set)return {$set:await l1Record([...v],full)};
 const out={};for(const key of Object.keys(v).sort())out[key]=await l1Record(v[key],full);return out;
}
function l1Box(el){if(!el)return null;const r=el.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,left:r.left,top:r.top,right:r.right,bottom:r.bottom};}
function l1ReadCanvas(el){if(!el)return null;const c=el.getContext('2d');if(!c)throw Error('L1_PROBE: actual canvas2D unavailable');return {width:el.width,height:el.height,rect:l1Box(el),style:el.getAttribute('style'),rgba:c.getImageData(0,0,el.width,el.height).data};}
function l1Dom(){
 const card=document.querySelector('.c');if(!card)throw Error('L1_PROBE: card unavailable');
 const nodes=[card,...card.querySelectorAll('*')];
 const style=(el,pseudo)=>{const s=getComputedStyle(el,pseudo),values={};for(const k of s)values[k]=s.getPropertyValue(k);return values;};
 return {cardHTML:card.outerHTML,cardRect:l1Box(card),dpr:devicePixelRatio,viewport:{width:innerWidth,height:innerHeight},
  styles:nodes.map((el,i)=>({i,tag:el.tagName,rect:l1Box(el),style:style(el),before:style(el,'::before'),after:style(el,'::after')})),
  headStyles:[...document.querySelectorAll('head style,head link[rel="stylesheet"]')].map(el=>({tag:el.tagName,href:el.getAttribute('href'),text:el.tagName==='STYLE'?el.textContent:null})),
  fonts:{status:document.fonts.status,faces:[...document.fonts].map(f=>({family:f.family,style:f.style,weight:f.weight,stretch:f.stretch,unicodeRange:f.unicodeRange,status:f.status}))},
  geometry:{photo:l1Box(document.querySelector('.mphoto')),disc:l1Box(document.querySelector('.moon-mask-disc')),detail:l1Box(document.querySelector('.moon-detail-canvas'))},
  layers:[...card.querySelectorAll('canvas,svg,.scrim,.atmo,#wxfx,.times,.d,.belt')].map(el=>({tag:el.tagName,class:el.getAttribute('class'),style:el.getAttribute('style'),rect:l1Box(el)}))};
}
const l1Probe={schema:'r0022-l1-full-composition-probe/v1',enabled:true,armed:false,holding:false,admissions:0,failure:null,host:null,
 assertAdmission:l1RequireAdmission,assertCommon:l1RequireCommon,
 bindHost(value){if(this.host)throw Error('L1_PROBE: duplicate host binding');this.host=value;},
 bindNativeInputs(reader){if(this.nativeInputs||typeof reader!=='function')throw Error('L1_PROBE: absent/duplicate native-input binding');this.nativeInputs=reader;},
 abort(reason){this.failure??=String(reason);},
 noteAdmission(value){if(this.holding)this.abort('A new admitted worker result replaced the common transaction');this.admissions++;this.lastAdmission=value;},
 surface(){return this.adoptedSurface??null;},
 arm(){if(this.holding)throw Error('L1_PROBE: transaction already active');this.failure=null;this.armed=true;return {nextAdmission:this.admissions+1};},
 ready(){return !!this.host?.ready()&&typeof this.nativeInputs==='function'&&!!this.adoptedSurface&&!!window.SalahMoonRuntime?.state?.current&&document.fonts?.status==='loaded';},
 async begin(){
  if(!this.armed||!this.ready()||this.holding)throw Error('L1_PROBE: complete admitted input not ready');
  this.holding=true;this.savedAnimations=document.getAnimations().map(a=>({animation:a,state:a.playState,time:a.currentTime,rate:a.playbackRate}));
  try{
   for(const {animation} of this.savedAnimations)animation.pause();
   await Promise.all(this.savedAnimations.map(({animation})=>animation.ready));
   this.inputs=this.host.begin();
   this.publishedOrdinaryPixels=await this.outputRecord();this.host.current();
   this.ordinary=this.host.ordinary();this.label='ordinary';this.host.current();
   this.commonInputs=null;this.domAndFontsChecks=null;this.ordinaryPixels=await this.outputRecord();this.baseline=await this.commonHashes();this.host.current();
   if(this.publishedOrdinaryPixels.sky.rgba.sha256!==this.ordinaryPixels.sky.rgba.sha256||this.publishedOrdinaryPixels.detail.rgba.sha256!==this.ordinaryPixels.detail.rgba.sha256)throw Error('L1_PROBE: original published ordinary output differs from held-input ordinary recomposition');
   return {schema:this.schema,ordinary:this.ordinaryPixels,common:this.baseline,sourceCheck:this.inputs.sourceCheck,check:this.host.current(),
    originalPublishedOrdinary:{skyRgbaSha256:this.publishedOrdinaryPixels.sky.rgba.sha256,detailRgbaSha256:this.publishedOrdinaryPixels.detail.rgba.sha256,pixelEqualToHeldOrdinary:true},
    heldAnimations:this.savedAnimations.map(({state,time,rate,animation})=>({originalState:state,originalTime:time,rate,heldTime:animation.currentTime})),
    acceptedClock:'Original native real1x accepted UTC; no freeze/relabel/epoch reset'};
  }catch(e){this.abort(e.message);try{await this.release();}catch(restore){this.cleanupErrors??=[];this.cleanupErrors.push(String(restore.message??restore));}throw e;}
 },
 async commonHashes(){
  if(this.failure)throw Error('L1_PROBE: '+this.failure);const common=this.host.common(),moon=window.SalahMoonRuntime.state;
  const source={...common,v5Inputs:{surface:this.surface(),accepted:moon.accepted,epoch:moon.epoch,
   backing:l1ReadCanvas(window.SalahNativeSkyHost.lunarSurface()),adoptions:this.surfaceAdoptions},domAndFonts:l1Dom()};
  source.nativeForeground.acceptedNativeInputs=this.nativeInputs();
  // Full-card inputs include every original DOM canvas except the two output
  // consumers which intentionally differ between arms. Preserve their pixels.
  source.domAndFonts.unchangedCanvases=[...document.querySelector('.c').querySelectorAll('canvas')]
   .filter(el=>!el.matches('.real-sky-canvas,.moon-detail-canvas')).map(el=>({class:el.className,pixels:l1ReadCanvas(el)}));
  if(source.domAndFonts.fonts.status!=='loaded')throw Error('L1_PROBE: fonts changed/unfinished');
  if(!this.commonInputs)this.commonInputs=structuredClone(source);
  const out={};for(const [key,value] of Object.entries(source)){
   const record=await l1Record(value);out[key]=await l1Sha(l1Utf8(record));
   const changes=this.commonRecordChecks??={};
   const rec=changes[key]??={baselineSha256:out[key],baseline:record,firstChanged:null};
   if(out[key]!==rec.baselineSha256&&!rec.firstChanged)rec.firstChanged={sha256:out[key],record};
   if(key==='domAndFonts'){
    const checks=this.domAndFontsChecks??={baselineSha256:null,lastSha256:null,firstChanged:null};
    checks.baselineSha256??=out[key];checks.lastSha256=out[key];
    if(out[key]!==checks.baselineSha256&&!checks.firstChanged)checks.firstChanged={label:this.label??null,sha256:out[key],recordJSON:JSON.stringify(record)};
   }
  }
  this.host.current();return out;
 },
 async outputRecord(){
  const out=this.host.outputs(),detail=l1ReadCanvas(document.querySelector('.moon-detail-canvas'));
  if(!detail||getComputedStyle(document.querySelector('.moon-detail-canvas')).visibility!=='visible')throw Error('L1_PROBE: actual device detail output unavailable');
  return {sky:await l1Record(out.sky),detail:await l1Record(detail),detailState:structuredClone(window.SalahMoonDetail.state),composition:out.composition,display:out.display,lunarDisplay:out.lunarDisplay};
 },
 async select(label){
  if(!this.holding||this.failure)throw Error('L1_PROBE: transaction not usable');
  const arm=label==='C'?'C':label==='B'?'B':label==='A'||label==='A-restored'?'A':null;if(!arm)throw Error('L1_PROBE: invalid label');
  l1RequireCommon(this.baseline,await this.commonHashes());const result=this.host.render(arm);
  const common=await this.commonHashes();l1RequireCommon(this.baseline,common);const outputs=await this.outputRecord();
  if(arm==='A'&&(outputs.sky.rgba.sha256!==this.ordinaryPixels.sky.rgba.sha256||outputs.detail.rgba.sha256!==this.ordinaryPixels.detail.rgba.sha256))throw Error('L1_PROBE: A does not reproduce ordinary full sky/detail outputs');
  this.label=label;this.selected={label,arm,common,outputs,check:this.host.current(),composeCheck:result.check};return this.selected;
 },
 async checkpoint(){if(!this.holding||this.failure)throw Error('L1_PROBE: transaction failed');l1RequireCommon(this.baseline,await this.commonHashes());return {label:this.label,check:this.host.current()};},
 async exportInputs(){
  const original=this.inputs??this.host?.captured();if(!original)throw Error('L1_PROBE: no original admitted inputs');
  return {schema:this.schema,bufferBytes:'Original typed view bytes; no numeric reconstruction; explicit view/backing lengths',
   endianness:(()=>{const a=new Uint16Array([1]);return new Uint8Array(a.buffer)[0]===1?'little':'big';})(),
   original:await l1Record(original,true),commonInputs:await l1Record(this.commonInputs,true),
   ordinaryOutputHashes:this.ordinaryPixels?{skyRgbaSha256:this.ordinaryPixels.sky.rgba.sha256,detailRgbaSha256:this.ordinaryPixels.detail.rgba.sha256}:null,
   publishedOrdinaryOutputHashes:this.publishedOrdinaryPixels?{skyRgbaSha256:this.publishedOrdinaryPixels.sky.rgba.sha256,detailRgbaSha256:this.publishedOrdinaryPixels.detail.rgba.sha256}:null,
   commonRecordChecks:this.commonRecordChecks??null,baselineCommon:this.baseline??null,domAndFontsChecks:this.domAndFontsChecks??null,admission:this.lastAdmission??null,failure:this.failure,cleanupErrors:this.cleanupErrors??[],
   completeness:this.inputs&&this.commonInputs&&this.ordinaryPixels?'complete-transaction-inputs':'admission-only-or-incomplete-transaction'};
 },
 async release(){
  let error=null,result=null;try{result=this.host?.end()??null;}catch(e){this.abort(e.message);error=e;}
  finally{
   this.holding=false;this.armed=false;
   for(const {animation,state,time,rate} of this.savedAnimations??[])try{animation.playbackRate=rate;if(state==='running')animation.play();else if(state==='paused')animation.pause();else if(state==='finished')animation.finish();else if(state==='idle')animation.cancel();}catch(e){this.abort(e.message);error??=e;}
   this.savedAnimations=[];
  }
  if(error)throw error;return {consumerRestore:result,failure:this.failure};
 }};
window.__L1QAProbe=l1Probe;
let l1Detail=window.SalahMoonDetail;
Object.defineProperty(window,'SalahMoonDetail',{configurable:true,enumerable:true,get(){return l1Detail;},set(value){
 l1Detail=value;if(!value||typeof value.adopt!=='function')return;
 const original=value.adopt;value.adopt=function(surface){const result=original.call(this,surface);l1Probe.adoptedSurface=surface;l1Probe.surfaceAdoptions=(l1Probe.surfaceAdoptions??0)+1;return result;};
}});

})();
