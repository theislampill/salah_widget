"""Adapt the accepted held-frame probe onto current main; no browser launch."""
from pathlib import Path
import difflib, hashlib, json, subprocess

OUT=Path(__file__).resolve().parent
ROOT=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget')
OLD=Path('C:/Users/theis/Documents/Codex/salah-rlgwo-execution-20261009')
PROBE=OLD/'candidates/l1-full-composition-probe50-02/salah_widget'
DRIVER=OLD/'workers/root/l1-full-composition-driver-r6'
BASE='fc8d13338f9274a768580cda5a805492f80c510d'
PR43='50e46b7ecfde9c8bea9c0cf00b6017afaf27aab9'
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def once(s,a,b):
    assert s.count(a)==1,(a[:100],s.count(a))
    return s.replace(a,b,1)
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()==BASE
resuming=bool(git('status','--porcelain').strip())
owners=['real-sky/native-preview.mjs','real-sky/native-host.mjs','src/native/index.html']
baseline={p:git('show',BASE+':'+p) for p in owners}
patch=''
for rel in owners:
    old=git('show',PR43+':'+rel).decode()
    instrumented=(PROBE/rel).read_text(encoding='utf-8')
    if rel=='real-sky/native-host.mjs':
        # Production recovery expanded clear(). Retain that owner verbatim;
        # only prepend the historical transaction-abort observation.
        start=" function clear(reason='invalidated'){"
        end=' // Identity/age fences'
        current=baseline[rel].decode()
        live_clear=current[current.index(start):current.index(end)]
        old=old[:old.index(start)]+live_clear+old[old.index(end):]
        instrumented=instrumented[:instrumented.index(start)]+live_clear.replace(start,start+"if(l1Probe?.holding)l1Probe.abort(reason);",1)+instrumented[instrumented.index(end):]
    patch+=''.join(difflib.unified_diff(old.splitlines(True),instrumented.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel,n=1))
(OUT/'comparison').mkdir(exist_ok=True)
p=OUT/'comparison/inherited-instrumentation.patch';p.write_text(patch,encoding='utf-8',newline='\n')
subprocess.run(['git','apply','--reverse' if resuming else '--check','--check',str(p)],cwd=ROOT,check=True)
for rel,b in baseline.items():
    target=OUT/'comparison/baseline'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
if not resuming:
    runtime={}
    for rel in git('ls-tree','-r','--name-only',BASE).decode().splitlines():
        if rel in {'index.html','offline.html','config.js','builder.html'} or rel.startswith('real-sky/') or (rel.startswith('moon/') and rel.split('/')[1] not in {'src','tests'}):
            b=(ROOT/rel).read_bytes();runtime[rel]={'bytes':len(b),'sha256':sha(b)}
    save(OUT/'comparison/BASE_RUNTIME.json',{'schemaVersion':1,'files':runtime,'treeSha256':sha(''.join(v['sha256']+'  '+k+'\n' for k,v in sorted(runtime.items())).encode()),'algorithm':'SHA256 of sorted <sha256><two spaces><relative POSIX path><LF> records'})
    subprocess.run(['git','apply',str(p)],cwd=ROOT,check=True)
else:
    assert (OUT/'comparison/BASE_RUNTIME.json').is_file()

preview=(ROOT/owners[0]).read_text(encoding='utf-8')
h2=(OUT/'h2-proposal.mjs').read_text(encoding='utf-8')
mapping=preview[preview.index('export function nativeSkyPresentationL1Proposal'):preview.index('export function nativeAtmosphereFieldsL1Proposal')]
mapping=mapping.replace('nativeSkyPresentationL1Proposal','nativeSkyPresentationH2Proposal',1).replace('nativeLunarNightDisplay(raster,1-strength)','nativeLunarCompactDisplay(raster,1-strength)')
assert 'nativeLunarNightDisplay(' not in mapping
preview+='\n'+h2+'\n'+mapping
(ROOT/owners[0]).write_text(preview,encoding='utf-8',newline='\n')

host=(ROOT/owners[1]).read_text(encoding='utf-8')
host=once(host,'nativeSkyPresentationL1Proposal} from','nativeSkyPresentationL1Proposal,nativeLunarCompactFields,nativeSkyPresentationH2Proposal} from')
host=once(host,'   l1Transaction={capture:own',"""   const disc=document.querySelector('.moon-mask-disc'),matrix=disc?.getScreenCTM(),rect=canvas.getBoundingClientRect();
   if(!matrix)throw new Error('L1_PROBE: calendar anchor unavailable');
   const moonAnchor={x:matrix.e-rect.left,y:matrix.f-rect.top};
   const compactFields=nativeLunarCompactFields(own.result.raster.physicalState,own.result.raster.atmosphere,own.request.options.view,own.request.options.diffuse.residualNight,moonAnchor,...grid);
   Object.assign(fields,compactFields);
   l1Transaction={capture:own""")
host=once(host,"if(!['A','B'].includes(arm))","if(!['A','B','C'].includes(arm))")
host=once(host,"const raster=arm==='A'?raw:nativeSkyPresentationL1Proposal({...raw,solarAerosolLinear:fields.solarAerosolLinear,", "const mapper=arm==='C'?nativeSkyPresentationH2Proposal:nativeSkyPresentationL1Proposal;\n   const raster=arm==='A'?raw:mapper({...raw,lunarCompactLinear:fields.lunarCompactLinear,lunarRegisteredLinear:fields.lunarRegisteredLinear,lunarRegistration:fields.lunarRegistration,solarAerosolLinear:fields.solarAerosolLinear,")
host=once(host,"   return l1ComposeTarget({...own.result,raster});", "   if(arm==='C'&&raster.lunarDisplayPresentation?.hypothesis!=='H2')throw new Error('L1_PROBE: compact-only registration did not execute');\n   return l1ComposeTarget({...own.result,raster});")
(ROOT/owners[1]).write_text(host,encoding='utf-8',newline='\n')
init=(DRIVER/'probe-init.js').read_text(encoding='utf-8')
init=once(init,"const arm=label==='B'?'B':label==='A'", "const arm=label==='C'?'C':label==='B'?'B':label==='A'")
(OUT/'comparison/probe-init.js').write_text(init,encoding='utf-8',newline='\n')
rows=[]
for rel in owners:
    b=(ROOT/rel).read_bytes();rows.append({'path':rel,'base':{'bytes':len(baseline[rel]),'sha256':sha(baseline[rel])},'instrumented':{'bytes':len(b),'sha256':sha(b)}})
save(OUT/'comparison/SOURCES.json',{'baseCommit':BASE,'historicalProbeBase':PR43,'sourceRows':rows,'purpose':'Disposable native complete-composition A/H1/H2 comparison; not production or startup acceptance','contractSha256':sha((OUT/'COMPARISON_CONTRACT.md').read_bytes()),'permittedRuntimeChanges':['index.html','offline.html','real-sky/native-sky.js','real-sky/native-preview.mjs','real-sky/native-host.mjs','moon/BUILD.json']})
print(json.dumps({'status':'PROTOTYPE_SOURCES_PREPARED','owners':rows}))
