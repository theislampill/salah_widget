from pathlib import Path,PurePosixPath
import concurrent.futures,datetime,hashlib,io,json,subprocess,tarfile,urllib.request
O=Path(__file__).resolve().parent;P=O/'publication';E=O/'publication-effects';PREFIX='evidence/R0022/owner-display-20261015/'
def sha(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def api(p):return json.loads(subprocess.check_output(['gh','api','repos/theislampill/salah_widget/'+p]))
intent=json.loads((E/'push-intent.json').read_bytes());commit=intent['commit'];manifest=json.loads((P/'payload-manifest.json').read_bytes());archives={PREFIX+a['path']:a for a in manifest['archives']};started=now()
assert not(E/'http-readback.json').exists()
remote=api('git/commits/'+commit);assert remote['tree']['sha']==intent['tree']and[x['sha']for x in remote['parents']]==[intent['base']]
def verify(row):
 url='https://raw.githubusercontent.com/theislampill/salah_widget/'+commit+'/'+row['path']
 request=urllib.request.Request(url,headers={'Accept-Encoding':'identity','Cache-Control':'no-cache','User-Agent':'R0022-immutable-evidence-readback'})
 with urllib.request.urlopen(request,timeout=60)as response:status=response.status;b=response.read()
 assert status==200 and len(b)==row['bytes']and sha(b)==row['sha256'],row['path']
 decoded=[]
 if row['path']in archives:
  with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz')as tf:
   members=tf.getmembers();expected=archives[row['path']]['files'];assert[m.name for m in members]==[r['original']for r in expected]
   for member,want in zip(members,expected):
    assert member.isfile()and not PurePosixPath(member.name).is_absolute()and'..'not in PurePosixPath(member.name).parts
    data=tf.extractfile(member).read();assert len(data)==want['bytes']and sha(data)==want['sha256'];decoded.append({'original':member.name,'sha256':sha(data),'bytes':len(data)})
 return {'path':row['path'],'url':url,'status':status,'bytes':len(b),'sha256':sha(b),'decodedFiles':decoded}
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:results=list(pool.map(verify,intent['files']))
assert api('git/ref/heads/main')['object']['sha']==intent['base'];assert api('issues/34')['state']=='open'
r={'schema':'r0022-public-display-byte-readback/v1','status':'PASS_GIT_HTTP_AND_EVERY_DECODED_ORIGINAL_BYTE','startedUtc':started,'finishedUtc':now(),'evidenceCommit':commit,'tree':intent['tree'],'base':intent['base'],'contractSha256':manifest['contractSha256'],'files':results,'qualification':'Publication custody only; owner acceptance, final native matrix, cost, merge and closure remain open.'}
(E/'http-readback.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'evidenceCommit':commit,'httpFiles':len(results),'decodedOriginalFiles':sum(len(x['decodedFiles'])for x in results),'status':r['status']}))
