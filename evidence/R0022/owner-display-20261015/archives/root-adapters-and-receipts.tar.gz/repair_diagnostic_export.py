from pathlib import Path
O=Path(__file__).resolve().parent;D=O/'comparison';prior=O/'capture-chromium-dpr1-diagnostic2/observer-source';prior.mkdir(exist_ok=True)
for name in ['capture_probe.py','probe-init.js']:(prior/name).write_bytes((D/name).read_bytes())
p=D/'probe-init.js';s=p.read_text(encoding='utf-8')
a='if(out[key]!==rec.baselineSha256&&!rec.firstChanged)rec.firstChanged={sha256:out[key],record};'
b="if(out[key]!==rec.baselineSha256&&!rec.firstChanged)rec.firstChanged={sha256:out[key],record,...(key==='v5Inputs'?{backingRaw:await l1Record(value.backing,true)}:{})};"
assert s.count(a)==1;s=s.replace(a,b,1)
a='commonRecordChecks:this.commonRecordChecks??null,';assert s.count(a)==1
s=s.replace(a,'commonRecordChecksJSON:JSON.stringify(this.commonRecordChecks??null),',1)
p.write_text(s,encoding='utf-8',newline='\n')
p=D/'capture_probe.py';s=p.read_text(encoding='utf-8')
a=" if frame is None:return\n try:report['releaseAfterFailure']="
b=" if frame is None:return\n try:report['commonRecordChecks']=await frame.evaluate('()=>window.__L1QAProbe.commonRecordChecks??null')\n except Exception as diagnostic:report['errors'].append('diagnostic read: '+str(diagnostic))\n try:report['releaseAfterFailure']="
assert s.count(a)==1;s=s.replace(a,b,1)
a="  packed=await frame.evaluate('()=>window.__L1QAProbe.exportInputs()')\n  report['inputBuffersAfterFailure']=validate_export(packed,out)"
b="  packed=await frame.evaluate('()=>window.__L1QAProbe.exportInputs()')\n  save(out/'RAW_EXPORT.json',packed)\n  report['inputBuffersAfterFailure']=validate_export(packed,out)\n  (out/'RAW_EXPORT.json').unlink() # exact successful binary association retained separately"
assert s.count(a)==1;s=s.replace(a,b,1)
p.write_text(s,encoding='utf-8',newline='\n')
print('FIXED observer metadata mistaken for missing original typed buffer; product unchanged')
