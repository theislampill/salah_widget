// Disposable H2 comparison: only the compact empirical KS phase-function share
// changes display direction. Raw radiance and every physical eligibility input
// stay with their original owner. No separately measured aerosol claim.
export function nativeLunarCompactFields(state,atmosphere,view,residualNight,anchor,gx=24,gy=40){
 const mapping=skyProjection(view),width=view.width,height=view.height;
 if(!anchor||![anchor.x,anchor.y].every(Number.isFinite)||anchor.x<0||anchor.y<0||anchor.x>=width||anchor.y>=height)throw new RangeError('Measured calendar anchor required');
 const sky=createSkyModel(state,atmosphere,{residualNight}),target=horizontalDirection(mapping.unproject(anchor.x,anchor.y));
 const cg=new Float64Array((gx+1)*(gy+1)*3),dg=new Float64Array(cg.length),radius=state.moon.angularRadiusDeg??.25;
 const parts=separation=>{const rho=Math.max(radius,separation),u=Math.min(1,Math.max(0,(rho-8)/4)),blend=u*u*(3-2*u),compact=6.2e7/(rho*rho)*(1-blend);return {compact,total:10**5.36*(1.06+Math.cos(rho*Math.PI/180)**2)+compact+10**(6.15-rho/40)*blend};};
 for(let y=0;y<=gy;y++)for(let x=0;x<=gx;x++){
  const px=x*width/gx,py=y*height/gy;if(!mapping.above(px,py))continue;
  const dir=mapping.unproject(px,py),sample=sky.sample(dir),original=parts(sample.moonSeparationDeg),ray=horizontalDirection(dir);
  const relocated=parts(Math.acos(Math.max(-1,Math.min(1,ray[0]*target[0]+ray[1]*target[1]+ray[2]*target[2])))*180/Math.PI);
  // The original sample includes real Moon airmass/phase/distance/visible-disc,
  // target airmass and cloud ONCE. Divide only its known phase function, then
  // use the destination ray's solid angle; never translate a pixel-flux texture.
  const amplitude=sample.moonLuminance/original.total,omega=mapping.solidAngle(px,py)/V_ZERO_ILLUMINANCE_LUX,at=(y*(gx+1)+x)*3;
  for(let c=0;c<3;c++){cg[at+c]=amplitude*original.compact*omega;dg[at+c]=amplitude*relocated.compact*omega;}
 }
 const lunarCompactLinear=new Float64Array(width*height*3),lunarRegisteredLinear=new Float64Array(lunarCompactLinear.length);
 for(let y=0;y<height;y++)for(let x=0;x<width;x++){
  if(!mapping.above(x+.5,y+.5))continue;
  const u=(x+.5)/width*gx,v=(y+.5)/height*gy,ix=Math.min(gx-1,Math.floor(u)),iy=Math.min(gy-1,Math.floor(v)),tx=u-ix,ty=v-iy,at=(y*width+x)*3,tl=(iy*(gx+1)+ix)*3,bl=tl+(gx+1)*3;
  for(let c=0;c<3;c++){
   lunarCompactLinear[at+c]=(cg[tl+c]*(1-tx)+cg[tl+3+c]*tx)*(1-ty)+(cg[bl+c]*(1-tx)+cg[bl+3+c]*tx)*ty;
   lunarRegisteredLinear[at+c]=(dg[tl+c]*(1-tx)+dg[tl+3+c]*tx)*(1-ty)+(dg[bl+c]*(1-tx)+dg[bl+3+c]*tx)*ty;
  }
 }
 return {lunarCompactLinear,lunarRegisteredLinear,lunarRegistration:{anchor,grid:[gx,gy],compactSupportDegrees:12,blendDegrees:[8,12],physicalMoon:state.moon,scope:'KS compact phase-function display center only; broad physical field and raw radiance retained'}};
}
function nativeLunarCompactDisplay(raster,nightWeight){
 if(nightWeight<=0)return null;
 const moon=raster.lunarBackgroundLinear,compact=raster.lunarCompactLinear,registered=raster.lunarRegisteredLinear,source=raster.skyBackgroundLinear??raster.backgroundLinear;
 if(!moon||!compact||!registered||moon.length!==source.length||compact.length!==moon.length||registered.length!==moon.length)throw new RangeError('Bound H2 decomposition required');
 if(!moon.some(v=>v>0))return null;
 const shown=new Float64Array(moon.length);let pixels=0;
 for(let i=0;i<moon.length;i++){
  if(!Number.isFinite(compact[i])||!Number.isFinite(registered[i])||compact[i]<0||registered[i]<0||compact[i]>moon[i]+64*Number.EPSILON*Math.max(1,moon[i]))throw new RangeError('Invalid compact lunar share');
  shown[i]=Math.max(0,moon[i]-compact[i])+registered[i];if(i%3===0&&shown[i]!==moon[i])pixels++;
 }
 return {shown,presentation:{owner:'native lunar compact display proposal',hypothesis:'H2',pixels,nightWeight,rawPhysicalRetained:true,registration:raster.lunarRegistration}};
}
