from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess,sys
O=Path(__file__).resolve().parent;D=O/'ordinary';R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget')
def read(p):return json.loads(p.read_bytes())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def ident(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
engine=sys.argv[1];dpr=int(sys.argv[2]);scene=sys.argv[3];label=sys.argv[4]
assert engine in ['chromium','firefox'] and dpr in [1,2] and scene in ['clear','partial','rain','day','moon-negative','dawn']
spec=importlib.util.spec_from_file_location('identity',R/'tools/cp9/runtime_identity.py');identity=importlib.util.module_from_spec(spec);spec.loader.exec_module(identity)
runtime=identity.runtime_identity(R);assert runtime==read(O/'h1-prototype/RUNTIME.json')
assert read(O/'browser-lease.json')['status']=='FREE'
old=read(Path('C:/Users/theis/Documents/Codex/salah-rlgwo-execution-20261009/ACTIVE_LEDGER.json'));assert old['resourceLeases']['heavy-browser']['status']=='FREE'
assert read(Path('C:/Users/theis/.codex/work-products/r0024-execution-20261015/execution.json'))['heavyLease']['kind']=='FREE'
prior=read(Path('C:/Users/theis/.codex/work-products/r0024-execution-20261015/native')/engine/('resume-r2'if engine=='chromium'else'resume-r6')/'results.json')['capability']
exe=Path(prior['executable']);driver=prior['driver'];assert ident(exe)['sha256']==prior['executableSha256'];assert ident(Path(driver['node']))['sha256']==driver['nodeSha256']
assert ident(Path(driver['cli']))['sha256']==driver['files']['cli.js']
out=O/('ordinary-'+engine+'-dpr'+str(dpr)+'-'+scene+'-'+label);assert not out.exists()
leaseId=out.name;lock=O/'native-resource.lock'
with lock.open('x')as f:f.write(leaseId)
lease={'leaseId':leaseId,'status':'ACTIVE','owner':'R0022 root','scope':'One disposable ordinary1x full-scene60second native capture; no held arms/product trace','command':str(D/'capture_ordinary.py'),'startedAtUtc':now(),'sourceRuntime':runtime['treeSha256']};save(O/'browser-lease.json',lease)
cmd=['C:/workspace/ai/cp9-integration-20261005/venv/Scripts/python.exe','-I','-B',str(D/'capture_ordinary.py'),'--root',str(R),'--out',str(out),'--scene',scene,'--modes','cold','--duration','60','--dpr',str(dpr),'--video','--capture-trace','--driver-node',driver['node'],'--driver-cli',driver['cli']]
env=dict(os.environ,SALAH_BROWSER=engine,SALAH_BROWSER_EXECUTABLE=str(exe))
receipt={'command':cmd,'lease':lease,'status':'STARTED','runtime':runtime['treeSha256'],'driver':{'version':driver['version'],'node':ident(Path(driver['node'])),'cli':ident(Path(driver['cli']))},'browser':ident(exe),'adapter':ident(D/'capture_ordinary.py')}
try:
 print('EXECUTING '+leaseId,flush=True)
 with (O/(leaseId+'-stdout.log')).open('wb')as stdout,(O/(leaseId+'-stderr.log')).open('wb')as stderr:p=subprocess.run(cmd,env=env,stdout=stdout,stderr=stderr)
 receipt['exitCode']=p.returncode;receipt['status']=read(out/'results.json')['status']if(out/'results.json').is_file()else'NO_RESULT'
finally:
 receipt['runtimeUnchanged']=identity.runtime_identity(R)==runtime;receipt['finishedAtUtc']=now();save(O/(leaseId+'-dispatch.json'),receipt)
 lease.update(status='FREE',owner=None,finishedAtUtc=now());save(O/'browser-lease.json',lease)
 assert lock.read_text()==leaseId;lock.unlink()
print(json.dumps(receipt),flush=True)
