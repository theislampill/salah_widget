import assert from 'node:assert/strict';
import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
const root='C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget';
const m=await import(pathToFileURL(root+'/real-sky/native-preview.mjs'));
const o=JSON.parse(fs.readFileSync('C:/Users/theis/Documents/Codex/salah-rlgwo-execution-20261009/evidence/R0022-L1/full-composition-pair-06/ORIGINAL_INPUTS.json')).original;
const state=o.result.raster.physicalState,atmos=o.result.raster.atmosphere,view=o.request.options.view,residual=o.request.options.diffuse.residualNight;
const fields=m.nativeAtmosphereFieldsL1Proposal(state,atmos,view,residual,41,67);
const compact=m.nativeLunarCompactFields(state,atmos,view,residual,{x:269,y:56},41,67);
const bytes=a=>Buffer.from(a.buffer,a.byteOffset,a.byteLength),near=(a,b)=>Math.abs(a-b)<=3e-13*Math.max(1,Math.abs(a),Math.abs(b));
const saved=Object.fromEntries(Object.entries(fields).filter(([,v])=>ArrayBuffer.isView(v)).map(([k,v])=>[k,Buffer.from(bytes(v))]));
const raw={...o.result.raster,linear:Float64Array.from(fields.background,v=>v+.0003),skyBackgroundLinear:fields.background,backgroundLinear:fields.background,lunarBackgroundLinear:fields.lunarBackgroundLinear,stellarLinear:new Float64Array(fields.background.length).fill(.0003),diffuseLinear:new Float64Array(fields.background.length),solarBackgroundLinear:fields.solarBackgroundLinear,solarAerosolLinear:fields.solarAerosolLinear,...compact};
const shownA=m.nativeSkyPresentationL1Proposal(raw,view,null),shownB=m.nativeSkyPresentationH2Proposal(raw,view,null);
for(const [k,b] of Object.entries(saved))assert(bytes(fields[k]).equals(b),'raw mutation '+k);
for(const out of [shownA,shownB]){
 assert.equal(out.effectiveExposure,raw.effectiveExposure);assert.equal(out.physicalSkyBackgroundLinear,raw.skyBackgroundLinear);assert.equal(out.stellarLinear,raw.stellarLinear);
 for(let i=0;i<raw.linear.length;i++)assert(near(out.linear[i]-out.skyBackgroundLinear[i],.0003),'non-lunar source changed');
}
let ordered=[];
for(let i=0;i<raw.linear.length;i+=3){
 assert(compact.lunarCompactLinear[i]<=raw.lunarBackgroundLinear[i]+1e-13,'compact overdraw');
 assert(near(shownB.skyBackgroundLinear[i],raw.skyBackgroundLinear[i]-compact.lunarCompactLinear[i]+compact.lunarRegisteredLinear[i]),'H2 changed broad field');
 ordered.push([raw.lunarBackgroundLinear[i],shownA.lunarNightDisplayLinear[i]]);
}
ordered.sort((a,b)=>a[0]-b[0]);for(let i=1;i<ordered.length;i++)assert(ordered[i][1]+1e-14>=ordered[i-1][1],'H1 direction reversal');
const below={...state,moon:{...state.moon,altDeg:-10}};
const z=m.nativeLunarCompactFields(below,atmos,view,residual,{x:269,y:56},41,67);
assert(z.lunarCompactLinear.every(v=>v===0)&&z.lunarRegisteredLinear.every(v=>v===0),'calendar anchor bypassed real horizon');
// Negative changes are passed into the real display consumer, not checked by strings.
const badUnits={...raw,lunarCompactLinear:Float64Array.from(compact.lunarCompactLinear,v=>v*1e12)};
assert.throws(()=>m.nativeSkyPresentationH2Proposal(badUnits,view,null),RangeError);
const wholeMoved={...shownB,skyBackgroundLinear:Float64Array.from(raw.skyBackgroundLinear,(_,i)=>compact.lunarRegisteredLinear[i])};
assert(wholeMoved.skyBackgroundLinear.some((v,i)=>!near(v,raw.skyBackgroundLinear[i]-compact.lunarCompactLinear[i]+compact.lunarRegisteredLinear[i])),'whole-field mutant escaped');
const nonLunarChanged=Float64Array.from(shownA.linear,v=>v*.9);
assert(nonLunarChanged.some((v,i)=>!near(v-shownA.skyBackgroundLinear[i],.0003)),'global-darkening mutant escaped');
console.log(JSON.stringify({status:'PASS_COMPARISON_SOURCE_ONLY',samples:raw.linear.length/3,controls:['raw/exposure identity','non-lunar identity','H1 ordering','H2 broad field identity','physical below-horizon zero','bad-unit rejection','whole-field and global-darkening mutants'],nativePixels:false}));
