from pathlib import Path,PurePosixPath
import datetime,gzip,hashlib,io,json,shutil,tarfile
O=Path(__file__).resolve().parent;P=O/'publication';P.mkdir(exist_ok=False)
def read(p):return json.loads(p.read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
assert read(O/'browser-lease.json')['status']=='FREE' and not (O/'native-resource.lock').exists()
assert (O/'decision/independent-review.json').is_file()
contract=read(O/'decision/display-contract.json');assert not contract['ownerAccepted']
groups={}
for p in sorted(O.rglob('*')):
 if not p.is_file()or p.is_relative_to(P)or any(s in ['publication-effects','__pycache__']for s in p.relative_to(O).parts):continue
 rel=p.relative_to(O).as_posix();group=p.relative_to(O).parts[0]if len(p.relative_to(O).parts)>1 else'root-adapters-and-receipts'
 groups.setdefault(group,[]).append((rel,p))
frozen=read(O/'inputs/frozen32-verification.json');fr=Path(frozen['source'])
for row in frozen['files']:
 p=fr/row['path'];assert sha(p.read_bytes())==row['sha256']and p.stat().st_size==row['bytes']
 groups.setdefault('frozen-l1-original32',[]).append(('retained/frozen-l1-original32/'+row['path'],p))
old=Path('C:/Users/theis/Documents/Codex/salah-rlgwo-execution-20261009/workers/r0022_whole_owner_r1')
for p in sorted((old/'retained').rglob('*')):
 if p.is_file():groups.setdefault('retained-accepted-work',[]).append(('retained/accepted-work/'+p.relative_to(old/'retained').as_posix(),p))
archives=[]
for group,files in groups.items():
 dest=P/'archives'/(group+'.tar.gz');dest.parent.mkdir(exist_ok=True)
 rows=[]
 with dest.open('wb')as f,gzip.GzipFile(filename='',mode='wb',fileobj=f,compresslevel=6,mtime=0)as gz,tarfile.open(fileobj=gz,mode='w')as tf:
  for rel,path in sorted(files):
   b=path.read_bytes();ti=tarfile.TarInfo(rel);ti.size=len(b);ti.mode=0o644;ti.mtime=0;tf.addfile(ti,io.BytesIO(b));rows.append({'original':rel,'sourcePath':str(path),'bytes':len(b),'sha256':sha(b)})
 assert dest.stat().st_size<90*1024**2,('Archive needs predeclared byte splitting',dest)
 with tarfile.open(dest,'r:gz')as tf:
  members=tf.getmembers();assert[m.name for m in members]==[r['original']for r in rows]
  for member,row in zip(members,rows):
   assert member.isfile()and'..'not in PurePosixPath(member.name).parts
   b=tf.extractfile(member).read();assert len(b)==row['bytes']and sha(b)==row['sha256']
 archives.append({'path':dest.relative_to(P).as_posix(),'bytes':dest.stat().st_size,'sha256':sha(dest.read_bytes()),'files':rows})
 print(json.dumps({'archive':group,'files':len(rows),'compressedBytes':dest.stat().st_size}),flush=True)
# Human-readable originals remain byte-identical alongside the complete archives.
direct=[O/'decision/display-contract.json',O/'decision/OWNER_DISPLAY_DECISION.html',O/'decision/independent-review.json',O/'EXECUTION.json']
direct+=sorted((O/'capture-chromium-dpr1-r4').glob('*.png'))
for name in ['ordinary-chromium-dpr1-clear-r1','ordinary-firefox-dpr2-clear-r1','ordinary-chromium-dpr2-rain-r1']:
 direct +=[O/name/'cold-at60s.png',O/name/'results.json']+list((O/name/'video').glob('*.webm'))
for p in direct:
 dest=P/p.relative_to(O);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest);assert sha(dest.read_bytes())==sha(p.read_bytes())
manifest={'schema':'r0022-display-decision-payload/v1','createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':contract['baseCommit'],'prototypeRuntime':contract['prototypeRuntimeSha256'],'contractSha256':sha((O/'decision/display-contract.json').read_bytes()),'archives':archives,'directCopies':[{'path':p.relative_to(O).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in direct],'qualification':'Concrete display-selection evidence only. Original failures retained. Owner acceptance, remaining native matrix, actual cost and production/closure gates remain open. RetainedBALANCE includes existing receipts/maps, not a claim that every historical referenced native artifact is re-published in this selection bundle.','excluded':['No personal/disposable browser profile directories were produced by these captures. Publication itself and later publication-effects receipts are excluded from their own snapshot. Python caches excluded.']}
write(P/'payload-manifest.json',manifest)
readme='''# R0022 owner display decision evidence

This non-deploying branch preserves the concrete H1/H2 comparison, ordinary H1 prototype, all retained failures, original native pixels/videos, exact buffers, source identities and independent read-only review. It does not close issue #34 or grant production merge approval.

Recommended contract: **R0022-L1-H1-K003-H020-v1**. The JSON contract and original whole cards under `decision/` describe the actual owner selection. H1 bounds lunar display energy at its physical direction while retaining raw astronomical fields and V5. H2 fails the unchanged proposed ROI bounds and puts glare over the calendar Moon.

`payload-manifest.json` maps every original byte stream to a lossless archive. Direct image/video copies are byte-identical conveniences for review. Each archive was decoded and checked before publication. A separate Git/HTTP readback receipt follows publication. Local paths inside historical records are provenance; archive member names provide the portable mapping.

The ordinary captures are display-propagation observations, not R0021 timing or actual extension-parent qualification. Firefox held comparison r4 failed currentness before any arm and restoration failed; context closure was containment. The later independent ordinary Firefox run does not erase that failure. Original videos remain as recorded.

Original accepted BALANCE is reused under exact source compatibility, not restarted. The final selected-source native matrix, original warmed cost and added L1 cost still require proof. Issue #34 remains OPEN. The owner must accept this display contract/appearance and later approve an independently reviewed exact production PR head/base. Only then may the already-authorized delivery/certificate-first closure sequence proceed.
'''
(P/'README.md').write_text(readme,encoding='utf-8')
print(json.dumps({'archives':len(archives),'members':sum(len(a['files'])for a in archives),'compressedBytes':sum(a['bytes']for a in archives),'contract':manifest['contractSha256']}))
