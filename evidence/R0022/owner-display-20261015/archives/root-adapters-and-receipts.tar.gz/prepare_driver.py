from pathlib import Path
import json,hashlib
O=Path(__file__).resolve().parent;D=O/'comparison'
old=Path('C:/Users/theis/Documents/Codex/salah-rlgwo-execution-20261009/workers/root/l1-full-composition-driver-r6/capture_probe.py')
s=old.read_text(encoding='utf-8').replace('RUN=HERE.parents[2]','RUN=HERE.parent')
start=s.index('def require_root_lease(');end=s.index('def clock_script(',start)
s=s[:start]+'''def root_lease(a):
 p=RUN/'browser-lease.json';row=read(p)
 if row.get('status')!='ACTIVE' or row.get('owner')!='R0022 root' or row.get('leaseId')!=a.lease_id or Path(row.get('command','')).resolve()!=(HERE/'capture_probe.py').resolve():raise ValueError('Exact serial R0022 browser lease required')
 return {'ledger':identity(p),'lease':row}

def require_runtime_bindings(actual,base,allowed):
 left,right=base['files'],actual['files']
 if set(left)!=set(right):raise ValueError('Served inventory changed')
 for rel,row in left.items():
  if rel not in allowed and right[rel]!=row:raise ValueError('Protected runtime drift: '+rel)
 expected=read(HERE/'BUILT_RUNTIME.json')
 if actual!=expected:raise ValueError('Runtime differs from the exact independently reviewed prototype build')
 return {'baseTreeSha256':base['treeSha256'],'actualTreeSha256':actual['treeSha256'],'fullInventoryBound':True,'declaredChangedOutputs':allowed}

def preflight(a):
 source=read(HERE/'INPUTS.json');root=a.root.resolve();out=a.out.resolve()
 if root!=Path(source['root']).resolve():raise ValueError('Wrong served worktree')
 if out.exists() or not out.is_relative_to(RUN) or out.is_relative_to(root):raise ValueError('Fresh output outside served tree required')
 for row in source['sourceRows']:
  if identity(root/row['path'])['sha256']!=row['instrumented']['sha256']:raise ValueError('Source changed: '+row['path'])
 if identity(RUN/'COMPARISON_CONTRACT.md')['sha256']!=source['contractSha256']:raise ValueError('Predeclared comparison contract changed')
 if not a.executable.is_file():raise ValueError('Explicit native executable required')
 if a.stamp is not None and datetime.fromisoformat(a.stamp.replace('Z','+00:00')).tzinfo is None:raise ValueError('UTC offset required')
 bundle=(root/'real-sky/native-sky.js').read_text(encoding='utf-8')
 for rel in ['real-sky/native-preview.mjs','real-sky/native-host.mjs']:
  authored=(root/rel).read_text(encoding='utf-8')
  compiled=re.sub(r'^import .*?;\\s*$', '',authored,flags=re.M)
  compiled=re.sub(r'\\bexport (?=(?:const|let|function|class|async function)\\b)','',compiled)
  if compiled not in bundle:raise ValueError('Generated output does not consume '+rel)
 return {'baseCommit':source['baseCommit'],'root':str(root),'out':str(out),'sourceBindings':source['sourceRows'],'init':identity(HERE/'probe-init.js'),'executable':identity(a.executable),'browserFamily':a.browser,'dpr':a.dpr,'clockFixture':a.stamp,'rootHeavyBrowserLease':root_lease(a) if a.execute else None,'builtByThisDriver':False,'externalEffects':'Disposable headless native browser and local fixture server; no personal profile or desktop access'}

'''+s[end:]
s=s.replace("for label in ['A','B','A-restored']:","for label in ['A','B','C','A-restored']:")
s=s.replace("png_controls(out,['A','B','A-restored'],a.dpr)","png_controls(out,['A','B','C','A-restored'],a.dpr)")
(D/'capture_probe.py').write_text(s,encoding='utf-8',newline='\n')
source=json.loads((D/'SOURCES.json').read_bytes());source['root']='C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget'
source['driverProvenance']={'path':str(old),'sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'changes':'Fresh current-main source/runtime and owner serial lease binding; add C=H2 arm. Actual admission, unchanged inputs, currentness, pixels, restoration and cleanup guards retained.'}
(D/'INPUTS.json').write_text(json.dumps(source,indent=2)+'\n',encoding='utf-8')
print('DRIVER_PREPARED_NO_BROWSER')
