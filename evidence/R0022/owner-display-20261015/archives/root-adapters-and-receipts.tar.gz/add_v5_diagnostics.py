from pathlib import Path
import hashlib,json
O=Path(__file__).resolve().parent;D=O/'comparison';before=O/'capture-chromium-dpr1-r1/observer-source';before.mkdir(exist_ok=True)
for name in ['capture_probe.py','probe-init.js','INPUTS.json','SOURCES.json','BUILT_RUNTIME.json']:
    (before/name).write_bytes((D/name).read_bytes())
p=D/'probe-init.js';s=p.read_text(encoding='utf-8')
needle="   if(key==='domAndFonts'){"
assert s.count(needle)==1
s=s.replace(needle,"""   const changes=this.commonRecordChecks??={};
   const rec=changes[key]??={baselineSha256:out[key],baseline:record,firstChanged:null};
   if(out[key]!==rec.baselineSha256&&!rec.firstChanged)rec.firstChanged={sha256:out[key],record};
"""+needle,1)
needle='baselineCommon:this.baseline??null,';assert s.count(needle)==1
s=s.replace(needle,'commonRecordChecks:this.commonRecordChecks??null,'+needle,1)
p.write_text(s,encoding='utf-8',newline='\n')
p=D/'capture_probe.py';s=p.read_text(encoding='utf-8')
needle="   transaction=await frame.evaluate('()=>window.__L1QAProbe.begin()');report['ordinary']=transaction"
assert s.count(needle)==1
s=s.replace(needle,needle+"\n   # Diagnostic acquisition stops on the original common-input mismatch; no arm selection.\n   await frame.evaluate('()=>window.__L1QAProbe.checkpoint()')\n   raise ValueError('DIAGNOSTIC_ONLY: first common checkpoint stable; no comparison requested')",1)
needle=" report['status']='FAILED_OR_GATED_NO_PAIR';report['errors'].append(str(error))"
assert s.count(needle)==1
s=s.replace(needle,needle+"\n if frame is not None:\n  try:await frame.page.screenshot(path=str(out/'failure-page.png'),full_page=True,animations='allow',caret='initial')\n  except Exception:pass",1)
p.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps({'purpose':'Exact V5 mismatch discriminator only; equality unchanged','initSha256':hashlib.sha256((D/'probe-init.js').read_bytes()).hexdigest(),'driverSha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
