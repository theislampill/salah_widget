from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,sys
O=Path(__file__).resolve().parent;R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget')
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
assert read(O/'browser-lease.json')['status']=='FREE' and not (O/'native-resource.lock').exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='fc8d13338f9274a768580cda5a805492f80c510d'
current=read(O/'comparison/BUILT_RUNTIME.json')
for rel,row in current['files'].items():assert sha(R/rel)==row['sha256'],rel
D=O/'h1-prototype';D.mkdir(exist_ok=False)
for rel in ['real-sky/native-preview.mjs','real-sky/native-host.mjs','src/native/index.html','index.html','offline.html','real-sky/native-sky.js']:
 p=D/'retained-comparison'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/rel).read_bytes())
for rel in ['real-sky/native-preview.mjs','real-sky/native-host.mjs','src/native/index.html']:
 (R/rel).write_bytes((O/'comparison/baseline'/rel).read_bytes())
patch=Path('C:/Users/theis/Documents/Codex/salah-rlgwo-execution-20261009/workers/r0022_whole_owner_r1/proposal/l1-display.patch')
assert sha(patch)=='6d585aa9aa2f03f89b4c2ac5ebc03186e244542a951dc7864016be1f1d3f323e'
subprocess.run(['git','apply','--check',str(patch)],cwd=R,check=True)
subprocess.run(['git','apply',str(patch)],cwd=R,check=True)
with (D/'build.log').open('wb')as f:subprocess.run([sys.executable,'-B','tools/build_native.py'],cwd=R,stdout=f,stderr=subprocess.STDOUT,check=True)
s=importlib.util.spec_from_file_location('identity',R/'tools/cp9/runtime_identity.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
actual=m.runtime_identity(R);base=read(O/'comparison/BASE_RUNTIME.json');assert set(actual['files'])==set(base['files'])
changed=[p for p in base['files']if base['files'][p]!=actual['files'][p]]
assert set(changed)=={'index.html','offline.html','real-sky/native-sky.js','real-sky/native-preview.mjs','real-sky/native-host.mjs'},changed
save(D/'RUNTIME.json',actual)
sources={p:{'sha256':sha(R/p),'bytes':(R/p).stat().st_size}for p in ['real-sky/native-preview.mjs','real-sky/native-host.mjs','src/native/index.html','real-sky/native-first-paint.mjs']}
for rel in sources:
 p=D/'source'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/rel).read_bytes())
save(D/'BINDING.json',{'schema':'r0022-h1-disposable-prototype/v1','base':'fc8d13338f9274a768580cda5a805492f80c510d','runtime':actual['treeSha256'],'changedRuntime':changed,'protectedUnchanged':130,'sources':sources,'sourcePatchSha256':sha(patch),'ownerAccepted':False,'purpose':'Ordinary complete-scene display proposal before owner acceptance; no production integration or merge','atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
print(json.dumps(read(D/'BINDING.json')))
