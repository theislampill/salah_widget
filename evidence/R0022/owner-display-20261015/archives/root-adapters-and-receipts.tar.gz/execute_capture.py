from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,sys
O=Path(__file__).resolve().parent;D=O/'comparison';R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget')
def read(p):return json.loads(p.read_bytes())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
spec=importlib.util.spec_from_file_location('identity',R/'tools/cp9/runtime_identity.py');identity=importlib.util.module_from_spec(spec);spec.loader.exec_module(identity)
runtime=identity.runtime_identity(R);base=read(D/'BASE_RUNTIME.json');inputs=read(D/'INPUTS.json')
assert set(runtime['files'])==set(base['files'])
changed=[p for p in base['files'] if base['files'][p]!=runtime['files'][p]]
assert set(changed)<=set(inputs['permittedRuntimeChanges']),changed
save(D/'BUILT_RUNTIME.json',runtime)
save(D/'BUILD_BINDING.json',{'base':inputs['baseCommit'],'runtime':runtime['treeSha256'],'changedRuntime':changed,'unchangedProtectedRuntime':len(base['files'])-len(changed),'frozenV1':'PASS verified separately','atUtc':now()})
engine=sys.argv[1] if len(sys.argv)>1 else 'chromium';dpr=int(sys.argv[2]) if len(sys.argv)>2 else 1;label=sys.argv[3] if len(sys.argv)>3 else 'r1'
exe=Path('C:/Users/theis/AppData/Local/ms-playwright')/('chromium-1223/chrome-win64/chrome.exe' if engine=='chromium' else 'firefox-1522/firefox/firefox.exe')
out=O/('capture-'+engine+'-dpr'+str(dpr)+'-'+label);assert not out.exists()
old=read(Path('C:/Users/theis/Documents/Codex/salah-rlgwo-execution-20261009/ACTIVE_LEDGER.json'))
assert old['resourceLeases']['heavy-browser']['status']=='FREE'
r24=read(Path('C:/Users/theis/.codex/work-products/r0024-execution-20261015/execution.json'));assert r24['heavyLease']['kind']=='FREE'
leaseId='r0022-comparison-'+engine+'-'+str(dpr)+'-'+label
lock=O/'native-resource.lock';f=lock.open('x');f.write(leaseId);f.close()
lease={'leaseId':leaseId,'status':'ACTIVE','owner':'R0022 root','command':str(D/'capture_probe.py'),'scope':'One native unstripped current-main/H1/H2 common-input comparison','startedAtUtc':now(),'sourceRuntime':runtime['treeSha256']}
save(O/'browser-lease.json',lease)
cmd=['C:/workspace/ai/cp9-integration-20261005/venv/Scripts/python.exe','-I','-B',str(D/'capture_probe.py'),'--root',str(R),'--out',str(out),'--browser',engine,'--executable',str(exe),'--stamp','2026-09-25T02:00:00Z','--dpr',str(dpr),'--lease-id',leaseId]
receipt={'command':cmd,'lease':lease,'status':'STARTED','changedRuntime':changed}
try:
    p=subprocess.run(cmd,capture_output=True);(O/(leaseId+'-preflight.log')).write_bytes(p.stdout+p.stderr);assert p.returncode==0,p.stderr.decode()
    receipt['command']=cmd+['--execute'];print('EXECUTING '+leaseId,flush=True)
    with (O/(leaseId+'-stdout.log')).open('wb') as stdout,(O/(leaseId+'-stderr.log')).open('wb') as stderr:p=subprocess.run(cmd+['--execute'],stdout=stdout,stderr=stderr)
    receipt['exitCode']=p.returncode;receipt['status']=read(out/'RESULT.json')['status'] if (out/'RESULT.json').is_file() else 'NO_RESULT'
finally:
    receipt['finishedAtUtc']=now();save(O/(leaseId+'-dispatch.json'),receipt)
    lease.update(status='FREE',owner=None,finishedAtUtc=now());save(O/'browser-lease.json',lease)
    assert lock.read_text()==leaseId;lock.unlink()
print(json.dumps(receipt),flush=True)
