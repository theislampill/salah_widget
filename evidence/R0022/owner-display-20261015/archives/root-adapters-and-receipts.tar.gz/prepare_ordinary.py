from pathlib import Path
import hashlib,json
O=Path(__file__).resolve().parent
R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget')
S=Path('C:/Users/theis/.codex/worktrees/r0022-whole-owner/salah_widget/tools/cp9/celestial_startup_check.py')
D=O/'ordinary';D.mkdir(exist_ok=True)
text=S.read_text(encoding='utf-8')
replacements={
 "sys.path.insert(0,str(Path(__file__).resolve().parent))": "sys.path.insert(0,"+repr(str(R/'tools/cp9'))+")",
 "sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'tests'))": "sys.path.insert(0,"+repr(str(R/'tests'))+")",
 "   while time.monotonic()-start<a.duration:\n    if (final.get('moon') or {}).get('visibleSource')=='refined-terrain':break\n    await asyncio.sleep(1)\n    final=await frame.evaluate(FINAL)":
 "   # Fixed ordinary observation through 60 seconds; never finish at a favourable late frame.\n   checkpoints=[]\n   for target in [30,45,60]:\n    await asyncio.sleep(max(0,target-(time.monotonic()-start)))\n    observed=await frame.evaluate(FINAL)\n    shot=f'{mode}-at{target}s.png'\n    began=time.monotonic()\n    await page.screenshot(path=str(a.out/shot),timeout=30000)\n    checkpoints.append({'targetSeconds':target,'state':observed,'file':shot,'captureStartMs':(began-start)*1000,'captureEndMs':(time.monotonic()-start)*1000})\n   final=await frame.evaluate(FINAL)",
 "'at15s':initial,'final':final": "'at15s':initial,'ordinaryCheckpoints':checkpoints,'final':final",
}
for old,new in replacements.items():
 assert text.count(old)==1,(old,text.count(old))
 text=text.replace(old,new)
(D/'capture_ordinary.py').write_text(text,encoding='utf-8',newline='\n')
def ident(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
manifest={'schema':'r0022-ordinary-driver/v1','parent':ident(S),'adapter':ident(D/'capture_ordinary.py'),'helpers':[ident(R/p)for p in ['tools/cp9/browser_runtime.py','tools/cp9/runtime_identity.py','tests/v1_browser.py']],
 'scope':'Unmodified ordinary candidate runtime; real advancing 1x clock; valid controlled provider records; no product instrumentation/held arms/layer stripping; first15s original native video and PNGs, then actual states and complete cards at30/45/60s. Native trace timestamps retained; no startup latency or extension-parent PASS.',
 'predeclaredDurationSeconds':60,'negativeEvidence':'Blank/gapped native recordings remain failures, no later still repairs continuous video.',
 'changedDriverBehaviour':['Import exact candidate helpers','Fixed60second observation replacing stop-when-refined','Record30/45/60second actual states and images']}
(D/'DRIVER.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(manifest))
