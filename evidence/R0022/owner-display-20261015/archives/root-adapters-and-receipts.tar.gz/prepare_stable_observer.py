from pathlib import Path
O=Path(__file__).resolve().parent;D=O/'comparison';prior=O/'capture-chromium-dpr1-diagnostic3/observer-source';prior.mkdir(exist_ok=True)
for name in ['capture_probe.py','probe-init.js']:(prior/name).write_bytes((D/name).read_bytes())
p=D/'capture_probe.py';s=p.read_text(encoding='utf-8')
a="   # Diagnostic acquisition stops on the original common-input mismatch; no arm selection.\n   await frame.evaluate('()=>window.__L1QAProbe.checkpoint()')\n   raise ValueError('DIAGNOSTIC_ONLY: first common checkpoint stable; no comparison requested')"
assert s.count(a)==1;s=s.replace(a,'',1)
a="   transaction=await frame.evaluate('()=>window.__L1QAProbe.begin()');report['ordinary']=transaction"
assert s.count(a)==1
b="""   # The inherited probe observes a native GPU/CPU backing canvas. A measured
   # nine-byte readback change is retained; establish exact observer stability
   # before admission rather than relaxing any common-input equality.
   stability=await frame.evaluate('''async()=>{
    const q=window.__L1QAProbe,records=[],before=window.SalahMoonRuntime.state;
    for(let n=0;n<3;n++){
     const moon=window.SalahMoonRuntime.state;
     if(!moon.current||moon.accepted.identity!==before.accepted.identity)throw Error('READBACK: native material changed');
     const canvas=window.SalahNativeSkyHost.lunarSurface(),bytes=canvas.getContext('2d').getImageData(0,0,canvas.width,canvas.height).data;
     const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(v=>v.toString(16).padStart(2,'0')).join('');
     let str='';for(let i=0;i<bytes.length;i+=16384)str+=String.fromCharCode(...bytes.subarray(i,i+16384));
     records.push({index:n,sha256:hash,base64:btoa(str),bytes:bytes.length,width:canvas.width,height:canvas.height});
    }
    const after=window.SalahMoonRuntime.state;
    return {records,before,after,lastTwoEqual:records[1].sha256===records[2].sha256,
     materialUnchanged:JSON.stringify(before.accepted)===JSON.stringify(after.accepted)&&before.epoch===after.epoch&&before.renders===after.renders&&after.current===true,
     cause:'Observed readback instability; backend migration not asserted'};
   }''')
   for row in stability['records']:
    raw=base64.b64decode(row.pop('base64'),validate=True)
    if len(raw)!=row['bytes'] or sha(raw)!=row['sha256']:raise ValueError('Readback diagnostic byte association failed')
    file=out/('pre-transaction-backing-'+str(row['index'])+'.bin');file.write_bytes(raw);row['file']=str(file)
   report['preTransactionReadback']=stability;save(out/'RESULT.json',report)
   if not stability['lastTwoEqual'] or not stability['materialUnchanged']:raise ValueError('Pre-transaction readback remained unstable; no pair')
"""+a
s=s.replace(a,b,1)
p.write_text(s,encoding='utf-8',newline='\n')
print('Stable observer prepared; no product or equality change')
