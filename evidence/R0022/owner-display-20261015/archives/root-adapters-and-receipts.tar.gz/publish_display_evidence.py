from pathlib import Path
import datetime,hashlib,json,os,subprocess
O=Path(__file__).resolve().parent;R=Path('C:/Users/theis/.codex/worktrees/r0022-execution/salah_widget');P=O/'publication';E=O/'publication-effects';E.mkdir(exist_ok=True)
BASE='fc8d13338f9274a768580cda5a805492f80c510d';BRANCH='codex/r0022-evidence-20261015';PREFIX='evidence/R0022/owner-display-20261015/'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a,env=None):return subprocess.check_output(['git',*a],cwd=R,env=env)
def api(p):return json.loads(subprocess.check_output(['gh','api','repos/theislampill/salah_widget/'+p]))
def record(name,x):
 with(E/name).open('x',encoding='utf-8')as f:f.write(json.dumps(x,indent=2)+'\n')
assert not (E/'push-intent.json').exists(),'Reconcile prior effect before retry'
assert git('rev-parse','HEAD').decode().strip()==BASE
remote=git('remote','get-url','origin').decode().strip();assert remote=='https://github.com/theislampill/salah_widget.git'
assert api('git/ref/heads/main')['object']['sha']==BASE
issue=api('issues/34');assert issue['state']=='open'
pages=api('pages');assert pages['source']=={'branch':'main','path':'/'}and pages['build_type']=='legacy'
assert not git('ls-remote','--heads','origin','refs/heads/'+BRANCH).strip(),'Existing remote evidence branch; reconcile rather than overwrite'
assert not git('for-each-ref','--format=%(objectname)','refs/heads/'+BRANCH).strip(),'Existing local evidence branch; reconcile rather than overwrite'
manifest=json.loads((P/'payload-manifest.json').read_bytes());assert manifest['base']==BASE
for a in manifest['archives']:assert sha((P/a['path']).read_bytes())==a['sha256']
review=json.loads((P/'decision/independent-review.json').read_bytes());assert review['contractSha256']==manifest['contractSha256']and review['verdict']=='READY_FOR_OWNER_DISPLAY_SELECTION_ONLY'
index=E/'temporary-evidence-index';assert not index.exists();env=os.environ.copy();env['GIT_INDEX_FILE']=str(index)
git('read-tree',BASE,env=env);files=[]
for p in sorted(P.rglob('*')):
 if not p.is_file():continue
 rel=PREFIX+p.relative_to(P).as_posix();blob=git('hash-object','-w','--',str(p)).decode().strip();git('update-index','--add','--cacheinfo','100644,'+blob+','+rel,env=env)
 files.append({'path':rel,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'blobSha':blob})
tree=git('write-tree',env=env).decode().strip()
msg=E/'commit-message.txt';msg.write_text('Preserve R0022 bounded display decision evidence\n\nKeep H1/H2 originals, ordinary prototype, independent review and failed attempts. Owner display selection, original cost, remaining native controls, production approval and closure stay open.\n\nCo-Authored-By: Codex <noreply@openai.com>\n',encoding='utf-8')
commit=git('commit-tree',tree,'-p',BASE,'-F',str(msg)).decode().strip()
record('push-intent.json',{'atUtc':now(),'repo':remote,'branch':BRANCH,'base':BASE,'commit':commit,'tree':tree,'files':files,'contractSha256':manifest['contractSha256'],'pages':pages['source'],'authority':'Owner execution order permits immutable non-deploying evidence publication. No main/source-PR/merge/issue effect.'})
git('update-ref','refs/heads/'+BRANCH,commit,'0'*40)
p=subprocess.run(['git','push','origin',commit+':refs/heads/'+BRANCH],cwd=R,capture_output=True)
record('push-result.json',{'atUtc':now(),'exitCode':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()});assert p.returncode==0,'Inspect actual remote ref before retry'
ref=api('git/ref/heads/'+BRANCH);assert ref['object']['sha']==commit
current=api('git/ref/heads/main')['object']['sha'];issue=api('issues/34');assert current==BASE and issue['state']=='open'
record('git-readback.json',{'atUtc':now(),'ref':ref,'main':current,'issue34':issue['state'],'commit':api('git/commits/'+commit)})
print(json.dumps({'evidenceCommit':commit,'tree':tree,'files':len(files),'url':'https://github.com/theislampill/salah_widget/tree/'+commit+'/'+PREFIX,'mainUnchanged':current,'issue34':'open'}))
