from pathlib import Path
p=Path(__file__).resolve().parent/'comparison/capture_probe.py';s=p.read_text(encoding='utf-8')
a=s.index('   # The inherited probe observes');b=s.index("   transaction=await frame.evaluate",a)
block=s[a:b]
block=block.replace('const q=window.__L1QAProbe,records=[],before=window.SalahMoonRuntime.state;','const q=window.__L1QAProbe,records=[],before=window.SalahMoonRuntime.state,adoptionsBefore=q.surfaceAdoptions;')
block=block.replace('return {records,before,after,lastTwoEqual:','return {records,before,after,adoptionsBefore,adoptionsAfter:q.surfaceAdoptions,lastTwoEqual:')
block=block.replace('before.renders===after.renders&&after.current===true','before.renders===after.renders&&adoptionsBefore===q.surfaceAdoptions&&after.current===true&&before.phasePrecision.maximumPositionErrorDevicePixels===.0416&&after.phasePrecision.maximumPositionErrorDevicePixels===.0416&&before.phasePrecision.targetPositionErrorBound<=.0416&&after.phasePrecision.targetPositionErrorBound<=.0416')
s=s[:a]+s[b:];needle="   report['leaseBeforeArm']=root_lease(a);armed=";assert s.count(needle)==1;s=s.replace(needle,block+needle,1)
p.write_text(s,encoding='utf-8',newline='\n')
print('Observer preparation precedes a fresh current sky admission; exact original phase bound retained')
